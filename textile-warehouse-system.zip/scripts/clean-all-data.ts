/**
 * تنظيف جميع البيانات من النظام
 * Clean all data from the system
 */

/**
 * تنظيف جميع البيانات المخزنة
 */
function cleanAllData(): void {
  console.log("🧹 بدء تنظيف جميع البيانات من النظام...")

  // قائمة جميع مفاتيح البيانات في النظام
  const dataKeys = [
    "customers",
    "materials",
    "users",
    "inventory",
    "productionOrders",
    "invoices",
    "deliveryStatements",
    "separations",
    "dyeingMaterials",
    "materialIssuances",
    "openingBalances",
    "settings",
    "activityLog",
    "processingInvoices",
    "balances",
    "reports",
    "financialData",
    "materialsCosts",
    "productionCosts",
  ]

  let cleanedCount = 0

  // تنظيف كل مفتاح
  dataKeys.forEach((key) => {
    try {
      if (typeof localStorage !== "undefined") {
        localStorage.removeItem(key)
        console.log(`✅ تم تنظيف: ${key}`)
        cleanedCount++
      }
    } catch (error) {
      console.log(`⚠️ تعذر تنظيف ${key}: ${error.message}`)
    }
  })

  // تنظيف جميع البيانات المخزنة في localStorage
  try {
    if (typeof localStorage !== "undefined") {
      // الحصول على جميع المفاتيح
      const allKeys = Object.keys(localStorage)

      // تنظيف المفاتيح المتعلقة بالنظام
      allKeys.forEach((key) => {
        if (
          key.startsWith("textile_") ||
          key.startsWith("warehouse_") ||
          key.startsWith("inventory_") ||
          key.startsWith("production_") ||
          key.startsWith("dyeing_") ||
          key.includes("customer") ||
          key.includes("material") ||
          key.includes("order") ||
          key.includes("invoice") ||
          key.includes("user") ||
          key.includes("auth")
        ) {
          localStorage.removeItem(key)
          console.log(`✅ تم تنظيف مفتاح إضافي: ${key}`)
          cleanedCount++
        }
      })
    }
  } catch (error) {
    console.log(`⚠️ خطأ في تنظيف localStorage: ${error.message}`)
  }

  // تنظيف sessionStorage أيضاً
  try {
    if (typeof sessionStorage !== "undefined") {
      sessionStorage.clear()
      console.log("✅ تم تنظيف sessionStorage")
    }
  } catch (error) {
    console.log(`⚠️ خطأ في تنظيف sessionStorage: ${error.message}`)
  }

  console.log(`\n🎉 تم تنظيف ${cleanedCount} عنصر من البيانات`)
  console.log("✨ النظام الآن نظيف وجاهز للاستخدام بدون أي بيانات مدخلة مسبقاً")

  // إنشاء مستخدم المدير الافتراضي فقط
  createDefaultAdmin()
}

/**
 * إنشاء مستخدم المدير الافتراضي
 */
function createDefaultAdmin(): void {
  console.log("\n👤 إنشاء مستخدم المدير الافتراضي...")

  const defaultAdmin = {
    id: 1,
    username: "admin",
    password: "admin123", // في النظام الحقيقي يجب تشفيرها
    fullName: "مدير النظام",
    role: "admin",
    permissions: { all: true },
    active: true,
    lastLogin: "لم يسجل دخول بعد",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }

  try {
    if (typeof localStorage !== "undefined") {
      localStorage.setItem("users", JSON.stringify([defaultAdmin]))
      console.log("✅ تم إنشاء مستخدم المدير الافتراضي")
      console.log("📝 بيانات تسجيل الدخول:")
      console.log("   اسم المستخدم: admin")
      console.log("   كلمة المرور: admin123")
    }
  } catch (error) {
    console.log(`⚠️ خطأ في إنشاء المستخدم الافتراضي: ${error.message}`)
  }
}

/**
 * التحقق من حالة النظام بعد التنظيف
 */
function verifyCleanState(): void {
  console.log("\n🔍 التحقق من حالة النظام بعد التنظيف...")

  const dataKeys = [
    "customers",
    "materials",
    "inventory",
    "productionOrders",
    "invoices",
    "deliveryStatements",
    "separations",
    "dyeingMaterials",
    "materialIssuances",
  ]

  let isEmpty = true

  dataKeys.forEach((key) => {
    try {
      if (typeof localStorage !== "undefined") {
        const data = localStorage.getItem(key)
        if (data && data !== "null" && data !== "[]") {
          console.log(`⚠️ ${key} لا يزال يحتوي على بيانات: ${data.substring(0, 50)}...`)
          isEmpty = false
        } else {
          console.log(`✅ ${key} فارغ`)
        }
      }
    } catch (error) {
      console.log(`⚠️ خطأ في فحص ${key}: ${error.message}`)
    }
  })

  if (isEmpty) {
    console.log("\n🎉 تأكيد: النظام نظيف تماماً!")
  } else {
    console.log("\n⚠️ تحذير: لا يزال هناك بعض البيانات في النظام")
  }

  // فحص المستخدمين
  try {
    if (typeof localStorage !== "undefined") {
      const users = localStorage.getItem("users")
      if (users) {
        const parsedUsers = JSON.parse(users)
        console.log(`👥 عدد المستخدمين: ${parsedUsers.length}`)
        if (parsedUsers.length === 1 && parsedUsers[0].username === "admin") {
          console.log("✅ يوجد مستخدم المدير الافتراضي فقط")
        }
      }
    }
  } catch (error) {
    console.log(`⚠️ خطأ في فحص المستخدمين: ${error.message}`)
  }
}

/**
 * إنشاء تقرير حالة النظام
 */
function generateSystemStatusReport(): void {
  console.log("\n📊 تقرير حالة النظام:")
  console.log("=".repeat(50))

  const report = {
    timestamp: new Date().toISOString(),
    status: "CLEAN",
    dataStatus: {
      customers: 0,
      materials: 0,
      inventory: 0,
      productionOrders: 0,
      invoices: 0,
      users: 1, // المدير الافتراضي فقط
      dyeingMaterials: 0,
      materialIssuances: 0,
    },
    systemInfo: {
      version: "1.0.0",
      lastCleaned: new Date().toISOString(),
      defaultAdminCreated: true,
    },
    recommendations: [
      "النظام جاهز للاستخدام",
      "يمكن البدء بإدخال بيانات العملاء والأصناف",
      "تأكد من تغيير كلمة مرور المدير الافتراضي",
      "قم بإنشاء نسخة احتياطية دورية",
    ],
  }

  console.log(JSON.stringify(report, null, 2))
  console.log("\n✨ النظام جاهز للاستخدام!")
}

// تشغيل عملية التنظيف
console.log("🚀 بدء عملية تنظيف النظام...")
cleanAllData()
verifyCleanState()
generateSystemStatusReport()

console.log("\n🏁 انتهت عملية التنظيف بنجاح!")
console.log("💡 يمكنك الآن استخدام النظام بدون أي بيانات مدخلة مسبقاً")
