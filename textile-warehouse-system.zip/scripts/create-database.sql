-- إنشاء قاعدة البيانات
CREATE DATABASE IF NOT EXISTS textile_warehouse CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE textile_warehouse;

-- جدول المستخدمين
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    role ENUM('admin', 'user') DEFAULT 'user',
    permissions JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- جدول العملاء
CREATE TABLE customers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- جدول الأصناف/الخامات
CREATE TABLE materials (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    unit ENUM('kg', 'meter', 'piece') NOT NULL,
    category VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- جدول حركات المخزون
CREATE TABLE inventory_movements (
    id INT PRIMARY KEY AUTO_INCREMENT,
    permit_number VARCHAR(50) NOT NULL,
    movement_type ENUM('incoming', 'outgoing', 'return') NOT NULL,
    date DATE NOT NULL,
    customer_id INT,
    material_id INT,
    quantity DECIMAL(10,2) NOT NULL,
    rolls_count INT,
    customer_permit_number VARCHAR(50),
    notes TEXT,
    user_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id),
    FOREIGN KEY (material_id) REFERENCES materials(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- جدول أوامر التشغيل
CREATE TABLE production_orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_number VARCHAR(50) UNIQUE NOT NULL,
    permit_number VARCHAR(50) NOT NULL,
    customer_id INT,
    material_id INT,
    quantity DECIMAL(10,2) NOT NULL,
    status ENUM('in_production', 'completed') DEFAULT 'in_production',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    FOREIGN KEY (customer_id) REFERENCES customers(id),
    FOREIGN KEY (material_id) REFERENCES materials(id)
);

-- جدول فواتير التجهيز
CREATE TABLE processing_invoices (
    id INT PRIMARY KEY AUTO_INCREMENT,
    customer_id INT,
    production_order_id INT,
    color VARCHAR(50),
    quantity DECIMAL(10,2) NOT NULL,
    rolls_count INT,
    separations INT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id),
    FOREIGN KEY (production_order_id) REFERENCES production_orders(id)
);

-- جدول بيان تسليم الجاهز
CREATE TABLE delivery_statements (
    id INT PRIMARY KEY AUTO_INCREMENT,
    statement_number INT AUTO_INCREMENT UNIQUE,
    customer_id INT,
    material_id INT,
    ready_quantity DECIMAL(10,2) NOT NULL,
    rolls_count INT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id),
    FOREIGN KEY (material_id) REFERENCES materials(id)
);

-- جدول سجل النشاطات
CREATE TABLE activity_log (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    action VARCHAR(50) NOT NULL,
    table_name VARCHAR(50) NOT NULL,
    record_id INT,
    old_values JSON,
    new_values JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- إدراج المستخدم الافتراضي
INSERT INTO users (username, password, full_name, role, permissions) 
VALUES ('admin', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'مدير النظام', 'admin', '{"all": true}');
