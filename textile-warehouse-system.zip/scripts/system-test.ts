/**
 * اختبار شامل لجميع وظائف النظام
 *
 * هذا الملف يحتوي على اختبارات لجميع الوظائف الرئيسية في النظام
 * يمكن تشغيله للتأكد من أن جميع الوظائف تعمل بشكل صحيح
 */

import { dataManager } from "@/lib/data-manager"

// بيانات اختبار
const testCustomers = [
  { id: 101, code: "TC001", name: "عميل اختبار 1", createdAt: "2024-06-01" },
  { id: 102, code: "TC002", name: "عميل اختبار 2", createdAt: "2024-06-02" },
]

const testMaterials = [
  { id: 201, code: "TM001", name: "صنف اختبار 1", unit: "كجم", createdAt: "2024-06-01" },
  { id: 202, code: "TM002", name: "صنف اختبار 2", unit: "متر", createdAt: "2024-06-02" },
]

const testInventory = [
  {
    id: 301,
    customerId: 101,
    materialId: 201,
    quantity: 100,
    type: "incoming",
    date: "2024-06-05",
    notes: "وارد اختبار",
  },
  {
    id: 302,
    customerId: 101,
    materialId: 201,
    quantity: 50,
    type: "outgoing",
    date: "2024-06-06",
    notes: "منصرف اختبار",
  },
  {
    id: 303,
    customerId: 101,
    materialId: 201,
    quantity: 20,
    type: "returned",
    date: "2024-06-07",
    notes: "مرتجع اختبار",
  },
  {
    id: 304,
    customerId: 101,
    materialId: 201,
    quantity: 30,
    type: "delivered",
    date: "2024-06-08",
    notes: "تسليم اختبار",
  },
]

const testProductionOrders = [
  {
    id: 401,
    orderNumber: "PO-TEST-001",
    customerId: 101,
    customerName: "عميل اختبار 1",
    materialId: 201,
    materialName: "صنف اختبار 1",
    quantity: 50,
    unit: "كجم",
    status: "in_production",
    createdAt: "2024-06-10",
  },
  {
    id: 402,
    orderNumber: "PO-TEST-002",
    customerId: 101,
    customerName: "عميل اختبار 1",
    materialId: 201,
    materialName: "صنف اختبار 1",
    quantity: 30,
    unit: "كجم",
    status: "completed",
    createdAt: "2024-06-11",
  },
]

const testSeparations = [
  {
    id: 501,
    separationNumber: "SEP-TEST-001",
    customerId: 101,
    customerName: "عميل اختبار 1",
    materialId: 201,
    materialName: "صنف اختبار 1",
    unit: "كجم",
    separatedQuantity: 5,
    rollsCount: 1,
    separationReason: "عيوب في الصباغة",
    status: "separated",
    createdAt: "2024-06-12",
  },
]

const testDeliveryStatements = [
  {
    id: 601,
    statementNumber: 1001,
    date: "2024-06-15",
    customerId: 101,
    customerName: "عميل اختبار 1",
    items: [
      {
        id: 701,
        productionOrderId: 402,
        productionOrderNumber: "PO-TEST-002",
        materialId: 201,
        materialName: "صنف اختبار 1",
        color: "أزرق",
        originalQuantity: 30,
        readyQuantityKg: 25,
        readyQuantityMeter: 50,
        rollsCount: 2,
        unit: "كجم",
        notes: "تم التجهيز بنجاح",
      },
    ],
    notes: "بيان تسليم للعميل",
    createdAt: "2024-06-15",
    status: "pending",
  },
]

// وظائف الاختبار

/**
 * اختبار حساب الرصيد النهائي
 * يتأكد من أن الرصيد النهائي يتم حسابه بشكل صحيح
 */
export function testBalanceCalculation() {
  console.log("بدء اختبار حساب الرصيد النهائي...")

  try {
    // حالة اختبار 1: رصيد بداية المدة + الوارد - المنصرف + المرتجع - المسلم
    const openingBalance = 100
    const incoming = 200
    const outgoing = 80
    const returned = 30
    const delivered = 50
    const separatedQuantity = 10
    const readyQuantity = 20

    // الحساب المتوقع: 100 + 200 - 80 + 30 = 250 (بدون خصم المسلم)
    const expectedFinalBalance = openingBalance + incoming - outgoing + returned

    // حساب الرصيد النهائي
    const calculatedFinalBalance = calculateFinalBalance(
      openingBalance,
      incoming,
      outgoing,
      returned,
      delivered,
      separatedQuantity,
      readyQuantity,
    )

    // التحقق من صحة الحساب
    const isCorrect = calculatedFinalBalance === expectedFinalBalance

    console.log(`رصيد بداية المدة: ${openingBalance}`)
    console.log(`الوارد: ${incoming}`)
    console.log(`المنصرف: ${outgoing}`)
    console.log(`المرتجع: ${returned}`)
    console.log(`المسلم: ${delivered}`)
    console.log(`المنفصلات: ${separatedQuantity}`)
    console.log(`الكمية الجاهزة: ${readyQuantity}`)
    console.log(`الرصيد النهائي المتوقع: ${expectedFinalBalance}`)
    console.log(`الرصيد النهائي المحسوب: ${calculatedFinalBalance}`)
    console.log(`نتيجة الاختبار: ${isCorrect ? "ناجح ✅" : "فاشل ❌"}`)

    return {
      success: isCorrect,
      message: isCorrect
        ? "تم حساب الرصيد النهائي بشكل صحيح"
        : `خطأ في حساب الرصيد النهائي. المتوقع: ${expectedFinalBalance}، المحسوب: ${calculatedFinalBalance}`,
      expected: expectedFinalBalance,
      calculated: calculatedFinalBalance,
    }
  } catch (error) {
    console.error("خطأ في اختبار حساب الرصيد النهائي:", error)
    return {
      success: false,
      message: "حدث خطأ أثناء اختبار حساب الرصيد النهائي: " + error.message,
    }
  }
}

/**
 * حساب الرصيد النهائي
 * الرصيد النهائي = رصيد بداية المدة + الوارد - المنصرف + المرتجع - المسلم
 */
function calculateFinalBalance(
  openingBalance: number,
  incoming: number,
  outgoing: number,
  returned: number,
  delivered: number,
  separatedQuantity: number,
  readyQuantity: number,
): number {
  // الرصيد النهائي = رصيد بداية المدة + الوارد - المنصرف + المرتجع - المسلم
  return openingBalance + incoming - outgoing + returned
}

/**
 * اختبار إدارة العملاء
 */
export async function testCustomerManagement() {
  console.log("بدء اختبار إدارة العملاء...")

  try {
    // حفظ البيانات الحالية
    const originalCustomers = dataManager.getCustomers()

    // إضافة عملاء اختبار
    dataManager.setCustomers(testCustomers)

    // التحقق من إضافة العملاء
    const customers = dataManager.getCustomers()
    const addSuccess =
      customers.length === testCustomers.length &&
      customers.every((c, i) => c.id === testCustomers[i].id && c.name === testCustomers[i].name)

    // استعادة البيانات الأصلية
    dataManager.setCustomers(originalCustomers)

    console.log(`نتيجة اختبار إضافة العملاء: ${addSuccess ? "ناجح ✅" : "فاشل ❌"}`)

    return {
      success: addSuccess,
      message: addSuccess ? "تم إدارة العملاء بنجاح" : "فشل في إدارة العملاء",
    }
  } catch (error) {
    console.error("خطأ في اختبار إدارة العملاء:", error)
    return {
      success: false,
      message: "حدث خطأ أثناء اختبار إدارة العملاء: " + error.message,
    }
  }
}

/**
 * اختبار إدارة الأصناف
 */
export async function testMaterialManagement() {
  console.log("بدء اختبار إدارة الأصناف...")

  try {
    // حفظ البيانات الحالية
    const originalMaterials = dataManager.getMaterials()

    // إضافة أصناف اختبار
    dataManager.setMaterials(testMaterials)

    // التحقق من إضافة الأصناف
    const materials = dataManager.getMaterials()
    const addSuccess =
      materials.length === testMaterials.length &&
      materials.every((m, i) => m.id === testMaterials[i].id && m.name === testMaterials[i].name)

    // استعادة البيانات الأصلية
    dataManager.setMaterials(originalMaterials)

    console.log(`نتيجة اختبار إدارة الأصناف: ${addSuccess ? "ناجح ✅" : "فاشل ❌"}`)

    return {
      success: addSuccess,
      message: addSuccess ? "تم إدارة الأصناف بنجاح" : "فشل في إدارة الأصناف",
    }
  } catch (error) {
    console.error("خطأ في اختبار إدارة الأصناف:", error)
    return {
      success: false,
      message: "حدث خطأ أثناء اختبار إدارة الأصناف: " + error.message,
    }
  }
}

/**
 * اختبار إدارة المخزون
 */
export async function testInventoryManagement() {
  console.log("بدء اختبار إدارة المخزون...")

  try {
    // حفظ البيانات الحالية
    const originalInventory = dataManager.getData("inventory", [])

    // إضافة مخزون اختبار
    dataManager.setData("inventory", testInventory)

    // التحقق من إضافة المخزون
    const inventory = dataManager.getData("inventory", [])
    const addSuccess =
      inventory.length === testInventory.length &&
      inventory.every((item, i) => item.id === testInventory[i].id && item.quantity === testInventory[i].quantity)

    // استعادة البيانات الأصلية
    dataManager.setData("inventory", originalInventory)

    console.log(`نتيجة اختبار إدارة المخزون: ${addSuccess ? "ناجح ✅" : "فاشل ❌"}`)

    return {
      success: addSuccess,
      message: addSuccess ? "تم إدارة المخزون بنجاح" : "فشل في إدارة المخزون",
    }
  } catch (error) {
    console.error("خطأ في اختبار إدارة المخزون:", error)
    return {
      success: false,
      message: "حدث خطأ أثناء اختبار إدارة المخزون: " + error.message,
    }
  }
}

/**
 * اختبار إدارة أوامر التشغيل
 */
export async function testProductionOrderManagement() {
  console.log("بدء اختبار إدارة أوامر التشغيل...")

  try {
    // حفظ البيانات الحالية
    const originalOrders = dataManager.getData("productionOrders", [])

    // إضافة أوامر تشغيل اختبار
    dataManager.setData("productionOrders", testProductionOrders)

    // التحقق من إضافة أوامر التشغيل
    const orders = dataManager.getData("productionOrders", [])
    const addSuccess =
      orders.length === testProductionOrders.length &&
      orders.every(
        (o, i) => o.id === testProductionOrders[i].id && o.orderNumber === testProductionOrders[i].orderNumber,
      )

    // استعادة البيانات الأصلية
    dataManager.setData("productionOrders", originalOrders)

    console.log(`نتيجة اختبار إدارة أوامر التشغيل: ${addSuccess ? "ناجح ✅" : "فاشل ❌"}`)

    return {
      success: addSuccess,
      message: addSuccess ? "تم إدارة أوامر التشغيل بنجاح" : "فشل في إدارة أوامر التشغيل",
    }
  } catch (error) {
    console.error("خطأ في اختبار إدارة أوامر التشغيل:", error)
    return {
      success: false,
      message: "حدث خطأ أثناء اختبار إدارة أوامر التشغيل: " + error.message,
    }
  }
}

/**
 * اختبار إدارة المنفصلات
 */
export async function testSeparationsManagement() {
  console.log("بدء اختبار إدارة المنفصلات...")

  try {
    // حفظ البيانات الحالية
    const originalSeparations = dataManager.getData("separations", [])

    // إضافة منفصلات اختبار
    dataManager.setData("separations", testSeparations)

    // التحقق من إضافة المنفصلات
    const separations = dataManager.getData("separations", [])
    const addSuccess =
      separations.length === testSeparations.length &&
      separations.every(
        (s, i) => s.id === testSeparations[i].id && s.separationNumber === testSeparations[i].separationNumber,
      )

    // استعادة البيانات الأصلية
    dataManager.setData("separations", originalSeparations)

    console.log(`نتيجة اختبار إدارة المنفصلات: ${addSuccess ? "ناجح ✅" : "فاشل ❌"}`)

    return {
      success: addSuccess,
      message: addSuccess ? "تم إدارة المنفصلات بنجاح" : "فشل في إدارة المنفصلات",
    }
  } catch (error) {
    console.error("خطأ في اختبار إدارة المنفصلات:", error)
    return {
      success: false,
      message: "حدث خطأ أثناء اختبار إدارة المنفصلات: " + error.message,
    }
  }
}

/**
 * اختبار إدارة بيانات التسليم
 */
export async function testDeliveryStatementManagement() {
  console.log("بدء اختبار إدارة بيانات التسليم...")

  try {
    // حفظ البيانات الحالية
    const originalStatements = dataManager.getData("deliveryStatements", [])

    // إضافة بيانات تسليم اختبار
    dataManager.setData("deliveryStatements", testDeliveryStatements)

    // التحقق من إضافة بيانات التسليم
    const statements = dataManager.getData("deliveryStatements", [])
    const addSuccess =
      statements.length === testDeliveryStatements.length &&
      statements.every(
        (s, i) =>
          s.id === testDeliveryStatements[i].id && s.statementNumber === testDeliveryStatements[i].statementNumber,
      )

    // استعادة البيانات الأصلية
    dataManager.setData("deliveryStatements", originalStatements)

    console.log(`نتيجة اختبار إدارة بيانات التسليم: ${addSuccess ? "ناجح ✅" : "فاشل ❌"}`)

    return {
      success: addSuccess,
      message: addSuccess ? "تم إدارة بيانات التسليم بنجاح" : "فشل في إدارة بيانات التسليم",
    }
  } catch (error) {
    console.error("خطأ في اختبار إدارة بيانات التسليم:", error)
    return {
      success: false,
      message: "حدث خطأ أثناء اختبار إدارة بيانات التسليم: " + error.message,
    }
  }
}

/**
 * اختبار تصدير واستيراد البيانات
 */
export async function testDataExportImport() {
  console.log("بدء اختبار تصدير واستيراد البيانات...")

  try {
    // حفظ البيانات الحالية
    const originalCustomers = dataManager.getCustomers()
    const originalMaterials = dataManager.getMaterials()

    // تعيين بيانات الاختبار
    dataManager.setCustomers(testCustomers)
    dataManager.setMaterials(testMaterials)

    // تصدير البيانات
    const exportResult = dataManager.exportAllData()

    // استعادة البيانات الأصلية
    dataManager.setCustomers(originalCustomers)
    dataManager.setMaterials(originalMaterials)

    console.log(`نتيجة اختبار التصدير والاستيراد: ${exportResult.success ? "ناجح ✅" : "فاشل ❌"}`)

    return {
      success: exportResult.success,
      message: exportResult.success
        ? "تم تصدير واستيراد البيانات بنجاح"
        : "فشل في تصدير واستيراد البيانات: " + exportResult.message,
    }
  } catch (error) {
    console.error("خطأ في اختبار تصدير واستيراد البيانات:", error)
    return {
      success: false,
      message: "حدث خطأ أثناء اختبار تصدير واستيراد البيانات: " + error.message,
    }
  }
}

/**
 * اختبار شامل لجميع وظائف النظام
 */
export async function runFullSystemTest() {
  console.log("بدء الاختبار الشامل لجميع وظائف النظام...")

  const results = {
    balanceCalculation: await testBalanceCalculation(),
    customerManagement: await testCustomerManagement(),
    materialManagement: await testMaterialManagement(),
    inventoryManagement: await testInventoryManagement(),
    productionOrderManagement: await testProductionOrderManagement(),
    separationsManagement: await testSeparationsManagement(),
    deliveryStatementManagement: await testDeliveryStatementManagement(),
    dataExportImport: await testDataExportImport(),
  }

  // حساب نتيجة الاختبار الشامل
  const totalTests = Object.keys(results).length
  const passedTests = Object.values(results).filter((result: any) => result.success).length
  const success = passedTests === totalTests

  console.log("نتائج الاختبار الشامل:")
  Object.entries(results).forEach(([testName, result]: [string, any]) => {
    console.log(`- ${testName}: ${result.success ? "ناجح ✅" : "فاشل ❌"} - ${result.message}`)
  })
  console.log(`الإجمالي: ${passedTests}/${totalTests} (${((passedTests / totalTests) * 100).toFixed(2)}%)`)

  return {
    success,
    passedTests,
    totalTests,
    results,
    message: success ? "تم اجتياز جميع الاختبارات بنجاح" : `تم اجتياز ${passedTests} من أصل ${totalTests} اختبار`,
  }
}
