-- إضافة جدول منفصلات الإنتاج
CREATE TABLE production_separations (
    id INT PRIMARY KEY AUTO_INCREMENT,
    separation_number VARCHAR(50) UNIQUE NOT NULL,
    production_order_id INT,
    material_id INT,
    customer_id INT,
    separated_quantity DECIMAL(10,2) NOT NULL,
    rolls_count INT,
    separation_reason VARCHAR(255),
    separation_date DATE NOT NULL,
    status ENUM('separated', 'reprocessed') DEFAULT 'separated',
    notes TEXT,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    reprocessed_at TIMESTAMP NULL,
    new_production_order_id INT NULL,
    FOREIGN KEY (production_order_id) REFERENCES production_orders(id),
    FOREIGN KEY (material_id) REFERENCES materials(id),
    FOREIGN KEY (customer_id) REFERENCES customers(id),
    FOREIGN KEY (created_by) REFERENCES users(id),
    FOREIGN KEY (new_production_order_id) REFERENCES production_orders(id)
);

-- تعديل جدول أوامر التشغيل لإضافة حقول المنفصلات
ALTER TABLE production_orders 
ADD COLUMN separated_quantity DECIMAL(10,2) DEFAULT 0,
ADD COLUMN final_quantity DECIMAL(10,2) DEFAULT 0,
ADD COLUMN has_separations BOOLEAN DEFAULT FALSE;

-- تعديل جدول فواتير التجهيز لإضافة معلومات المنفصلات
ALTER TABLE processing_invoices 
ADD COLUMN separated_quantity DECIMAL(10,2) DEFAULT 0,
ADD COLUMN separation_notes TEXT;

-- إدراج بيانات تجريبية للمنفصلات
INSERT INTO production_separations (
    separation_number, production_order_id, material_id, customer_id, 
    separated_quantity, rolls_count, separation_reason, separation_date, 
    notes, created_by
) VALUES 
('SEP001', 1, 1, 1, 25.5, 1, 'عيوب في الصباغة', '2024-03-10', 'لون غير متطابق مع المطلوب', 1),
('SEP002', 2, 2, 2, 15.0, 1, 'عيوب في النسيج', '2024-03-12', 'خيوط مقطوعة', 1),
('SEP003', 3, 3, 3, 30.0, 2, 'عيوب في الصباغة', '2024-03-14', 'درجة لون فاتحة', 1);

-- تحديث أوامر التشغيل الموجودة
UPDATE production_orders SET 
    separated_quantity = 25.5,
    final_quantity = quantity - 25.5,
    has_separations = TRUE
WHERE id = 1;

UPDATE production_orders SET 
    separated_quantity = 15.0,
    final_quantity = quantity - 15.0,
    has_separations = TRUE
WHERE id = 2;

UPDATE production_orders SET 
    separated_quantity = 30.0,
    final_quantity = quantity - 30.0,
    has_separations = TRUE
WHERE id = 3;
