-- إضافة حقول التكلفة إلى جدول أوامر التشغيل
ALTER TABLE production_orders 
ADD COLUMN dyeing_materials_cost DECIMAL(10,2) DEFAULT 0 COMMENT 'تكلفة مواد الصباغة',
ADD COLUMN processing_materials_cost DECIMAL(10,2) DEFAULT 0 COMMENT 'تكلفة مواد التجهيز',
ADD COLUMN total_materials_cost DECIMAL(10,2) DEFAULT 0 COMMENT 'إجمالي تكلفة المواد';

-- إنشاء جدول أنواع مواد الصباغة
CREATE TABLE dyeing_materials (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL COMMENT 'اسم المادة',
    unit VARCHAR(20) NOT NULL COMMENT 'وحدة القياس',
    unit_cost DECIMAL(10,2) NOT NULL COMMENT 'تكلفة الوحدة',
    category ENUM('dye', 'chemical', 'auxiliary') DEFAULT 'dye' COMMENT 'نوع المادة',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- إنشاء جدول أنواع مواد التجهيز
CREATE TABLE processing_materials (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL COMMENT 'اسم المادة',
    unit VARCHAR(20) NOT NULL COMMENT 'وحدة القياس',
    unit_cost DECIMAL(10,2) NOT NULL COMMENT 'تكلفة الوحدة',
    category ENUM('softener', 'stiffener', 'waterproof', 'other') DEFAULT 'other' COMMENT 'نوع المادة',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- إنشاء جدول تفاصيل مواد الصباغة المستخدمة في كل أمر
CREATE TABLE production_order_dyeing_materials (
    id INT PRIMARY KEY AUTO_INCREMENT,
    production_order_id INT NOT NULL,
    dyeing_material_id INT NOT NULL,
    quantity DECIMAL(10,2) NOT NULL COMMENT 'الكمية المستخدمة',
    unit_cost DECIMAL(10,2) NOT NULL COMMENT 'تكلفة الوحدة وقت الاستخدام',
    total_cost DECIMAL(10,2) NOT NULL COMMENT 'إجمالي التكلفة',
    notes TEXT COMMENT 'ملاحظات',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (production_order_id) REFERENCES production_orders(id) ON DELETE CASCADE,
    FOREIGN KEY (dyeing_material_id) REFERENCES dyeing_materials(id)
);

-- إنشاء جدول تفاصيل مواد التجهيز المستخدمة في كل أمر
CREATE TABLE production_order_processing_materials (
    id INT PRIMARY KEY AUTO_INCREMENT,
    production_order_id INT NOT NULL,
    processing_material_id INT NOT NULL,
    quantity DECIMAL(10,2) NOT NULL COMMENT 'الكمية المستخدمة',
    unit_cost DECIMAL(10,2) NOT NULL COMMENT 'تكلفة الوحدة وقت الاستخدام',
    total_cost DECIMAL(10,2) NOT NULL COMMENT 'إجمالي التكلفة',
    notes TEXT COMMENT 'ملاحظات',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (production_order_id) REFERENCES production_orders(id) ON DELETE CASCADE,
    FOREIGN KEY (processing_material_id) REFERENCES processing_materials(id)
);

-- إدراج بيانات تجريبية لمواد الصباغة
INSERT INTO dyeing_materials (name, unit, unit_cost, category) VALUES
('صبغة أزرق مباشر', 'كجم', 45.50, 'dye'),
('صبغة أحمر تفاعلي', 'كجم', 52.00, 'dye'),
('صبغة أخضر حمضي', 'كجم', 48.75, 'dye'),
('ملح الطعام', 'كجم', 2.50, 'chemical'),
('كربونات الصوديوم', 'كجم', 3.20, 'chemical'),
('حمض الخليك', 'لتر', 8.90, 'chemical'),
('مادة مثبتة للون', 'لتر', 15.60, 'auxiliary'),
('مادة منظفة', 'كجم', 12.30, 'auxiliary');

-- إدراج بيانات تجريبية لمواد التجهيز
INSERT INTO processing_materials (name, unit, unit_cost, category) VALUES
('مادة منعمة سيليكون', 'لتر', 25.80, 'softener'),
('مادة منعمة طبيعية', 'لتر', 18.50, 'softener'),
('مادة مقوية للنسيج', 'كجم', 22.40, 'stiffener'),
('مادة مقاومة للماء', 'لتر', 35.70, 'waterproof'),
('مادة مضادة للكهرباء الساكنة', 'لتر', 28.90, 'other'),
('مادة مضادة للبكتيريا', 'لتر', 42.15, 'other'),
('مادة مثبتة للشكل', 'كجم', 19.80, 'stiffener'),
('مادة عطرية', 'لتر', 65.25, 'other');

-- إدراج بيانات تجريبية لمواد الصباغة المستخدمة
INSERT INTO production_order_dyeing_materials (production_order_id, dyeing_material_id, quantity, unit_cost, total_cost, notes) VALUES
-- أمر التشغيل الأول (PO001)
(1, 1, 2.5, 45.50, 113.75, 'صباغة باللون الأزرق'),
(1, 4, 5.0, 2.50, 12.50, 'ملح للتثبيت'),
(1, 5, 1.2, 3.20, 3.84, 'كربونات للتفاعل'),
(1, 7, 0.8, 15.60, 12.48, 'مثبت اللون'),

-- أمر التشغيل الثاني (PO002)
(2, 2, 1.8, 52.00, 93.60, 'صباغة باللون الأحمر'),
(2, 4, 3.5, 2.50, 8.75, 'ملح للتثبيت'),
(2, 6, 0.5, 8.90, 4.45, 'حمض للتفاعل'),
(2, 8, 1.0, 12.30, 12.30, 'مادة منظفة'),

-- أمر التشغيل الثالث (PO003)
(3, 3, 3.2, 48.75, 156.00, 'صباغة باللون الأخضر'),
(3, 4, 6.0, 2.50, 15.00, 'ملح للتثبيت'),
(3, 5, 1.5, 3.20, 4.80, 'كربونات للتفاعل'),
(3, 7, 1.0, 15.60, 15.60, 'مثبت اللون');

-- إدراج بيانات تجريبية لمواد التجهيز المستخدمة
INSERT INTO production_order_processing_materials (production_order_id, processing_material_id, quantity, unit_cost, total_cost, notes) VALUES
-- أمر التشغيل الأول (PO001)
(1, 1, 1.5, 25.80, 38.70, 'تنعيم بالسيليكون'),
(1, 5, 0.8, 28.90, 23.12, 'مضاد للكهرباء الساكنة'),
(1, 8, 0.3, 65.25, 19.58, 'إضافة عطر خفيف'),

-- أمر التشغيل الثاني (PO002)
(2, 2, 1.2, 18.50, 22.20, 'تنعيم طبيعي'),
(2, 4, 0.9, 35.70, 32.13, 'مقاومة للماء'),
(2, 6, 0.7, 42.15, 29.51, 'مضاد للبكتيريا'),

-- أمر التشغيل الثالث (PO003)
(3, 3, 2.0, 22.40, 44.80, 'تقوية النسيج'),
(3, 7, 1.8, 19.80, 35.64, 'تثبيت الشكل'),
(3, 1, 1.0, 25.80, 25.80, 'تنعيم نهائي');

-- تحديث تكاليف أوامر التشغيل الموجودة
UPDATE production_orders SET 
    dyeing_materials_cost = (
        SELECT COALESCE(SUM(total_cost), 0) 
        FROM production_order_dyeing_materials 
        WHERE production_order_id = production_orders.id
    ),
    processing_materials_cost = (
        SELECT COALESCE(SUM(total_cost), 0) 
        FROM production_order_processing_materials 
        WHERE production_order_id = production_orders.id
    );

-- تحديث إجمالي تكلفة المواد
UPDATE production_orders SET 
    total_materials_cost = dyeing_materials_cost + processing_materials_cost;

-- إنشاء مؤشرات لتحسين الأداء
CREATE INDEX idx_production_order_dyeing_materials_order_id ON production_order_dyeing_materials(production_order_id);
CREATE INDEX idx_production_order_processing_materials_order_id ON production_order_processing_materials(production_order_id);
CREATE INDEX idx_dyeing_materials_category ON dyeing_materials(category);
CREATE INDEX idx_processing_materials_category ON processing_materials(category);
