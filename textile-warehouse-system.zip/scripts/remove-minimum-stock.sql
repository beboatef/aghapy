-- إزالة عمود الحد الأدنى للمخزون من جدول المواد
ALTER TABLE materials DROP COLUMN IF EXISTS minimum_stock;

-- إزالة أي فهارس مرتبطة بالحد الأدنى
DROP INDEX IF EXISTS idx_materials_minimum_stock;

-- تحديث أي عروض (views) تستخدم الحد الأدنى
DROP VIEW IF EXISTS low_stock_materials;

-- إزالة أي جداول مؤقتة للحد الأدنى
DROP TABLE IF EXISTS minimum_stock_alerts;

-- تحديث تعليقات الجدول
COMMENT ON TABLE materials IS 'جدول المواد الخام والأصناف - تم إزالة الحد الأدنى للمخزون';
