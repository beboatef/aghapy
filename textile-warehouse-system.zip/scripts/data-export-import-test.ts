/**
 * اختبار وظائف استيراد وتصدير البيانات
 *
 * هذا الملف يحتوي على وظائف لاختبار عمليات استيراد وتصدير البيانات
 * يمكن استخدامه للتأكد من أن البيانات يتم حفظها واستعادتها بشكل صحيح
 */

import { dataManager } from "@/lib/data-manager"

// بيانات اختبار للعملاء
const testCustomers = [
  { id: 101, code: "TC001", name: "عميل اختبار 1", createdAt: "2024-06-01" },
  { id: 102, code: "TC002", name: "عميل اختبار 2", createdAt: "2024-06-02" },
]

// بيانات اختبار للأصناف
const testMaterials = [
  { id: 201, code: "TM001", name: "صنف اختبار 1", unit: "كجم", createdAt: "2024-06-01" },
  { id: 202, code: "TM002", name: "صنف اختبار 2", unit: "متر", createdAt: "2024-06-02" },
]

// بيانات اختبار للمخزون
const testInventory = [
  {
    id: 301,
    customerId: 101,
    materialId: 201,
    quantity: 100,
    type: "incoming",
    date: "2024-06-05",
    notes: "وارد اختبار",
  },
  {
    id: 302,
    customerId: 101,
    materialId: 201,
    quantity: 50,
    type: "outgoing",
    date: "2024-06-06",
    notes: "منصرف اختبار",
  },
]

/**
 * اختبار تصدير البيانات
 * يقوم بإنشاء بيانات اختبار وتصديرها
 */
export async function testExportData() {
  console.log("بدء اختبار تصدير البيانات...")

  try {
    // حفظ البيانات الحالية
    const originalCustomers = dataManager.getCustomers()
    const originalMaterials = dataManager.getMaterials()
    const originalInventory = dataManager.getData("inventory", [])

    // تعيين بيانات الاختبار
    dataManager.setCustomers(testCustomers)
    dataManager.setMaterials(testMaterials)
    dataManager.setData("inventory", testInventory)

    // تصدير البيانات
    const result = dataManager.exportAllData()

    // استعادة البيانات الأصلية
    dataManager.setCustomers(originalCustomers)
    dataManager.setMaterials(originalMaterials)
    dataManager.setData("inventory", originalInventory)

    console.log("نتيجة اختبار التصدير:", result)
    return result
  } catch (error) {
    console.error("خطأ في اختبار التصدير:", error)
    return { success: false, message: "حدث خطأ أثناء اختبار التصدير: " + error.message }
  }
}

/**
 * اختبار استيراد البيانات
 * يقوم بإنشاء ملف بيانات وهمي واستيراده
 */
export async function testImportData() {
  console.log("بدء اختبار استيراد البيانات...")

  try {
    // حفظ البيانات الحالية
    const originalCustomers = dataManager.getCustomers()
    const originalMaterials = dataManager.getMaterials()
    const originalInventory = dataManager.getData("inventory", [])

    // إنشاء بيانات اختبار للاستيراد
    const testData = {
      customers: testCustomers,
      materials: testMaterials,
      inventory: testInventory,
      users: dataManager.getUsers(),
      productionOrders: [],
      invoices: [],
      settings: {},
      exportDate: new Date().toISOString(),
      version: "1.0",
    }

    // تحويل البيانات إلى ملف
    const jsonString = JSON.stringify(testData)
    const blob = new Blob([jsonString], { type: "application/json" })
    const file = new File([blob], "test-import.json", { type: "application/json" })

    // استيراد البيانات
    const result = await dataManager.importData(file)

    // التحقق من نجاح الاستيراد
    if (result.success) {
      const importedCustomers = dataManager.getCustomers()
      const importedMaterials = dataManager.getMaterials()
      const importedInventory = dataManager.getData("inventory", [])

      console.log("البيانات المستوردة:", {
        customers: importedCustomers,
        materials: importedMaterials,
        inventory: importedInventory,
      })

      // استعادة البيانات الأصلية
      dataManager.setCustomers(originalCustomers)
      dataManager.setMaterials(originalMaterials)
      dataManager.setData("inventory", originalInventory)
    }

    console.log("نتيجة اختبار الاستيراد:", result)
    return result
  } catch (error) {
    console.error("خطأ في اختبار الاستيراد:", error)
    return { success: false, message: "حدث خطأ أثناء اختبار الاستيراد: " + error.message }
  }
}

/**
 * اختبار كامل لعمليات الاستيراد والتصدير
 */
export async function runFullTest() {
  console.log("بدء الاختبار الكامل لعمليات الاستيراد والتصدير...")

  const exportResult = await testExportData()
  console.log("نتيجة اختبار التصدير:", exportResult)

  const importResult = await testImportData()
  console.log("نتيجة اختبار الاستيراد:", importResult)

  return {
    export: exportResult,
    import: importResult,
    success: exportResult.success && importResult.success,
  }
}
