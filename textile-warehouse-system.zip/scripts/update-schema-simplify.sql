-- تحديث جدول المواد لإزالة حقل الفئة
ALTER TABLE materials DROP COLUMN category;

-- تحديث جدول العملاء لإزالة حقل الهاتف والعنوان
ALTER TABLE customers DROP COLUMN phone;
ALTER TABLE customers DROP COLUMN address;
