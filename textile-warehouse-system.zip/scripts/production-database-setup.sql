-- إعداد قاعدة البيانات للإنتاج
-- Production Database Setup

-- إنشاء قاعدة البيانات
CREATE DATABASE IF NOT EXISTS textile_warehouse_production 
CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE textile_warehouse_production;

-- جدول المستخدمين مع تشفير كلمات المرور
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE,
    phone VARCHAR(20),
    role ENUM('admin', 'manager', 'operator', 'viewer') DEFAULT 'operator',
    permissions JSON,
    is_active BOOLEAN DEFAULT TRUE,
    last_login TIMESTAMP NULL,
    failed_login_attempts INT DEFAULT 0,
    locked_until TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT,
    INDEX idx_username (username),
    INDEX idx_email (email),
    INDEX idx_role (role),
    INDEX idx_active (is_active)
);

-- جدول العملاء مع فهرسة محسنة
CREATE TABLE customers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    name_en VARCHAR(100),
    phone VARCHAR(20),
    email VARCHAR(100),
    address TEXT,
    city VARCHAR(50),
    country VARCHAR(50) DEFAULT 'Saudi Arabia',
    tax_number VARCHAR(50),
    credit_limit DECIMAL(15,2) DEFAULT 0,
    payment_terms INT DEFAULT 30,
    is_active BOOLEAN DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT,
    INDEX idx_code (code),
    INDEX idx_name (name),
    INDEX idx_active (is_active),
    INDEX idx_city (city),
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- جدول الأصناف/المواد مع تصنيف محسن
CREATE TABLE materials (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    name_en VARCHAR(100),
    description TEXT,
    unit ENUM('kg', 'meter', 'piece', 'liter', 'gram', 'yard') NOT NULL,
    category VARCHAR(50),
    subcategory VARCHAR(50),
    brand VARCHAR(50),
    color VARCHAR(50),
    weight DECIMAL(10,3),
    width DECIMAL(10,2),
    composition TEXT,
    minimum_stock DECIMAL(10,2) DEFAULT 0,
    maximum_stock DECIMAL(10,2) DEFAULT 0,
    reorder_point DECIMAL(10,2) DEFAULT 0,
    standard_cost DECIMAL(10,2) DEFAULT 0,
    selling_price DECIMAL(10,2) DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    barcode VARCHAR(100),
    qr_code TEXT,
    image_url VARCHAR(255),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT,
    INDEX idx_code (code),
    INDEX idx_name (name),
    INDEX idx_category (category),
    INDEX idx_active (is_active),
    INDEX idx_barcode (barcode),
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- جدول حركات المخزون مع تتبع مفصل
CREATE TABLE inventory_movements (
    id INT PRIMARY KEY AUTO_INCREMENT,
    permit_number VARCHAR(50) NOT NULL,
    movement_type ENUM('incoming', 'outgoing', 'returned', 'delivered', 'adjustment', 'transfer') NOT NULL,
    reference_type ENUM('purchase', 'sale', 'production', 'return', 'adjustment', 'transfer', 'opening_balance') NOT NULL,
    reference_id INT,
    date DATE NOT NULL,
    time TIME DEFAULT CURRENT_TIME,
    customer_id INT,
    material_id INT NOT NULL,
    quantity DECIMAL(12,3) NOT NULL,
    unit_cost DECIMAL(10,2) DEFAULT 0,
    total_cost DECIMAL(15,2) GENERATED ALWAYS AS (quantity * unit_cost) STORED,
    rolls_count INT DEFAULT 0,
    weight_per_roll DECIMAL(10,3),
    customer_permit_number VARCHAR(50),
    warehouse_location VARCHAR(50),
    batch_number VARCHAR(50),
    expiry_date DATE,
    quality_grade ENUM('A', 'B', 'C', 'Rejected') DEFAULT 'A',
    notes TEXT,
    status ENUM('pending', 'approved', 'completed', 'cancelled') DEFAULT 'pending',
    approved_by INT,
    approved_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT NOT NULL,
    INDEX idx_permit (permit_number),
    INDEX idx_date (date),
    INDEX idx_customer (customer_id),
    INDEX idx_material (material_id),
    INDEX idx_type (movement_type),
    INDEX idx_status (status),
    INDEX idx_batch (batch_number),
    FOREIGN KEY (customer_id) REFERENCES customers(id),
    FOREIGN KEY (material_id) REFERENCES materials(id),
    FOREIGN KEY (created_by) REFERENCES users(id),
    FOREIGN KEY (approved_by) REFERENCES users(id)
);

-- جدول أوامر التشغيل مع تتبع التكاليف
CREATE TABLE production_orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_number VARCHAR(50) UNIQUE NOT NULL,
    permit_number VARCHAR(50) NOT NULL,
    customer_id INT NOT NULL,
    material_id INT NOT NULL,
    quantity DECIMAL(12,3) NOT NULL,
    unit VARCHAR(20) NOT NULL,
    color VARCHAR(50),
    special_instructions TEXT,
    priority ENUM('low', 'normal', 'high', 'urgent') DEFAULT 'normal',
    status ENUM('pending', 'in_production', 'quality_check', 'completed', 'cancelled') DEFAULT 'pending',
    planned_start_date DATE,
    planned_end_date DATE,
    actual_start_date DATE,
    actual_end_date DATE,
    material_cost DECIMAL(15,2) DEFAULT 0,
    dyeing_materials_cost DECIMAL(15,2) DEFAULT 0,
    processing_materials_cost DECIMAL(15,2) DEFAULT 0,
    labor_cost DECIMAL(15,2) DEFAULT 0,
    overhead_cost DECIMAL(15,2) DEFAULT 0,
    total_cost DECIMAL(15,2) GENERATED ALWAYS AS (
        material_cost + dyeing_materials_cost + processing_materials_cost + labor_cost + overhead_cost
    ) STORED,
    selling_price DECIMAL(15,2) DEFAULT 0,
    profit_margin DECIMAL(5,2) GENERATED ALWAYS AS (
        CASE WHEN selling_price > 0 THEN ((selling_price - total_cost) / selling_price * 100) ELSE 0 END
    ) STORED,
    completed_quantity DECIMAL(12,3) DEFAULT 0,
    quality_grade ENUM('A', 'B', 'C', 'Rejected') DEFAULT 'A',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT NOT NULL,
    INDEX idx_order_number (order_number),
    INDEX idx_customer (customer_id),
    INDEX idx_material (material_id),
    INDEX idx_status (status),
    INDEX idx_priority (priority),
    INDEX idx_dates (planned_start_date, planned_end_date),
    FOREIGN KEY (customer_id) REFERENCES customers(id),
    FOREIGN KEY (material_id) REFERENCES materials(id),
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- جدول المنفصلات مع تفاصيل الأسباب
CREATE TABLE separations (
    id INT PRIMARY KEY AUTO_INCREMENT,
    separation_number VARCHAR(50) UNIQUE NOT NULL,
    production_order_id INT NOT NULL,
    customer_id INT NOT NULL,
    material_id INT NOT NULL,
    separated_quantity DECIMAL(12,3) NOT NULL,
    rolls_count INT DEFAULT 0,
    separation_reason ENUM(
        'color_defect', 'fabric_defect', 'size_issue', 'contamination', 
        'machine_error', 'human_error', 'quality_issue', 'other'
    ) NOT NULL,
    detailed_reason TEXT,
    separation_date DATE NOT NULL,
    responsible_person VARCHAR(100),
    action_taken ENUM('rework', 'discount', 'reject', 'return', 'pending') DEFAULT 'pending',
    cost_impact DECIMAL(15,2) DEFAULT 0,
    status ENUM('separated', 'resolved', 'written_off') DEFAULT 'separated',
    resolution_notes TEXT,
    resolved_by INT,
    resolved_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT NOT NULL,
    INDEX idx_separation_number (separation_number),
    INDEX idx_production_order (production_order_id),
    INDEX idx_customer (customer_id),
    INDEX idx_material (material_id),
    INDEX idx_date (separation_date),
    INDEX idx_status (status),
    FOREIGN KEY (production_order_id) REFERENCES production_orders(id),
    FOREIGN KEY (customer_id) REFERENCES customers(id),
    FOREIGN KEY (material_id) REFERENCES materials(id),
    FOREIGN KEY (created_by) REFERENCES users(id),
    FOREIGN KEY (resolved_by) REFERENCES users(id)
);

-- جدول بيانات التسليم مع تتبع مفصل
CREATE TABLE delivery_statements (
    id INT PRIMARY KEY AUTO_INCREMENT,
    statement_number INT AUTO_INCREMENT UNIQUE,
    date DATE NOT NULL,
    customer_id INT NOT NULL,
    total_items INT DEFAULT 0,
    total_quantity_kg DECIMAL(12,3) DEFAULT 0,
    total_quantity_meter DECIMAL(12,3) DEFAULT 0,
    total_rolls INT DEFAULT 0,
    total_value DECIMAL(15,2) DEFAULT 0,
    delivery_method ENUM('pickup', 'delivery', 'shipping') DEFAULT 'pickup',
    delivery_address TEXT,
    delivery_date DATE,
    delivery_person VARCHAR(100),
    vehicle_number VARCHAR(50),
    status ENUM('pending', 'ready', 'delivered', 'cancelled') DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT NOT NULL,
    delivered_by INT,
    delivered_at TIMESTAMP NULL,
    INDEX idx_statement_number (statement_number),
    INDEX idx_date (date),
    INDEX idx_customer (customer_id),
    INDEX idx_status (status),
    FOREIGN KEY (customer_id) REFERENCES customers(id),
    FOREIGN KEY (created_by) REFERENCES users(id),
    FOREIGN KEY (delivered_by) REFERENCES users(id)
);

-- جدول عناصر بيان التسليم
CREATE TABLE delivery_statement_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    delivery_statement_id INT NOT NULL,
    production_order_id INT NOT NULL,
    material_id INT NOT NULL,
    color VARCHAR(50),
    original_quantity DECIMAL(12,3) NOT NULL,
    ready_quantity_kg DECIMAL(12,3) DEFAULT 0,
    ready_quantity_meter DECIMAL(12,3) DEFAULT 0,
    rolls_count INT DEFAULT 0,
    unit_price DECIMAL(10,2) DEFAULT 0,
    total_value DECIMAL(15,2) GENERATED ALWAYS AS (ready_quantity_kg * unit_price) STORED,
    quality_grade ENUM('A', 'B', 'C') DEFAULT 'A',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_delivery_statement (delivery_statement_id),
    INDEX idx_production_order (production_order_id),
    INDEX idx_material (material_id),
    FOREIGN KEY (delivery_statement_id) REFERENCES delivery_statements(id) ON DELETE CASCADE,
    FOREIGN KEY (production_order_id) REFERENCES production_orders(id),
    FOREIGN KEY (material_id) REFERENCES materials(id)
);

-- جدول مواد الصباغة والتشطيب
CREATE TABLE dyeing_materials (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    name_en VARCHAR(100),
    category ENUM('dye', 'chemical', 'auxiliary', 'finishing') NOT NULL,
    subcategory VARCHAR(50),
    unit ENUM('kg', 'liter', 'gram', 'piece') NOT NULL,
    purchase_price DECIMAL(10,2) DEFAULT 0,
    current_stock DECIMAL(12,3) DEFAULT 0,
    minimum_stock DECIMAL(10,2) DEFAULT 0,
    maximum_stock DECIMAL(10,2) DEFAULT 0,
    reorder_point DECIMAL(10,2) DEFAULT 0,
    supplier VARCHAR(100),
    shelf_life_days INT DEFAULT 0,
    storage_conditions TEXT,
    safety_notes TEXT,
    is_hazardous BOOLEAN DEFAULT FALSE,
    status ENUM('active', 'inactive', 'discontinued') DEFAULT 'active',
    barcode VARCHAR(100),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT,
    INDEX idx_code (code),
    INDEX idx_name (name),
    INDEX idx_category (category),
    INDEX idx_status (status),
    INDEX idx_stock_level (current_stock, minimum_stock),
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- جدول حركات مواد الصباغة
CREATE TABLE dyeing_material_movements (
    id INT PRIMARY KEY AUTO_INCREMENT,
    dyeing_material_id INT NOT NULL,
    movement_type ENUM('purchase', 'usage', 'adjustment', 'return', 'waste') NOT NULL,
    reference_type ENUM('production_order', 'purchase_order', 'adjustment', 'return') NOT NULL,
    reference_id INT,
    quantity DECIMAL(12,3) NOT NULL,
    unit_cost DECIMAL(10,2) DEFAULT 0,
    total_cost DECIMAL(15,2) GENERATED ALWAYS AS (quantity * unit_cost) STORED,
    batch_number VARCHAR(50),
    expiry_date DATE,
    date DATE NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT NOT NULL,
    INDEX idx_material (dyeing_material_id),
    INDEX idx_date (date),
    INDEX idx_type (movement_type),
    INDEX idx_batch (batch_number),
    FOREIGN KEY (dyeing_material_id) REFERENCES dyeing_materials(id),
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- جدول صرف مواد الصباغة لأوامر التشغيل
CREATE TABLE material_issuances (
    id INT PRIMARY KEY AUTO_INCREMENT,
    issuance_number VARCHAR(50) UNIQUE NOT NULL,
    production_order_id INT NOT NULL,
    date DATE NOT NULL,
    total_cost DECIMAL(15,2) DEFAULT 0,
    status ENUM('pending', 'approved', 'issued', 'cancelled') DEFAULT 'pending',
    approved_by INT,
    approved_at TIMESTAMP NULL,
    issued_by INT,
    issued_at TIMESTAMP NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT NOT NULL,
    INDEX idx_issuance_number (issuance_number),
    INDEX idx_production_order (production_order_id),
    INDEX idx_date (date),
    INDEX idx_status (status),
    FOREIGN KEY (production_order_id) REFERENCES production_orders(id),
    FOREIGN KEY (created_by) REFERENCES users(id),
    FOREIGN KEY (approved_by) REFERENCES users(id),
    FOREIGN KEY (issued_by) REFERENCES users(id)
);

-- جدول عناصر صرف مواد الصباغة
CREATE TABLE material_issuance_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    material_issuance_id INT NOT NULL,
    dyeing_material_id INT NOT NULL,
    required_quantity DECIMAL(12,3) NOT NULL,
    issued_quantity DECIMAL(12,3) DEFAULT 0,
    unit_cost DECIMAL(10,2) DEFAULT 0,
    total_cost DECIMAL(15,2) GENERATED ALWAYS AS (issued_quantity * unit_cost) STORED,
    batch_number VARCHAR(50),
    notes TEXT,
    INDEX idx_issuance (material_issuance_id),
    INDEX idx_material (dyeing_material_id),
    FOREIGN KEY (material_issuance_id) REFERENCES material_issuances(id) ON DELETE CASCADE,
    FOREIGN KEY (dyeing_material_id) REFERENCES dyeing_materials(id)
);

-- جدول الأرصدة الافتتاحية
CREATE TABLE opening_balances (
    id INT PRIMARY KEY AUTO_INCREMENT,
    customer_id INT NOT NULL,
    material_id INT NOT NULL,
    quantity DECIMAL(12,3) NOT NULL,
    unit_cost DECIMAL(10,2) DEFAULT 0,
    total_value DECIMAL(15,2) GENERATED ALWAYS AS (quantity * unit_cost) STORED,
    date DATE NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT NOT NULL,
    UNIQUE KEY unique_customer_material (customer_id, material_id),
    INDEX idx_customer (customer_id),
    INDEX idx_material (material_id),
    INDEX idx_date (date),
    FOREIGN KEY (customer_id) REFERENCES customers(id),
    FOREIGN KEY (material_id) REFERENCES materials(id),
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- جدول سجل النشاطات للمراجعة
CREATE TABLE activity_log (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    action VARCHAR(50) NOT NULL,
    table_name VARCHAR(50) NOT NULL,
    record_id INT,
    old_values JSON,
    new_values JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_id),
    INDEX idx_action (action),
    INDEX idx_table (table_name),
    INDEX idx_date (created_at),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- جدول إعدادات النظام
CREATE TABLE system_settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    setting_type ENUM('string', 'number', 'boolean', 'json') DEFAULT 'string',
    description TEXT,
    is_public BOOLEAN DEFAULT FALSE,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by INT,
    INDEX idx_key (setting_key),
    FOREIGN KEY (updated_by) REFERENCES users(id)
);

-- جدول النسخ الاحتياطية
CREATE TABLE backups (
    id INT PRIMARY KEY AUTO_INCREMENT,
    backup_name VARCHAR(100) NOT NULL,
    backup_type ENUM('manual', 'automatic', 'scheduled') DEFAULT 'manual',
    file_path VARCHAR(255),
    file_size BIGINT,
    tables_included JSON,
    status ENUM('in_progress', 'completed', 'failed') DEFAULT 'in_progress',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    created_by INT,
    notes TEXT,
    INDEX idx_date (created_at),
    INDEX idx_status (status),
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- إنشاء المستخدم الافتراضي (كلمة المرور مشفرة)
INSERT INTO users (username, password_hash, full_name, email, role, permissions) 
VALUES (
    'admin', 
    '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/VcSAg/9qm', -- admin123
    'مدير النظام', 
    'admin@textile-warehouse.com',
    'admin', 
    '{"all": true, "users": true, "settings": true, "backup": true}'
);

-- إدراج الإعدادات الافتراضية
INSERT INTO system_settings (setting_key, setting_value, setting_type, description, is_public) VALUES
('company_name', 'نظام إدارة مخازن النسيج', 'string', 'اسم الشركة', true),
('company_address', 'الرياض، المملكة العربية السعودية', 'string', 'عنوان الشركة', true),
('company_phone', '+966 11 123 4567', 'string', 'هاتف الشركة', true),
('company_email', 'info@textile-warehouse.com', 'string', 'بريد الشركة', true),
('currency', 'SAR', 'string', 'العملة الافتراضية', true),
('language', 'ar', 'string', 'اللغة الافتراضية', true),
('timezone', 'Asia/Riyadh', 'string', 'المنطقة الزمنية', false),
('backup_frequency', '24', 'number', 'تكرار النسخ الاحتياطي بالساعات', false),
('session_timeout', '30', 'number', 'انتهاء الجلسة بالدقائق', false),
('max_login_attempts', '3', 'number', 'عدد محاولات تسجيل الدخول', false);

-- إنشاء الفهارس المركبة للأداء
CREATE INDEX idx_inventory_customer_material_date ON inventory_movements(customer_id, material_id, date);
CREATE INDEX idx_production_customer_status ON production_orders(customer_id, status);
CREATE INDEX idx_delivery_customer_date ON delivery_statements(customer_id, date);

-- إنشاء Views للتقارير السريعة
CREATE VIEW v_current_balances AS
SELECT 
    c.id as customer_id,
    c.name as customer_name,
    m.id as material_id,
    m.name as material_name,
    m.unit,
    COALESCE(ob.quantity, 0) as opening_balance,
    COALESCE(incoming.total, 0) as total_incoming,
    COALESCE(outgoing.total, 0) as total_outgoing,
    COALESCE(returned.total, 0) as total_returned,
    COALESCE(delivered.total, 0) as total_delivered,
    (COALESCE(ob.quantity, 0) + COALESCE(incoming.total, 0) - COALESCE(outgoing.total, 0) + COALESCE(returned.total, 0) - COALESCE(delivered.total, 0)) as current_balance
FROM customers c
CROSS JOIN materials m
LEFT JOIN opening_balances ob ON c.id = ob.customer_id AND m.id = ob.material_id
LEFT JOIN (
    SELECT customer_id, material_id, SUM(quantity) as total
    FROM inventory_movements 
    WHERE movement_type = 'incoming' AND status = 'completed'
    GROUP BY customer_id, material_id
) incoming ON c.id = incoming.customer_id AND m.id = incoming.material_id
LEFT JOIN (
    SELECT customer_id, material_id, SUM(quantity) as total
    FROM inventory_movements 
    WHERE movement_type = 'outgoing' AND status = 'completed'
    GROUP BY customer_id, material_id
) outgoing ON c.id = outgoing.customer_id AND m.id = outgoing.material_id
LEFT JOIN (
    SELECT customer_id, material_id, SUM(quantity) as total
    FROM inventory_movements 
    WHERE movement_type = 'returned' AND status = 'completed'
    GROUP BY customer_id, material_id
) returned ON c.id = returned.customer_id AND m.id = returned.material_id
LEFT JOIN (
    SELECT customer_id, material_id, SUM(quantity) as total
    FROM inventory_movements 
    WHERE movement_type = 'delivered' AND status = 'completed'
    GROUP BY customer_id, material_id
) delivered ON c.id = delivered.customer_id AND m.id = delivered.material_id
WHERE c.is_active = TRUE AND m.is_active = TRUE;

-- View للإحصائيات السريعة
CREATE VIEW v_dashboard_stats AS
SELECT 
    (SELECT COUNT(*) FROM customers WHERE is_active = TRUE) as active_customers,
    (SELECT COUNT(*) FROM materials WHERE is_active = TRUE) as active_materials,
    (SELECT COUNT(*) FROM production_orders WHERE status = 'in_production') as active_orders,
    (SELECT COUNT(*) FROM production_orders WHERE status = 'completed' AND DATE(completed_at) = CURDATE()) as completed_today,
    (SELECT SUM(total_cost) FROM production_orders WHERE status = 'completed' AND MONTH(completed_at) = MONTH(CURDATE())) as monthly_production_cost,
    (SELECT COUNT(*) FROM separations WHERE status = 'separated') as pending_separations,
    (SELECT COUNT(*) FROM delivery_statements WHERE status = 'pending') as pending_deliveries;

COMMIT;

-- إنشاء مستخدم قاعدة البيانات للتطبيق
CREATE USER IF NOT EXISTS 'textile_app'@'%' IDENTIFIED BY 'SecurePassword123!';
GRANT SELECT, INSERT, UPDATE, DELETE ON textile_warehouse_production.* TO 'textile_app'@'%';
FLUSH PRIVILEGES;

SELECT 'Database setup completed successfully!' as status;
