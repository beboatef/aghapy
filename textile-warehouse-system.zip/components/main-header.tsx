"use client"

// This is a placeholder component for backward compatibility
// The main navigation is now handled by SidebarLayout
export function MainHeader() {
  return null
}

// Export for backward compatibility
export default MainHeader
