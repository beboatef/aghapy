"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Bell, Search, User, LogOut, Shield, Settings } from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { useAuth } from "@/hooks/use-auth"

export function Header() {
  const [searchQuery, setSearchQuery] = useState("")
  const { currentUser, isAdmin, logout } = useAuth()

  const handleLogout = () => {
    logout()
    window.location.href = "/login"
  }

  return (
    <header className="bg-white border-b border-gray-200 px-6 py-4">
      <div className="flex items-center justify-between">
        {/* شريط البحث */}
        <div className="flex-1 max-w-md">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              type="text"
              placeholder="البحث في النظام..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pr-10 bg-gray-50 border-gray-200"
            />
          </div>
        </div>

        {/* الإشعارات ومعلومات المستخدم */}
        <div className="flex items-center gap-4">
          {/* الإشعارات */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="relative">
                <Bell className="h-5 w-5" />
                <Badge className="absolute -top-1 -right-1 h-5 w-5 rounded-full p-0 text-xs bg-red-500">3</Badge>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-80">
              <DropdownMenuLabel>الإشعارات</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <div className="max-h-64 overflow-y-auto">
                <DropdownMenuItem className="flex flex-col items-start p-3">
                  <div className="font-medium text-sm">طلب تحويل جديد</div>
                  <div className="text-xs text-gray-500 mt-1">طلب تحويل أمر التشغيل PO003 من شركة القطن السعودي</div>
                  <div className="text-xs text-gray-400 mt-1">منذ 5 دقائق</div>
                </DropdownMenuItem>
                <DropdownMenuItem className="flex flex-col items-start p-3">
                  <div className="font-medium text-sm">تم إكمال أمر تشغيل</div>
                  <div className="text-xs text-gray-500 mt-1">
                    تم إكمال أمر التشغيل PO002 وترحيل الكمية إلى مخزن الجاهز
                  </div>
                  <div className="text-xs text-gray-400 mt-1">منذ ساعة</div>
                </DropdownMenuItem>
                <DropdownMenuItem className="flex flex-col items-start p-3">
                  <div className="font-medium text-sm">مخزون منخفض</div>
                  <div className="text-xs text-gray-500 mt-1">كمية القطن الأبيض الخام أقل من الحد الأدنى</div>
                  <div className="text-xs text-gray-400 mt-1">منذ 3 ساعات</div>
                </DropdownMenuItem>
              </div>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-center text-blue-600">عرض جميع الإشعارات</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* معلومات المستخدم */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="flex items-center gap-2">
                <div className="flex items-center gap-2">
                  <div className="text-right">
                    <div className="text-sm font-medium">{currentUser?.fullName || "مستخدم"}</div>
                    <div className="text-xs text-gray-500 flex items-center gap-1">
                      {isAdmin() && <Shield className="h-3 w-3" />}
                      {currentUser?.role === "admin" ? "مدير النظام" : "مستخدم"}
                    </div>
                  </div>
                  <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center">
                    <User className="h-4 w-4 text-blue-600" />
                  </div>
                </div>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel>حسابي</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <User className="ml-2 h-4 w-4" />
                <span>الملف الشخصي</span>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Settings className="ml-2 h-4 w-4" />
                <span>الإعدادات</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleLogout} className="text-red-600">
                <LogOut className="ml-2 h-4 w-4" />
                <span>تسجيل الخروج</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  )
}
