"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { ChevronUp, ChevronDown, Search, Filter, RotateCcw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

interface Column {
  key: string
  label: string
  sortable?: boolean
  render?: (value: any, row: any) => React.ReactNode
}

interface AnimatedTableProps {
  data: any[]
  columns: Column[]
  searchable?: boolean
  filterable?: boolean
  loading?: boolean
  onRowClick?: (row: any) => void
  className?: string
}

export function AnimatedTable({
  data,
  columns,
  searchable = true,
  filterable = false,
  loading = false,
  onRowClick,
  className = "",
}: AnimatedTableProps) {
  const [sortConfig, setSortConfig] = useState<{ key: string; direction: "asc" | "desc" } | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [filteredData, setFilteredData] = useState(data)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  useEffect(() => {
    let filtered = data

    if (searchTerm) {
      filtered = filtered.filter((row) =>
        columns.some((column) => String(row[column.key]).toLowerCase().includes(searchTerm.toLowerCase())),
      )
    }

    if (sortConfig) {
      filtered.sort((a, b) => {
        const aValue = a[sortConfig.key]
        const bValue = b[sortConfig.key]

        if (aValue < bValue) {
          return sortConfig.direction === "asc" ? -1 : 1
        }
        if (aValue > bValue) {
          return sortConfig.direction === "asc" ? 1 : -1
        }
        return 0
      })
    }

    setFilteredData(filtered)
  }, [data, searchTerm, sortConfig, columns])

  const handleSort = (key: string) => {
    let direction: "asc" | "desc" = "asc"
    if (sortConfig && sortConfig.key === key && sortConfig.direction === "asc") {
      direction = "desc"
    }
    setSortConfig({ key, direction })
  }

  const containerVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
        staggerChildren: 0.1,
      },
    },
  }

  const headerVariants = {
    hidden: { opacity: 0, x: -20 },
    visible: {
      opacity: 1,
      x: 0,
      transition: { duration: 0.5 },
    },
  }

  const rowVariants = {
    hidden: { opacity: 0, x: -20 },
    visible: (index: number) => ({
      opacity: 1,
      x: 0,
      transition: {
        duration: 0.5,
        delay: index * 0.05,
      },
    }),
    exit: {
      opacity: 0,
      x: 20,
      transition: { duration: 0.3 },
    },
  }

  const cellVariants = {
    hidden: { opacity: 0, scale: 0.8 },
    visible: {
      opacity: 1,
      scale: 1,
      transition: { duration: 0.3 },
    },
  }

  const loadingVariants = {
    animate: {
      opacity: [0.5, 1, 0.5],
      transition: {
        duration: 1.5,
        repeat: Number.POSITIVE_INFINITY,
        ease: "easeInOut",
      },
    },
  }

  if (loading) {
    return (
      <motion.div
        className={`animate-table-container ${className}`}
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <div className="space-y-4">
          <motion.div
            className="flex items-center justify-between p-4 bg-white dark:bg-gray-800 rounded-lg shadow-sm"
            variants={loadingVariants}
            animate="animate"
          >
            <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-32"></div>
            <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-24"></div>
          </motion.div>

          <div className="overflow-hidden rounded-lg border border-gray-200 dark:border-gray-700">
            <table className="w-full">
              <thead className="bg-gray-50 dark:bg-gray-800">
                <tr>
                  {columns.map((column, index) => (
                    <th key={column.key} className="px-6 py-4 text-right">
                      <motion.div
                        className="h-4 bg-gray-200 dark:bg-gray-700 rounded"
                        variants={loadingVariants}
                        animate="animate"
                        style={{ animationDelay: `${index * 0.1}s` }}
                      ></motion.div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-700">
                {[...Array(5)].map((_, rowIndex) => (
                  <tr key={rowIndex}>
                    {columns.map((column, colIndex) => (
                      <td key={column.key} className="px-6 py-4">
                        <motion.div
                          className="h-4 bg-gray-200 dark:bg-gray-700 rounded"
                          variants={loadingVariants}
                          animate="animate"
                          style={{ animationDelay: `${(rowIndex * columns.length + colIndex) * 0.05}s` }}
                        ></motion.div>
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </motion.div>
    )
  }

  return (
    <motion.div
      className={`animate-table-container ${className}`}
      variants={containerVariants}
      initial="hidden"
      animate={isVisible ? "visible" : "hidden"}
    >
      {(searchable || filterable) && (
        <motion.div
          className="flex items-center justify-between p-4 bg-white dark:bg-gray-800 rounded-lg shadow-sm mb-4"
          variants={headerVariants}
        >
          <div className="flex items-center space-x-4">
            {searchable && (
              <motion.div className="relative" whileHover={{ scale: 1.02 }} whileFocus={{ scale: 1.02 }}>
                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="البحث في الجدول..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pr-10 w-64 focus-ring"
                />
              </motion.div>
            )}

            {filterable && (
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button variant="outline" size="sm">
                  <Filter className="w-4 h-4 mr-2" />
                  فلتر
                </Button>
              </motion.div>
            )}
          </div>

          <motion.div
            className="flex items-center space-x-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            <span className="text-sm text-gray-600 dark:text-gray-400">
              {filteredData.length} من {data.length} عنصر
            </span>

            {(searchTerm || sortConfig) && (
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setSearchTerm("")
                    setSortConfig(null)
                  }}
                >
                  <RotateCcw className="w-4 h-4 mr-2" />
                  إعادة تعيين
                </Button>
              </motion.div>
            )}
          </motion.div>
        </motion.div>
      )}

      <motion.div
        className="overflow-hidden rounded-lg border border-gray-200 dark:border-gray-700 shadow-sm"
        variants={headerVariants}
        whileHover={{ boxShadow: "0 10px 25px rgba(0,0,0,0.1)" }}
        transition={{ duration: 0.3 }}
      >
        <table className="w-full">
          <thead className="bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-700">
            <tr>
              {columns.map((column, index) => (
                <motion.th
                  key={column.key}
                  className={`px-6 py-4 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider ${
                    column.sortable ? "cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-600" : ""
                  }`}
                  variants={cellVariants}
                  custom={index}
                  onClick={() => column.sortable && handleSort(column.key)}
                  whileHover={column.sortable ? { scale: 1.02, backgroundColor: "rgba(59, 130, 246, 0.1)" } : {}}
                  whileTap={column.sortable ? { scale: 0.98 } : {}}
                >
                  <div className="flex items-center justify-end space-x-1">
                    <span>{column.label}</span>
                    {column.sortable && (
                      <motion.div
                        className="flex flex-col"
                        animate={{
                          rotate: sortConfig?.key === column.key ? (sortConfig.direction === "asc" ? 0 : 180) : 0,
                        }}
                        transition={{ duration: 0.3 }}
                      >
                        {sortConfig?.key === column.key ? (
                          sortConfig.direction === "asc" ? (
                            <ChevronUp className="w-4 h-4 text-blue-500" />
                          ) : (
                            <ChevronDown className="w-4 h-4 text-blue-500" />
                          )
                        ) : (
                          <ChevronDown className="w-4 h-4 text-gray-400" />
                        )}
                      </motion.div>
                    )}
                  </div>
                </motion.th>
              ))}
            </tr>
          </thead>

          <tbody className="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-700">
            <AnimatePresence mode="wait">
              {filteredData.length === 0 ? (
                <motion.tr
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.5 }}
                >
                  <td colSpan={columns.length} className="px-6 py-12 text-center">
                    <motion.div
                      className="flex flex-col items-center space-y-3"
                      variants={containerVariants}
                      initial="hidden"
                      animate="visible"
                    >
                      <motion.div
                        className="w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center"
                        animate={{ rotate: [0, 10, -10, 0] }}
                        transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
                      >
                        <Search className="w-8 h-8 text-gray-400" />
                      </motion.div>
                      <p className="text-gray-500 dark:text-gray-400">لا توجد بيانات للعرض</p>
                      {searchTerm && <p className="text-sm text-gray-400">جرب البحث بكلمات مختلفة</p>}
                    </motion.div>
                  </td>
                </motion.tr>
              ) : (
                filteredData.map((row, index) => (
                  <motion.tr
                    key={row.id || index}
                    className={`hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors ${
                      onRowClick ? "cursor-pointer" : ""
                    }`}
                    variants={rowVariants}
                    custom={index}
                    initial="hidden"
                    animate="visible"
                    exit="exit"
                    whileHover={{
                      scale: 1.01,
                      boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
                      transition: { duration: 0.2 },
                    }}
                    onClick={() => onRowClick?.(row)}
                    layout
                  >
                    {columns.map((column, colIndex) => (
                      <motion.td
                        key={column.key}
                        className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100"
                        variants={cellVariants}
                        whileHover={{ scale: 1.02 }}
                        transition={{ duration: 0.2 }}
                      >
                        <motion.div
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: colIndex * 0.05 }}
                        >
                          {column.render ? column.render(row[column.key], row) : row[column.key]}
                        </motion.div>
                      </motion.td>
                    ))}
                  </motion.tr>
                ))
              )}
            </AnimatePresence>
          </tbody>
        </table>
      </motion.div>

      {filteredData.length > 0 && (
        <motion.div
          className="flex items-center justify-between px-6 py-3 bg-gray-50 dark:bg-gray-800 rounded-b-lg"
          variants={headerVariants}
          initial="hidden"
          animate="visible"
          transition={{ delay: 0.5 }}
        >
          <motion.div
            className="text-sm text-gray-700 dark:text-gray-300"
            animate={{ opacity: [0.7, 1, 0.7] }}
            transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
          >
            عرض {filteredData.length} من {data.length} عنصر
          </motion.div>

          <motion.div
            className="flex items-center space-x-2"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.7 }}
          ></motion.div>
        </motion.div>
      )}
    </motion.div>
  )
}
