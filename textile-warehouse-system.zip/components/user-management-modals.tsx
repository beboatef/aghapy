"use client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { X, User, Save } from "lucide-react"

interface UserType {
  id: number
  username: string
  fullName: string
  role: string
  active: boolean
  lastLogin: string
}

interface UserFormData {
  username: string
  fullName: string
  password: string
  role: string
  active: boolean
}

interface EditUserModalProps {
  isOpen: boolean
  onClose: () => void
  user: UserType | null
  formData: UserFormData
  onFormChange: (field: string, value: any) => void
  onSave: () => void
  formErrors: { username: string; fullName: string; password: string }
}

interface AddUserModalProps {
  isOpen: boolean
  onClose: () => void
  formData: UserFormData
  onFormChange: (field: string, value: any) => void
  onSave: () => void
  formErrors: { username: string; fullName: string; password: string }
}

export function EditUserModal({
  isOpen,
  onClose,
  user,
  formData,
  onFormChange,
  onSave,
  formErrors,
}: EditUserModalProps) {
  if (!isOpen || !user) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <Card className="w-full max-w-md mx-4">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center">
              <User className="h-5 w-5 ml-2" />
              تعديل المستخدم
            </div>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="edit-username">اسم المستخدم</Label>
            <Input
              id="edit-username"
              value={formData.username}
              onChange={(e) => onFormChange("username", e.target.value)}
              disabled={user.role === "admin"}
              className={formErrors.username ? "border-red-500" : ""}
            />
            {formErrors.username && <p className="text-red-500 text-sm mt-1">{formErrors.username}</p>}
          </div>

          <div>
            <Label htmlFor="edit-fullName">الاسم الكامل</Label>
            <Input
              id="edit-fullName"
              value={formData.fullName}
              onChange={(e) => onFormChange("fullName", e.target.value)}
              className={formErrors.fullName ? "border-red-500" : ""}
            />
            {formErrors.fullName && <p className="text-red-500 text-sm mt-1">{formErrors.fullName}</p>}
          </div>

          <div>
            <Label htmlFor="edit-password">كلمة المرور الجديدة (اتركها فارغة إذا لم ترد تغييرها)</Label>
            <Input
              id="edit-password"
              type="password"
              value={formData.password}
              onChange={(e) => onFormChange("password", e.target.value)}
              placeholder="اتركها فارغة للاحتفاظ بكلمة المرور الحالية"
            />
          </div>

          <div>
            <Label htmlFor="edit-role">الدور</Label>
            <select
              id="edit-role"
              className="w-full p-2 border rounded-md"
              value={formData.role}
              onChange={(e) => onFormChange("role", e.target.value)}
              disabled={user.role === "admin"}
            >
              <option value="user">مستخدم</option>
              <option value="admin">مدير</option>
            </select>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="edit-active">حالة المستخدم</Label>
              <p className="text-sm text-gray-600">تفعيل أو إلغاء تفعيل المستخدم</p>
            </div>
            <Switch
              id="edit-active"
              checked={formData.active}
              onCheckedChange={(checked) => onFormChange("active", checked)}
              disabled={user.role === "admin"}
            />
          </div>

          <div className="flex gap-2 pt-4">
            <Button onClick={onSave} className="flex-1">
              <Save className="h-4 w-4 ml-2" />
              حفظ التغييرات
            </Button>
            <Button variant="outline" onClick={onClose} className="flex-1">
              إلغاء
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export function AddUserModal({ isOpen, onClose, formData, onFormChange, onSave, formErrors }: AddUserModalProps) {
  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <Card className="w-full max-w-md mx-4">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center">
              <User className="h-5 w-5 ml-2" />
              إضافة مستخدم جديد
            </div>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="add-username">اسم المستخدم</Label>
            <Input
              id="add-username"
              value={formData.username}
              onChange={(e) => onFormChange("username", e.target.value)}
              placeholder="أدخل اسم المستخدم"
              className={formErrors.username ? "border-red-500" : ""}
            />
            {formErrors.username && <p className="text-red-500 text-sm mt-1">{formErrors.username}</p>}
          </div>

          <div>
            <Label htmlFor="add-fullName">الاسم الكامل</Label>
            <Input
              id="add-fullName"
              value={formData.fullName}
              onChange={(e) => onFormChange("fullName", e.target.value)}
              placeholder="أدخل الاسم الكامل"
              className={formErrors.fullName ? "border-red-500" : ""}
            />
            {formErrors.fullName && <p className="text-red-500 text-sm mt-1">{formErrors.fullName}</p>}
          </div>

          <div>
            <Label htmlFor="add-password">كلمة المرور</Label>
            <Input
              id="add-password"
              type="password"
              value={formData.password}
              onChange={(e) => onFormChange("password", e.target.value)}
              placeholder="أدخل كلمة المرور"
              className={formErrors.password ? "border-red-500" : ""}
            />
            {formErrors.password && <p className="text-red-500 text-sm mt-1">{formErrors.password}</p>}
          </div>

          <div>
            <Label htmlFor="add-role">الدور</Label>
            <select
              id="add-role"
              className="w-full p-2 border rounded-md"
              value={formData.role}
              onChange={(e) => onFormChange("role", e.target.value)}
            >
              <option value="user">مستخدم</option>
              <option value="admin">مدير</option>
            </select>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="add-active">حالة المستخدم</Label>
              <p className="text-sm text-gray-600">تفعيل المستخدم عند الإنشاء</p>
            </div>
            <Switch
              id="add-active"
              checked={formData.active}
              onCheckedChange={(checked) => onFormChange("active", checked)}
            />
          </div>

          <div className="flex gap-2 pt-4">
            <Button onClick={onSave} className="flex-1">
              <Save className="h-4 w-4 ml-2" />
              إضافة المستخدم
            </Button>
            <Button variant="outline" onClick={onClose} className="flex-1">
              إلغاء
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
