"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { TrendingUp, Activity, DollarSign, Package, Users, AlertTriangle, CheckCircle } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface StatCard {
  id: string
  title: string
  value: number | string
  previousValue?: number
  change?: number
  changeType?: "increase" | "decrease" | "neutral"
  icon?: React.ReactNode
  color?: "blue" | "green" | "red" | "yellow" | "purple" | "indigo"
  format?: "number" | "currency" | "percentage"
  loading?: boolean
}

interface AnimatedStatsCardsProps {
  stats: StatCard[]
  loading?: boolean
  className?: string
}

const iconMap = {
  activity: Activity,
  dollar: DollarSign,
  package: Package,
  users: Users,
  warning: AlertTriangle,
  check: CheckCircle,
  trending: TrendingUp,
}

const colorMap = {
  blue: "from-blue-500 to-blue-600",
  green: "from-green-500 to-green-600",
  red: "from-red-500 to-red-600",
  yellow: "from-yellow-500 to-yellow-600",
  purple: "from-purple-500 to-purple-600",
  indigo: "from-indigo-500 to-indigo-600",
}

function CountUpAnimation({
  value,
  format = "number",
  duration = 2000,
}: {
  value: number | string
  format?: "number" | "currency" | "percentage"
  duration?: number
}) {
  const [displayValue, setDisplayValue] = useState(0)
  const numericValue = typeof value === "string" ? Number.parseFloat(value) || 0 : value

  useEffect(() => {
    if (typeof numericValue !== "number") return

    let startTime: number
    let animationFrame: number

    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime
      const progress = Math.min((currentTime - startTime) / duration, 1)

      // Easing function for smooth animation
      const easeOutQuart = 1 - Math.pow(1 - progress, 4)
      const currentValue = numericValue * easeOutQuart

      setDisplayValue(currentValue)

      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate)
      }
    }

    animationFrame = requestAnimationFrame(animate)

    return () => {
      if (animationFrame) {
        cancelAnimationFrame(animationFrame)
      }
    }
  }, [numericValue, duration])

  const formatValue = (val: number) => {
    switch (format) {
      case "currency":
        return new Intl.NumberFormat("ar-SA", {
          style: "currency",
          currency: "SAR",
          minimumFractionDigits: 0,
          maximumFractionDigits: 0,
        }).format(val)
      case "percentage":
        return `${val.toFixed(1)}%`
      default:
        return new Intl.NumberFormat("ar-SA").format(Math.floor(val))
    }
  }

  return (
    <motion.span
      key={displayValue}
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      {formatValue(displayValue)}
    </motion.span>
  )
}

function StatCardComponent({ stat, index }: { stat: StatCard; index: number }) {
  const [isHovered, setIsHovered] = useState(false)

  const cardVariants = {
    hidden: {
      opacity: 0,
      y: 50,
      scale: 0.9,
    },
    visible: {
      opacity: 1,
      y: 0,
      scale: 1,
      transition: {
        duration: 0.6,
        delay: index * 0.1,
        ease: "easeOut",
      },
    },
    hover: {
      y: -8,
      scale: 1.02,
      transition: {
        duration: 0.3,
        ease: "easeInOut",
      },
    },
  }

  const iconVariants = {
    initial: { rotate: 0, scale: 1 },
    hover: {
      rotate: 360,
      scale: 1.1,
      transition: { duration: 0.6 },
    },
    pulse: {
      scale: [1, 1.1, 1],
      transition: {
        duration: 2,
        repeat: Number.POSITIVE_INFINITY,
        ease: "easeInOut",
      },
    },
  }

  const changeVariants = {
    hidden: { opacity: 0, x: -20 },
    visible: {
      opacity: 1,
      x: 0,
      transition: { delay: 0.5 + index * 0.1 },
    },
  }

  if (stat.loading) {
    return (
      <motion.div variants={cardVariants} initial="hidden" animate="visible">
        <Card className="relative overflow-hidden">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              <motion.div
                className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-24"
                animate={{ opacity: [0.5, 1, 0.5] }}
                transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY }}
              />
            </CardTitle>
            <motion.div
              className="h-4 w-4 bg-gray-200 dark:bg-gray-700 rounded"
              animate={{ opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY, delay: 0.2 }}
            />
          </CardHeader>
          <CardContent>
            <motion.div
              className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-20 mb-2"
              animate={{ opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY, delay: 0.4 }}
            />
            <motion.div
              className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-16"
              animate={{ opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY, delay: 0.6 }}
            />
          </CardContent>
        </Card>
      </motion.div>
    )
  }

  return (
    <motion.div
      variants={cardVariants}
      initial="hidden"
      animate="visible"
      whileHover="hover"
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
    >
      <Card className="relative overflow-hidden cursor-pointer group">
        {/* Background Gradient */}
        <motion.div
          className={`absolute inset-0 bg-gradient-to-br ${colorMap[stat.color || "blue"]} opacity-0 group-hover:opacity-5 transition-opacity duration-300`}
          initial={{ scale: 0 }}
          whileHover={{ scale: 1 }}
          transition={{ duration: 0.3 }}
        />

        {/* Animated Border */}
        <motion.div
          className="absolute inset-0 border-2 border-transparent group-hover:border-blue-200 dark:group-hover:border-blue-800 rounded-lg"
          initial={{ opacity: 0 }}
          whileHover={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
        />

        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-400">{stat.title}</CardTitle>

          <motion.div
            variants={iconVariants}
            initial="initial"
            animate={isHovered ? "hover" : "pulse"}
            className={`h-4 w-4 text-${stat.color || "blue"}-500`}
          >
            {stat.icon || <Activity className="h-4 w-4" />}
          </motion.div>
        </CardHeader>

        <CardContent>
          <motion.div
            className="text-2xl font-bold text-gray-900 dark:text-gray-100"
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.3 + index * 0.1 }}
          >
            {typeof stat.value === "number" ? (
              <CountUpAnimation value={stat.value} format={stat.format} duration={1500 + index * 200} />
            ) : (
              stat.value
            )}
          </motion.div>

          {stat.change !== undefined && (
            <motion.div
              variants={changeVariants}
              initial="hidden"
              animate="visible"
              className="flex items-center text-xs"
            >
              <motion.div
                animate={{
                  rotate: stat.changeType === "increase" ? 0 : 180,
                  color: stat.changeType === "increase" ? "#10b981" : "#ef4444",
                }}
                transition={{ duration: 0.3 }}
              >
                <TrendingUp className="h-3 w-3 mr-1" />
              </motion.div>

              <span
                className={`${
                  stat.changeType === "increase"
                    ? "text-green-600 dark:text-green-400"
                    : "text-red-600 dark:text-red-400"
                }`}
              >
                {Math.abs(stat.change)}%
              </span>

              <span className="text-gray-500 dark:text-gray-400 mr-1">من الشهر الماضي</span>
            </motion.div>
          )}

          {/* Progress Bar Animation */}
          {stat.previousValue && typeof stat.value === "number" && (
            <motion.div
              className="mt-2 h-1 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1 + index * 0.1 }}
            >
              <motion.div
                className={`h-full bg-gradient-to-r ${colorMap[stat.color || "blue"]}`}
                initial={{ width: 0 }}
                animate={{ width: `${Math.min((stat.value / stat.previousValue) * 100, 100)}%` }}
                transition={{ duration: 1.5, delay: 1.2 + index * 0.1 }}
              />
            </motion.div>
          )}
        </CardContent>

        {/* Floating Particles Effect */}
        <AnimatePresence>
          {isHovered && (
            <>
              {[...Array(3)].map((_, i) => (
                <motion.div
                  key={i}
                  className={`absolute w-1 h-1 bg-${stat.color || "blue"}-400 rounded-full`}
                  initial={{
                    opacity: 0,
                    x: Math.random() * 100,
                    y: Math.random() * 100,
                  }}
                  animate={{
                    opacity: [0, 1, 0],
                    y: [100, -20],
                    x: Math.random() * 200 - 100,
                  }}
                  exit={{ opacity: 0 }}
                  transition={{
                    duration: 2,
                    delay: i * 0.2,
                    repeat: Number.POSITIVE_INFINITY,
                  }}
                />
              ))}
            </>
          )}
        </AnimatePresence>
      </Card>
    </motion.div>
  )
}

export function AnimatedStatsCards({ stats, loading = false, className = "" }: AnimatedStatsCardsProps) {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  }

  return (
    <motion.div
      className={`grid gap-4 md:grid-cols-2 lg:grid-cols-4 ${className}`}
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      {stats.map((stat, index) => (
        <StatCardComponent key={stat.id} stat={{ ...stat, loading: loading || stat.loading }} index={index} />
      ))}
    </motion.div>
  )
}
