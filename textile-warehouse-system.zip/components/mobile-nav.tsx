"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import {
  Home,
  ShoppingCart,
  Users,
  Package,
  FileText,
  BarChart3,
  Settings,
  LogOut,
  Menu,
  DollarSign,
  Palette,
  Warehouse,
  Calculator,
  User,
} from "lucide-react"
import { useAuth } from "@/hooks/use-auth"

const navigation = [
  { name: "الرئيسية", href: "/", icon: Home },
  { name: "أوامر التشغيل", href: "/production-orders", icon: ShoppingCart },
  { name: "العملاء", href: "/customers", icon: Users },
  { name: "الأصناف", href: "/materials", icon: Package },
  { name: "المخزون", href: "/inventory", icon: Package },
  { name: "الأرصدة", href: "/balances", icon: BarChart3 },
  { name: "الفواتير", href: "/invoices", icon: FileText },
  { name: "التقارير", href: "/reports", icon: BarChart3 },
]

const dyeingNavigation = [
  { name: "مخزن مواد الصباغة", href: "/dyeing-materials-warehouse", icon: Warehouse },
  { name: "مواد الصباغة والتجهيز", href: "/dyeing-inventory", icon: Palette },
  { name: "نظام صرف المواد", href: "/material-issuance-system", icon: Package },
  { name: "تقارير المخزون والاستهلاك", href: "/inventory-reports", icon: BarChart3 },
  { name: "تحليل تكاليف الإنتاج", href: "/production-cost-analysis", icon: Calculator },
]

const financialNavigation = [
  { name: "اللوحة المالية", href: "/financial-dashboard", icon: DollarSign },
  { name: "التقارير المالية", href: "/financial-reports", icon: BarChart3 },
]

export function MobileNav() {
  const [open, setOpen] = useState(false)
  const pathname = usePathname()
  const { user, logout } = useAuth()

  const isActive = (href: string) => {
    if (href === "/") {
      return pathname === "/"
    }
    return pathname.startsWith(href)
  }

  return (
    <div className="md:hidden">
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetTrigger asChild>
          <Button
            variant="ghost"
            size="sm"
            className="h-9 w-9 p-0 transition-all duration-200 transform hover:scale-110"
          >
            <Menu className="h-5 w-5" />
            <span className="sr-only">فتح القائمة</span>
          </Button>
        </SheetTrigger>
        <SheetContent side="right" className="w-80 p-0">
          <SheetHeader className="p-6 border-b border-gray-200 dark:border-gray-700">
            <SheetTitle className="flex items-center text-right">
              <div className="h-8 w-8 bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg flex items-center justify-center ml-3">
                <Warehouse className="h-5 w-5 text-white" />
              </div>
              <span className="text-lg font-bold bg-gradient-to-r from-blue-600 to-blue-700 bg-clip-text text-transparent">
                Aghapy Dyeing
              </span>
            </SheetTitle>
          </SheetHeader>

          <div className="flex flex-col h-full">
            <div className="flex-1 overflow-y-auto p-4">
              {/* User Info */}
              <div className="flex items-center p-4 mb-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <div className="h-10 w-10 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center ml-3">
                  <User className="h-5 w-5 text-white" />
                </div>
                <div className="text-right">
                  <div className="text-sm font-medium">{user?.name || "المستخدم"}</div>
                  <div className="text-xs text-gray-500 dark:text-gray-400">مدير النظام</div>
                </div>
              </div>

              {/* Main Navigation */}
              <div className="space-y-1 mb-6">
                <h3 className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2">
                  القائمة الرئيسية
                </h3>
                {navigation.map((item) => (
                  <Link
                    key={item.name}
                    href={item.href}
                    onClick={() => setOpen(false)}
                    className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-all duration-200 ${
                      isActive(item.href)
                        ? "bg-blue-100 text-blue-700 dark:bg-blue-900/50 dark:text-blue-300"
                        : "text-gray-600 hover:text-gray-900 hover:bg-gray-100 dark:text-gray-300 dark:hover:text-white dark:hover:bg-gray-700"
                    }`}
                  >
                    <item.icon className="ml-3 h-5 w-5 flex-shrink-0" />
                    {item.name}
                  </Link>
                ))}
              </div>

              {/* Dyeing Navigation */}
              <div className="space-y-1 mb-6">
                <h3 className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2">
                  الصباغة والتجهيز
                </h3>
                {dyeingNavigation.map((item) => (
                  <Link
                    key={item.name}
                    href={item.href}
                    onClick={() => setOpen(false)}
                    className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-all duration-200 ${
                      isActive(item.href)
                        ? "bg-blue-100 text-blue-700 dark:bg-blue-900/50 dark:text-blue-300"
                        : "text-gray-600 hover:text-gray-900 hover:bg-gray-100 dark:text-gray-300 dark:hover:text-white dark:hover:bg-gray-700"
                    }`}
                  >
                    <item.icon className="ml-3 h-5 w-5 flex-shrink-0" />
                    {item.name}
                  </Link>
                ))}
              </div>

              {/* Financial Navigation */}
              <div className="space-y-1 mb-6">
                <h3 className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2">
                  المالية
                </h3>
                {financialNavigation.map((item) => (
                  <Link
                    key={item.name}
                    href={item.href}
                    onClick={() => setOpen(false)}
                    className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-all duration-200 ${
                      isActive(item.href)
                        ? "bg-blue-100 text-blue-700 dark:bg-blue-900/50 dark:text-blue-300"
                        : "text-gray-600 hover:text-gray-900 hover:bg-gray-100 dark:text-gray-300 dark:hover:text-white dark:hover:bg-gray-700"
                    }`}
                  >
                    <item.icon className="ml-3 h-5 w-5 flex-shrink-0" />
                    {item.name}
                  </Link>
                ))}
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="border-t border-gray-200 dark:border-gray-700 p-4 space-y-2">
              <Link
                href="/settings"
                onClick={() => setOpen(false)}
                className="flex items-center px-3 py-2 rounded-md text-sm font-medium text-gray-600 hover:text-gray-900 hover:bg-gray-100 dark:text-gray-300 dark:hover:text-white dark:hover:bg-gray-700 transition-all duration-200"
              >
                <Settings className="ml-3 h-5 w-5 flex-shrink-0" />
                الإعدادات
              </Link>
              <button
                onClick={() => {
                  logout()
                  setOpen(false)
                }}
                className="flex items-center w-full px-3 py-2 rounded-md text-sm font-medium text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 transition-all duration-200"
              >
                <LogOut className="ml-3 h-5 w-5 flex-shrink-0" />
                تسجيل الخروج
              </button>
            </div>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  )
}
