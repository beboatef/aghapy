"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Home,
  BarChart3,
  Users,
  ShoppingCart,
  Package,
  Settings,
  HelpCircle,
  Search,
  User,
  LogOut,
  Menu,
  X,
  Wallet,
  FileText,
  TrendingUp,
  Palette,
  Calculator,
  DollarSign,
  CreditCard,
  UserCheck,
  BarChart2,
} from "lucide-react"
import { useAuth } from "@/hooks/use-auth"

const navigation = [
  { name: "لوحة التحكم", href: "/", icon: Home, nameEn: "Dashboard" },
  { name: "التحليلات", href: "/analytics", icon: BarChart3, nameEn: "Analytics" },
  { name: "العملاء", href: "/customers", icon: Users, nameEn: "Customers" },
  { name: "أوامر التشغيل", href: "/production-orders", icon: ShoppingCart, nameEn: "Orders" },
  { name: "الأصناف", href: "/materials", icon: Package, nameEn: "Products" },
  { name: "المخزون", href: "/inventory", icon: Package, nameEn: "Inventory" },
  { name: "الأرصدة", href: "/balances", icon: BarChart2, nameEn: "Balances" },
]

const financialNavigation = [
  { name: "الخزينة", href: "/treasury", icon: Wallet, nameEn: "Treasury" },
  { name: "حسابات العملاء", href: "/customer-accounts", icon: CreditCard, nameEn: "Customer Accounts" },
  { name: "تقارير العملاء", href: "/customer-reports", icon: UserCheck, nameEn: "Customer Reports" },
  { name: "اللوحة المالية", href: "/financial-dashboard", icon: DollarSign, nameEn: "Financial Dashboard" },
  { name: "التقارير المالية", href: "/financial-reports", icon: FileText, nameEn: "Financial Reports" },
]

const dyeingNavigation = [
  { name: "مخزن مواد الصباغة", href: "/dyeing-materials-warehouse", icon: Palette, nameEn: "Dyeing Materials" },
  { name: "مواد الصباغة والتجهيز", href: "/dyeing-inventory", icon: Package, nameEn: "Dyeing Inventory" },
  { name: "نظام صرف المواد", href: "/material-issuance-system", icon: TrendingUp, nameEn: "Material Issuance" },
  { name: "تحليل تكاليف الإنتاج", href: "/production-cost-analysis", icon: Calculator, nameEn: "Cost Analysis" },
]

const bottomNavigation = [
  { name: "الإعدادات", href: "/settings", icon: Settings, nameEn: "Settings" },
  { name: "مركز المساعدة", href: "/help", icon: HelpCircle, nameEn: "Help Center" },
]

interface ModernLayoutProps {
  children: React.ReactNode
  title?: string
  subtitle?: string
}

export function ModernLayout({
  children,
  title = "لوحة التحكم",
  subtitle = "مرحباً بك، إليك ما يحدث اليوم",
}: ModernLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const pathname = usePathname()
  const { user, logout } = useAuth()

  const isActive = (href: string) => {
    if (href === "/") {
      return pathname === "/"
    }
    return pathname.startsWith(href)
  }

  const allNavigation = [...navigation, ...financialNavigation, ...dyeingNavigation]

  const NavItem = ({ item, section = "" }: { item: any; section?: string }) => (
    <Link
      href={item.href}
      className={`sidebar-nav-item ${isActive(item.href) ? "active" : ""}`}
      onClick={() => setSidebarOpen(false)}
    >
      <item.icon className="sidebar-nav-icon" />
      <div className="flex-1">
        <div className="text-sm font-medium">{item.name}</div>
        <div className="text-xs opacity-75">{item.nameEn}</div>
      </div>
    </Link>
  )

  return (
    <div className="dashboard-layout">
      {/* Sidebar */}
      <div className={`sidebar ${sidebarOpen ? "open" : ""}`}>
        <div className="sidebar-content custom-scrollbar">
          {/* Logo */}
          <div className="sidebar-logo">
            <div className="sidebar-logo-icon">
              <Package className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="sidebar-logo-text">Aghapy Dyeing</div>
              <div className="text-white/60 text-xs">نظام إدارة المصبغة</div>
            </div>
          </div>

          {/* Navigation */}
          <nav className="sidebar-nav">
            {/* Main Navigation */}
            <div className="mb-6">
              {navigation.map((item) => (
                <NavItem key={item.href} item={item} />
              ))}
            </div>

            {/* Financial Section */}
            <div className="mb-6">
              <div className="text-white/60 text-xs uppercase tracking-wider mb-3 px-4">المالية والحسابات</div>
              {financialNavigation.map((item) => (
                <NavItem key={item.href} item={item} section="financial" />
              ))}
            </div>

            {/* Dyeing Section */}
            <div className="mb-6">
              <div className="text-white/60 text-xs uppercase tracking-wider mb-3 px-4">الصباغة والتجهيز</div>
              {dyeingNavigation.map((item) => (
                <NavItem key={item.href} item={item} section="dyeing" />
              ))}
            </div>

            {/* Bottom Navigation */}
            <div className="mt-auto pt-6 border-t border-white/20">
              {bottomNavigation.map((item) => (
                <NavItem key={item.href} item={item} />
              ))}
            </div>
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <div className="main-content">
        {/* Top Header */}
        <header className="top-header">
          <div className="flex items-center">
            <Button variant="ghost" size="sm" className="md:hidden mr-4" onClick={() => setSidebarOpen(!sidebarOpen)}>
              {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
            <div>
              <h1 className="header-title">{title}</h1>
              <p className="header-subtitle">{subtitle}</p>
            </div>
          </div>

          <div className="header-right">
            {/* Search */}
            <div className="search-box hidden md:block">
              <Search className="search-icon" />
              <Input
                type="text"
                placeholder="البحث..."
                className="search-input"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            {/* User Profile */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <div className="user-profile">
                  <div className="user-info">
                    <div className="user-name">{user?.name || "أحمد محمد"}</div>
                    <div className="user-role">مدير النظام</div>
                  </div>
                  <div className="user-avatar">
                    <User className="w-5 h-5 text-white" />
                  </div>
                </div>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuItem asChild>
                  <Link href="/settings" className="flex items-center">
                    <Settings className="w-4 h-4 mr-2" />
                    الإعدادات
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={logout} className="text-red-600">
                  <LogOut className="w-4 h-4 mr-2" />
                  تسجيل الخروج
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        {/* Page Content */}
        <main className="dashboard-content">{children}</main>
      </div>

      {/* Mobile Overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 bg-black/50 z-30 md:hidden" onClick={() => setSidebarOpen(false)} />
      )}
    </div>
  )
}
