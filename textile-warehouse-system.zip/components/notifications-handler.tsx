"use client"

import { useState, useEffect } from "react"
import { Bell, X, CheckCircle, AlertTriangle, Info, ArrowRightLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { ScrollArea } from "@/components/ui/scroll-area"
import { toast } from "@/components/ui/use-toast"

interface Notification {
  id: number
  type: "warning" | "info" | "success" | "transfer"
  title: string
  message: string
  read: boolean
  createdAt: string
  url?: string
  relatedId?: number
}

export function NotificationsHandler() {
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: 1,
      type: "warning",
      title: "رصيد منخفض",
      message: "رصيد القطن الأبيض لدى شركة النسيج المتحدة أصبح منخفضاً (15 كجم)",
      read: false,
      createdAt: "2024-03-15 14:30:00",
      url: "/balances",
    },
    {
      id: 2,
      type: "info",
      title: "أمر تشغيل جديد",
      message: "تم إضافة أمر تشغيل جديد رقم PO005 لشركة القطن السعودي",
      read: false,
      createdAt: "2024-03-15 13:15:00",
      url: "/production-orders",
    },
    {
      id: 3,
      type: "success",
      title: "تم التسليم",
      message: "تم تسليم بيان رقم 1001 لشركة النسيج المتحدة بنجاح",
      read: true,
      createdAt: "2024-03-15 12:00:00",
      url: "/invoices",
    },
    {
      id: 4,
      type: "transfer",
      title: "طلب تحويل جديد",
      message: "طلب تحويل أمر التشغيل PO003 من شركة القطن السعودي إلى شركة النسيج المتحدة",
      read: false,
      createdAt: "2024-03-15 10:30:00",
      url: "/invoices",
      relatedId: 1,
    },
    {
      id: 5,
      type: "success",
      title: "تمت الموافقة على طلب التحويل",
      message: "تمت الموافقة على تحويل أمر التشغيل PO002 من مصنع الألوان الحديث إلى شركة النسيج المتحدة",
      read: false,
      createdAt: "2024-03-15 09:45:00",
      url: "/invoices",
      relatedId: 2,
    },
    {
      id: 6,
      type: "warning",
      title: "تم رفض طلب التحويل",
      message:
        "تم رفض تحويل أمر التشغيل PO001 من شركة النسيج المتحدة إلى مصنع الألوان الحديث. السبب: عدم توفر الموافقة المطلوبة",
      read: false,
      createdAt: "2024-03-15 08:20:00",
      url: "/invoices",
      relatedId: 3,
    },
  ])

  const [isOpen, setIsOpen] = useState(false)

  // عدد الإشعارات غير المقروءة
  const unreadCount = notifications.filter((n) => !n.read).length

  // تحديث الإشعارات كل 30 ثانية
  useEffect(() => {
    const interval = setInterval(() => {
      // هنا يمكن إضافة منطق جلب الإشعارات من الخادم
      checkForNewNotifications()
    }, 30000)

    return () => clearInterval(interval)
  }, [])

  // فحص الإشعارات الجديدة
  const checkForNewNotifications = () => {
    // محاكاة فحص الإشعارات الجديدة
    // في التطبيق الحقيقي، سيتم جلب البيانات من API
  }

  // تحديد أيقونة الإشعار حسب النوع
  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "warning":
        return <AlertTriangle className="h-4 w-4 text-yellow-600" />
      case "success":
        return <CheckCircle className="h-4 w-4 text-green-600" />
      case "transfer":
        return <ArrowRightLeft className="h-4 w-4 text-purple-600" />
      default:
        return <Info className="h-4 w-4 text-blue-600" />
    }
  }

  // تحديد لون الخلفية حسب النوع
  const getNotificationBgColor = (type: string) => {
    switch (type) {
      case "warning":
        return "bg-yellow-50 border-yellow-200"
      case "success":
        return "bg-green-50 border-green-200"
      case "transfer":
        return "bg-purple-50 border-purple-200"
      default:
        return "bg-blue-50 border-blue-200"
    }
  }

  // تحديد لون النص حسب النوع
  const getNotificationTextColor = (type: string) => {
    switch (type) {
      case "warning":
        return "text-yellow-800"
      case "success":
        return "text-green-800"
      case "transfer":
        return "text-purple-800"
      default:
        return "text-blue-800"
    }
  }

  // تحديد لون العنوان حسب النوع
  const getNotificationTitleColor = (type: string) => {
    switch (type) {
      case "warning":
        return "text-yellow-900"
      case "success":
        return "text-green-900"
      case "transfer":
        return "text-purple-900"
      default:
        return "text-blue-900"
    }
  }

  // تحديد الإشعار كمقروء
  const markAsRead = (id: number) => {
    setNotifications(
      notifications.map((notification) => (notification.id === id ? { ...notification, read: true } : notification)),
    )
  }

  // تحديد جميع الإشعارات كمقروءة
  const markAllAsRead = () => {
    setNotifications(notifications.map((notification) => ({ ...notification, read: true })))
    toast({
      title: "تم تحديد الكل كمقروء",
      description: "تم تحديد جميع الإشعارات كمقروءة",
    })
  }

  // حذف إشعار
  const deleteNotification = (id: number) => {
    setNotifications(notifications.filter((notification) => notification.id !== id))
    toast({
      title: "تم الحذف",
      description: "تم حذف الإشعار بنجاح",
    })
  }

  // التنقل إلى الصفحة المرتبطة بالإشعار
  const handleNotificationClick = (notification: Notification) => {
    markAsRead(notification.id)
    if (notification.url) {
      // في التطبيق الحقيقي، استخدم router.push
      console.log(`Navigate to: ${notification.url}`)
      window.location.href = notification.url
    }
    setIsOpen(false)
  }

  // تنسيق التاريخ
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60))

    if (diffInMinutes < 1) return "الآن"
    if (diffInMinutes < 60) return `منذ ${diffInMinutes} دقيقة`
    if (diffInMinutes < 1440) return `منذ ${Math.floor(diffInMinutes / 60)} ساعة`
    return `منذ ${Math.floor(diffInMinutes / 1440)} يوم`
  }

  return (
    <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="sm" className="relative">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <Badge
              variant="destructive"
              className="absolute -top-1 -right-1 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs"
            >
              {unreadCount > 99 ? "99+" : unreadCount}
            </Badge>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80 z-50">
        <DropdownMenuLabel className="flex items-center justify-between">
          <span>الإشعارات</span>
          {unreadCount > 0 && (
            <Button variant="ghost" size="sm" onClick={markAllAsRead} className="text-xs">
              تحديد الكل كمقروء
            </Button>
          )}
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <ScrollArea className="h-96">
          {notifications.length > 0 ? (
            notifications.map((notification) => (
              <DropdownMenuItem
                key={notification.id}
                className={`p-0 focus:bg-transparent ${!notification.read ? "bg-gray-50" : ""}`}
                onClick={() => handleNotificationClick(notification)}
              >
                <div
                  className={`w-full p-3 border-r-4 ${getNotificationBgColor(notification.type)} ${
                    !notification.read ? "border-r-blue-500" : "border-r-transparent"
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3 space-x-reverse flex-1">
                      <div className="flex-shrink-0 mt-1">{getNotificationIcon(notification.type)}</div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <p className={`text-sm font-medium ${getNotificationTitleColor(notification.type)}`}>
                            {notification.title}
                          </p>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-6 w-6 p-0 hover:bg-red-100"
                            onClick={(e) => {
                              e.stopPropagation()
                              deleteNotification(notification.id)
                            }}
                          >
                            <X className="h-3 w-3 text-gray-400 hover:text-red-600" />
                          </Button>
                        </div>
                        <p className={`text-xs ${getNotificationTextColor(notification.type)} mt-1 line-clamp-2`}>
                          {notification.message}
                        </p>
                        <p className="text-xs text-gray-500 mt-2">{formatDate(notification.createdAt)}</p>
                      </div>
                    </div>
                  </div>
                  {!notification.read && <div className="absolute top-2 left-2 w-2 h-2 bg-blue-500 rounded-full"></div>}
                </div>
              </DropdownMenuItem>
            ))
          ) : (
            <div className="p-4 text-center text-gray-500">
              <Bell className="h-8 w-8 mx-auto mb-2 text-gray-300" />
              <p>لا توجد إشعارات</p>
            </div>
          )}
        </ScrollArea>
        {notifications.length > 0 && (
          <>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="text-center text-blue-600 hover:text-blue-700 cursor-pointer">
              عرض جميع الإشعارات
            </DropdownMenuItem>
          </>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
