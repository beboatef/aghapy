"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"
import { useRouter, usePathname } from "next/navigation"
import { SidebarLayout } from "@/components/sidebar-layout"

interface User {
  id: string
  name: string
  email: string
  role: "admin" | "user"
  isActive: boolean
}

interface AuthContextType {
  user: User | null
  login: (email: string, password: string) => Promise<boolean>
  logout: () => void
  isAuthenticated: boolean
  isLoading: boolean
  isAdmin: () => boolean
  canDelete: () => boolean
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Default users for demo
const defaultUsers: User[] = [
  {
    id: "1",
    name: "أحمد محمد",
    email: "admin",
    role: "admin",
    isActive: true,
  },
  {
    id: "2",
    name: "محمد أحمد",
    email: "user1",
    role: "user",
    isActive: true,
  },
  {
    id: "3",
    name: "سارة علي",
    email: "user2",
    role: "user",
    isActive: false,
  },
]

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    const checkAuth = () => {
      try {
        const authToken = localStorage.getItem("authToken")
        const userData = localStorage.getItem("user")

        if (authToken && userData) {
          const parsedUser = JSON.parse(userData)
          setUser(parsedUser)
        }
      } catch (error) {
        console.error("Error checking auth:", error)
        localStorage.removeItem("authToken")
        localStorage.removeItem("user")
      }
      setIsLoading(false)
    }

    checkAuth()
  }, [])

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      // Find user
      const foundUser = defaultUsers.find((u) => u.email === email)

      if (!foundUser) {
        throw new Error("المستخدم غير موجود")
      }

      if (!foundUser.isActive) {
        throw new Error("الحساب غير مفعل")
      }

      // Check password (demo: any password works for active users)
      if (password.length < 3) {
        throw new Error("كلمة المرور قصيرة جداً")
      }

      // Set auth data
      const authToken = `token_${foundUser.id}_${Date.now()}`
      localStorage.setItem("authToken", authToken)
      localStorage.setItem("user", JSON.stringify(foundUser))

      setUser(foundUser)
      return true
    } catch (error) {
      console.error("Login error:", error)
      return false
    }
  }

  const logout = () => {
    localStorage.removeItem("authToken")
    localStorage.removeItem("user")
    setUser(null)
    router.push("/login")
  }

  const isAdmin = () => user?.role === "admin"
  const canDelete = () => user?.role === "admin"

  // Show loading screen
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50 dark:bg-gray-900">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600 dark:text-gray-400">جاري التحميل...</p>
        </div>
      </div>
    )
  }

  // Login page - no auth required
  if (pathname === "/login") {
    return (
      <AuthContext.Provider
        value={{
          user,
          login,
          logout,
          isAuthenticated: !!user,
          isLoading,
          isAdmin,
          canDelete,
        }}
      >
        {children}
      </AuthContext.Provider>
    )
  }

  // Protected pages - require auth
  if (!user) {
    router.push("/login")
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50 dark:bg-gray-900">
        <div className="text-center">
          <p className="text-gray-600 dark:text-gray-400">جاري إعادة التوجيه...</p>
        </div>
      </div>
    )
  }

  // Authenticated layout with sidebar
  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        logout,
        isAuthenticated: !!user,
        isLoading,
        isAdmin,
        canDelete,
      }}
    >
      <SidebarLayout>{children}</SidebarLayout>
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
