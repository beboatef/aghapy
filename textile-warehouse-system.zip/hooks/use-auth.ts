"use client"

import { useState, useEffect, useContext } from "react"
import { AuthContext } from "@/components/auth-provider"

interface User {
  id: number
  username: string
  fullName: string
  role: "admin" | "user"
  active: boolean
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

export function useAuthLegacy() {
  // This is just for backward compatibility
  // The main useAuth is now in auth-provider
  return useContext(AuthContext)
}

export function useAuthLocal() {
  const [currentUser, setCurrentUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // محاكاة تحميل بيانات المستخدم الحالي
    // في التطبيق الحقيقي، ستأتي هذه البيانات من JWT أو session
    const loadCurrentUser = () => {
      try {
        const savedUser = localStorage.getItem("currentUser")
        if (savedUser) {
          setCurrentUser(JSON.parse(savedUser))
        } else {
          // مستخدم افتراضي للتجربة (أدمن)
          const defaultUser: User = {
            id: 1,
            username: "admin",
            fullName: "مدير النظام",
            role: "admin",
            active: true,
          }
          setCurrentUser(defaultUser)
          localStorage.setItem("currentUser", JSON.stringify(defaultUser))
        }
      } catch (error) {
        console.error("Error loading user:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadCurrentUser()
  }, [])

  const isAdmin = () => {
    return currentUser?.role === "admin"
  }

  const canDelete = () => {
    return isAdmin()
  }

  const canEdit = () => {
    return currentUser?.active === true
  }

  const login = (username: string, password: string) => {
    // محاكاة تسجيل الدخول
    const users = JSON.parse(localStorage.getItem("users") || "[]")
    const user = users.find((u: any) => u.username === username && u.password === password && u.active)

    if (user) {
      const currentUser: User = {
        id: user.id,
        username: user.username,
        fullName: user.fullName,
        role: user.role,
        active: user.active,
      }
      setCurrentUser(currentUser)
      localStorage.setItem("currentUser", JSON.stringify(currentUser))
      return { success: true, user: currentUser }
    }

    return { success: false, error: "اسم المستخدم أو كلمة المرور غير صحيحة" }
  }

  const logout = () => {
    setCurrentUser(null)
    localStorage.removeItem("currentUser")
  }

  return {
    currentUser,
    isLoading,
    isAdmin,
    canDelete,
    canEdit,
    login,
    logout,
  }
}
