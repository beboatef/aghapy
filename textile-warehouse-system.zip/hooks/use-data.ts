"use client"

import { useState, useEffect } from "react"
import { dataManager } from "@/lib/data-manager"

export function useCustomers() {
  const [customers, setCustomers] = useState(() => dataManager.getCustomers())

  useEffect(() => {
    const updateCustomers = () => {
      setCustomers(dataManager.getCustomers())
    }

    dataManager.addListener("customers", updateCustomers)
    return () => dataManager.removeListener("customers", updateCustomers)
  }, [])

  const updateCustomers = (newCustomers: any[]) => {
    dataManager.setCustomers(newCustomers)
    setCustomers(newCustomers)
  }

  return { customers, updateCustomers }
}

export function useMaterials() {
  const [materials, setMaterials] = useState(() => dataManager.getMaterials())

  useEffect(() => {
    const updateMaterials = () => {
      setMaterials(dataManager.getMaterials())
    }

    dataManager.addListener("materials", updateMaterials)
    return () => dataManager.removeListener("materials", updateMaterials)
  }, [])

  const updateMaterials = (newMaterials: any[]) => {
    dataManager.setMaterials(newMaterials)
    setMaterials(newMaterials)
  }

  return { materials, updateMaterials }
}

export function useUsers() {
  const [users, setUsers] = useState(() => dataManager.getUsers())

  useEffect(() => {
    const updateUsers = () => {
      setUsers(dataManager.getUsers())
    }

    dataManager.addListener("users", updateUsers)
    return () => dataManager.removeListener("users", updateUsers)
  }, [])

  const updateUsers = (newUsers: any[]) => {
    dataManager.setUsers(newUsers)
    setUsers(newUsers)
  }

  return { users, updateUsers }
}

export function useDyeingMaterials() {
  const [dyeingMaterials, setDyeingMaterials] = useState(() => dataManager.getDyeingMaterials())

  useEffect(() => {
    const updateDyeingMaterials = () => {
      setDyeingMaterials(dataManager.getDyeingMaterials())
    }

    dataManager.addListener("dyeingMaterials", updateDyeingMaterials)
    return () => dataManager.removeListener("dyeingMaterials", updateDyeingMaterials)
  }, [])

  const updateDyeingMaterials = (newMaterials: any[]) => {
    dataManager.setDyeingMaterials(newMaterials)
    setDyeingMaterials(newMaterials)
  }

  return { dyeingMaterials, updateDyeingMaterials }
}

export function useMaterialIssuances() {
  const [materialIssuances, setMaterialIssuances] = useState(() => dataManager.getMaterialIssuances())

  useEffect(() => {
    const updateMaterialIssuances = () => {
      setMaterialIssuances(dataManager.getMaterialIssuances())
    }

    dataManager.addListener("materialIssuances", updateMaterialIssuances)
    return () => dataManager.removeListener("materialIssuances", updateMaterialIssuances)
  }, [])

  const updateMaterialIssuances = (newIssuances: any[]) => {
    dataManager.setMaterialIssuances(newIssuances)
    setMaterialIssuances(newIssuances)
  }

  return { materialIssuances, updateMaterialIssuances }
}
