"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { PageLayout } from "@/components/page-layout"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  Plus,
  Edit,
  Trash2,
  Save,
  Zap,
  Droplets,
  Flame,
  Factory,
  Wrench,
  DollarSign,
  Calendar,
  TrendingUp,
} from "lucide-react"
import { dataManager } from "@/lib/data-manager"
import { toast } from "@/components/ui/use-toast"

type IndirectCostCategory = {
  id: string
  name: string
  nameAr: string
  icon: string
  color: string
  unit: string
}

type IndirectCost = {
  id: string
  categoryId: string
  categoryName: string
  date: string
  amount: number
  quantity?: number
  unitPrice?: number
  description: string
  notes?: string
  createdBy: string
  createdAt: string
}

const costCategories: IndirectCostCategory[] = [
  {
    id: "electricity",
    name: "Electricity",
    nameAr: "الكهرباء",
    icon: "zap",
    color: "yellow",
    unit: "kWh",
  },
  {
    id: "water",
    name: "Water",
    nameAr: "المياه",
    icon: "droplets",
    color: "blue",
    unit: "m³",
  },
  {
    id: "gas",
    name: "Gas",
    nameAr: "الغاز",
    icon: "flame",
    color: "orange",
    unit: "m³",
  },
  {
    id: "salt",
    name: "Salt",
    nameAr: "الملح",
    icon: "package",
    color: "gray",
    unit: "kg",
  },
  {
    id: "water_treatment",
    name: "Water Treatment Plant",
    nameAr: "محطة معالجة المياه",
    icon: "factory",
    color: "green",
    unit: "service",
  },
  {
    id: "maintenance",
    name: "Maintenance",
    nameAr: "الصيانة",
    icon: "wrench",
    color: "purple",
    unit: "service",
  },
  {
    id: "other",
    name: "Other",
    nameAr: "أخرى",
    icon: "dollar-sign",
    color: "indigo",
    unit: "item",
  },
]

const getIcon = (iconName: string) => {
  switch (iconName) {
    case "zap":
      return Zap
    case "droplets":
      return Droplets
    case "flame":
      return Flame
    case "factory":
      return Factory
    case "wrench":
      return Wrench
    case "dollar-sign":
      return DollarSign
    default:
      return DollarSign
  }
}

export default function IndirectCostsPage() {
  const [indirectCosts, setIndirectCosts] = useState<IndirectCost[]>([])
  const [showDialog, setShowDialog] = useState(false)
  const [editingCost, setEditingCost] = useState<IndirectCost | null>(null)
  const [activeTab, setActiveTab] = useState("add-cost")
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split("T")[0])

  const [formData, setFormData] = useState({
    categoryId: "",
    amount: "",
    quantity: "",
    unitPrice: "",
    description: "",
    notes: "",
  })

  useEffect(() => {
    loadData()
  }, [])

  const loadData = () => {
    const savedCosts = dataManager.getData("indirectCosts", [])
    setIndirectCosts(savedCosts)
  }

  const resetForm = () => {
    setFormData({
      categoryId: "",
      amount: "",
      quantity: "",
      unitPrice: "",
      description: "",
      notes: "",
    })
    setEditingCost(null)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.categoryId || !formData.amount || !formData.description) {
      toast({
        title: "خطأ في البيانات",
        description: "يرجى ملء جميع الحقول المطلوبة",
        variant: "destructive",
      })
      return
    }

    const category = costCategories.find((c) => c.id === formData.categoryId)
    if (!category) return

    const costData: IndirectCost = {
      id: editingCost ? editingCost.id : `IC-${Date.now()}`,
      categoryId: formData.categoryId,
      categoryName: category.nameAr,
      date: selectedDate,
      amount: Number.parseFloat(formData.amount),
      quantity: formData.quantity ? Number.parseFloat(formData.quantity) : undefined,
      unitPrice: formData.unitPrice ? Number.parseFloat(formData.unitPrice) : undefined,
      description: formData.description,
      notes: formData.notes,
      createdBy: "Current User",
      createdAt: editingCost ? editingCost.createdAt : new Date().toISOString(),
    }

    let updatedCosts: IndirectCost[]
    if (editingCost) {
      updatedCosts = indirectCosts.map((cost) => (cost.id === editingCost.id ? costData : cost))
      toast({
        title: "تم تحديث التكلفة",
        description: `تم تحديث تكلفة ${category.nameAr} بنجاح`,
      })
    } else {
      updatedCosts = [...indirectCosts, costData]
      toast({
        title: "تم إضافة التكلفة",
        description: `تم إضافة تكلفة ${category.nameAr} بمبلغ ${formData.amount} ج.م`,
      })
    }

    dataManager.setData("indirectCosts", updatedCosts)
    setIndirectCosts(updatedCosts)
    resetForm()
    setShowDialog(false)
  }

  const handleEdit = (cost: IndirectCost) => {
    setEditingCost(cost)
    setFormData({
      categoryId: cost.categoryId,
      amount: cost.amount.toString(),
      quantity: cost.quantity?.toString() || "",
      unitPrice: cost.unitPrice?.toString() || "",
      description: cost.description,
      notes: cost.notes || "",
    })
    setSelectedDate(cost.date)
    setShowDialog(true)
  }

  const handleDelete = (costId: string) => {
    const updatedCosts = indirectCosts.filter((cost) => cost.id !== costId)
    dataManager.setData("indirectCosts", updatedCosts)
    setIndirectCosts(updatedCosts)
    toast({
      title: "تم حذف التكلفة",
      description: "تم حذف التكلفة بنجاح",
    })
  }

  const getTodayCosts = () => {
    const today = new Date().toISOString().split("T")[0]
    return indirectCosts.filter((cost) => cost.date === today)
  }

  const getTodayTotal = () => {
    return getTodayCosts().reduce((sum, cost) => sum + cost.amount, 0)
  }

  const getWeekCosts = () => {
    const today = new Date()
    const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000)
    return indirectCosts.filter((cost) => {
      const costDate = new Date(cost.date)
      return costDate >= weekAgo && costDate <= today
    })
  }

  const getWeekTotal = () => {
    return getWeekCosts().reduce((sum, cost) => sum + cost.amount, 0)
  }

  const getCategoryTotal = (categoryId: string, period: "today" | "week") => {
    const costs = period === "today" ? getTodayCosts() : getWeekCosts()
    return costs.filter((cost) => cost.categoryId === categoryId).reduce((sum, cost) => sum + cost.amount, 0)
  }

  const getCategoryColor = (color: string) => {
    switch (color) {
      case "yellow":
        return "bg-yellow-100 text-yellow-800"
      case "blue":
        return "bg-blue-100 text-blue-800"
      case "orange":
        return "bg-orange-100 text-orange-800"
      case "gray":
        return "bg-gray-100 text-gray-800"
      case "green":
        return "bg-green-100 text-green-800"
      case "purple":
        return "bg-purple-100 text-purple-800"
      case "indigo":
        return "bg-indigo-100 text-indigo-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <PageLayout title="التكاليف غير المباشرة">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="add-cost">إضافة تكلفة</TabsTrigger>
          <TabsTrigger value="daily-costs">التكاليف اليومية</TabsTrigger>
          <TabsTrigger value="reports">التقارير</TabsTrigger>
        </TabsList>

        <TabsContent value="add-cost">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Quick Add Cards */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">إضافة سريعة</h3>
              <div className="grid grid-cols-2 gap-4">
                {costCategories.map((category) => {
                  const IconComponent = getIcon(category.icon)
                  return (
                    <Card
                      key={category.id}
                      className="cursor-pointer hover:shadow-md transition-shadow"
                      onClick={() => {
                        setFormData({ ...formData, categoryId: category.id })
                        setShowDialog(true)
                      }}
                    >
                      <CardContent className="p-4 text-center">
                        <IconComponent className={`h-8 w-8 mx-auto mb-2 text-${category.color}-600`} />
                        <div className="font-medium">{category.nameAr}</div>
                        <div className="text-sm text-gray-500">{category.name}</div>
                        <div className="text-xs text-blue-600 mt-1">
                          اليوم: {getCategoryTotal(category.id, "today").toFixed(2)} ج.م
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </div>

            {/* Today's Summary */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  ملخص اليوم
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-blue-600">{getTodayTotal().toFixed(2)} ج.م</div>
                    <div className="text-sm text-gray-500">إجمالي التكاليف غير المباشرة اليوم</div>
                  </div>

                  <div className="space-y-2">
                    {costCategories.map((category) => {
                      const total = getCategoryTotal(category.id, "today")
                      if (total === 0) return null

                      const IconComponent = getIcon(category.icon)
                      return (
                        <div key={category.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                          <div className="flex items-center gap-2">
                            <IconComponent className={`h-4 w-4 text-${category.color}-600`} />
                            <span className="text-sm">{category.nameAr}</span>
                          </div>
                          <span className="font-medium">{total.toFixed(2)} ج.م</span>
                        </div>
                      )
                    })}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="daily-costs">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>التكاليف اليومية</CardTitle>
              <Button onClick={() => setShowDialog(true)}>
                <Plus className="h-4 w-4 mr-2" />
                إضافة تكلفة
              </Button>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>التاريخ</TableHead>
                      <TableHead>الفئة</TableHead>
                      <TableHead>الوصف</TableHead>
                      <TableHead className="text-right">الكمية</TableHead>
                      <TableHead className="text-right">سعر الوحدة</TableHead>
                      <TableHead className="text-right">المبلغ</TableHead>
                      <TableHead>الإجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {indirectCosts
                      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                      .map((cost) => {
                        const category = costCategories.find((c) => c.id === cost.categoryId)
                        const IconComponent = getIcon(category?.icon || "dollar-sign")
                        return (
                          <TableRow key={cost.id}>
                            <TableCell>{cost.date}</TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <IconComponent className={`h-4 w-4 text-${category?.color || "gray"}-600`} />
                                <Badge className={getCategoryColor(category?.color || "gray")}>
                                  {cost.categoryName}
                                </Badge>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div>
                                <div className="font-medium">{cost.description}</div>
                                {cost.notes && <div className="text-sm text-gray-500">{cost.notes}</div>}
                              </div>
                            </TableCell>
                            <TableCell className="text-right">
                              {cost.quantity ? `${cost.quantity} ${category?.unit}` : "—"}
                            </TableCell>
                            <TableCell className="text-right">
                              {cost.unitPrice ? `${cost.unitPrice.toFixed(2)} ج.م` : "—"}
                            </TableCell>
                            <TableCell className="text-right font-medium text-blue-600">
                              {cost.amount.toFixed(2)} ج.م
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                <Button variant="ghost" size="sm" onClick={() => handleEdit(cost)}>
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleDelete(cost.id)}
                                  className="text-red-600 hover:text-red-700"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        )
                      })}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports">
          <div className="space-y-6">
            {/* Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="h-5 w-5 text-blue-600" />
                    اليوم
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-blue-600">{getTodayTotal().toFixed(2)} ج.م</div>
                  <div className="text-sm text-gray-500">{getTodayCosts().length} عنصر</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-green-600" />
                    هذا الأسبوع
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">{getWeekTotal().toFixed(2)} ج.م</div>
                  <div className="text-sm text-gray-500">{getWeekCosts().length} عنصر</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="h-5 w-5 text-purple-600" />
                    متوسط يومي
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-purple-600">{(getWeekTotal() / 7).toFixed(2)} ج.م</div>
                  <div className="text-sm text-gray-500">آخر 7 أيام</div>
                </CardContent>
              </Card>
            </div>

            {/* Category Breakdown */}
            <Card>
              <CardHeader>
                <CardTitle>تفصيل التكاليف حسب الفئة</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-medium mb-4">اليوم</h4>
                    <div className="space-y-2">
                      {costCategories.map((category) => {
                        const total = getCategoryTotal(category.id, "today")
                        const percentage = getTodayTotal() > 0 ? (total / getTodayTotal()) * 100 : 0
                        const IconComponent = getIcon(category.icon)

                        return (
                          <div key={category.id} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                            <div className="flex items-center gap-3">
                              <IconComponent className={`h-5 w-5 text-${category.color}-600`} />
                              <div>
                                <div className="font-medium">{category.nameAr}</div>
                                <div className="text-sm text-gray-500">{percentage.toFixed(1)}%</div>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="font-medium">{total.toFixed(2)} ج.م</div>
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium mb-4">هذا الأسبوع</h4>
                    <div className="space-y-2">
                      {costCategories.map((category) => {
                        const total = getCategoryTotal(category.id, "week")
                        const percentage = getWeekTotal() > 0 ? (total / getWeekTotal()) * 100 : 0
                        const IconComponent = getIcon(category.icon)

                        return (
                          <div key={category.id} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                            <div className="flex items-center gap-3">
                              <IconComponent className={`h-5 w-5 text-${category.color}-600`} />
                              <div>
                                <div className="font-medium">{category.nameAr}</div>
                                <div className="text-sm text-gray-500">{percentage.toFixed(1)}%</div>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="font-medium">{total.toFixed(2)} ج.م</div>
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Add/Edit Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{editingCost ? "تعديل التكلفة" : "إضافة تكلفة غير مباشرة"}</DialogTitle>
            <DialogDescription>أدخل تفاصيل التكلفة غير المباشرة</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="date" className="text-right">
                  التاريخ
                </Label>
                <Input
                  id="date"
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="col-span-3"
                  required
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="category" className="text-right">
                  الفئة
                </Label>
                <select
                  id="category"
                  value={formData.categoryId}
                  onChange={(e) => setFormData({ ...formData, categoryId: e.target.value })}
                  className="col-span-3 flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  required
                >
                  <option value="">اختر الفئة...</option>
                  {costCategories.map((category) => (
                    <option key={category.id} value={category.id}>
                      {category.nameAr}
                    </option>
                  ))}
                </select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="description" className="text-right">
                  الوصف
                </Label>
                <Input
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="col-span-3"
                  placeholder="وصف التكلفة..."
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="quantity">الكمية</Label>
                  <Input
                    id="quantity"
                    type="number"
                    step="0.01"
                    value={formData.quantity}
                    onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                    placeholder="0.00"
                  />
                </div>
                <div>
                  <Label htmlFor="unitPrice">سعر الوحدة</Label>
                  <Input
                    id="unitPrice"
                    type="number"
                    step="0.01"
                    value={formData.unitPrice}
                    onChange={(e) => setFormData({ ...formData, unitPrice: e.target.value })}
                    placeholder="0.00"
                  />
                </div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="amount" className="text-right">
                  المبلغ الإجمالي
                </Label>
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  className="col-span-3"
                  placeholder="0.00"
                  required
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="notes" className="text-right">
                  ملاحظات
                </Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="col-span-3"
                  placeholder="ملاحظات إضافية..."
                  rows={3}
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setShowDialog(false)
                  resetForm()
                }}
              >
                إلغاء
              </Button>
              <Button type="submit">
                <Save className="h-4 w-4 mr-2" />
                {editingCost ? "تحديث" : "حفظ"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </PageLayout>
  )
}
