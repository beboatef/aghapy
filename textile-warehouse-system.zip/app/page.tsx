"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/components/auth-provider"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import {
  BarChart3,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Package,
  Users,
  ShoppingCart,
  AlertTriangle,
  CheckCircle,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
} from "lucide-react"
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip, Line, LineChart } from "recharts"
import { dataManager } from "@/lib/data-manager"
import Link from "next/link"

export default function HomePage() {
  const router = useRouter()
  const { isAuthenticated, isLoading } = useAuth()
  const [stats, setStats] = useState({
    totalOrders: 0,
    totalCustomers: 0,
    totalMaterials: 0,
    totalRevenue: 0,
    pendingOrders: 0,
    completedOrders: 0,
    lowStockItems: 0,
    overduePayments: 0,
  })

  const [chartData, setChartData] = useState([])
  const [revenueData, setRevenueData] = useState([])

  useEffect(() => {
    if (!isLoading) {
      if (isAuthenticated) {
        router.push("/dashboard")
      } else {
        router.push("/login")
      }
    }
  }, [isAuthenticated, isLoading, router])

  useEffect(() => {
    // Load data from data manager
    const customers = dataManager.getCustomers()
    const materials = dataManager.getMaterials()
    const productionOrders = dataManager.getData("productionOrders", [])
    const invoices = dataManager.getData("invoices", [])
    const dyeingMaterials = dataManager.getDyeingMaterials()

    // Calculate statistics
    const totalOrders = productionOrders.length
    const totalCustomers = customers.length
    const totalMaterials = materials.length + dyeingMaterials.length
    const totalRevenue = invoices.reduce((sum: number, invoice: any) => sum + (invoice.totalAmount || 0), 0)
    const pendingOrders = productionOrders.filter((order: any) => order.status === "pending").length
    const completedOrders = productionOrders.filter((order: any) => order.status === "completed").length
    const lowStockItems =
      materials.filter((material: any) => material.currentStock <= material.minimumStock).length +
      dyeingMaterials.filter((material: any) => material.currentStock <= material.minimumStock).length

    setStats({
      totalOrders,
      totalCustomers,
      totalMaterials,
      totalRevenue,
      pendingOrders,
      completedOrders,
      lowStockItems,
      overduePayments: 0,
    })

    // Generate chart data
    const monthlyData = [
      { month: "يناير", orders: 12, revenue: 45000 },
      { month: "فبراير", orders: 19, revenue: 52000 },
      { month: "مارس", orders: 15, revenue: 48000 },
      { month: "أبريل", orders: 22, revenue: 61000 },
      { month: "مايو", orders: 18, revenue: 55000 },
      { month: "يونيو", orders: 25, revenue: 68000 },
    ]

    setChartData(monthlyData)
    setRevenueData(monthlyData)
  }, [isLoading, isAuthenticated])

  const StatCard = ({ title, value, icon: Icon, trend, trendValue, color = "blue" }: any) => (
    <Card className="card-hover">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600 dark:text-gray-400">{title}</p>
            <p className={`text-2xl font-bold text-${color}-600 dark:text-${color}-400`}>
              {typeof value === "number" && value > 1000 ? value.toLocaleString() : value}
            </p>
            {trend && (
              <div className="flex items-center mt-2">
                {trend === "up" ? (
                  <ArrowUpRight className="h-4 w-4 text-green-500" />
                ) : (
                  <ArrowDownRight className="h-4 w-4 text-red-500" />
                )}
                <span className={`text-sm ${trend === "up" ? "text-green-500" : "text-red-500"}`}>{trendValue}%</span>
                <span className="text-sm text-gray-500 mr-2">من الشهر الماضي</span>
              </div>
            )}
          </div>
          <div
            className={`w-12 h-12 bg-${color}-100 dark:bg-${color}-900/20 rounded-lg flex items-center justify-center`}
          >
            <Icon className={`w-6 h-6 text-${color}-600 dark:text-${color}-400`} />
          </div>
        </div>
      </CardContent>
    </Card>
  )

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">جاري التحميل...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold text-gray-900 dark:text-white">مرحباً بك في نظام إدارة المصبغة</h1>
        <p className="text-lg text-gray-600 dark:text-gray-400">لوحة التحكم الرئيسية - نظرة شاملة على أداء المصبغة</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="إجمالي الطلبات"
          value={stats.totalOrders}
          icon={ShoppingCart}
          trend="up"
          trendValue="12"
          color="blue"
        />
        <StatCard
          title="إجمالي العملاء"
          value={stats.totalCustomers}
          icon={Users}
          trend="up"
          trendValue="8"
          color="green"
        />
        <StatCard
          title="إجمالي المواد"
          value={stats.totalMaterials}
          icon={Package}
          trend="down"
          trendValue="3"
          color="purple"
        />
        <StatCard
          title="إجمالي الإيرادات"
          value={`${stats.totalRevenue.toLocaleString()} ج.م`}
          icon={DollarSign}
          trend="up"
          trendValue="15"
          color="yellow"
        />
      </div>

      {/* Secondary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="طلبات معلقة" value={stats.pendingOrders} icon={Clock} color="orange" />
        <StatCard title="طلبات مكتملة" value={stats.completedOrders} icon={CheckCircle} color="green" />
        <StatCard title="مواد منخفضة المخزون" value={stats.lowStockItems} icon={AlertTriangle} color="red" />
        <StatCard title="مدفوعات متأخرة" value={stats.overduePayments} icon={TrendingDown} color="red" />
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Orders Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <BarChart3 className="w-5 h-5 ml-2" />
              الطلبات الشهرية
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="orders" fill="#3B82F6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Revenue Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUp className="w-5 h-5 ml-2" />
              الإيرادات الشهرية
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={revenueData}>
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="revenue" stroke="#10B981" strokeWidth={3} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>الإجراءات السريعة</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Link href="/production-orders">
              <Button className="w-full h-20 flex flex-col items-center justify-center space-y-2">
                <ShoppingCart className="w-6 h-6" />
                <span>أمر تشغيل جديد</span>
              </Button>
            </Link>
            <Link href="/customers">
              <Button variant="outline" className="w-full h-20 flex flex-col items-center justify-center space-y-2">
                <Users className="w-6 h-6" />
                <span>إضافة عميل</span>
              </Button>
            </Link>
            <Link href="/materials">
              <Button variant="outline" className="w-full h-20 flex flex-col items-center justify-center space-y-2">
                <Package className="w-6 h-6" />
                <span>إدارة المواد</span>
              </Button>
            </Link>
            <Link href="/reports">
              <Button variant="outline" className="w-full h-20 flex flex-col items-center justify-center space-y-2">
                <BarChart3 className="w-6 h-6" />
                <span>عرض التقارير</span>
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle>النشاط الأخير</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center space-x-reverse space-x-4 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/40 rounded-full flex items-center justify-center">
                <ShoppingCart className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              </div>
              <div className="flex-1">
                <p className="font-medium">تم إنشاء أمر تشغيل جديد</p>
                <p className="text-sm text-gray-500">أمر رقم PO-001 للعميل شركة النسيج المتحدة</p>
              </div>
              <span className="text-sm text-gray-500">منذ ساعتين</span>
            </div>

            <div className="flex items-center space-x-reverse space-x-4 p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <div className="w-10 h-10 bg-green-100 dark:bg-green-900/40 rounded-full flex items-center justify-center">
                <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400" />
              </div>
              <div className="flex-1">
                <p className="font-medium">تم اكتمال أمر تشغيل</p>
                <p className="text-sm text-gray-500">أمر رقم PO-002 تم تسليمه بنجاح</p>
              </div>
              <span className="text-sm text-gray-500">منذ 4 ساعات</span>
            </div>

            <div className="flex items-center space-x-reverse space-x-4 p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
              <div className="w-10 h-10 bg-yellow-100 dark:bg-yellow-900/40 rounded-full flex items-center justify-center">
                <AlertTriangle className="w-5 h-5 text-yellow-600 dark:text-yellow-400" />
              </div>
              <div className="flex-1">
                <p className="font-medium">تحذير مخزون منخفض</p>
                <p className="text-sm text-gray-500">مادة Direct Blue 86 تحتاج إعادة تموين</p>
              </div>
              <span className="text-sm text-gray-500">منذ يوم</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
