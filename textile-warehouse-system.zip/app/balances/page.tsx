"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { PageLayout } from "@/components/page-layout"
import { Download, Search, FileText, ExternalLink, Database, Filter, Scissors, TruckIcon, Edit } from "lucide-react"

interface Customer {
  id: number
  code: string
  name: string
}

interface Material {
  id: number
  code: string
  name: string
  unit: string
}

interface BalanceRecord {
  customerId: number
  customerName: string
  materialId: number
  materialName: string
  unit: string
  openingBalance: number
  incoming: number
  outgoing: number
  returned: number
  delivered: number
  separatedQuantity: number
  readyQuantity: number
  final: number
}

interface MovementDetail {
  id: number
  date: string
  permitNumber: string
  type: string
  quantity: number
  rollsCount: number
  notes: string
  username: string
  createdAt: string
}

export default function BalancesPage() {
  // مصفوفة العملاء والأصناف - بيانات محاكاة
  const customers: Customer[] = [
    { id: 1, code: "C001", name: "شركة النسيج المتحدة" },
    { id: 2, code: "C002", name: "مصنع الألوان الحديث" },
    { id: 3, code: "C003", name: "شركة القطن السعودي" },
  ]

  const materials: Material[] = [
    { id: 1, code: "M001", name: "قطن أبيض خام", unit: "كجم" },
    { id: 2, code: "M002", name: "بوليستر أزرق", unit: "متر" },
    { id: 3, code: "M003", name: "قطن ملون", unit: "كجم" },
  ]

  // بيانات الأرصدة - بيانات محاكاة
  const [balances, setBalances] = useState<BalanceRecord[]>([])

  // إضافة بيانات منفصلات الإنتاج
  const [productionSeparations, setProductionSeparations] = useState([])

  // بيانات تفاصيل الحركة لصنف معين - بيانات محاكاة
  const [movementDetails, setMovementDetails] = useState<MovementDetail[]>([])

  // متغيرات الحالة والفلاتر
  const [searchTerm, setSearchTerm] = useState("")
  const [customerFilter, setCustomerFilter] = useState("all_customers")
  const [materialFilter, setMaterialFilter] = useState("all_materials")
  const [viewType, setViewType] = useState("by_customer")
  const [showDetailsDialog, setShowDetailsDialog] = useState(false)
  const [selectedBalance, setSelectedBalance] = useState<BalanceRecord | null>(null)
  const [dateFrom, setDateFrom] = useState("")
  const [dateTo, setDateTo] = useState("")
  const [showFiltersDialog, setShowFiltersDialog] = useState(false)

  // States for edit opening balance and adjustment dialogs
  const [showEditOpeningBalanceDialog, setShowEditOpeningBalanceDialog] = useState(false)
  const [showAdjustmentDialog, setShowAdjustmentDialog] = useState(false)
  const [selectedBalanceForEdit, setSelectedBalanceForEdit] = useState<BalanceRecord | null>(null)
  const [newOpeningBalance, setNewOpeningBalance] = useState("")
  const [adjustmentQuantity, setAdjustmentQuantity] = useState("")
  const [adjustmentReason, setAdjustmentReason] = useState("")
  const [adjustmentType, setAdjustmentType] = useState("add")

  // تهيئة البيانات عند تحميل الصفحة
  useEffect(() => {
    const initialBalances: BalanceRecord[] = [
      {
        customerId: 1,
        customerName: "شركة النسيج المتحدة",
        materialId: 1,
        materialName: "قطن أبيض خام",
        unit: "كجم",
        openingBalance: 100,
        incoming: 400,
        outgoing: 240,
        returned: 50,
        delivered: 180,
        separatedQuantity: 15,
        readyQuantity: 20,
        final: 0,
      },
      {
        customerId: 1,
        customerName: "شركة النسيج المتحدة",
        materialId: 2,
        materialName: "بوليستر أزرق",
        unit: "متر",
        openingBalance: 50,
        incoming: 200,
        outgoing: 150,
        returned: 20,
        delivered: 120,
        separatedQuantity: 5,
        readyQuantity: 10,
        final: 0,
      },
      {
        customerId: 2,
        customerName: "مصنع الألوان الحديث",
        materialId: 1,
        materialName: "قطن أبيض خام",
        unit: "كجم",
        openingBalance: 75,
        incoming: 300,
        outgoing: 280,
        returned: 30,
        delivered: 250,
        separatedQuantity: 10,
        readyQuantity: 15,
        final: 0,
      },
      {
        customerId: 2,
        customerName: "مصنع الألوان الحديث",
        materialId: 3,
        materialName: "قطن ملون",
        unit: "كجم",
        openingBalance: 200,
        incoming: 500,
        outgoing: 350,
        returned: 40,
        delivered: 300,
        separatedQuantity: 20,
        readyQuantity: 25,
        final: 0,
      },
      {
        customerId: 3,
        customerName: "شركة القطن السعودي",
        materialId: 2,
        materialName: "بوليستر أزرق",
        unit: "متر",
        openingBalance: 150,
        incoming: 600,
        outgoing: 450,
        returned: 45,
        delivered: 400,
        separatedQuantity: 25,
        readyQuantity: 30,
        final: 0,
      },
    ]

    // حساب الرصيد النهائي لكل سجل
    const balancesWithCalculatedFinal = initialBalances.map((balance) => {
      const finalBalance = balance.openingBalance + balance.incoming - balance.outgoing + balance.returned
      return {
        ...balance,
        final: finalBalance,
      }
    })

    setBalances(balancesWithCalculatedFinal)
  }, [])

  // فلترة الأرصدة
  const filteredBalances = balances.filter((balance) => {
    const matchesSearch = balance.customerName.includes(searchTerm) || balance.materialName.includes(searchTerm)
    const matchesCustomer = customerFilter === "all_customers" || balance.customerId.toString() === customerFilter
    const matchesMaterial = materialFilter === "all_materials" || balance.materialId.toString() === materialFilter

    return matchesSearch && matchesCustomer && matchesMaterial
  })

  // عرض بيانات العملاء أو الأصناف حسب نوع العرض المختار
  const groupedBalances = Array.isArray(filteredBalances)
    ? viewType === "by_customer"
      ? Object.values(
          filteredBalances.reduce(
            (acc, balance) => {
              if (!acc[balance.customerId]) {
                acc[balance.customerId] = {
                  customerId: balance.customerId,
                  customerName: balance.customerName,
                  materials: [],
                }
              }
              acc[balance.customerId].materials.push(balance)
              return acc
            },
            {} as Record<number, any>,
          ),
        )
      : Object.values(
          filteredBalances.reduce(
            (acc, balance) => {
              if (!acc[balance.materialId]) {
                acc[balance.materialId] = {
                  materialId: balance.materialId,
                  materialName: balance.materialName,
                  unit: balance.unit,
                  customers: [],
                  totalOpeningBalance: 0,
                  totalIncoming: 0,
                  totalOutgoing: 0,
                  totalReturned: 0,
                  totalDelivered: 0,
                  totalSeparatedQuantity: 0,
                  totalReadyQuantity: 0,
                  totalFinal: 0,
                }
              }
              acc[balance.materialId].customers.push(balance)
              acc[balance.materialId].totalIncoming += balance.incoming
              acc[balance.materialId].totalOutgoing += balance.outgoing
              acc[balance.materialId].totalReturned += balance.returned
              acc[balance.materialId].totalDelivered += balance.delivered
              acc[balance.materialId].totalSeparatedQuantity += balance.separatedQuantity
              acc[balance.materialId].totalReadyQuantity += balance.readyQuantity
              acc[balance.materialId].totalFinal += balance.final
              acc[balance.materialId].totalOpeningBalance += balance.openingBalance
              return acc
            },
            {} as Record<number, any>,
          ),
        )
    : []

  // عرض تفاصيل الحركة لصنف معين
  const handleShowDetails = (balance: BalanceRecord) => {
    setSelectedBalance(balance)
    setShowDetailsDialog(true)
  }

  // تصدير الأرصدة
  const exportBalances = (format: string) => {
    alert(`تم تصدير الأرصدة بتنسيق ${format}`)
  }

  // طباعة الأرصدة
  const printBalances = () => {
    window.print()
  }

  const handleEditOpeningBalance = (balance: BalanceRecord) => {
    setSelectedBalanceForEdit(balance)
    setNewOpeningBalance(balance.openingBalance.toString())
    setShowEditOpeningBalanceDialog(true)
  }

  const handleSaveOpeningBalance = () => {
    if (selectedBalanceForEdit) {
      const updatedBalances = balances.map((balance) => {
        if (
          balance.customerId === selectedBalanceForEdit.customerId &&
          balance.materialId === selectedBalanceForEdit.materialId
        ) {
          const newBalance = Number.parseFloat(newOpeningBalance)
          const finalBalance = newBalance + balance.incoming - balance.outgoing + balance.returned
          return {
            ...balance,
            openingBalance: newBalance,
            final: finalBalance,
          }
        }
        return balance
      })
      setBalances(updatedBalances)
      setShowEditOpeningBalanceDialog(false)
    }
  }

  const handleAdjustment = (balance: BalanceRecord) => {
    setSelectedBalanceForEdit(balance)
    setAdjustmentQuantity("")
    setAdjustmentReason("")
    setAdjustmentType("add")
    setShowAdjustmentDialog(true)
  }

  const handleSaveAdjustment = () => {
    if (selectedBalanceForEdit) {
      const quantity = Number.parseFloat(adjustmentQuantity)
      const updatedBalances = balances.map((balance) => {
        if (
          balance.customerId === selectedBalanceForEdit.customerId &&
          balance.materialId === selectedBalanceForEdit.materialId
        ) {
          return {
            ...balance,
            final: adjustmentType === "add" ? balance.final + quantity : balance.final - quantity,
          }
        }
        return balance
      })
      setBalances(updatedBalances)
      setShowAdjustmentDialog(false)
    }
  }

  return (
    <PageLayout title="الأرصدة">
      {/* رأس الصفحة */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
        <h1 className="page-title mb-4 sm:mb-0">
          <Database className="page-icon text-blue-600" />
          الأرصدة
        </h1>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm" onClick={() => setShowFiltersDialog(true)}>
            <Filter className="h-4 w-4 ml-2" />
            فلاتر متقدمة
          </Button>
          <Button variant="outline" size="sm" onClick={() => exportBalances("Excel")}>
            <Download className="h-4 w-4 ml-2" />
            تصدير Excel
          </Button>
          <Button variant="outline" size="sm" onClick={() => exportBalances("PDF")}>
            <FileText className="h-4 w-4 ml-2" />
            تصدير PDF
          </Button>
          <Button variant="outline" size="sm" onClick={printBalances}>
            <FileText className="h-4 w-4 ml-2" />
            طباعة
          </Button>
        </div>
      </div>

      {/* فلاتر وعرض */}
      <Card className="mb-6 border-0 shadow-sm">
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div className="relative">
              <Search className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="البحث..."
                className="pr-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Select value={customerFilter} onValueChange={setCustomerFilter}>
              <SelectTrigger>
                <SelectValue placeholder="العميل" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all_customers">جميع العملاء</SelectItem>
                {Array.isArray(customers) &&
                  customers.map((customer) => (
                    <SelectItem key={customer.id} value={customer.id.toString()}>
                      {customer.name}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
            <Select value={materialFilter} onValueChange={setMaterialFilter}>
              <SelectTrigger>
                <SelectValue placeholder="الصنف" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all_materials">جميع الأصناف</SelectItem>
                {Array.isArray(materials) &&
                  materials.map((material) => (
                    <SelectItem key={material.id} value={material.id.toString()}>
                      {material.name}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
          </div>

          <Tabs value={viewType} onValueChange={setViewType} className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="by_customer">عرض حسب العملاء</TabsTrigger>
              <TabsTrigger value="by_material">عرض حسب الأصناف</TabsTrigger>
              <TabsTrigger value="separations">منفصلات الإنتاج</TabsTrigger>
            </TabsList>
          </Tabs>
        </CardContent>
      </Card>

      {/* عرض الأرصدة */}
      <Tabs value={viewType} onValueChange={setViewType} className="w-full">
        <TabsContent value="by_customer" className="space-y-6">
          {Array.isArray(groupedBalances) &&
            groupedBalances.map((group: any) => (
              <Card key={group.customerId} className="border-0 shadow-sm">
                <CardHeader className="pb-2 bg-gray-50">
                  <CardTitle className="flex items-center justify-between">
                    <span>العميل: {group.customerName}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b bg-gray-50">
                          <th className="text-right p-3">الصنف</th>
                          <th className="text-right p-3">الوحدة</th>
                          <th className="text-right p-3 bg-blue-50">رصيد بداية المدة</th>
                          <th className="text-right p-3">إجمالي الوارد</th>
                          <th className="text-right p-3">إجمالي المنصرف</th>
                          <th className="text-right p-3">إجمالي المرتجع</th>
                          <th className="text-right p-3 bg-green-50">الكمية المسلمة</th>
                          <th className="text-right p-3 text-orange-600">المنفصلات</th>
                          <th className="text-right p-3 text-sky-500 bg-sky-50">الكمية الجاهزة</th>
                          <th className="text-right p-3">الرصيد النهائي</th>
                          <th className="text-right p-3">الرصيد مخصوم منه الجاهز</th>
                          <th className="text-right p-3">تفاصيل الحركة</th>
                          <th className="text-right p-3">الإجراءات</th>
                        </tr>
                      </thead>
                      <tbody>
                        {Array.isArray(group.materials) &&
                          group.materials.map((balance: BalanceRecord) => {
                            const finalBalanceAdjusted = balance.final - balance.readyQuantity
                            return (
                              <tr
                                key={`${balance.customerId}-${balance.materialId}`}
                                className="border-b hover:bg-gray-50"
                              >
                                <td className="p-3">{balance.materialName}</td>
                                <td className="p-3">{balance.unit}</td>
                                <td className="p-3 text-blue-600 font-medium bg-blue-50">
                                  <div className="flex items-center">
                                    <Database className="h-4 w-4 ml-1" />
                                    {balance.openingBalance}
                                  </div>
                                </td>
                                <td className="p-3 text-blue-600">{balance.incoming}</td>
                                <td className="p-3 text-red-600">{balance.outgoing}</td>
                                <td className="p-3 text-orange-600">{balance.returned}</td>
                                <td className="p-3 text-green-600 font-medium bg-green-50">
                                  <div className="flex items-center">
                                    <TruckIcon className="h-4 w-4 ml-1" />
                                    {balance.delivered}
                                  </div>
                                </td>
                                <td className="p-3 text-orange-600 font-medium">{balance.separatedQuantity}</td>
                                <td className="p-3 text-sky-600 font-medium bg-sky-50">{balance.readyQuantity}</td>
                                <td className="p-3 text-green-600 font-bold">{balance.final}</td>
                                <td className="p-3 text-purple-600 font-bold">{finalBalanceAdjusted}</td>
                                <td className="p-3">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="text-blue-600"
                                    onClick={() => handleShowDetails(balance)}
                                  >
                                    <ExternalLink className="h-4 w-4 ml-1" />
                                    عرض التفاصيل
                                  </Button>
                                </td>
                                <td className="p-3">
                                  <div className="flex gap-1">
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => handleEditOpeningBalance(balance)}
                                    >
                                      <Edit className="h-3 w-3 ml-1" />
                                      تعديل الرصيد
                                    </Button>
                                    <Button variant="outline" size="sm" onClick={() => handleAdjustment(balance)}>
                                      <Edit className="h-3 w-3 ml-1" />
                                      عمل تسوية
                                    </Button>
                                  </div>
                                </td>
                              </tr>
                            )
                          })}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            ))}
          {groupedBalances.length === 0 && (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-8 text-center text-gray-500">لا توجد أرصدة للعرض</CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="by_material" className="space-y-6">
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-2">
              <CardTitle>الأرصدة حسب الأصناف</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b bg-gray-50">
                      <th className="text-right p-3">الصنف</th>
                      <th className="text-right p-3">الوحدة</th>
                      <th className="text-right p-3 bg-blue-50">إجمالي رصيد البداية</th>
                      <th className="text-right p-3">إجمالي الوارد</th>
                      <th className="text-right p-3">إجمالي المنصرف</th>
                      <th className="text-right p-3">إجمالي المرتجع</th>
                      <th className="text-right p-3 bg-green-50">إجمالي المسلم</th>
                      <th className="text-right p-3 text-orange-600">إجمالي المنفصلات</th>
                      <th className="text-right p-3 text-sky-500 bg-sky-50">إجمالي الكمية الجاهزة</th>
                      <th className="text-right p-3">الرصيد النهائي</th>
                      <th className="text-right p-3">تفاصيل الحركة</th>
                    </tr>
                  </thead>
                  <tbody>
                    {groupedBalances.map((group: any) => (
                      <tr key={group.materialId} className="border-b hover:bg-gray-50">
                        <td className="p-3">{group.materialName}</td>
                        <td className="p-3">{group.unit}</td>
                        <td className="p-3 text-blue-600 font-medium bg-blue-50">
                          <div className="flex items-center">
                            <Database className="h-4 w-4 ml-1" />
                            {group.totalOpeningBalance}
                          </div>
                        </td>
                        <td className="p-3 text-blue-600">{group.totalIncoming}</td>
                        <td className="p-3 text-red-600">{group.totalOutgoing}</td>
                        <td className="p-3 text-orange-600">{group.totalReturned}</td>
                        <td className="p-3 text-green-600 font-medium bg-green-50">
                          <div className="flex items-center">
                            <TruckIcon className="h-4 w-4 ml-1" />
                            {group.totalDelivered}
                          </div>
                        </td>
                        <td className="p-3 text-orange-600 font-medium">{group.totalSeparatedQuantity}</td>
                        <td className="p-3 text-sky-600 font-medium bg-sky-50">{group.totalReadyQuantity}</td>
                        <td className="p-3 text-green-600 font-bold">{group.totalFinal}</td>
                        <td className="p-3">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setMaterialFilter(group.materialId.toString())}
                          >
                            عرض التفاصيل حسب العملاء
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="separations" className="space-y-6">
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center">
                <Scissors className="h-5 w-5 ml-2 text-orange-600" />
                منفصلات الإنتاج
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b bg-gray-50">
                      <th className="text-right p-3">رقم المنفصل</th>
                      <th className="text-right p-3">العميل</th>
                      <th className="text-right p-3">الصنف</th>
                      <th className="text-right p-3">الكمية</th>
                      <th className="text-right p-3">عدد الأتواب</th>
                      <th className="text-right p-3">سبب الفصل</th>
                      <th className="text-right p-3">الحالة</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Array.isArray(productionSeparations) &&
                      productionSeparations
                        .filter((sep) => {
                          const matchesSearch =
                            sep.customerName.includes(searchTerm) ||
                            sep.materialName.includes(searchTerm) ||
                            sep.separationNumber.includes(searchTerm)
                          const matchesCustomer =
                            customerFilter === "all_customers" || sep.customerId.toString() === customerFilter
                          const matchesMaterial =
                            materialFilter === "all_materials" || sep.materialId.toString() === materialFilter
                          return matchesSearch && matchesCustomer && matchesMaterial
                        })
                        .map((separation) => (
                          <tr key={separation.id} className="border-b hover:bg-gray-50">
                            <td className="p-3 font-mono">{separation.separationNumber}</td>
                            <td className="p-3">{separation.customerName}</td>
                            <td className="p-3">{separation.materialName}</td>
                            <td className="p-3 text-orange-600 font-medium">
                              {separation.separatedQuantity} {separation.unit}
                            </td>
                            <td className="p-3">{separation.rollsCount}</td>
                            <td className="p-3">{separation.separationReason}</td>
                            <td className="p-3">
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                                متاح للإعادة تشغيل
                              </span>
                            </td>
                          </tr>
                        ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* نافذة تفاصيل الحركة */}
      <Dialog open={showDetailsDialog} onOpenChange={setShowDetailsDialog}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>
              تفاصيل حركة الصنف: {selectedBalance?.materialName} - {selectedBalance?.customerName}
            </DialogTitle>
            <DialogDescription>جميع العمليات والحركات على هذا الصنف لهذا العميل</DialogDescription>
          </DialogHeader>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-right p-3">التاريخ</th>
                  <th className="text-right p-3">رقم الإذن</th>
                  <th className="text-right p-3">نوع الحركة</th>
                  <th className="text-right p-3">الكمية</th>
                  <th className="text-right p-3">عدد الأتواب</th>
                  <th className="text-right p-3">ملاحظات</th>
                  <th className="text-right p-3">المستخدم</th>
                  <th className="text-right p-3">تاريخ العملية</th>
                </tr>
              </thead>
              <tbody>
                {Array.isArray(movementDetails) &&
                  movementDetails.map((detail) => (
                    <tr key={detail.id} className="border-b hover:bg-gray-50">
                      <td className="p-3">{detail.date}</td>
                      <td className="p-3 font-mono">{detail.permitNumber}</td>
                      <td className="p-3">
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            detail.type === "وارد"
                              ? "bg-blue-100 text-blue-800"
                              : detail.type === "منصرف"
                                ? "bg-red-100 text-red-800"
                                : detail.type === "تسليم"
                                  ? "bg-green-100 text-green-800"
                                  : "bg-orange-100 text-orange-800"
                          }`}
                        >
                          {detail.type}
                        </span>
                      </td>
                      <td className="p-3">
                        {detail.quantity} {selectedBalance?.unit}
                      </td>
                      <td className="p-3">{detail.rollsCount}</td>
                      <td className="p-3">{detail.notes || "-"}</td>
                      <td className="p-3">{detail.username}</td>
                      <td className="p-3 text-gray-500 text-sm">{detail.createdAt}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
          <div className="flex justify-end">
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setShowDetailsDialog(false)
              }}
            >
              إغلاق
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* نافذة الفلاتر المتقدمة */}
      <Dialog open={showFiltersDialog} onOpenChange={setShowFiltersDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>فلاتر متقدمة</DialogTitle>
            <DialogDescription>تحديد نطاق زمني وفلاتر إضافية للأرصدة</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="dateFrom" className="text-right">
                من تاريخ
              </Label>
              <Input
                id="dateFrom"
                type="date"
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="dateTo" className="text-right">
                إلى تاريخ
              </Label>
              <Input
                id="dateTo"
                type="date"
                value={dateTo}
                onChange={(e) => setDateTo(e.target.value)}
                className="col-span-3"
              />
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="customer" className="text-right">
                العميل
              </Label>
              <Select value={customerFilter} onValueChange={setCustomerFilter}>
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="العميل" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all_customers">جميع العملاء</SelectItem>
                  {customers.map((customer) => (
                    <SelectItem key={customer.id} value={customer.id.toString()}>
                      {customer.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="material" className="text-right">
                الصنف
              </Label>
              <Select value={materialFilter} onValueChange={setMaterialFilter}>
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="الصنف" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all_materials">جميع الأصناف</SelectItem>
                  {materials.map((material) => (
                    <SelectItem key={material.id} value={material.id.toString()}>
                      {material.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button
              variant="outline"
              onClick={() => {
                setDateFrom("")
                setDateTo("")
                setCustomerFilter("all_customers")
                setMaterialFilter("all_materials")
                setSearchTerm("")
              }}
            >
              إعادة تعيين
            </Button>
            <Button onClick={() => setShowFiltersDialog(false)}>تطبيق الفلاتر</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Opening Balance Dialog */}
      <Dialog open={showEditOpeningBalanceDialog} onOpenChange={setShowEditOpeningBalanceDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>تعديل رصيد بداية المدة</DialogTitle>
            <DialogDescription>أدخل الرصيد الجديد لبداية المدة</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="newOpeningBalance" className="text-right">
                الرصيد الجديد
              </Label>
              <Input
                id="newOpeningBalance"
                type="number"
                value={newOpeningBalance}
                onChange={(e) => setNewOpeningBalance(e.target.value)}
                className="col-span-3"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setShowEditOpeningBalanceDialog(false)}>
              إلغاء
            </Button>
            <Button onClick={handleSaveOpeningBalance}>حفظ</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Adjustment Dialog */}
      <Dialog open={showAdjustmentDialog} onOpenChange={setShowAdjustmentDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>عمل تسوية</DialogTitle>
            <DialogDescription>إضافة أو خصم كمية معينة مع ذكر السبب</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="adjustmentType" className="text-right">
                نوع التسوية
              </Label>
              <Select value={adjustmentType} onValueChange={setAdjustmentType}>
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="اختر نوع التسوية" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="add">إضافة</SelectItem>
                  <SelectItem value="subtract">خصم</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="adjustmentQuantity" className="text-right">
                الكمية
              </Label>
              <Input
                id="adjustmentQuantity"
                type="number"
                value={adjustmentQuantity}
                onChange={(e) => setAdjustmentQuantity(e.target.value)}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="adjustmentReason" className="text-right">
                السبب
              </Label>
              <Input
                id="adjustmentReason"
                type="text"
                value={adjustmentReason}
                onChange={(e) => setAdjustmentReason(e.target.value)}
                className="col-span-3"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setShowAdjustmentDialog(false)}>
              إلغاء
            </Button>
            <Button onClick={handleSaveAdjustment}>حفظ</Button>
          </div>
        </DialogContent>
      </Dialog>
    </PageLayout>
  )
}
