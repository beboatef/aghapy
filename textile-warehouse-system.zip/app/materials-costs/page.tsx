"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { PageLayout } from "@/components/page-layout"
import { DollarSign, Plus, Search, Download, Upload, Trash2, AlertTriangle, Palette, Wrench } from "lucide-react"
import { useAuth } from "@/hooks/use-auth"

interface DyeingMaterial {
  id: number
  name: string
  category: string
  unit: string
  pricePerUnit: number
  supplier: string
  notes?: string
  createdAt: string
}

interface ProcessingMaterial {
  id: number
  name: string
  category: string
  unit: string
  pricePerUnit: number
  supplier: string
  notes?: string
  createdAt: string
}

export default function MaterialsCostsPage() {
  const [activeTab, setActiveTab] = useState("dyeing")
  const [showDyeingDialog, setShowDyeingDialog] = useState(false)
  const [showProcessingDialog, setShowProcessingDialog] = useState(false)
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all_categories")
  const [selectedMaterial, setSelectedMaterial] = useState<DyeingMaterial | ProcessingMaterial | null>(null)
  const [materialType, setMaterialType] = useState<"dyeing" | "processing">("dyeing")

  const { canDelete } = useAuth()

  // بيانات مواد الصباغة
  const [dyeingMaterials, setDyeingMaterials] = useState<DyeingMaterial[]>([
    {
      id: 1,
      name: "صبغة أزرق مباشر",
      category: "صبغات مباشرة",
      unit: "كجم",
      pricePerUnit: 45.5,
      supplier: "شركة الكيماويات المصرية",
      notes: "للقطن والكتان",
      createdAt: "2024-01-15",
    },
    {
      id: 2,
      name: "صبغة أحمر تفاعلي",
      category: "صبغات تفاعلية",
      unit: "كجم",
      pricePerUnit: 52.75,
      supplier: "مؤسسة الألوان الحديثة",
      notes: "مقاومة للغسيل",
      createdAt: "2024-01-20",
    },
    {
      id: 3,
      name: "ملح الطعام",
      category: "مواد مساعدة",
      unit: "كجم",
      pricePerUnit: 3.25,
      supplier: "شركة الملح المصري",
      createdAt: "2024-02-01",
    },
    {
      id: 4,
      name: "كربونات الصوديوم",
      category: "مواد مساعدة",
      unit: "كجم",
      pricePerUnit: 8.9,
      supplier: "الشركة العربية للكيماويات",
      notes: "درجة نقاء عالية",
      createdAt: "2024-02-05",
    },
  ])

  // بيانات مواد التجهيز
  const [processingMaterials, setProcessingMaterials] = useState<ProcessingMaterial[]>([
    {
      id: 1,
      name: "منعم أقمشة",
      category: "منعمات",
      unit: "لتر",
      pricePerUnit: 28.5,
      supplier: "شركة المنظفات المتقدمة",
      notes: "للأقمشة القطنية",
      createdAt: "2024-01-18",
    },
    {
      id: 2,
      name: "مثبت لون",
      category: "مثبتات",
      unit: "كجم",
      pricePerUnit: 35.75,
      supplier: "مؤسسة الكيماويات الصناعية",
      notes: "يحافظ على ثبات اللون",
      createdAt: "2024-01-25",
    },
    {
      id: 3,
      name: "مضاد للتجعد",
      category: "مواد تشطيب",
      unit: "لتر",
      pricePerUnit: 42.0,
      supplier: "شركة التشطيب الحديث",
      createdAt: "2024-02-10",
    },
    {
      id: 4,
      name: "مقاوم للماء",
      category: "مواد تشطيب",
      unit: "لتر",
      pricePerUnit: 65.25,
      supplier: "الشركة المتخصصة للتشطيب",
      notes: "للأقمشة الخارجية",
      createdAt: "2024-02-15",
    },
  ])

  const [dyeingFormData, setDyeingFormData] = useState({
    name: "",
    category: "",
    unit: "كجم",
    pricePerUnit: "",
    supplier: "",
    notes: "",
  })

  const [processingFormData, setProcessingFormData] = useState({
    name: "",
    category: "",
    unit: "لتر",
    pricePerUnit: "",
    supplier: "",
    notes: "",
  })

  // فئات مواد الصباغة
  const dyeingCategories = [
    "صبغات مباشرة",
    "صبغات تفاعلية",
    "صبغات حمضية",
    "صبغات قاعدية",
    "مواد مساعدة",
    "مواد تحضيرية",
  ]

  // فئات مواد التجهيز
  const processingCategories = ["منعمات", "مثبتات", "مواد تشطيب", "مضادات التجعد", "مقاومات الماء", "مواد حماية"]

  // فلترة المواد
  const filteredDyeingMaterials = dyeingMaterials.filter((material) => {
    const matchesSearch = material.name.includes(searchTerm) || material.supplier.includes(searchTerm)
    const matchesCategory = categoryFilter === "all_categories" || material.category === categoryFilter
    return matchesSearch && matchesCategory
  })

  const filteredProcessingMaterials = processingMaterials.filter((material) => {
    const matchesSearch = material.name.includes(searchTerm) || material.supplier.includes(searchTerm)
    const matchesCategory = categoryFilter === "all_categories" || material.category === categoryFilter
    return matchesSearch && matchesCategory
  })

  // إحصائيات سريعة
  const dyeingStats = {
    totalMaterials: dyeingMaterials.length,
    totalValue: dyeingMaterials.reduce((sum, material) => sum + material.pricePerUnit, 0),
    avgPrice: dyeingMaterials.reduce((sum, material) => sum + material.pricePerUnit, 0) / dyeingMaterials.length,
  }

  const processingStats = {
    totalMaterials: processingMaterials.length,
    totalValue: processingMaterials.reduce((sum, material) => sum + material.pricePerUnit, 0),
    avgPrice:
      processingMaterials.reduce((sum, material) => sum + material.pricePerUnit, 0) / processingMaterials.length,
  }

  // إضافة مادة صباغة
  const handleAddDyeingMaterial = () => {
    const newMaterial: DyeingMaterial = {
      id: Date.now(),
      name: dyeingFormData.name,
      category: dyeingFormData.category,
      unit: dyeingFormData.unit,
      pricePerUnit: Number.parseFloat(dyeingFormData.pricePerUnit),
      supplier: dyeingFormData.supplier,
      notes: dyeingFormData.notes,
      createdAt: new Date().toISOString().split("T")[0],
    }

    setDyeingMaterials([...dyeingMaterials, newMaterial])
    setShowDyeingDialog(false)
    setDyeingFormData({
      name: "",
      category: "",
      unit: "كجم",
      pricePerUnit: "",
      supplier: "",
      notes: "",
    })
  }

  // إضافة مادة تجهيز
  const handleAddProcessingMaterial = () => {
    const newMaterial: ProcessingMaterial = {
      id: Date.now(),
      name: processingFormData.name,
      category: processingFormData.category,
      unit: processingFormData.unit,
      pricePerUnit: Number.parseFloat(processingFormData.pricePerUnit),
      supplier: processingFormData.supplier,
      notes: processingFormData.notes,
      createdAt: new Date().toISOString().split("T")[0],
    }

    setProcessingMaterials([...processingMaterials, newMaterial])
    setShowProcessingDialog(false)
    setProcessingFormData({
      name: "",
      category: "",
      unit: "لتر",
      pricePerUnit: "",
      supplier: "",
      notes: "",
    })
  }

  // حذف مادة
  const handleDeleteMaterial = () => {
    if (selectedMaterial && materialType) {
      if (materialType === "dyeing") {
        setDyeingMaterials(dyeingMaterials.filter((material) => material.id !== selectedMaterial.id))
      } else {
        setProcessingMaterials(processingMaterials.filter((material) => material.id !== selectedMaterial.id))
      }
      setShowDeleteDialog(false)
      setSelectedMaterial(null)
      alert(`تم حذف المادة ${selectedMaterial.name} بنجاح`)
    }
  }

  // فتح نافذة الحذف
  const openDeleteDialog = (material: DyeingMaterial | ProcessingMaterial, type: "dyeing" | "processing") => {
    setSelectedMaterial(material)
    setMaterialType(type)
    setShowDeleteDialog(true)
  }

  return (
    <PageLayout title="تكاليف المواد">
      {/* رأس الصفحة */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
        <h1 className="page-title mb-4 sm:mb-0">
          <DollarSign className="page-icon text-purple-600" />
          إدارة تكاليف المواد
        </h1>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm">
            <Upload className="h-4 w-4 ml-2" />
            استيراد Excel
          </Button>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 ml-2" />
            تصدير Excel
          </Button>
        </div>
      </div>

      {/* إحصائيات سريعة */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">مواد الصباغة</p>
                <p className="text-2xl font-bold text-blue-600">{dyeingStats.totalMaterials}</p>
                <p className="text-xs text-gray-500">إجمالي القيمة: {dyeingStats.totalValue.toFixed(2)} ج.م</p>
              </div>
              <Palette className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">مواد التجهيز</p>
                <p className="text-2xl font-bold text-green-600">{processingStats.totalMaterials}</p>
                <p className="text-xs text-gray-500">إجمالي القيمة: {processingStats.totalValue.toFixed(2)} ج.م</p>
              </div>
              <Wrench className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">متوسط سعر الصباغة</p>
                <p className="text-2xl font-bold text-purple-600">{dyeingStats.avgPrice.toFixed(2)}</p>
                <p className="text-xs text-gray-500">ج.م / وحدة</p>
              </div>
              <DollarSign className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">متوسط سعر التجهيز</p>
                <p className="text-2xl font-bold text-orange-600">{processingStats.avgPrice.toFixed(2)}</p>
                <p className="text-xs text-gray-500">ج.م / وحدة</p>
              </div>
              <DollarSign className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* تبويبات المواد */}
      <Tabs defaultValue="dyeing" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="dyeing" className="text-blue-600">
            <Palette className="h-4 w-4 ml-2" />
            مواد الصباغة
          </TabsTrigger>
          <TabsTrigger value="processing" className="text-green-600">
            <Wrench className="h-4 w-4 ml-2" />
            مواد التجهيز
          </TabsTrigger>
        </TabsList>

        {/* مواد الصباغة */}
        <TabsContent value="dyeing">
          <Card className="mb-6 border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4">
                <h3 className="text-lg font-semibold text-blue-600 mb-2 sm:mb-0">مواد الصباغة</h3>
                <Button onClick={() => setShowDyeingDialog(true)} size="sm" className="bg-blue-600 hover:bg-blue-700">
                  <Plus className="h-4 w-4 ml-2" />
                  إضافة مادة صباغة
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div className="relative">
                  <Search className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="بحث في مواد الصباغة..."
                    className="pr-10"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="الفئة" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all_categories">جميع الفئات</SelectItem>
                    {dyeingCategories.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-right p-3">اسم المادة</th>
                      <th className="text-right p-3">الفئة</th>
                      <th className="text-right p-3">الوحدة</th>
                      <th className="text-right p-3">السعر/الوحدة</th>
                      <th className="text-right p-3">المورد</th>
                      <th className="text-right p-3">ملاحظات</th>
                      {canDelete() && <th className="text-right p-3">الإجراءات</th>}
                    </tr>
                  </thead>
                  <tbody>
                    {filteredDyeingMaterials.length > 0 ? (
                      filteredDyeingMaterials.map((material) => (
                        <tr key={material.id} className="border-b hover:bg-gray-50">
                          <td className="p-3 font-medium">{material.name}</td>
                          <td className="p-3">
                            <span className="badge badge-blue">{material.category}</span>
                          </td>
                          <td className="p-3">{material.unit}</td>
                          <td className="p-3 font-bold text-blue-600">{material.pricePerUnit.toFixed(2)} ج.م</td>
                          <td className="p-3">{material.supplier}</td>
                          <td className="p-3 text-gray-600 truncate max-w-xs">{material.notes || "—"}</td>
                          {canDelete() && (
                            <td className="p-3">
                              <Button
                                size="sm"
                                variant="ghost"
                                className="text-red-600 hover:text-red-700 hover:bg-red-50"
                                onClick={() => openDeleteDialog(material, "dyeing")}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </td>
                          )}
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={canDelete() ? 7 : 6} className="p-4 text-center text-gray-500">
                          لا توجد مواد صباغة للعرض
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* مواد التجهيز */}
        <TabsContent value="processing">
          <Card className="mb-6 border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4">
                <h3 className="text-lg font-semibold text-green-600 mb-2 sm:mb-0">مواد التجهيز</h3>
                <Button
                  onClick={() => setShowProcessingDialog(true)}
                  size="sm"
                  className="bg-green-600 hover:bg-green-700"
                >
                  <Plus className="h-4 w-4 ml-2" />
                  إضافة مادة تجهيز
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div className="relative">
                  <Search className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="بحث في مواد التجهيز..."
                    className="pr-10"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="الفئة" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all_categories">جميع الفئات</SelectItem>
                    {processingCategories.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-right p-3">اسم المادة</th>
                      <th className="text-right p-3">الفئة</th>
                      <th className="text-right p-3">الوحدة</th>
                      <th className="text-right p-3">السعر/الوحدة</th>
                      <th className="text-right p-3">المورد</th>
                      <th className="text-right p-3">ملاحظات</th>
                      {canDelete() && <th className="text-right p-3">الإجراءات</th>}
                    </tr>
                  </thead>
                  <tbody>
                    {filteredProcessingMaterials.length > 0 ? (
                      filteredProcessingMaterials.map((material) => (
                        <tr key={material.id} className="border-b hover:bg-gray-50">
                          <td className="p-3 font-medium">{material.name}</td>
                          <td className="p-3">
                            <span className="badge badge-green">{material.category}</span>
                          </td>
                          <td className="p-3">{material.unit}</td>
                          <td className="p-3 font-bold text-green-600">{material.pricePerUnit.toFixed(2)} ج.م</td>
                          <td className="p-3">{material.supplier}</td>
                          <td className="p-3 text-gray-600 truncate max-w-xs">{material.notes || "—"}</td>
                          {canDelete() && (
                            <td className="p-3">
                              <Button
                                size="sm"
                                variant="ghost"
                                className="text-red-600 hover:text-red-700 hover:bg-red-50"
                                onClick={() => openDeleteDialog(material, "processing")}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </td>
                          )}
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={canDelete() ? 7 : 6} className="p-4 text-center text-gray-500">
                          لا توجد مواد تجهيز للعرض
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* نافذة إضافة مادة صباغة */}
      <Dialog open={showDyeingDialog} onOpenChange={setShowDyeingDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>إضافة مادة صباغة جديدة</DialogTitle>
            <DialogDescription>أدخل بيانات مادة الصباغة ثم اضغط على إضافة</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="dyeing-name" className="text-right">
                اسم المادة
              </Label>
              <Input
                id="dyeing-name"
                value={dyeingFormData.name}
                onChange={(e) => setDyeingFormData({ ...dyeingFormData, name: e.target.value })}
                className="col-span-3"
                required
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="dyeing-category" className="text-right">
                الفئة
              </Label>
              <Select
                value={dyeingFormData.category}
                onValueChange={(value) => setDyeingFormData({ ...dyeingFormData, category: value })}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="اختر الفئة" />
                </SelectTrigger>
                <SelectContent>
                  {dyeingCategories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="dyeing-unit" className="text-right">
                الوحدة
              </Label>
              <Select
                value={dyeingFormData.unit}
                onValueChange={(value) => setDyeingFormData({ ...dyeingFormData, unit: value })}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="اختر الوحدة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="كجم">كجم</SelectItem>
                  <SelectItem value="جرام">جرام</SelectItem>
                  <SelectItem value="لتر">لتر</SelectItem>
                  <SelectItem value="مل">مل</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="dyeing-price" className="text-right">
                السعر/الوحدة
              </Label>
              <Input
                id="dyeing-price"
                type="number"
                step="0.01"
                value={dyeingFormData.pricePerUnit}
                onChange={(e) => setDyeingFormData({ ...dyeingFormData, pricePerUnit: e.target.value })}
                className="col-span-3"
                required
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="dyeing-supplier" className="text-right">
                المورد
              </Label>
              <Input
                id="dyeing-supplier"
                value={dyeingFormData.supplier}
                onChange={(e) => setDyeingFormData({ ...dyeingFormData, supplier: e.target.value })}
                className="col-span-3"
                required
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="dyeing-notes" className="text-right">
                ملاحظات
              </Label>
              <Input
                id="dyeing-notes"
                value={dyeingFormData.notes}
                onChange={(e) => setDyeingFormData({ ...dyeingFormData, notes: e.target.value })}
                className="col-span-3"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDyeingDialog(false)}>
              إلغاء
            </Button>
            <Button onClick={handleAddDyeingMaterial} className="bg-blue-600 hover:bg-blue-700">
              إضافة
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* نافذة إضافة مادة تجهيز */}
      <Dialog open={showProcessingDialog} onOpenChange={setShowProcessingDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>إضافة مادة تجهيز جديدة</DialogTitle>
            <DialogDescription>أدخل بيانات مادة التجهيز ثم اضغط على إضافة</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="processing-name" className="text-right">
                اسم المادة
              </Label>
              <Input
                id="processing-name"
                value={processingFormData.name}
                onChange={(e) => setProcessingFormData({ ...processingFormData, name: e.target.value })}
                className="col-span-3"
                required
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="processing-category" className="text-right">
                الفئة
              </Label>
              <Select
                value={processingFormData.category}
                onValueChange={(value) => setProcessingFormData({ ...processingFormData, category: value })}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="اختر الفئة" />
                </SelectTrigger>
                <SelectContent>
                  {processingCategories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="processing-unit" className="text-right">
                الوحدة
              </Label>
              <Select
                value={processingFormData.unit}
                onValueChange={(value) => setProcessingFormData({ ...processingFormData, unit: value })}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="اختر الوحدة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="لتر">لتر</SelectItem>
                  <SelectItem value="مل">مل</SelectItem>
                  <SelectItem value="كجم">كجم</SelectItem>
                  <SelectItem value="جرام">جرام</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="processing-price" className="text-right">
                السعر/الوحدة
              </Label>
              <Input
                id="processing-price"
                type="number"
                step="0.01"
                value={processingFormData.pricePerUnit}
                onChange={(e) => setProcessingFormData({ ...processingFormData, pricePerUnit: e.target.value })}
                className="col-span-3"
                required
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="processing-supplier" className="text-right">
                المورد
              </Label>
              <Input
                id="processing-supplier"
                value={processingFormData.supplier}
                onChange={(e) => setProcessingFormData({ ...processingFormData, supplier: e.target.value })}
                className="col-span-3"
                required
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="processing-notes" className="text-right">
                ملاحظات
              </Label>
              <Input
                id="processing-notes"
                value={processingFormData.notes}
                onChange={(e) => setProcessingFormData({ ...processingFormData, notes: e.target.value })}
                className="col-span-3"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowProcessingDialog(false)}>
              إلغاء
            </Button>
            <Button onClick={handleAddProcessingMaterial} className="bg-green-600 hover:bg-green-700">
              إضافة
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* نافذة تأكيد الحذف */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center text-red-600">
              <AlertTriangle className="h-5 w-5 ml-2" />
              تأكيد الحذف
            </DialogTitle>
            <DialogDescription>
              هل أنت متأكد من حذف المادة "{selectedMaterial?.name}"؟
              <br />
              <span className="text-red-600 font-medium">هذا الإجراء لا يمكن التراجع عنه!</span>
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="bg-red-50 border border-red-200 rounded-md p-4">
              <div className="flex items-center">
                <AlertTriangle className="h-5 w-5 text-red-600 ml-2" />
                <div className="text-sm text-red-800">
                  <p className="font-medium">تفاصيل المادة المراد حذفها:</p>
                  <p>الاسم: {selectedMaterial?.name}</p>
                  <p>الفئة: {selectedMaterial?.category}</p>
                  <p>
                    السعر: {selectedMaterial?.pricePerUnit.toFixed(2)} ج.م/{selectedMaterial?.unit}
                  </p>
                  <p>المورد: {selectedMaterial?.supplier}</p>
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>
              إلغاء
            </Button>
            <Button variant="destructive" onClick={handleDeleteMaterial}>
              <Trash2 className="h-4 w-4 ml-2" />
              تأكيد الحذف
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageLayout>
  )
}
