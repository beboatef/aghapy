"use client"

import { useState, useEffect } from "react"
import { PageLayout } from "@/components/page-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { BarChart3, TrendingUp, TrendingDown, DollarSign, Package, Users, Filter, Download } from "lucide-react"
import {
  Bar,
  BarChart,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
} from "recharts"
import { dataManager } from "@/lib/data-manager"

interface CustomerReport {
  customerId: number
  customerName: string
  customerCode: string
  totalQuantity: number
  totalValue: number
  totalOrders: number
  averageOrderValue: number
  lastOrderDate: string
  status: "active" | "inactive"
  paymentStatus: "good" | "warning" | "overdue"
}

export default function CustomerReportsPage() {
  const [customers, setCustomers] = useState<any[]>([])
  const [customerReports, setCustomerReports] = useState<CustomerReport[]>([])
  const [activeTab, setActiveTab] = useState("summary")
  const [selectedCustomer, setSelectedCustomer] = useState("all")
  const [dateFrom, setDateFrom] = useState("2024-01-01")
  const [dateTo, setDateTo] = useState("2024-12-31")
  const [reportType, setReportType] = useState("quantity")

  useEffect(() => {
    // Load data
    const loadedCustomers = dataManager.getCustomers()
    const productionOrders = dataManager.getData("productionOrders", [])
    const invoices = dataManager.getData("invoices", [])
    const customerAccounts = dataManager.getData("customerAccounts", [])

    setCustomers(loadedCustomers)

    // Generate customer reports
    const reports: CustomerReport[] = loadedCustomers.map((customer) => {
      const customerOrders = productionOrders.filter((order: any) => order.customerId === customer.id)
      const customerInvoices = invoices.filter((invoice: any) => invoice.customerId === customer.id)
      const customerAccount = customerAccounts.find((acc: any) => acc.customerId === customer.id)

      const totalQuantity = customerOrders.reduce((sum: number, order: any) => sum + (order.quantity || 0), 0)
      const totalValue = customerInvoices.reduce((sum: number, invoice: any) => sum + (invoice.totalAmount || 0), 0)
      const totalOrders = customerOrders.length
      const averageOrderValue = totalOrders > 0 ? totalValue / totalOrders : 0
      const lastOrderDate =
        customerOrders.length > 0
          ? customerOrders.sort((a: any, b: any) => new Date(b.date).getTime() - new Date(a.date).getTime())[0].date
          : ""

      const status =
        totalOrders > 0 && new Date(lastOrderDate) > new Date(Date.now() - 90 * 24 * 60 * 60 * 1000)
          ? "active"
          : "inactive"

      const paymentStatus =
        customerAccount?.totalOutstanding > 0
          ? customerAccount.totalOutstanding > customerAccount.creditLimit * 0.8
            ? "overdue"
            : "warning"
          : "good"

      return {
        customerId: customer.id,
        customerName: customer.name,
        customerCode: customer.code,
        totalQuantity,
        totalValue,
        totalOrders,
        averageOrderValue,
        lastOrderDate,
        status,
        paymentStatus,
      }
    })

    setCustomerReports(reports)
  }, [])

  // Filter reports
  const filteredReports = customerReports.filter((report) => {
    if (selectedCustomer !== "all" && report.customerId.toString() !== selectedCustomer) {
      return false
    }
    return true
  })

  // Calculate totals
  const totalCustomers = customerReports.length
  const activeCustomers = customerReports.filter((r) => r.status === "active").length
  const totalQuantity = customerReports.reduce((sum, r) => sum + r.totalQuantity, 0)
  const totalValue = customerReports.reduce((sum, r) => sum + r.totalValue, 0)
  const averageOrderValue = customerReports.reduce((sum, r) => sum + r.averageOrderValue, 0) / totalCustomers || 0

  // Chart data
  const topCustomersByQuantity = customerReports
    .sort((a, b) => b.totalQuantity - a.totalQuantity)
    .slice(0, 10)
    .map((customer) => ({
      name: customer.customerName,
      quantity: customer.totalQuantity,
      value: customer.totalValue,
    }))

  const topCustomersByValue = customerReports
    .sort((a, b) => b.totalValue - a.totalValue)
    .slice(0, 10)
    .map((customer) => ({
      name: customer.customerName,
      quantity: customer.totalQuantity,
      value: customer.totalValue,
    }))

  const customerStatusData = [
    { name: "نشط", value: activeCustomers, color: "#10B981" },
    { name: "غير نشط", value: totalCustomers - activeCustomers, color: "#EF4444" },
  ]

  const paymentStatusData = [
    {
      name: "جيد",
      value: customerReports.filter((r) => r.paymentStatus === "good").length,
      color: "#10B981",
    },
    {
      name: "تحذير",
      value: customerReports.filter((r) => r.paymentStatus === "warning").length,
      color: "#F59E0B",
    },
    {
      name: "متأخر",
      value: customerReports.filter((r) => r.paymentStatus === "overdue").length,
      color: "#EF4444",
    },
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "badge-success"
      case "inactive":
        return "badge-danger"
      default:
        return "badge-info"
    }
  }

  const getPaymentStatusColor = (status: string) => {
    switch (status) {
      case "good":
        return "badge-success"
      case "warning":
        return "badge-warning"
      case "overdue":
        return "badge-danger"
      default:
        return "badge-info"
    }
  }

  return (
    <PageLayout title="تقارير العملاء" subtitle="تقارير شاملة عن كميات وقيم العملاء">
      {/* Filters */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Filter className="w-5 h-5 ml-2" />
            فلاتر التقرير
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label>العميل</Label>
              <Select value={selectedCustomer} onValueChange={setSelectedCustomer}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع العملاء</SelectItem>
                  {customers.map((customer) => (
                    <SelectItem key={customer.id} value={customer.id.toString()}>
                      {customer.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>من تاريخ</Label>
              <Input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} />
            </div>
            <div>
              <Label>إلى تاريخ</Label>
              <Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} />
            </div>
            <div>
              <Label>نوع التقرير</Label>
              <Select value={reportType} onValueChange={setReportType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="quantity">الكميات</SelectItem>
                  <SelectItem value="value">القيم</SelectItem>
                  <SelectItem value="both">الكميات والقيم</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4 mb-6">
          <TabsTrigger value="summary">الملخص</TabsTrigger>
          <TabsTrigger value="quantity">تقرير الكميات</TabsTrigger>
          <TabsTrigger value="value">تقرير القيم</TabsTrigger>
          <TabsTrigger value="detailed">التقرير التفصيلي</TabsTrigger>
        </TabsList>

        <TabsContent value="summary">
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="card-hover">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">إجمالي العملاء</p>
                    <p className="text-2xl font-bold text-blue-600">{totalCustomers}</p>
                    <div className="flex items-center mt-2 text-sm">
                      <span className="text-green-500 font-medium">{activeCustomers} نشط</span>
                      <span className="text-gray-500 mr-2">من الإجمالي</span>
                    </div>
                  </div>
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Users className="w-6 h-6 text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="card-hover">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">إجمالي الكميات</p>
                    <p className="text-2xl font-bold text-green-600">{totalQuantity.toLocaleString()}</p>
                    <div className="flex items-center mt-2 text-sm">
                      <TrendingUp className="w-4 h-4 text-green-500 ml-1" />
                      <span className="text-green-500 font-medium">كجم/متر</span>
                    </div>
                  </div>
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <Package className="w-6 h-6 text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="card-hover">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">إجمالي القيم</p>
                    <p className="text-2xl font-bold text-purple-600">{totalValue.toLocaleString()} ج.م</p>
                    <div className="flex items-center mt-2 text-sm">
                      <TrendingUp className="w-4 h-4 text-green-500 ml-1" />
                      <span className="text-green-500 font-medium">+15%</span>
                      <span className="text-gray-500 mr-2">من الشهر الماضي</span>
                    </div>
                  </div>
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                    <DollarSign className="w-6 h-6 text-purple-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="card-hover">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">متوسط قيمة الطلب</p>
                    <p className="text-2xl font-bold text-orange-600">{averageOrderValue.toLocaleString()} ج.م</p>
                    <div className="flex items-center mt-2 text-sm">
                      <TrendingDown className="w-4 h-4 text-red-500 ml-1" />
                      <span className="text-red-500 font-medium">-3%</span>
                      <span className="text-gray-500 mr-2">من الشهر الماضي</span>
                    </div>
                  </div>
                  <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                    <BarChart3 className="w-6 h-6 text-orange-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <Card>
              <CardHeader>
                <CardTitle>حالة العملاء</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80 flex items-center justify-center">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsPieChart>
                      <Pie
                        data={customerStatusData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={120}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {customerStatusData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </RechartsPieChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex justify-center gap-4 mt-4">
                  {customerStatusData.map((item, index) => (
                    <div key={index} className="flex items-center">
                      <div className="w-3 h-3 rounded-full ml-2" style={{ backgroundColor: item.color }} />
                      <span className="text-sm text-gray-600">{item.name}</span>
                      <span className="text-sm font-medium text-gray-900 mr-2">{item.value}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>حالة المدفوعات</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80 flex items-center justify-center">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsPieChart>
                      <Pie
                        data={paymentStatusData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={120}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {paymentStatusData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </RechartsPieChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex justify-center gap-4 mt-4">
                  {paymentStatusData.map((item, index) => (
                    <div key={index} className="flex items-center">
                      <div className="w-3 h-3 rounded-full ml-2" style={{ backgroundColor: item.color }} />
                      <span className="text-sm text-gray-600">{item.name}</span>
                      <span className="text-sm font-medium text-gray-900 mr-2">{item.value}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="quantity">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold">تقرير الكميات</h2>
            <Button variant="outline" size="sm">
              <Download className="w-4 h-4 ml-2" />
              تصدير
            </Button>
          </div>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>أعلى العملاء بالكميات</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={topCustomersByQuantity}>
                    <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} interval={0} />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="quantity" fill="#3B82F6" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="text-right p-4 font-medium">العميل</th>
                      <th className="text-right p-4 font-medium">الكود</th>
                      <th className="text-right p-4 font-medium">إجمالي الكميات</th>
                      <th className="text-right p-4 font-medium">عدد الطلبات</th>
                      <th className="text-right p-4 font-medium">متوسط الكمية</th>
                      <th className="text-right p-4 font-medium">آخر طلب</th>
                      <th className="text-right p-4 font-medium">الحالة</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredReports
                      .sort((a, b) => b.totalQuantity - a.totalQuantity)
                      .map((report) => (
                        <tr key={report.customerId} className="border-b hover:bg-gray-50">
                          <td className="p-4 font-medium">{report.customerName}</td>
                          <td className="p-4">{report.customerCode}</td>
                          <td className="p-4 text-blue-600 font-medium">{report.totalQuantity.toLocaleString()}</td>
                          <td className="p-4">{report.totalOrders}</td>
                          <td className="p-4">
                            {report.totalOrders > 0 ? (report.totalQuantity / report.totalOrders).toFixed(1) : "0"}
                          </td>
                          <td className="p-4">{report.lastOrderDate || "لا يوجد"}</td>
                          <td className="p-4">
                            <Badge className={getStatusColor(report.status)}>
                              {report.status === "active" ? "نشط" : "غير نشط"}
                            </Badge>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="value">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold">تقرير القيم</h2>
            <Button variant="outline" size="sm">
              <Download className="w-4 h-4 ml-2" />
              تصدير
            </Button>
          </div>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>أعلى العملاء بالقيم</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={topCustomersByValue}>
                    <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} interval={0} />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="value" fill="#10B981" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="text-right p-4 font-medium">العميل</th>
                      <th className="text-right p-4 font-medium">الكود</th>
                      <th className="text-right p-4 font-medium">إجمالي القيم</th>
                      <th className="text-right p-4 font-medium">عدد الطلبات</th>
                      <th className="text-right p-4 font-medium">متوسط قيمة الطلب</th>
                      <th className="text-right p-4 font-medium">حالة الدفع</th>
                      <th className="text-right p-4 font-medium">الحالة</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredReports
                      .sort((a, b) => b.totalValue - a.totalValue)
                      .map((report) => (
                        <tr key={report.customerId} className="border-b hover:bg-gray-50">
                          <td className="p-4 font-medium">{report.customerName}</td>
                          <td className="p-4">{report.customerCode}</td>
                          <td className="p-4 text-green-600 font-medium">{report.totalValue.toLocaleString()} ج.م</td>
                          <td className="p-4">{report.totalOrders}</td>
                          <td className="p-4">{report.averageOrderValue.toLocaleString()} ج.م</td>
                          <td className="p-4">
                            <Badge className={getPaymentStatusColor(report.paymentStatus)}>
                              {report.paymentStatus === "good"
                                ? "جيد"
                                : report.paymentStatus === "warning"
                                  ? "تحذير"
                                  : "متأخر"}
                            </Badge>
                          </td>
                          <td className="p-4">
                            <Badge className={getStatusColor(report.status)}>
                              {report.status === "active" ? "نشط" : "غير نشط"}
                            </Badge>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="detailed">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold">التقرير التفصيلي</h2>
            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <Filter className="w-4 h-4 ml-2" />
                تصفية
              </Button>
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 ml-2" />
                تصدير
              </Button>
            </div>
          </div>

          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="text-right p-4 font-medium">العميل</th>
                      <th className="text-right p-4 font-medium">الكود</th>
                      <th className="text-right p-4 font-medium">إجمالي الكميات</th>
                      <th className="text-right p-4 font-medium">إجمالي القيم</th>
                      <th className="text-right p-4 font-medium">عدد الطلبات</th>
                      <th className="text-right p-4 font-medium">متوسط الكمية</th>
                      <th className="text-right p-4 font-medium">متوسط القيمة</th>
                      <th className="text-right p-4 font-medium">آخر طلب</th>
                      <th className="text-right p-4 font-medium">حالة الدفع</th>
                      <th className="text-right p-4 font-medium">الحالة</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredReports.map((report) => (
                      <tr key={report.customerId} className="border-b hover:bg-gray-50">
                        <td className="p-4 font-medium">{report.customerName}</td>
                        <td className="p-4">{report.customerCode}</td>
                        <td className="p-4 text-blue-600 font-medium">{report.totalQuantity.toLocaleString()}</td>
                        <td className="p-4 text-green-600 font-medium">{report.totalValue.toLocaleString()} ج.م</td>
                        <td className="p-4">{report.totalOrders}</td>
                        <td className="p-4">
                          {report.totalOrders > 0 ? (report.totalQuantity / report.totalOrders).toFixed(1) : "0"}
                        </td>
                        <td className="p-4">{report.averageOrderValue.toLocaleString()} ج.م</td>
                        <td className="p-4">{report.lastOrderDate || "لا يوجد"}</td>
                        <td className="p-4">
                          <Badge className={getPaymentStatusColor(report.paymentStatus)}>
                            {report.paymentStatus === "good"
                              ? "جيد"
                              : report.paymentStatus === "warning"
                                ? "تحذير"
                                : "متأخر"}
                          </Badge>
                        </td>
                        <td className="p-4">
                          <Badge className={getStatusColor(report.status)}>
                            {report.status === "active" ? "نشط" : "غير نشط"}
                          </Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </PageLayout>
  )
}
