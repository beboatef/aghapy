"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { PageLayout } from "@/components/page-layout"
import { BarChart2, Download, FileText, TrendingUp, Users, Package, Calendar } from "lucide-react"
import {
  Bar,
  BarChart,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from "recharts"

export default function ReportsPage() {
  const [reportType, setReportType] = useState("inventory_movement")
  const [dateFrom, setDateFrom] = useState("2024-03-01")
  const [dateTo, setDateTo] = useState("2024-03-31")
  const [customerFilter, setCustomerFilter] = useState("all_customers")

  // بيانات محاكاة للتقارير
  const inventoryData = [
    { name: "يناير", وارد: 400, منصرف: 240, مرتجع: 50 },
    { name: "فبراير", وارد: 300, منصرف: 280, مرتجع: 30 },
    { name: "مارس", وارد: 500, منصرف: 350, مرتجع: 40 },
    { name: "أبريل", وارد: 280, منصرف: 220, مرتجع: 25 },
    { name: "مايو", وارد: 450, منصرف: 400, مرتجع: 35 },
    { name: "يونيو", وارد: 600, منصرف: 450, مرتجع: 45 },
  ]

  const materialDistribution = [
    { name: "قطن", value: 45, color: "#3b82f6" },
    { name: "بوليستر", value: 30, color: "#ef4444" },
    { name: "حرير", value: 15, color: "#f59e0b" },
    { name: "كتان", value: 10, color: "#10b981" },
  ]

  const customerActivity = [
    { name: "شركة النسيج المتحدة", orders: 25, delivered: 22 },
    { name: "مصنع الألوان الحديث", orders: 18, delivered: 16 },
    { name: "شركة القطن السعودي", orders: 15, delivered: 14 },
    { name: "مصنع الأقمشة الفاخرة", orders: 12, delivered: 10 },
  ]

  const productionTrend = [
    { month: "يناير", completed: 20, inProgress: 5 },
    { month: "فبراير", completed: 25, inProgress: 8 },
    { month: "مارس", completed: 30, inProgress: 12 },
    { month: "أبريل", completed: 28, inProgress: 10 },
    { month: "مايو", completed: 35, inProgress: 15 },
    { month: "يونيو", completed: 40, inProgress: 18 },
  ]

  // بيانات تفصيلية لحركة أصناف العميل
  const customerMaterialMovements = [
    {
      material: "قطن مصري 100%",
      openingBalance: 150,
      received: 500,
      delivered: 320,
      inProduction: 180,
      currentBalance: 150,
      unit: "كجم",
    },
    {
      material: "بوليستر خليط",
      openingBalance: 200,
      received: 300,
      delivered: 250,
      inProduction: 120,
      currentBalance: 130,
      unit: "كجم",
    },
    {
      material: "حرير طبيعي",
      openingBalance: 50,
      received: 100,
      delivered: 80,
      inProduction: 40,
      currentBalance: 30,
      unit: "متر",
    },
  ]

  // بيانات ملخص العميل
  const customerSummary = {
    totalReceived: 900,
    totalDelivered: 650,
    totalInProduction: 340,
    totalBalance: 310,
    completedOrders: 25,
    pendingOrders: 8,
  }

  const customers = [
    { id: 1, name: "شركة النسيج المتحدة" },
    { id: 2, name: "مصنع الألوان الحديث" },
    { id: 3, name: "شركة القطن السعودي" },
  ]

  const reportTypes = [
    { value: "inventory_movement", label: "تقرير حركة المخزون" },
    { value: "customer_activity", label: "تقرير نشاط العملاء" },
    { value: "production_summary", label: "تقرير ملخص الإنتاج" },
    { value: "material_distribution", label: "تقرير توزيع الأصناف" },
    { value: "financial_summary", label: "التقرير المالي" },
    { value: "customer_details", label: "تقرير تفاصيل العميل" },
  ]

  const generateReport = () => {
    alert(`تم إنشاء ${reportTypes.find((r) => r.value === reportType)?.label} بنجاح`)
  }

  const exportReport = (format: string) => {
    alert(`تم تصدير التقرير بصيغة ${format}`)
  }

  const renderChart = () => {
    switch (reportType) {
      case "inventory_movement":
        return (
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={inventoryData}>
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="وارد" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              <Bar dataKey="منصرف" fill="#ef4444" radius={[4, 4, 0, 0]} />
              <Bar dataKey="مرتجع" fill="#f59e0b" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        )

      case "material_distribution":
        return (
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={materialDistribution}
                cx="50%"
                cy="50%"
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              >
                {materialDistribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        )

      case "customer_activity":
        return (
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={customerActivity} layout="horizontal">
              <XAxis type="number" />
              <YAxis dataKey="name" type="category" width={150} />
              <Tooltip />
              <Bar dataKey="orders" fill="#3b82f6" />
              <Bar dataKey="delivered" fill="#10b981" />
            </BarChart>
          </ResponsiveContainer>
        )

      case "production_summary":
        return (
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={productionTrend}>
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="completed" stroke="#10b981" strokeWidth={2} />
              <Line type="monotone" dataKey="inProgress" stroke="#f59e0b" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        )

      case "customer_details":
        return (
          <div className="space-y-6">
            {/* ملخص العميل */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
              <div className="bg-blue-50 p-4 rounded-lg text-center">
                <p className="text-sm text-blue-600 mb-1">إجمالي المستلم</p>
                <p className="text-2xl font-bold text-blue-700">{customerSummary.totalReceived} كجم</p>
              </div>
              <div className="bg-green-50 p-4 rounded-lg text-center">
                <p className="text-sm text-green-600 mb-1">إجمالي المسلم</p>
                <p className="text-2xl font-bold text-green-700">{customerSummary.totalDelivered} كجم</p>
              </div>
              <div className="bg-orange-50 p-4 rounded-lg text-center">
                <p className="text-sm text-orange-600 mb-1">قيد الإنتاج</p>
                <p className="text-2xl font-bold text-orange-700">{customerSummary.totalInProduction} كجم</p>
              </div>
              <div className="bg-purple-50 p-4 rounded-lg text-center">
                <p className="text-sm text-purple-600 mb-1">الرصيد الحالي</p>
                <p className="text-2xl font-bold text-purple-700">{customerSummary.totalBalance} كجم</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg text-center">
                <p className="text-sm text-gray-600 mb-1">أوامر مكتملة</p>
                <p className="text-2xl font-bold text-gray-700">{customerSummary.completedOrders}</p>
              </div>
              <div className="bg-yellow-50 p-4 rounded-lg text-center">
                <p className="text-sm text-yellow-600 mb-1">أوامر معلقة</p>
                <p className="text-2xl font-bold text-yellow-700">{customerSummary.pendingOrders}</p>
              </div>
            </div>

            {/* جدول تفاصيل الأصناف */}
            <div className="overflow-x-auto">
              <table className="w-full border-collapse border border-gray-300">
                <thead>
                  <tr className="bg-gray-50">
                    <th className="border border-gray-300 p-3 text-right">الصنف</th>
                    <th className="border border-gray-300 p-3 text-center">رصيد أول المدة</th>
                    <th className="border border-gray-300 p-3 text-center">المستلم</th>
                    <th className="border border-gray-300 p-3 text-center">المسلم</th>
                    <th className="border border-gray-300 p-3 text-center">قيد الإنتاج</th>
                    <th className="border border-gray-300 p-3 text-center">الرصيد الحالي</th>
                    <th className="border border-gray-300 p-3 text-center">الوحدة</th>
                  </tr>
                </thead>
                <tbody>
                  {customerMaterialMovements.map((item, index) => (
                    <tr key={index} className="hover:bg-gray-50">
                      <td className="border border-gray-300 p-3 font-medium">{item.material}</td>
                      <td className="border border-gray-300 p-3 text-center">{item.openingBalance}</td>
                      <td className="border border-gray-300 p-3 text-center text-blue-600 font-medium">
                        {item.received}
                      </td>
                      <td className="border border-gray-300 p-3 text-center text-green-600 font-medium">
                        {item.delivered}
                      </td>
                      <td className="border border-gray-300 p-3 text-center text-orange-600 font-medium">
                        {item.inProduction}
                      </td>
                      <td className="border border-gray-300 p-3 text-center text-purple-600 font-bold">
                        {item.currentBalance}
                      </td>
                      <td className="border border-gray-300 p-3 text-center text-gray-600">{item.unit}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr className="bg-gray-100 font-bold">
                    <td className="border border-gray-300 p-3">الإجمالي</td>
                    <td className="border border-gray-300 p-3 text-center">400</td>
                    <td className="border border-gray-300 p-3 text-center text-blue-600">900</td>
                    <td className="border border-gray-300 p-3 text-center text-green-600">650</td>
                    <td className="border border-gray-300 p-3 text-center text-orange-600">340</td>
                    <td className="border border-gray-300 p-3 text-center text-purple-600">310</td>
                    <td className="border border-gray-300 p-3 text-center">-</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        )

      default:
        return (
          <div className="flex items-center justify-center h-64 text-gray-500">
            <div className="text-center">
              <BarChart2 className="h-12 w-12 mx-auto mb-4" />
              <p>اختر نوع التقرير لعرض البيانات</p>
            </div>
          </div>
        )
    }
  }

  const getReportSummary = () => {
    switch (reportType) {
      case "inventory_movement":
        return {
          title: "ملخص حركة المخزون",
          stats: [
            { label: "إجمالي الوارد", value: "2,530 كجم", color: "text-blue-600" },
            { label: "إجمالي المنصرف", value: "1,940 كجم", color: "text-red-600" },
            { label: "إجمالي المرتجع", value: "225 كجم", color: "text-orange-600" },
            { label: "الرصيد الحالي", value: "365 كجم", color: "text-green-600" },
          ],
        }

      case "customer_activity":
        return {
          title: "ملخص نشاط العملاء",
          stats: [
            { label: "إجمالي العملاء", value: "45", color: "text-blue-600" },
            { label: "العملاء النشطون", value: "32", color: "text-green-600" },
            { label: "أوامر هذا الشهر", value: "78", color: "text-orange-600" },
            { label: "معدل التسليم", value: "94%", color: "text-purple-600" },
          ],
        }

      case "production_summary":
        return {
          title: "ملخص الإنتاج",
          stats: [
            { label: "أوامر مكتملة", value: "178", color: "text-green-600" },
            { label: "أوامر قيد التشغيل", value: "68", color: "text-blue-600" },
            { label: "متوسط وقت الإنتاج", value: "5.2 أيام", color: "text-orange-600" },
            { label: "معدل الإنجاز", value: "87%", color: "text-purple-600" },
          ],
        }

      case "material_distribution":
        return {
          title: "ملخص توزيع الأصناف",
          stats: [
            { label: "أصناف القطن", value: "45%", color: "text-blue-600" },
            { label: "أصناف البوليستر", value: "30%", color: "text-red-600" },
            { label: "أصناف الحرير", value: "15%", color: "text-orange-600" },
            { label: "أصناف أخرى", value: "10%", color: "text-green-600" },
          ],
        }

      case "customer_details":
        return {
          title: "ملخص تفاصيل العميل",
          stats: [
            { label: "إجمالي الأصناف", value: "3", color: "text-blue-600" },
            { label: "إجمالي المستلم", value: "900 كجم", color: "text-green-600" },
            { label: "إجمالي المسلم", value: "650 كجم", color: "text-orange-600" },
            { label: "الرصيد الإجمالي", value: "310 كجم", color: "text-purple-600" },
          ],
        }

      default:
        return {
          title: "ملخص التقرير",
          stats: [
            { label: "إجمالي البيانات", value: "0", color: "text-gray-600" },
            { label: "الفترة المحددة", value: "غير محدد", color: "text-gray-600" },
            { label: "نوع التقرير", value: "غير محدد", color: "text-gray-600" },
            { label: "الحالة", value: "في الانتظار", color: "text-gray-600" },
          ],
        }
    }
  }

  const summary = getReportSummary()

  return (
    <PageLayout title="التقارير">
      {/* رأس الصفحة */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
        <h1 className="page-title mb-4 sm:mb-0">
          <BarChart2 className="page-icon text-green-600" />
          التقارير والإحصائيات
        </h1>
        <div className="flex flex-wrap gap-2">
          <Button onClick={() => exportReport("PDF")} variant="outline" size="sm">
            <Download className="h-4 w-4 ml-2" />
            تصدير PDF
          </Button>
          <Button onClick={() => exportReport("Excel")} variant="outline" size="sm">
            <Download className="h-4 w-4 ml-2" />
            تصدير Excel
          </Button>
          <Button onClick={generateReport} size="sm">
            <FileText className="h-4 w-4 ml-2" />
            إنشاء التقرير
          </Button>
        </div>
      </div>

      {/* فلاتر التقرير */}
      <Card className="mb-6 border-0 shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Calendar className="h-5 w-5 ml-2" />
            إعدادات التقرير
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label htmlFor="reportType">نوع التقرير</Label>
              <Select value={reportType} onValueChange={setReportType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {reportTypes.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="dateFrom">من تاريخ</Label>
              <Input id="dateFrom" type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} />
            </div>
            <div>
              <Label htmlFor="dateTo">إلى تاريخ</Label>
              <Input id="dateTo" type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} />
            </div>
            <div>
              <Label htmlFor="customer">العميل</Label>
              <Select value={customerFilter} onValueChange={setCustomerFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all_customers">جميع العملاء</SelectItem>
                  {customers.map((customer) => (
                    <SelectItem key={customer.id} value={customer.id.toString()}>
                      {customer.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* ملخص التقرير */}
      <Card className="mb-6 border-0 shadow-sm">
        <CardHeader>
          <CardTitle>{summary.title}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {summary.stats.map((stat, index) => (
              <div key={index} className="text-center p-4 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-600 mb-1">{stat.label}</p>
                <p className={`text-2xl font-bold ${stat.color}`}>{stat.value}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* الرسم البياني */}
      <Card className="mb-6 border-0 shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center">
            <TrendingUp className="h-5 w-5 ml-2" />
            {reportTypes.find((r) => r.value === reportType)?.label || "الرسم البياني"}
          </CardTitle>
        </CardHeader>
        <CardContent>{renderChart()}</CardContent>
      </Card>

      {/* تقارير سريعة */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer">
          <CardContent className="p-6 text-center">
            <Users className="h-12 w-12 text-blue-600 mx-auto mb-4" />
            <h3 className="font-bold text-lg mb-2">تقرير العملاء</h3>
            <p className="text-gray-600 text-sm mb-4">تقرير شامل عن نشاط العملاء والطلبات</p>
            <Button variant="outline" size="sm" className="w-full">
              عرض التقرير
            </Button>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer">
          <CardContent className="p-6 text-center">
            <Package className="h-12 w-12 text-green-600 mx-auto mb-4" />
            <h3 className="font-bold text-lg mb-2">تقرير المخزون</h3>
            <p className="text-gray-600 text-sm mb-4">تقرير مفصل عن حالة المخزون والأرصدة</p>
            <Button variant="outline" size="sm" className="w-full">
              عرض التقرير
            </Button>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer">
          <CardContent className="p-6 text-center">
            <FileText className="h-12 w-12 text-purple-600 mx-auto mb-4" />
            <h3 className="font-bold text-lg mb-2">تقرير الإنتاج</h3>
            <p className="text-gray-600 text-sm mb-4">تقرير عن أوامر التشغيل ومعدلات الإنجاز</p>
            <Button variant="outline" size="sm" className="w-full">
              عرض التقرير
            </Button>
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  )
}
