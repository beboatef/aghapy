"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import {
  Plus,
  Filter,
  Download,
  Trash2,
  Check,
  Calculator,
  Package,
  DollarSign,
  TrendingUp,
  FileText,
  AlertTriangle,
} from "lucide-react"
import { dataManager } from "@/lib/data-manager"
import { toast } from "@/components/ui/use-toast"

// Define types
type DyeingMaterial = {
  id: string
  code: string
  name: string
  nameAr: string
  category: "dye" | "chemical" | "auxiliary" | "finishing"
  unit: "kg" | "gram" | "liter"
  purchasePrice: number
  currentStock: number
  minimumStock: number
}

type ProductionOrder = {
  id: number
  orderNumber: string
  permitNumber: string
  date: string
  customerId: number
  customerName: string
  materialId: number
  materialName: string
  quantity: number
  separatedQuantity: number
  finalQuantity: number
  unit: string
  status: "in_production" | "completed"
  hasSeparations: boolean
  notes?: string
  createdAt: string
  completedAt?: string
  materialsUsed: MaterialUsage[]
  totalMaterialsCost: number
  costPerUnit: number
  costsCalculated: boolean
}

type MaterialUsage = {
  materialId: string
  materialCode: string
  materialName: string
  materialNameAr: string
  category: string
  unit: string
  quantity: number
  unitPrice: number
  totalCost: number
  issuedDate: string
  issuedBy: string
}

type MaterialIssuance = {
  id: string
  productionOrderId: number
  productionOrderNumber: string
  date: string
  materials: MaterialUsage[]
  totalCost: number
  issuedBy: string
  status: "pending" | "approved" | "completed"
  notes?: string
}

export default function MaterialIssuancePage() {
  const [dyeingMaterials, setDyeingMaterials] = useState<DyeingMaterial[]>([])
  const [productionOrders, setProductionOrders] = useState<ProductionOrder[]>([])
  const [issuances, setIssuances] = useState<MaterialIssuance[]>([])
  const [activeTab, setActiveTab] = useState("issue-materials")

  const [selectedOrderId, setSelectedOrderId] = useState<string>("")
  const [selectedMaterials, setSelectedMaterials] = useState<MaterialUsage[]>([])
  const [currentMaterial, setCurrentMaterial] = useState({
    materialId: "",
    quantity: "",
  })

  // Load data
  useEffect(() => {
    loadData()
  }, [])

  const loadData = () => {
    // Load dyeing materials
    const materials = dataManager.getDyeingMaterials()
    setDyeingMaterials(materials)

    // Load production orders - تأكد من تحميل أوامر التشغيل الصحيحة
    const allOrders = dataManager.getData("productionOrders", [])
    console.log("All production orders:", allOrders) // للتشخيص
    const inProductionOrders = allOrders.filter((order: ProductionOrder) => order.status === "in_production")
    console.log("In production orders:", inProductionOrders) // للتشخيص
    setProductionOrders(inProductionOrders)

    // Load issuances
    const savedIssuances = dataManager.getData("materialIssuances", [])
    setIssuances(savedIssuances)
  }

  // Add material to issuance
  const addMaterialToIssuance = () => {
    if (!currentMaterial.materialId || !currentMaterial.quantity) {
      toast({
        title: "خطأ في البيانات",
        description: "يرجى اختيار مادة وإدخال كمية صحيحة",
        variant: "destructive",
      })
      return
    }

    const material = dyeingMaterials.find((m) => m.id === currentMaterial.materialId)
    if (!material) {
      toast({
        title: "خطأ",
        description: "لم يتم العثور على المادة المختارة",
        variant: "destructive",
      })
      return
    }

    const quantity = Number.parseFloat(currentMaterial.quantity)
    if (quantity > material.currentStock) {
      toast({
        title: "مخزون غير كافي",
        description: `المخزون المتاح: ${material.currentStock} ${material.unit}، المطلوب: ${quantity} ${material.unit}`,
        variant: "destructive",
      })
      return
    }

    const totalCost = quantity * material.purchasePrice

    const newMaterialUsage: MaterialUsage = {
      materialId: material.id,
      materialCode: material.code,
      materialName: material.name,
      materialNameAr: material.nameAr,
      category: material.category,
      unit: material.unit,
      quantity: quantity,
      unitPrice: material.purchasePrice,
      totalCost: totalCost,
      issuedDate: new Date().toISOString().split("T")[0],
      issuedBy: "Current User",
    }

    // Check if material already exists
    const existingIndex = selectedMaterials.findIndex((item) => item.materialId === material.id)

    if (existingIndex >= 0) {
      const updatedMaterials = [...selectedMaterials]
      const existingItem = updatedMaterials[existingIndex]
      const newQuantity = existingItem.quantity + quantity

      if (newQuantity > material.currentStock) {
        toast({
          title: "مخزون غير كافي",
          description: `إجمالي الكمية (${newQuantity} ${material.unit}) أكبر من المتاح (${material.currentStock} ${material.unit})`,
          variant: "destructive",
        })
        return
      }

      updatedMaterials[existingIndex] = {
        ...existingItem,
        quantity: newQuantity,
        totalCost: newQuantity * existingItem.unitPrice,
      }

      setSelectedMaterials(updatedMaterials)
    } else {
      setSelectedMaterials([...selectedMaterials, newMaterialUsage])
    }

    setCurrentMaterial({ materialId: "", quantity: "" })

    toast({
      title: "تم إضافة المادة",
      description: `تم إضافة ${material.name} بكمية ${quantity} ${material.unit}`,
    })
  }

  // Remove material from issuance
  const removeMaterialFromIssuance = (index: number) => {
    const updatedMaterials = selectedMaterials.filter((_, i) => i !== index)
    setSelectedMaterials(updatedMaterials)
  }

  // Calculate total cost
  const calculateTotalCost = () => {
    return selectedMaterials.reduce((sum, item) => sum + item.totalCost, 0)
  }

  // Submit issuance
  const submitIssuance = () => {
    if (!selectedOrderId || selectedMaterials.length === 0) {
      toast({
        title: "خطأ في البيانات",
        description: "يرجى اختيار أمر تشغيل وإضافة مواد",
        variant: "destructive",
      })
      return
    }

    const order = productionOrders.find((o) => o.id.toString() === selectedOrderId)
    if (!order) {
      toast({
        title: "خطأ",
        description: "لم يتم العثور على أمر التشغيل",
        variant: "destructive",
      })
      return
    }

    // Update material stocks
    const updatedMaterials = dyeingMaterials.map((material) => {
      const usedMaterial = selectedMaterials.find((used) => used.materialId === material.id)
      if (usedMaterial) {
        return {
          ...material,
          currentStock: material.currentStock - usedMaterial.quantity,
        }
      }
      return material
    })

    // Create new issuance
    const newIssuance: MaterialIssuance = {
      id: `ISS-${Date.now()}`,
      productionOrderId: order.id,
      productionOrderNumber: order.orderNumber,
      date: new Date().toISOString().split("T")[0],
      materials: selectedMaterials,
      totalCost: calculateTotalCost(),
      issuedBy: "Current User",
      status: "completed",
    }

    // Update production order with materials used
    const allOrders = dataManager.getData("productionOrders", [])
    const updatedAllOrders = allOrders.map((o: ProductionOrder) => {
      if (o.id.toString() === selectedOrderId) {
        const existingMaterials = o.materialsUsed || []
        const updatedMaterialsUsed = [...existingMaterials, ...selectedMaterials]
        const newTotalCost = updatedMaterialsUsed.reduce((sum, m) => sum + m.totalCost, 0)
        const newCostPerUnit = o.finalQuantity > 0 ? newTotalCost / o.finalQuantity : 0

        return {
          ...o,
          materialsUsed: updatedMaterialsUsed,
          totalMaterialsCost: newTotalCost,
          costPerUnit: newCostPerUnit,
          costsCalculated: true,
        }
      }
      return o
    })

    // Save data
    dataManager.setDyeingMaterials(updatedMaterials)
    dataManager.setData("materialIssuances", [...issuances, newIssuance])
    dataManager.setData("productionOrders", updatedAllOrders)

    // Update state
    setDyeingMaterials(updatedMaterials)
    setIssuances([...issuances, newIssuance])

    // Reload production orders
    const updatedInProductionOrders = updatedAllOrders.filter(
      (order: ProductionOrder) => order.status === "in_production",
    )
    setProductionOrders(updatedInProductionOrders)

    // Reset form
    setSelectedOrderId("")
    setSelectedMaterials([])
    setActiveTab("issuance-history")

    toast({
      title: "تم صرف المواد بنجاح",
      description: `تم صرف ${selectedMaterials.length} مواد لأمر التشغيل ${order.orderNumber}`,
    })
  }

  // Get category color
  const getCategoryColor = (category: string) => {
    switch (category) {
      case "dye":
        return "bg-blue-100 text-blue-800"
      case "chemical":
        return "bg-red-100 text-red-800"
      case "auxiliary":
        return "bg-green-100 text-green-800"
      case "finishing":
        return "bg-purple-100 text-purple-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  // Get status color
  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "approved":
        return "bg-blue-100 text-blue-800"
      case "completed":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">صرف المواد لأوامر التشغيل</h1>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="issue-materials">صرف المواد</TabsTrigger>
          <TabsTrigger value="issuance-history">سجل الصرف</TabsTrigger>
          <TabsTrigger value="daily-summary">ملخص يومي</TabsTrigger>
        </TabsList>

        <TabsContent value="issue-materials">
          {productionOrders.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <AlertTriangle className="h-12 w-12 text-yellow-500 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">لا توجد أوامر تشغيل متاحة</h3>
                <p className="text-gray-500 text-center mb-4">
                  لا توجد أوامر تشغيل قيد التنفيذ حالياً. يرجى إضافة أوامر تشغيل جديدة أولاً.
                </p>
                <Button onClick={() => (window.location.href = "/production-orders")}>إضافة أمر تشغيل جديد</Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Order Selection */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Package className="h-5 w-5" />
                    اختيار أمر التشغيل
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>أمر التشغيل ({productionOrders.length} متاح)</Label>
                    <Select value={selectedOrderId} onValueChange={setSelectedOrderId}>
                      <SelectTrigger>
                        <SelectValue placeholder="اختر أمر التشغيل..." />
                      </SelectTrigger>
                      <SelectContent>
                        {productionOrders.map((order) => (
                          <SelectItem key={order.id} value={order.id.toString()}>
                            {order.orderNumber} - {order.customerName} ({order.materialName})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {selectedOrderId && (
                    <div className="p-4 bg-blue-50 rounded-lg">
                      {(() => {
                        const order = productionOrders.find((o) => o.id.toString() === selectedOrderId)
                        if (!order) return null
                        return (
                          <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span className="text-gray-600">رقم الأمر:</span>
                              <span className="font-medium">{order.orderNumber}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">العميل:</span>
                              <span className="font-medium">{order.customerName}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">المادة:</span>
                              <span>{order.materialName}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">الكمية النهائية:</span>
                              <span className="font-medium text-green-600">
                                {order.finalQuantity} {order.unit}
                              </span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">التكلفة الحالية:</span>
                              <span className="font-medium text-blue-600">
                                {order.totalMaterialsCost.toFixed(2)} ج.م
                              </span>
                            </div>
                          </div>
                        )
                      })()}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Material Selection */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Plus className="h-5 w-5" />
                    إضافة المواد
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>المادة</Label>
                      <Select
                        value={currentMaterial.materialId}
                        onValueChange={(value) => setCurrentMaterial({ ...currentMaterial, materialId: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="اختر المادة..." />
                        </SelectTrigger>
                        <SelectContent>
                          {dyeingMaterials.map((material) => (
                            <SelectItem key={material.id} value={material.id}>
                              <div className="flex flex-col">
                                <span>
                                  {material.name} ({material.nameAr})
                                </span>
                                <span className="text-xs text-gray-500">
                                  متاح: {material.currentStock} {material.unit} - سعر: {material.purchasePrice} ج.م
                                </span>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>الكمية</Label>
                      <Input
                        type="number"
                        step="0.01"
                        value={currentMaterial.quantity}
                        onChange={(e) => setCurrentMaterial({ ...currentMaterial, quantity: e.target.value })}
                        placeholder="0.00"
                      />
                    </div>
                  </div>
                  <Button
                    onClick={addMaterialToIssuance}
                    disabled={!currentMaterial.materialId || !currentMaterial.quantity || !selectedOrderId}
                    className="w-full"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    إضافة المادة
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Selected Materials */}
          {selectedMaterials.length > 0 && (
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Calculator className="h-5 w-5" />
                    المواد المختارة ({selectedMaterials.length})
                  </span>
                  <span className="text-lg font-bold text-blue-600">إجمالي: {calculateTotalCost().toFixed(2)} ج.م</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>المادة</TableHead>
                        <TableHead>الفئة</TableHead>
                        <TableHead className="text-right">الكمية</TableHead>
                        <TableHead className="text-right">سعر الوحدة</TableHead>
                        <TableHead className="text-right">الإجمالي</TableHead>
                        <TableHead className="w-16"></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {selectedMaterials.map((item, index) => (
                        <TableRow key={index}>
                          <TableCell>
                            <div>
                              <div className="font-medium">{item.materialName}</div>
                              <div className="text-sm text-gray-500">{item.materialNameAr}</div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge className={getCategoryColor(item.category)}>{item.category}</Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            {item.quantity} {item.unit}
                          </TableCell>
                          <TableCell className="text-right">{item.unitPrice.toFixed(2)} ج.م</TableCell>
                          <TableCell className="text-right font-medium text-blue-600">
                            {item.totalCost.toFixed(2)} ج.م
                          </TableCell>
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => removeMaterialFromIssuance(index)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>

                <div className="mt-6 flex justify-end">
                  <Button onClick={submitIssuance} className="bg-green-600 hover:bg-green-700">
                    <Check className="h-4 w-4 mr-2" />
                    تأكيد صرف المواد
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="issuance-history">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>سجل صرف المواد</CardTitle>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  <Filter className="h-4 w-4 mr-2" />
                  تصفية
                </Button>
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  تصدير
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>رقم الصرف</TableHead>
                      <TableHead>أمر التشغيل</TableHead>
                      <TableHead>التاريخ</TableHead>
                      <TableHead className="text-right">عدد المواد</TableHead>
                      <TableHead className="text-right">التكلفة الإجمالية</TableHead>
                      <TableHead>الحالة</TableHead>
                      <TableHead>الإجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {issuances.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                          لا توجد عمليات صرف مواد بعد
                        </TableCell>
                      </TableRow>
                    ) : (
                      issuances.map((issuance) => (
                        <TableRow key={issuance.id}>
                          <TableCell className="font-mono">{issuance.id}</TableCell>
                          <TableCell>{issuance.productionOrderNumber}</TableCell>
                          <TableCell>{issuance.date}</TableCell>
                          <TableCell className="text-right">{issuance.materials.length}</TableCell>
                          <TableCell className="text-right font-medium text-blue-600">
                            {issuance.totalCost.toFixed(2)} ج.م
                          </TableCell>
                          <TableCell>
                            <Badge className={getStatusColor(issuance.status)}>
                              {issuance.status === "completed" ? "مكتمل" : "قيد المعالجة"}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Button variant="outline" size="sm">
                              <FileText className="h-4 w-4 mr-2" />
                              تفاصيل
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="daily-summary">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-green-600" />
                  إجمالي الصرف اليوم
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">
                  {issuances
                    .filter((i) => i.date === new Date().toISOString().split("T")[0])
                    .reduce((sum, i) => sum + i.totalCost, 0)
                    .toFixed(2)}{" "}
                  ج.م
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Package className="h-5 w-5 text-blue-600" />
                  عدد أوامر الصرف
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">
                  {issuances.filter((i) => i.date === new Date().toISOString().split("T")[0]).length}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-purple-600" />
                  متوسط التكلفة
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-purple-600">
                  {(() => {
                    const todayIssuances = issuances.filter((i) => i.date === new Date().toISOString().split("T")[0])
                    const average =
                      todayIssuances.length > 0
                        ? todayIssuances.reduce((sum, i) => sum + i.totalCost, 0) / todayIssuances.length
                        : 0
                    return average.toFixed(2)
                  })()} ج.م
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
