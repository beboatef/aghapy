"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Form } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { zodResolver } from "@hookform/resolvers/zod"
import { PlusCircle } from "lucide-react"
import { useState } from "react"
import { useForm } from "react-hook-form"
import * as z from "zod"

const customerSchema = z.object({
  name: z.string().min(2, {
    message: "يجب أن يكون الاسم أكثر من حرفين.",
  }),
  code: z.string().min(3, {
    message: "يجب أن يكون الكود أكثر من ثلاثة حروف أو أرقام.",
  }),
})

type Customer = z.infer<typeof customerSchema> & { id: string }

export default function CustomersPage() {
  const [customers, setCustomers] = useState<Customer[]>([])
  const [showForm, setShowForm] = useState(false)
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null)

  const form = useForm<z.infer<typeof customerSchema>>({
    resolver: zodResolver(customerSchema),
    defaultValues: {
      name: "",
      code: "",
    },
  })

  const [formData, setFormData] = useState({
    name: "",
    code: "",
  })

  const handleAddCustomer = () => {
    setShowForm(true)
    setEditingCustomer(null)
    setFormData({ name: "", code: "" })
    form.reset()
  }

  const handleEditCustomer = (customer: Customer) => {
    setShowForm(true)
    setEditingCustomer(customer)
    setFormData({
      name: customer.name,
      code: customer.code,
    })
    form.setValue("name", customer.name)
    form.setValue("code", customer.code)
  }

  const handleDeleteCustomer = (id: string) => {
    setCustomers(customers.filter((customer) => customer.id !== id))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // التحقق من عدم تكرار الكود
    const codeExists = customers.some(
      (customer) =>
        customer.code.toLowerCase() === formData.code.toLowerCase() &&
        (!editingCustomer || customer.id !== editingCustomer.id),
    )

    if (codeExists) {
      alert("كود العميل موجود مسبقاً! يرجى استخدام كود مختلف")
      return
    }

    if (editingCustomer) {
      // Update existing customer
      setCustomers(
        customers.map((customer) => (customer.id === editingCustomer.id ? { ...customer, ...formData } : customer)),
      )
    } else {
      // Add new customer
      const newCustomer: Customer = {
        id: crypto.randomUUID(),
        ...formData,
      }
      setCustomers([...customers, newCustomer])
    }

    setShowForm(false)
    setFormData({ name: "", code: "" })
    form.reset()
  }

  return (
    <div className="container py-10">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">العملاء</h1>
        <Button onClick={handleAddCustomer}>
          <PlusCircle className="mr-2 h-4 w-4" />
          إضافة عميل
        </Button>
      </div>

      {showForm && (
        <div className="rounded-md border p-4 mb-4">
          <Form {...form}>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="name" className="text-right">
                  اسم العميل *
                </Label>
                <div className="col-span-3">
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                    placeholder="اسم العميل"
                  />
                </div>
              </div>

              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="code" className="text-right">
                  كود العميل *
                </Label>
                <div className="col-span-3">
                  <Input
                    id="code"
                    value={formData.code}
                    onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                    required
                    placeholder="مثال: C001"
                  />
                  <p className="text-xs text-gray-500 mt-1">يجب أن يكون الكود فريداً وغير مكرر</p>
                </div>
              </div>

              <div className="flex justify-end">
                <Button type="submit">{editingCustomer ? "تعديل" : "إضافة"}</Button>
                <Button type="button" variant="secondary" onClick={() => setShowForm(false)} className="mr-2">
                  إلغاء
                </Button>
              </div>
            </form>
          </Form>
        </div>
      )}

      <Table>
        <TableCaption>قائمة العملاء.</TableCaption>
        <TableHeader>
          <TableRow>
            <TableHead>الاسم</TableHead>
            <TableHead>الكود</TableHead>
            <TableHead className="text-right">العمليات</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {customers.map((customer) => (
            <TableRow key={customer.id}>
              <TableCell>{customer.name}</TableCell>
              <TableCell>{customer.code}</TableCell>
              <TableCell className="text-right">
                <Button variant="link" size="sm" onClick={() => handleEditCustomer(customer)}>
                  تعديل
                </Button>
                <Button variant="link" size="sm" onClick={() => handleDeleteCustomer(customer.id)}>
                  حذف
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}
