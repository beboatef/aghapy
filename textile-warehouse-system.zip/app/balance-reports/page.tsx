"use client"

import { useState } from "react"
import { toast } from "@/components/ui/use-toast"
import { useAuth } from "@/hooks/use-auth"
import { exportToExcel, exportToPDF, printData } from "@/lib/export-utils"

// نوع البيانات للأرصدة
interface BalanceRecord {
  customerId: number
  customerName: string
  materialId: number
  materialName: string
  unit: string
  openingBalance: number
  incoming: number
  outgoing: number
  returned: number
  delivered: number
  separatedQuantity: number
  readyQuantity: number
  final: number
}

export default function BalanceReportsPage() {
  const { logout } = useAuth()
  // أنواع التقارير
  const reportTypes = [
    { value: "balance_summary", label: "ملخص الأرصدة" },
    { value: "balance_details", label: "تفاصيل الأرصدة" },
    { value: "movement_history", label: "سجل حركة الأصناف" },
    { value: "customer_balances", label: "أرصدة العملاء" },
    { value: "negative_balances", label: "الأرصدة السالبة" },
    { value: "ready_quantities", label: "الكميات الجاهزة" },
    { value: "separated_quantities", label: "المنفصلات" },
  ]

  // بيانات العملاء والأصناف - بيانات محاكاة
  const customers = [
    { id: 1, code: "C001", name: "شركة النسيج المتحدة" },
    { id: 2, code: "C002", name: "مصنع الألوان الحديث" },
    { id: 3, code: "C003", name: "شركة القطن السعودي" },
    { id: 4, code: "C004", name: "مصنع الأقمشة الفاخرة" },
    { id: 5, code: "C005", name: "شركة الخيوط العربية" },
  ]

  const materials = [
    { id: 1, code: "M001", name: "قطن أبيض خام", unit: "كجم" },
    { id: 2, code: "M002", name: "بوليستر أزرق", unit: "متر" },
    { id: 3, code: "M003", name: "قطن ملون", unit: "كجم" },
    { id: 4, code: "M004", name: "حرير طبيعي", unit: "متر" },
    { id: 5, code: "M005", name: "كتان مصري", unit: "كجم" },
  ]

  // بيانات الأرصدة - بيانات محاكاة
  const balanceData: BalanceRecord[] = [
    {
      customerId: 1,
      customerName: "شركة النسيج المتحدة",
      materialId: 1,
      materialName: "قطن أبيض خام",
      unit: "كجم",
      openingBalance: 100,
      incoming: 400,
      outgoing: 240,
      returned: 50,
      delivered: 180,
      separatedQuantity: 15,
      readyQuantity: 20,
      final: 130,
    },
    {
      customerId: 1,
      customerName: "شركة النسيج المتحدة",
      materialId: 2,
      materialName: "بوليستر أزرق",
      unit: "متر",
      openingBalance: 50,
      incoming: 200,
      outgoing: 150,
      returned: 20,
      delivered: 120,
      separatedQuantity: 5,
      readyQuantity: 10,
      final: 0,
    },
    {
      customerId: 2,
      customerName: "مصنع الألوان الحديث",
      materialId: 1,
      materialName: "قطن أبيض خام",
      unit: "كجم",
      openingBalance: 75,
      incoming: 300,
      outgoing: 280,
      returned: 30,
      delivered: 250,
      separatedQuantity: 10,
      readyQuantity: 15,
      final: -125,
    },
    {
      customerId: 2,
      customerName: "مصنع الألوان الحديث",
      materialId: 3,
      materialName: "قطن ملون",
      unit: "كجم",
      openingBalance: 200,
      incoming: 500,
      outgoing: 350,
      returned: 40,
      delivered: 300,
      separatedQuantity: 20,
      readyQuantity: 25,
      final: 90,
    },
    {
      customerId: 3,
      customerName: "شركة القطن السعودي",
      materialId: 2,
      materialName: "بوليستر أزرق",
      unit: "متر",
      openingBalance: 150,
      incoming: 600,
      outgoing: 450,
      returned: 45,
      delivered: 400,
      separatedQuantity: 25,
      readyQuantity: 30,
      final: -55,
    },
    {
      customerId: 4,
      customerName: "مصنع الأقمشة الفاخرة",
      materialId: 4,
      materialName: "حرير طبيعي",
      unit: "متر",
      openingBalance: 80,
      incoming: 250,
      outgoing: 180,
      returned: 15,
      delivered: 120,
      separatedQuantity: 8,
      readyQuantity: 12,
      final: 45,
    },
    {
      customerId: 5,
      customerName: "شركة الخيوط العربية",
      materialId: 5,
      materialName: "كتان مصري",
      unit: "كجم",
      openingBalance: 120,
      incoming: 350,
      outgoing: 280,
      returned: 25,
      delivered: 150,
      separatedQuantity: 12,
      readyQuantity: 18,
      final: 65,
    },
  ]

  // بيانات حركة الأصناف حسب الشهر - بيانات محاكاة
  const monthlyMovementData = [
    { month: "يناير", وارد: 450, منصرف: 320, مرتجع: 40, مسلم: 200 },
    { month: "فبراير", وارد: 380, منصرف: 290, مرتجع: 35, مسلم: 180 },
    { month: "مارس", وارد: 520, منصرف: 380, مرتجع: 45, مسلم: 250 },
    { month: "أبريل", وارد: 480, منصرف: 350, مرتجع: 30, مسلم: 220 },
    { month: "مايو", وارد: 550, منصرف: 420, مرتجع: 50, مسلم: 270 },
    { month: "يونيو", وارد: 600, منصرف: 450, مرتجع: 55, مسلم: 300 },
  ]

  // بيانات توزيع الأصناف - بيانات محاكاة
  const materialDistribution = [
    { name: "قطن أبيض خام", value: 35, color: "#3b82f6" },
    { name: "بوليستر أزرق", value: 25, color: "#ef4444" },
    { name: "قطن ملون", value: 20, color: "#f59e0b" },
    { name: "حرير طبيعي", value: 10, color: "#10b981" },
    { name: "كتان مصري", value: 10, color: "#8b5cf6" },
  ]

  // متغيرات الحالة
  const [reportType, setReportType] = useState("balance_summary")
  const [dateFrom, setDateFrom] = useState("2024-01-01")
  const [dateTo, setDateTo] = useState("2024-06-30")
  const [customerFilter, setCustomerFilter] = useState("all")
  const [materialFilter, setMaterialFilter] = useState("all")
  const [unitFilter, setUnitFilter] = useState("all")
  const [showNegativeOnly, setShowNegativeOnly] = useState(false)
  const [showZeroBalances, setShowZeroBalances] = useState(true)
  const [sortField, setSortField] = useState("customerName")
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc")
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false)
  const [chartType, setChartType] = useState("bar")
  const [showDetails, setShowDetails] = useState(false)
  const [expandedCustomers, setExpandedCustomers] = useState<number[]>([])
  const [isExporting, setIsExporting] = useState(false)
  const [reportName, setReportName] = useState("")

  // فلترة البيانات
  const filteredBalances = balanceData.filter((balance) => {
    // فلتر العميل
    if (customerFilter !== "all" && balance.customerId.toString() !== customerFilter) {
      return false
    }

    // فلتر الصنف
    if (materialFilter !== "all" && balance.materialId.toString() !== materialFilter) {
      return false
    }

    // فلتر الوحدة
    if (unitFilter !== "all" && balance.unit !== unitFilter) {
      return false
    }

    // فلتر الأرصدة السالبة
    if (showNegativeOnly && balance.final >= 0) {
      return false
    }

    // فلتر الأرصدة الصفرية
    if (!showZeroBalances && balance.final === 0) {
      return false
    }

    return true
  })

  // ترتيب البيانات
  const sortedBalances = [...filteredBalances].sort((a, b) => {
    let valueA: any = a[sortField as keyof BalanceRecord]
    let valueB: any = b[sortField as keyof BalanceRecord]

    if (typeof valueA === "string") {
      valueA = valueA.toLowerCase()
      valueB = valueB.toLowerCase()
    }

    if (valueA < valueB) {
      return sortDirection === "asc" ? -1 : 1
    }
    if (valueA > valueB) {
      return sortDirection === "asc" ? 1 : -1
    }
    return 0
  })

  // تجميع البيانات حسب العميل
  const balancesByCustomer = sortedBalances.reduce(
    (acc, balance) => {
      if (!acc[balance.customerId]) {
        acc[balance.customerId] = {
          customerId: balance.customerId,
          customerName: balance.customerName,
          materials: [],
          totalOpeningBalance: 0,
          totalIncoming: 0,
          totalOutgoing: 0,
          totalReturned: 0,
          totalDelivered: 0,
          totalSeparatedQuantity: 0,
          totalReadyQuantity: 0,
          totalFinal: 0,
        }
      }

      acc[balance.customerId].materials.push(balance)
      acc[balance.customerId].totalOpeningBalance += balance.openingBalance
      acc[balance.customerId].totalIncoming += balance.incoming
      acc[balance.customerId].totalOutgoing += balance.outgoing
      acc[balance.customerId].totalReturned += balance.returned
      acc[balance.customerId].totalDelivered += balance.delivered
      acc[balance.customerId].totalSeparatedQuantity += balance.separatedQuantity
      acc[balance.customerId].totalReadyQuantity += balance.readyQuantity
      acc[balance.customerId].totalFinal += balance.final

      return acc
    },
    {} as Record<number, any>,
  )

  // تجميع البيانات حسب الصنف
  const balancesByMaterial = sortedBalances.reduce(
    (acc, balance) => {
      if (!acc[balance.materialId]) {
        acc[balance.materialId] = {
          materialId: balance.materialId,
          materialName: balance.materialName,
          unit: balance.unit,
          customers: [],
          totalOpeningBalance: 0,
          totalIncoming: 0,
          totalOutgoing: 0,
          totalReturned: 0,
          totalDelivered: 0,
          totalSeparatedQuantity: 0,
          totalReadyQuantity: 0,
          totalFinal: 0,
        }
      }

      acc[balance.materialId].customers.push(balance)
      acc[balance.materialId].totalOpeningBalance += balance.openingBalance
      acc[balance.materialId].totalIncoming += balance.incoming
      acc[balance.materialId].totalOutgoing += balance.outgoing
      acc[balance.materialId].totalReturned += balance.returned
      acc[balance.materialId].totalDelivered += balance.delivered
      acc[balance.materialId].totalSeparatedQuantity += balance.separatedQuantity
      acc[balance.materialId].totalReadyQuantity += balance.readyQuantity
      acc[balance.materialId].totalFinal += balance.final
      return acc
    },
    {} as Record<number, any>,
  )

  // إجماليات عامة
  const totals = sortedBalances.reduce(
    (acc, balance) => {
      acc.openingBalance += balance.openingBalance
      acc.incoming += balance.incoming
      acc.outgoing += balance.outgoing
      acc.returned += balance.returned
      acc.delivered += balance.delivered
      acc.separatedQuantity += balance.separatedQuantity
      acc.readyQuantity += balance.readyQuantity
      acc.final += balance.final
      return acc
    },
    {
      openingBalance: 0,
      incoming: 0,
      outgoing: 0,
      returned: 0,
      delivered: 0,
      separatedQuantity: 0,
      readyQuantity: 0,
      final: 0,
    },
  )

  // بيانات للرسم البياني
  const chartData = Object.values(balancesByMaterial).map((material: any) => ({
    name: material.materialName,
    رصيد: material.totalFinal,
    وارد: material.totalIncoming,
    منصرف: material.totalOutgoing,
    مرتجع: material.totalReturned,
    مسلم: material.totalDelivered,
    منفصلات: material.totalSeparatedQuantity,
    جاهز: material.totalReadyQuantity,
  }))

  // بيانات الأرصدة السالبة
  const negativeBalances = sortedBalances.filter((balance) => balance.final < 0)

  // بيانات الكميات الجاهزة
  const readyQuantities = sortedBalances.filter((balance) => balance.readyQuantity > 0)

  // بيانات المنفصلات
  const separatedQuantities = sortedBalances.filter((balance) => balance.separatedQuantity > 0)

  // تبديل حالة التوسيع للعميل
  const toggleCustomerExpand = (customerId: number) => {
    if (expandedCustomers.includes(customerId)) {
      setExpandedCustomers(expandedCustomers.filter((id) => id !== customerId))
    } else {
      setExpandedCustomers([...expandedCustomers, customerId])
    }
  }

  // تغيير اتجاه الترتيب
  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc")
    } else {
      setSortField(field)
      setSortDirection("asc")
    }
  }

  // الحصول على عنوان التقرير الحالي
  const getCurrentReportTitle = () => {
    const reportTitle = reportTypes.find((r) => r.value === reportType)?.label || "تقرير الأرصدة"
    return `${reportTitle} (${dateFrom} - ${dateTo})`
  }

  // تحضير البيانات للتصدير
  const prepareExportData = () => {
    let exportData: any[] = []

    switch (reportType) {
      case "balance_summary":
        exportData = Object.values(balancesByMaterial).map((material: any) => ({
          الصنف: material.materialName,
          الوحدة: material.unit,
          رصيد_بداية_المدة: `${material.totalOpeningBalance.toLocaleString("ar-EG")} ج.م`,
          إجمالي_الوارد: `${material.totalIncoming.toLocaleString("ar-EG")} ج.م`,
          إجمالي_المنصرف: `${material.totalOutgoing.toLocaleString("ar-EG")} ج.م`,
          إجمالي_المرتجع: `${material.totalReturned.toLocaleString("ar-EG")} ج.م`,
          الكمية_المسلمة: `${material.totalDelivered.toLocaleString("ar-EG")} ج.م`,
          المنفصلات: `${material.totalSeparatedQuantity.toLocaleString("ar-EG")} ج.م`,
          الكمية_الجاهزة: `${material.totalReadyQuantity.toLocaleString("ar-EG")} ج.م`,
          الرصيد_النهائي: `${material.totalFinal.toLocaleString("ar-EG")} ج.م`,
          الرصيد_مخصوم_منه_الجاهز: `${(material.totalFinal - material.totalReadyQuantity).toLocaleString("ar-EG")} ج.م`,
        }))
        break

      case "negative_balances":
        exportData = negativeBalances.map((balance) => ({
          العميل: balance.customerName,
          الصنف: balance.materialName,
          الوحدة: balance.unit,
          رصيد_بداية_المدة: `${balance.openingBalance.toLocaleString("ar-EG")} ج.م`,
          إجمالي_الوارد: `${balance.incoming.toLocaleString("ar-EG")} ج.م`,
          إجمالي_المنصرف: `${balance.outgoing.toLocaleString("ar-EG")} ج.م`,
          إجمالي_المرتجع: `${balance.returned.toLocaleString("ar-EG")} ج.م`,
          الكمية_المسلمة: `${balance.delivered.toLocaleString("ar-EG")} ج.م`,
          الرصيد_النهائي: `${balance.final.toLocaleString("ar-EG")} ج.م`,
        }))
        break

      case "ready_quantities":
        exportData = readyQuantities.map((balance) => ({
          العميل: balance.customerName,
          الصنف: balance.materialName,
          الوحدة: balance.unit,
          الكمية_الجاهزة: `${balance.readyQuantity.toLocaleString("ar-EG")} ج.م`,
          الرصيد_النهائي: `${balance.final.toLocaleString("ar-EG")} ج.م`,
          نسبة_الجاهز_من_الرصيد:
            balance.final !== 0 ? ((balance.readyQuantity / balance.final) * 100).toFixed(2) + "%" : "غير محدد",
        }))
        break

      case "separated_quantities":
        exportData = separatedQuantities.map((balance) => ({
          العميل: balance.customerName,
          الصنف: balance.materialName,
          الوحدة: balance.unit,
          المنفصلات: `${balance.separatedQuantity.toLocaleString("ar-EG")} ج.م`,
          الرصيد_النهائي: `${balance.final.toLocaleString("ar-EG")} ج.م`,
          نسبة_المنفصلات_من_الرصيد:
            balance.final !== 0 ? ((balance.separatedQuantity / balance.final) * 100).toFixed(2) + "%" : "غير محدد",
        }))
        break

      default:
        exportData = sortedBalances.map((balance) => ({
          العميل: balance.customerName,
          الصنف: balance.materialName,
          الوحدة: balance.unit,
          رصيد_بداية_المدة: `${balance.openingBalance.toLocaleString("ar-EG")} ج.م`,
          إجمالي_الوارد: `${balance.incoming.toLocaleString("ar-EG")} ج.م`,
          إجمالي_المنصرف: `${balance.outgoing.toLocaleString("ar-EG")} ج.م`,
          إجمالي_المرتجع: `${balance.returned.toLocaleString("ar-EG")} ج.م`,
          الكمية_المسلمة: `${balance.delivered.toLocaleString("ar-EG")} ج.م`,
          المنفصلات: `${balance.separatedQuantity.toLocaleString("ar-EG")} ج.م`,
          الكمية_الجاهزة: `${balance.readyQuantity.toLocaleString("ar-EG")} ج.م`,
          الرصيد_النهائي: `${balance.final.toLocaleString("ar-EG")} ج.م`,
        }))
    }

    return exportData
  }

  // تحضير أعمدة التقرير للتصدير
  const prepareExportColumns = () => {
    let columns: { header: string; dataKey: string }[] = []

    switch (reportType) {
      case "balance_summary":
        columns = [
          { header: "الصنف", dataKey: "الصنف" },
          { header: "الوحدة", dataKey: "الوحدة" },
          { header: "رصيد بداية المدة", dataKey: "رصيد_بداية_المدة" },
          { header: "إجمالي الوارد", dataKey: "إجمالي_الوارد" },
          { header: "إجمالي المنصرف", dataKey: "إجمالي_المنصرف" },
          { header: "إجمالي المرتجع", dataKey: "إجمالي_المرتجع" },
          { header: "الكمية المسلمة", dataKey: "الكمية_المسلمة" },
          { header: "المنفصلات", dataKey: "المنفصلات" },
          { header: "الكمية الجاهزة", dataKey: "الكمية_الجاهزة" },
          { header: "الرصيد النهائي", dataKey: "الرصيد_النهائي" },
        ]
        break

      case "negative_balances":
        columns = [
          { header: "العميل", dataKey: "العميل" },
          { header: "الصنف", dataKey: "الصنف" },
          { header: "الوحدة", dataKey: "الوحدة" },
          { header: "رصيد بداية المدة", dataKey: "رصيد_بداية_المدة" },
          { header: "إجمالي الوارد", dataKey: "إجمالي_الوارد" },
          { header: "إجمالي المنصرف", dataKey: "إجمالي_المنصرف" },
          { header: "إجمالي المرتجع", dataKey: "إجمالي_المرتجع" },
          { header: "الكمية المسلمة", dataKey: "الكمية_المسلمة" },
          { header: "الرصيد النهائي", dataKey: "الرصيد_النهائي" },
        ]
        break

      case "ready_quantities":
        columns = [
          { header: "العميل", dataKey: "العميل" },
          { header: "الصنف", dataKey: "الصنف" },
          { header: "الوحدة", dataKey: "الوحدة" },
          { header: "الكمية الجاهزة", dataKey: "الكمية_الجاهزة" },
          { header: "الرصيد النهائي", dataKey: "الرصيد_النهائي" },
          { header: "نسبة الجاهز من الرصيد", dataKey: "نسبة_الجاهز_من_الرصيد" },
        ]
        break

      case "separated_quantities":
        columns = [
          { header: "العميل", dataKey: "العميل" },
          { header: "الصنف", dataKey: "الصنف" },
          { header: "الوحدة", dataKey: "الوحدة" },
          { header: "المنفصلات", dataKey: "المنفصلات" },
          { header: "الرصيد النهائي", dataKey: "الرصيد_النهائي" },
          { header: "نسبة المنفصلات من الرصيد", dataKey: "نسبة_المنفصلات_من_الرصيد" },
        ]
        break

      default:
        columns = [
          { header: "العميل", dataKey: "العميل" },
          { header: "الصنف", dataKey: "الصنف" },
          { header: "الوحدة", dataKey: "الوحدة" },
          { header: "رصيد بداية المدة", dataKey: "رصيد_بداية_المدة" },
          { header: "إجمالي الوارد", dataKey: "إجمالي_الوارد" },
          { header: "إجمالي المنصرف", dataKey: "إجمالي_المنصرف" },
          { header: "إجمالي المرتجع", dataKey: "إجمالي_المرتجع" },
          { header: "الكمية المسلمة", dataKey: "الكمية_المسلمة" },
          { header: "المنفصلات", dataKey: "المنفصلات" },
          { header: "الكمية الجاهزة", dataKey: "الكمية_الجاهزة" },
          { header: "الرصيد النهائي", dataKey: "الرصيد_النهائي" },
        ]
    }

    return columns
  }

  // تصدير التقرير
  const exportReport = (format: string) => {
    setIsExporting(true)

    try {
      const exportData = prepareExportData()
      const columns = prepareExportColumns()
      const title = getCurrentReportTitle()
      const fileName = reportName || `تقرير_الأرصدة_${new Date().toISOString().split("T")[0]}`

      let result

      if (format === "Excel") {
        result = exportToExcel(exportData, fileName, "الأرصدة")
      } else if (format === "PDF") {
        result = exportToPDF(exportData, fileName, title, columns)
      }

      if (result?.success) {
        toast({
          title: "تم التصدير بنجاح",
          description: result.message,
        })
      } else {
        toast({
          title: "فشل التصدير",
          description: result?.message || "حدث خطأ أثناء تصدير البيانات",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("خطأ في تصدير التقرير:", error)
      toast({
        title: "فشل التصدير",
        description: `حدث خطأ أثناء تصدير البيانات: ${error.message}`,
        variant: "destructive",
      })
    } finally {
      setIsExporting(false)
    }
  }

  // طباعة التقرير
  const printReport = () => {
    try {
      const exportData = prepareExportData()
      const columns = prepareExportColumns()
      const title = getCurrentReportTitle()

      const result = printData(exportData, title, columns)

      if (!result.success) {
        toast({
          title: "فشل الطباعة",
          description: result.message,
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("خطأ في طباعة التقرير:", error)
      toast({
        title: "فشل الطباعة",
        description: `حدث خطأ أثناء تحضير البيانات للطباعة: ${error.message}`,
        variant: "destructive",
      })
    }
  }

  // حفظ إعدادات التقرير
  const saveReportSettings = () => {
    if (!reportName) {
      toast({
        title: "خطأ",
        description: "يرجى إدخال اسم للتقرير",
        variant: "destructive",
      })
      return
    }

    const settings = {
      name: reportName,
      type: reportType,
      dateFrom,
      dateTo,
      customerFilter,
      materialFilter,
      unitFilter,
      showNegativeOnly,
      showZeroBalances,
      sortField,
      sortDirection,
      chartType,
    }

    // حفظ الإعدادات في localStorage
    const savedReports = JSON.parse(localStorage.getItem("savedReports") || "[]")
    savedReports.push(settings)
    localStorage.setItem("savedReports", JSON.stringify(savedReports))

    toast({
      title: "تم الحفظ بنجاح",
      description: "تم حفظ إعدادات التقرير بنجاح",
    })
  }

  const formatValue = (amount: number) => {
    return `${amount.toLocaleString("ar-EG")} ج.م`
  }
}
