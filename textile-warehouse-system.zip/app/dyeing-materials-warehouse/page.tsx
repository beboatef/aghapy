"use client"

import type React from "react"

import { useState, useEffect, useCallback } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  Package,
  Plus,
  Search,
  Edit,
  Trash2,
  MoreHorizontal,
  TrendingUp,
  AlertTriangle,
  Palette,
  Filter,
  Download,
  ShoppingCart,
  History,
  ArrowRightLeft,
} from "lucide-react"
import { useAuth } from "@/hooks/use-auth"
import { dataManager } from "@/lib/data-manager"
import { PageLayout } from "@/components/page-layout"

interface DyeingMaterial {
  id: number
  code: string
  name: string
  nameAr: string
  category: "dye" | "chemical" | "auxiliary" | "finishing"
  unit: "kg" | "gram" | "liter"
  purchasePrice: number
  currentStock: number
  minimumStock: number
  supplier: string
  lastPurchaseDate: string
  status: "active" | "inactive" | "low_stock"
  createdAt: string
  updatedAt: string
  parentMaterialId?: number
  isSubstituted?: boolean
  substitutedQuantity?: number
  originalQuantity?: number
}

interface StockMovement {
  id: number
  materialId: number
  materialName: string
  type: "purchase" | "usage" | "adjustment" | "substitution"
  quantity: number
  unit: string
  unitPrice?: number
  totalCost?: number
  reference: string
  notes?: string
  date: string
  createdBy: string
}

interface MaterialSubstitution {
  id: number
  originalMaterialId: number
  originalMaterialName: string
  substitutedMaterialId: number
  substitutedMaterialName: string
  quantitySubstituted: number
  unit: string
  reason: string
  date: string
  createdBy: string
  status: "active" | "completed"
  addedMaterialType?: "water" | "chemical" | "other"
  addedMaterialQuantity?: number
  finalQuantity?: number
  substitutionRatio?: number
}

export default function DyeingMaterialsWarehousePage() {
  const [activeTab, setActiveTab] = useState("all")
  const [showDialog, setShowDialog] = useState(false)
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const [showStockDialog, setShowStockDialog] = useState(false)
  const [showMovementsDialog, setShowMovementsDialog] = useState(false)
  const [showSubstitutionDialog, setShowSubstitutionDialog] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all_categories")
  const [selectedMaterial, setSelectedMaterial] = useState<DyeingMaterial | null>(null)
  const [isEditMode, setIsEditMode] = useState(false)

  const { isAdmin, canDelete } = useAuth()

  const [materials, setMaterials] = useState<DyeingMaterial[]>([])
  const [stockMovements, setStockMovements] = useState<StockMovement[]>([])
  const [substitutions, setSubstitutions] = useState<MaterialSubstitution[]>([])

  const [formData, setFormData] = useState({
    code: "",
    name: "",
    nameAr: "",
    category: "dye" as "dye" | "chemical" | "auxiliary" | "finishing",
    unit: "kg" as "kg" | "gram" | "liter",
    purchasePrice: "",
    currentStock: "",
    minimumStock: "",
    supplier: "",
  })

  const [stockFormData, setStockFormData] = useState({
    type: "purchase" as "purchase" | "usage" | "adjustment",
    quantity: "",
    unitPrice: "",
    reference: "",
    notes: "",
  })

  const [substitutionFormData, setSubstitutionFormData] = useState({
    originalMaterialId: "",
    quantityToSubstitute: "",
    addedMaterialType: "water" as "water" | "chemical" | "other", // water, chemical, other
    addedMaterialQuantity: "",
    finalQuantity: "",
    substitutionRatio: "",
    reason: "",
    notes: "",
  })

  // Load materials from data manager
  useEffect(() => {
    const loadedMaterials = dataManager.getDyeingMaterials()
    if (loadedMaterials.length === 0) {
      // Initialize with sample data
      const sampleMaterials: DyeingMaterial[] = [
        {
          id: 1,
          code: "DYE001",
          name: "Direct Blue 86",
          nameAr: "أزرق مباشر 86",
          category: "dye",
          unit: "kg",
          purchasePrice: 45.5,
          currentStock: 125.5,
          minimumStock: 20,
          supplier: "Advanced Colors Co.",
          lastPurchaseDate: "2024-03-01",
          status: "active",
          createdAt: "2024-01-15",
          updatedAt: "2024-03-01",
        },
        {
          id: 2,
          code: "CHM001",
          name: "Acetic Acid",
          nameAr: "حمض الخليك",
          category: "chemical",
          unit: "liter",
          purchasePrice: 12.75,
          currentStock: 85.2,
          minimumStock: 15,
          supplier: "Industrial Chemicals Ltd.",
          lastPurchaseDate: "2024-02-28",
          status: "active",
          createdAt: "2024-01-10",
          updatedAt: "2024-02-28",
        },
        {
          id: 3,
          code: "AUX001",
          name: "Fabric Softener",
          nameAr: "منعم الأقمشة",
          category: "auxiliary",
          unit: "kg",
          purchasePrice: 28.9,
          currentStock: 15.8,
          minimumStock: 25,
          supplier: "Textile Auxiliaries Inc.",
          lastPurchaseDate: "2024-03-05",
          status: "low_stock",
          createdAt: "2024-01-20",
          updatedAt: "2024-03-05",
        },
      ]
      dataManager.setDyeingMaterials(sampleMaterials)
      setMaterials(sampleMaterials)
    } else {
      setMaterials(loadedMaterials)
    }

    // Load stock movements
    const movements = dataManager.getData("stockMovements", [])
    setStockMovements(movements)

    // Load substitutions
    const loadedSubstitutions = dataManager.getData("materialSubstitutions", [])
    setSubstitutions(loadedSubstitutions)
  }, [])

  // Filter materials
  const filteredMaterials = materials.filter((material) => {
    const matchesTab =
      activeTab === "all" ||
      (activeTab === "active" && material.status === "active") ||
      (activeTab === "low_stock" && material.status === "low_stock") ||
      (activeTab === "inactive" && material.status === "inactive") ||
      (activeTab === "substituted" && material.isSubstituted)

    const matchesSearch =
      material.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      material.nameAr.includes(searchTerm) ||
      material.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      material.supplier.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesCategory = categoryFilter === "all_categories" || material.category === categoryFilter

    return matchesTab && matchesSearch && matchesCategory
  })

  const handleOpenDialog = (material?: DyeingMaterial) => {
    if (material) {
      setIsEditMode(true)
      setSelectedMaterial(material)
      setFormData({
        code: material.code,
        name: material.name,
        nameAr: material.nameAr,
        category: material.category,
        unit: material.unit,
        purchasePrice: material.purchasePrice.toString(),
        currentStock: material.currentStock.toString(),
        minimumStock: material.minimumStock.toString(),
        supplier: material.supplier,
      })
    } else {
      setIsEditMode(false)
      setSelectedMaterial(null)
      setFormData({
        code: "",
        name: "",
        nameAr: "",
        category: "dye",
        unit: "kg",
        purchasePrice: "",
        currentStock: "",
        minimumStock: "",
        supplier: "",
      })
    }
    setShowDialog(true)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (isEditMode && selectedMaterial) {
      const updatedMaterial = {
        ...selectedMaterial,
        code: formData.code,
        name: formData.name,
        nameAr: formData.nameAr,
        category: formData.category,
        unit: formData.unit,
        purchasePrice: Number.parseFloat(formData.purchasePrice),
        currentStock: Number.parseFloat(formData.currentStock),
        minimumStock: Number.parseFloat(formData.minimumStock),
        supplier: formData.supplier,
        status:
          Number.parseFloat(formData.currentStock) <= Number.parseFloat(formData.minimumStock)
            ? ("low_stock" as const)
            : ("active" as const),
        updatedAt: new Date().toISOString().split("T")[0],
      }

      const updatedMaterials = materials.map((m) => (m.id === selectedMaterial.id ? updatedMaterial : m))
      setMaterials(updatedMaterials)
      dataManager.setDyeingMaterials(updatedMaterials)
    } else {
      const newMaterial: DyeingMaterial = {
        id: Date.now(),
        code: formData.code,
        name: formData.name,
        nameAr: formData.nameAr,
        category: formData.category,
        unit: formData.unit,
        purchasePrice: Number.parseFloat(formData.purchasePrice),
        currentStock: Number.parseFloat(formData.currentStock),
        minimumStock: Number.parseFloat(formData.minimumStock),
        supplier: formData.supplier,
        lastPurchaseDate: new Date().toISOString().split("T")[0],
        status:
          Number.parseFloat(formData.currentStock) <= Number.parseFloat(formData.minimumStock) ? "low_stock" : "active",
        createdAt: new Date().toISOString().split("T")[0],
        updatedAt: new Date().toISOString().split("T")[0],
      }

      const updatedMaterials = [...materials, newMaterial]
      setMaterials(updatedMaterials)
      dataManager.setDyeingMaterials(updatedMaterials)

      // Add initial stock movement
      if (Number.parseFloat(formData.currentStock) > 0) {
        const newMovement: StockMovement = {
          id: Date.now(),
          materialId: newMaterial.id,
          materialName: newMaterial.name,
          type: "purchase",
          quantity: Number.parseFloat(formData.currentStock),
          unit: newMaterial.unit,
          unitPrice: newMaterial.purchasePrice,
          totalCost: Number.parseFloat(formData.currentStock) * newMaterial.purchasePrice,
          reference: "Initial Stock",
          notes: "رصيد افتتاحي",
          date: new Date().toISOString().split("T")[0],
          createdBy: "System",
        }
        const updatedMovements = [...stockMovements, newMovement]
        setStockMovements(updatedMovements)
        dataManager.setData("stockMovements", updatedMovements)
      }
    }

    setShowDialog(false)
  }

  const handleDeleteMaterial = () => {
    if (selectedMaterial) {
      const updatedMaterials = materials.filter((m) => m.id !== selectedMaterial.id)
      setMaterials(updatedMaterials)
      dataManager.setDyeingMaterials(updatedMaterials)
      setShowDeleteDialog(false)
      setSelectedMaterial(null)
    }
  }

  const handleStockMovement = () => {
    if (!selectedMaterial) return

    const quantity = Number.parseFloat(stockFormData.quantity)
    const unitPrice = stockFormData.unitPrice
      ? Number.parseFloat(stockFormData.unitPrice)
      : selectedMaterial.purchasePrice

    let newStock = selectedMaterial.currentStock
    if (stockFormData.type === "purchase" || stockFormData.type === "adjustment") {
      newStock += quantity
    } else if (stockFormData.type === "usage") {
      newStock -= quantity
    }

    // Update material stock
    const updatedMaterial = {
      ...selectedMaterial,
      currentStock: Math.max(0, newStock),
      status: newStock <= selectedMaterial.minimumStock ? ("low_stock" as const) : ("active" as const),
      lastPurchaseDate:
        stockFormData.type === "purchase" ? new Date().toISOString().split("T")[0] : selectedMaterial.lastPurchaseDate,
      updatedAt: new Date().toISOString().split("T")[0],
    }

    const updatedMaterials = materials.map((m) => (m.id === selectedMaterial.id ? updatedMaterial : m))
    setMaterials(updatedMaterials)
    dataManager.setDyeingMaterials(updatedMaterials)

    // Add stock movement record
    const newMovement: StockMovement = {
      id: Date.now(),
      materialId: selectedMaterial.id,
      materialName: selectedMaterial.name,
      type: stockFormData.type,
      quantity: quantity,
      unit: selectedMaterial.unit,
      unitPrice: unitPrice,
      totalCost: quantity * unitPrice,
      reference: stockFormData.reference,
      notes: stockFormData.notes,
      date: new Date().toISOString().split("T")[0],
      createdBy: "Current User",
    }

    const updatedMovements = [...stockMovements, newMovement]
    setStockMovements(updatedMovements)
    dataManager.setData("stockMovements", updatedMovements)

    setShowStockDialog(false)
    setStockFormData({
      type: "purchase",
      quantity: "",
      unitPrice: "",
      reference: "",
      notes: "",
    })
  }

  const handleMaterialSubstitution = () => {
    if (!selectedMaterial) return

    const originalMaterial = materials.find((m) => m.id.toString() === substitutionFormData.originalMaterialId)
    if (!originalMaterial) return

    const quantityToSubstitute = Number.parseFloat(substitutionFormData.quantityToSubstitute)
    const addedMaterialQuantity = Number.parseFloat(substitutionFormData.addedMaterialQuantity) || 0
    const finalQuantity =
      Number.parseFloat(substitutionFormData.finalQuantity) || quantityToSubstitute + addedMaterialQuantity
    const substitutionRatio = (quantityToSubstitute / finalQuantity) * 100

    // Check if original material has enough stock
    if (originalMaterial.currentStock < quantityToSubstitute) {
      alert("الكمية المطلوبة أكبر من المخزون المتاح للمادة الأصلية")
      return
    }

    // Create substituted material
    const substitutedMaterial: DyeingMaterial = {
      id: Date.now(),
      code: `${selectedMaterial.code}-SUB`,
      name: `${selectedMaterial.name} (محلول)`,
      nameAr: `${selectedMaterial.nameAr} (محلول)`,
      category: selectedMaterial.category,
      unit: selectedMaterial.unit,
      purchasePrice: selectedMaterial.purchasePrice,
      currentStock: finalQuantity,
      minimumStock: 0,
      supplier: selectedMaterial.supplier,
      lastPurchaseDate: new Date().toISOString().split("T")[0],
      status: "active",
      createdAt: new Date().toISOString().split("T")[0],
      updatedAt: new Date().toISOString().split("T")[0],
      parentMaterialId: originalMaterial.id,
      isSubstituted: true,
      substitutedQuantity: quantityToSubstitute,
      originalQuantity: originalMaterial.currentStock,
    }

    // Update original material stock
    const updatedOriginalMaterial = {
      ...originalMaterial,
      currentStock: originalMaterial.currentStock - quantityToSubstitute,
      updatedAt: new Date().toISOString().split("T")[0],
    }

    // Update materials array
    const updatedMaterials = materials.map((m) => (m.id === originalMaterial.id ? updatedOriginalMaterial : m))
    updatedMaterials.push(substitutedMaterial)

    setMaterials(updatedMaterials)
    dataManager.setDyeingMaterials(updatedMaterials)

    // Create substitution record
    const newSubstitution: MaterialSubstitution = {
      id: Date.now(),
      originalMaterialId: originalMaterial.id,
      originalMaterialName: originalMaterial.name,
      substitutedMaterialId: substitutedMaterial.id,
      substitutedMaterialName: substitutedMaterial.name,
      quantitySubstituted: quantityToSubstitute,
      unit: originalMaterial.unit,
      reason: substitutionFormData.reason,
      date: new Date().toISOString().split("T")[0],
      createdBy: "Current User",
      status: "active",
      addedMaterialType: substitutionFormData.addedMaterialType,
      addedMaterialQuantity: addedMaterialQuantity,
      finalQuantity: finalQuantity,
      substitutionRatio: substitutionRatio,
    }

    const updatedSubstitutions = [...substitutions, newSubstitution]
    setSubstitutions(updatedSubstitutions)
    dataManager.setData("materialSubstitutions", updatedSubstitutions)

    // Add stock movements
    const originalMovement: StockMovement = {
      id: Date.now(),
      materialId: originalMaterial.id,
      materialName: originalMaterial.name,
      type: "substitution",
      quantity: -quantityToSubstitute,
      unit: originalMaterial.unit,
      reference: `SUB-${Date.now()}`,
      notes: `إحلال إلى ${substitutedMaterial.name}`,
      date: new Date().toISOString().split("T")[0],
      createdBy: "Current User",
    }

    const substitutedMovement: StockMovement = {
      id: Date.now() + 1,
      materialId: substitutedMaterial.id,
      materialName: substitutedMaterial.name,
      type: "substitution",
      quantity: finalQuantity,
      unit: substitutedMaterial.unit,
      reference: `SUB-${Date.now()}`,
      notes: `إحلال من ${originalMaterial.name}`,
      date: new Date().toISOString().split("T")[0],
      createdBy: "Current User",
    }

    const updatedMovements = [...stockMovements, originalMovement, substitutedMovement]
    setStockMovements(updatedMovements)
    dataManager.setData("stockMovements", updatedMovements)

    setShowSubstitutionDialog(false)
    setSubstitutionFormData({
      originalMaterialId: "",
      quantityToSubstitute: "",
      addedMaterialType: "water",
      addedMaterialQuantity: "",
      finalQuantity: "",
      substitutionRatio: "",
      reason: "",
      notes: "",
    })

    alert(`تم إحلال ${quantityToSubstitute} ${originalMaterial.unit} من ${originalMaterial.name} بنجاح`)
  }

  const openStockDialog = (material: DyeingMaterial) => {
    setSelectedMaterial(material)
    setStockFormData({
      type: "purchase",
      quantity: "",
      unitPrice: material.purchasePrice.toString(),
      reference: "",
      notes: "",
    })
    setShowStockDialog(true)
  }

  const openMovementsDialog = (material: DyeingMaterial) => {
    setSelectedMaterial(material)
    setShowMovementsDialog(true)
  }

  const openSubstitutionDialog = (material: DyeingMaterial) => {
    setSelectedMaterial(material)
    setSubstitutionFormData({
      originalMaterialId: "",
      quantityToSubstitute: "",
      addedMaterialType: "water",
      addedMaterialQuantity: "",
      finalQuantity: "",
      substitutionRatio: "",
      reason: "",
      notes: "",
    })
    setShowSubstitutionDialog(true)
  }

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case "dye":
        return { en: "Dyes", ar: "أصباغ" }
      case "chemical":
        return { en: "Chemicals", ar: "كيماويات" }
      case "auxiliary":
        return { en: "Auxiliaries", ar: "مواد مساعدة" }
      case "finishing":
        return { en: "Finishing", ar: "تشطيب" }
      default:
        return { en: category, ar: category }
    }
  }

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "dye":
        return "bg-blue-100 text-blue-800"
      case "chemical":
        return "bg-red-100 text-red-800"
      case "auxiliary":
        return "bg-green-100 text-green-800"
      case "finishing":
        return "bg-purple-100 text-purple-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800"
      case "low_stock":
        return "bg-red-100 text-red-800"
      case "inactive":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "active":
        return { en: "Active", ar: "نشط" }
      case "low_stock":
        return { en: "Low Stock", ar: "مخزون منخفض" }
      case "inactive":
        return { en: "Inactive", ar: "غير نشط" }
      default:
        return { en: status, ar: status }
    }
  }

  const calculateFinalQuantity = useCallback(() => {
    const quantityToSubstitute = Number.parseFloat(substitutionFormData.quantityToSubstitute) || 0
    const addedMaterialQuantity = Number.parseFloat(substitutionFormData.addedMaterialQuantity) || 0
    setSubstitutionFormData((prev) => ({
      ...prev,
      finalQuantity: (quantityToSubstitute + addedMaterialQuantity).toString(),
    }))
  }, [substitutionFormData.quantityToSubstitute, substitutionFormData.addedMaterialQuantity])

  useEffect(() => {
    calculateFinalQuantity()
  }, [calculateFinalQuantity])

  // Calculate statistics
  const totalMaterials = materials.length
  const lowStockCount = materials.filter((m) => m.status === "low_stock").length
  const totalValue = materials.reduce((sum, m) => sum + m.currentStock * m.purchasePrice, 0)
  const activeCount = materials.filter((m) => m.status === "active").length
  const substitutedCount = materials.filter((m) => m.isSubstituted).length

  // Get movements for selected material
  const materialMovements = selectedMaterial
    ? stockMovements
        .filter((m) => m.materialId === selectedMaterial.id)
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    : []

  return (
    <PageLayout title="مخزن مواد الصباغة والتجهيز">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">مخزن مواد الصباغة والتجهيز</h1>
        <p className="text-lg text-gray-600 mb-1">Dyeing & Finishing Materials Warehouse</p>
        <p className="text-gray-600">{filteredMaterials.length} مادة موجودة</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">إجمالي المواد</p>
                <p className="text-sm text-gray-500 mb-2">Total Materials</p>
                <p className="text-2xl font-bold text-gray-900">{totalMaterials}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Package className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">المواد النشطة</p>
                <p className="text-sm text-gray-500 mb-2">Active Materials</p>
                <p className="text-2xl font-bold text-green-600">{activeCount}</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">مخزون منخفض</p>
                <p className="text-sm text-gray-500 mb-2">Low Stock Items</p>
                <p className="text-2xl font-bold text-red-600">{lowStockCount}</p>
              </div>
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                <AlertTriangle className="w-6 h-6 text-red-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">مواد محلولة</p>
                <p className="text-sm text-gray-500 mb-2">Substituted Materials</p>
                <p className="text-2xl font-bold text-purple-600">{substitutedCount}</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <ArrowRightLeft className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="border-0 shadow-sm mb-6">
        <CardContent className="p-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
            <TabsList className="bg-gray-100">
              <TabsTrigger value="all" className="data-[state=active]:bg-white">
                جميع المواد
              </TabsTrigger>
              <TabsTrigger value="active" className="data-[state=active]:bg-white">
                نشط
              </TabsTrigger>
              <TabsTrigger value="low_stock" className="data-[state=active]:bg-white">
                مخزون منخفض
              </TabsTrigger>
              <TabsTrigger value="substituted" className="data-[state=active]:bg-white">
                مواد محلولة
              </TabsTrigger>
              <TabsTrigger value="inactive" className="data-[state=active]:bg-white">
                غير نشط
              </TabsTrigger>
            </TabsList>
          </Tabs>

          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center space-x-4 w-full md:w-auto">
              <div className="relative flex-1 md:w-64">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="البحث في المواد..."
                  className="pl-10"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>

              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="الفئة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all_categories">جميع الفئات</SelectItem>
                  <SelectItem value="dye">أصباغ</SelectItem>
                  <SelectItem value="chemical">كيماويات</SelectItem>
                  <SelectItem value="auxiliary">مواد مساعدة</SelectItem>
                  <SelectItem value="finishing">تشطيب</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm">
                <Filter className="w-4 h-4 mr-2" />
                تصفية
              </Button>
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                تصدير
              </Button>
              <Button onClick={() => handleOpenDialog()} className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                إضافة مادة
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Materials Table */}
      <Card className="border-0 shadow-sm">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="text-right px-6 py-4 text-sm font-medium text-gray-600">الكود</th>
                  <th className="text-right px-6 py-4 text-sm font-medium text-gray-600">المادة</th>
                  <th className="text-right px-6 py-4 text-sm font-medium text-gray-600">الفئة</th>
                  <th className="text-right px-6 py-4 text-sm font-medium text-gray-600">المخزون</th>
                  <th className="text-right px-6 py-4 text-sm font-medium text-gray-600">السعر</th>
                  <th className="text-right px-6 py-4 text-sm font-medium text-gray-600">القيمة</th>
                  <th className="text-right px-6 py-4 text-sm font-medium text-gray-600">الحالة</th>
                  <th className="text-right px-6 py-4 text-sm font-medium text-gray-600">الإجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredMaterials.map((material) => (
                  <tr key={material.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <span className="text-sm font-medium text-gray-900">{material.code}</span>
                      {material.isSubstituted && (
                        <Badge className="mr-2 bg-purple-100 text-purple-800 text-xs">محلول</Badge>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-3">
                        <div
                          className="w-8 h-8 rounded-full flex items-center justify-center"
                          style={{ backgroundColor: getCategoryColor(material.category).split("-")[0] + "-50" }}
                        >
                          <Palette
                            className="w-4 h-4"
                            style={{ color: getCategoryColor(material.category).split(" ")[1] }}
                          />
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-900">{material.name}</p>
                          <p className="text-xs text-gray-500">{material.nameAr}</p>
                          {material.parentMaterialId && (
                            <div className="flex items-center">
                              <ArrowRightLeft className="w-3 h-3 mr-1 text-purple-500" />
                              <p className="text-xs text-purple-600">
                                محلول من: {materials.find((m) => m.id === material.parentMaterialId)?.name}
                              </p>
                            </div>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <Badge className={getCategoryColor(material.category)}>
                        {getCategoryLabel(material.category).ar}
                      </Badge>
                    </td>
                    <td className="px-6 py-4">
                      <div>
                        <span
                          className={`text-sm font-medium ${
                            material.currentStock <= material.minimumStock ? "text-red-600" : "text-gray-900"
                          }`}
                        >
                          {material.currentStock} {material.unit}
                        </span>
                        <p className="text-xs text-gray-500">
                          الحد الأدنى: {material.minimumStock} {material.unit}
                        </p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm font-medium text-gray-900">{material.purchasePrice.toFixed(2)} ج.م</span>
                      <p className="text-xs text-gray-500">لكل {material.unit}</p>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm font-medium text-purple-600">
                        {(material.currentStock * material.purchasePrice).toFixed(2)} ج.م
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <Badge className={getStatusColor(material.status)}>{getStatusLabel(material.status).ar}</Badge>
                    </td>
                    <td className="px-6 py-4">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => openStockDialog(material)}>
                            <ShoppingCart className="w-4 h-4 mr-2" />
                            حركة مخزون
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => openSubstitutionDialog(material)}>
                            <ArrowRightLeft className="w-4 h-4 mr-2" />
                            إحلال مادة
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => openMovementsDialog(material)}>
                            <History className="w-4 h-4 mr-2" />
                            سجل الحركات
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleOpenDialog(material)}>
                            <Edit className="w-4 h-4 mr-2" />
                            تعديل
                          </DropdownMenuItem>
                          {canDelete() && (
                            <DropdownMenuItem
                              onClick={() => {
                                setSelectedMaterial(material)
                                setShowDeleteDialog(true)
                              }}
                              className="text-red-600"
                            >
                              <Trash2 className="w-4 h-4 mr-2" />
                              حذف
                            </DropdownMenuItem>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Add/Edit Material Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{isEditMode ? "تعديل المادة" : "إضافة مادة جديدة"}</DialogTitle>
            <DialogDescription>{isEditMode ? "تحديث معلومات المادة" : "أدخل تفاصيل المادة"}</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="grid gap-6 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="code">كود المادة</Label>
                  <Input
                    id="code"
                    value={formData.code}
                    onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                    placeholder="e.g., DYE001"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="supplier">المورد</Label>
                  <Input
                    id="supplier"
                    value={formData.supplier}
                    onChange={(e) => setFormData({ ...formData, supplier: e.target.value })}
                    placeholder="اسم المورد"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">الاسم بالإنجليزية</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Material name in English"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="nameAr">الاسم بالعربية</Label>
                  <Input
                    id="nameAr"
                    value={formData.nameAr}
                    onChange={(e) => setFormData({ ...formData, nameAr: e.target.value })}
                    placeholder="اسم المادة بالعربية"
                    dir="rtl"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="category">الفئة</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value: "dye" | "chemical" | "auxiliary" | "finishing") =>
                      setFormData({ ...formData, category: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="dye">أصباغ</SelectItem>
                      <SelectItem value="chemical">كيماويات</SelectItem>
                      <SelectItem value="auxiliary">مواد مساعدة</SelectItem>
                      <SelectItem value="finishing">تشطيب</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="unit">الوحدة</Label>
                  <Select
                    value={formData.unit}
                    onValueChange={(value: "kg" | "gram" | "liter") => setFormData({ ...formData, unit: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="kg">كيلوجرام (kg)</SelectItem>
                      <SelectItem value="gram">جرام (g)</SelectItem>
                      <SelectItem value="liter">لتر (L)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="purchasePrice">سعر الشراء</Label>
                  <Input
                    id="purchasePrice"
                    type="number"
                    step="0.01"
                    value={formData.purchasePrice}
                    onChange={(e) => setFormData({ ...formData, purchasePrice: e.target.value })}
                    placeholder="0.00"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="currentStock">المخزون الحالي</Label>
                  <Input
                    id="currentStock"
                    type="number"
                    step="0.01"
                    value={formData.currentStock}
                    onChange={(e) => setFormData({ ...formData, currentStock: e.target.value })}
                    placeholder="0.00"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="minimumStock">الحد الأدنى</Label>
                  <Input
                    id="minimumStock"
                    type="number"
                    step="0.01"
                    value={formData.minimumStock}
                    onChange={(e) => setFormData({ ...formData, minimumStock: e.target.value })}
                    placeholder="0.00"
                    required
                  />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setShowDialog(false)}>
                إلغاء
              </Button>
              <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                {isEditMode ? "تحديث المادة" : "إضافة المادة"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Stock Movement Dialog */}
      <Dialog open={showStockDialog} onOpenChange={setShowStockDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>حركة مخزون</DialogTitle>
            <DialogDescription>
              {selectedMaterial?.name} ({selectedMaterial?.nameAr})
              <br />
              المخزون الحالي: {selectedMaterial?.currentStock} {selectedMaterial?.unit}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div>
              <Label htmlFor="type">نوع الحركة</Label>
              <Select
                value={stockFormData.type}
                onValueChange={(value: "purchase" | "usage" | "adjustment") =>
                  setStockFormData({ ...stockFormData, type: value })
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="purchase">شراء</SelectItem>
                  <SelectItem value="usage">استخدام</SelectItem>
                  <SelectItem value="adjustment">تسوية</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="quantity">الكمية</Label>
                <Input
                  id="quantity"
                  type="number"
                  step="0.01"
                  value={stockFormData.quantity}
                  onChange={(e) => setStockFormData({ ...stockFormData, quantity: e.target.value })}
                  placeholder="0.00"
                  required
                />
              </div>
              <div>
                <Label htmlFor="unitPrice">سعر الوحدة</Label>
                <Input
                  id="unitPrice"
                  type="number"
                  step="0.01"
                  value={stockFormData.unitPrice}
                  onChange={(e) => setStockFormData({ ...stockFormData, unitPrice: e.target.value })}
                  placeholder="0.00"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="reference">المرجع</Label>
              <Input
                id="reference"
                value={stockFormData.reference}
                onChange={(e) => setStockFormData({ ...stockFormData, reference: e.target.value })}
                placeholder="رقم الفاتورة أو المرجع"
                required
              />
            </div>
            <div>
              <Label htmlFor="notes">ملاحظات</Label>
              <Input
                id="notes"
                value={stockFormData.notes}
                onChange={(e) => setStockFormData({ ...stockFormData, notes: e.target.value })}
                placeholder="ملاحظات إضافية"
              />
            </div>
            {stockFormData.quantity && stockFormData.unitPrice && (
              <div className="bg-blue-50 p-3 rounded-md">
                <p className="text-blue-800 text-sm">
                  <strong>إجمالي التكلفة:</strong>{" "}
                  {(Number.parseFloat(stockFormData.quantity) * Number.parseFloat(stockFormData.unitPrice)).toFixed(2)}{" "}
                  ج.م
                </p>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowStockDialog(false)}>
              إلغاء
            </Button>
            <Button onClick={handleStockMovement} className="bg-green-600 hover:bg-green-700">
              تنفيذ الحركة
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Material Substitution Dialog */}
      <Dialog open={showSubstitutionDialog} onOpenChange={setShowSubstitutionDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>إحلال مادة</DialogTitle>
            <DialogDescription>
              إحلال مادة جديدة من مادة موجودة
              <br />
              المادة المحددة: {selectedMaterial?.name} ({selectedMaterial?.nameAr})
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div>
              <Label htmlFor="originalMaterial">المادة الأصلية للإحلال منها</Label>
              <Select
                value={substitutionFormData.originalMaterialId}
                onValueChange={(value) =>
                  setSubstitutionFormData({ ...substitutionFormData, originalMaterialId: value })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="اختر المادة الأصلية" />
                </SelectTrigger>
                <SelectContent>
                  {materials
                    .filter((m) => m.id !== selectedMaterial?.id && !m.isSubstituted && m.currentStock > 0)
                    .map((material) => (
                      <SelectItem key={material.id} value={material.id.toString()}>
                        {material.name} ({material.nameAr}) - متاح: {material.currentStock} {material.unit}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="quantityToSubstitute">الكمية المراد إحلالها</Label>
              <Input
                id="quantityToSubstitute"
                type="number"
                step="0.01"
                value={substitutionFormData.quantityToSubstitute}
                onChange={(e) => {
                  setSubstitutionFormData({ ...substitutionFormData, quantityToSubstitute: e.target.value })
                }}
                placeholder="0.00"
                required
              />
              {substitutionFormData.originalMaterialId && (
                <p className="text-xs text-gray-500 mt-1">
                  المتاح:{" "}
                  {materials.find((m) => m.id.toString() === substitutionFormData.originalMaterialId)?.currentStock}{" "}
                  {materials.find((m) => m.id.toString() === substitutionFormData.originalMaterialId)?.unit}
                </p>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="addedMaterialType">المادة المضافة</Label>
                <Select
                  value={substitutionFormData.addedMaterialType}
                  onValueChange={(value: "water" | "chemical" | "other") => {
                    setSubstitutionFormData({ ...substitutionFormData, addedMaterialType: value })
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="اختر المادة المضافة" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="water">ماء</SelectItem>
                    <SelectItem value="chemical">كيماويات</SelectItem>
                    <SelectItem value="other">أخرى</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="addedMaterialQuantity">كمية المادة المضافة</Label>
                <Input
                  id="addedMaterialQuantity"
                  type="number"
                  step="0.01"
                  value={substitutionFormData.addedMaterialQuantity}
                  onChange={(e) => {
                    setSubstitutionFormData({ ...substitutionFormData, addedMaterialQuantity: e.target.value })
                  }}
                  placeholder="0.00"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="finalQuantity">الكمية النهائية</Label>
              <Input
                id="finalQuantity"
                type="number"
                step="0.01"
                value={substitutionFormData.finalQuantity}
                onChange={(e) => {
                  setSubstitutionFormData({ ...substitutionFormData, finalQuantity: e.target.value })
                }}
                placeholder="0.00"
              />
            </div>

            <div>
              <Label htmlFor="substitutionRatio">نسبة الإحلال</Label>
              <Input
                id="substitutionRatio"
                type="text"
                value={
                  substitutionFormData.quantityToSubstitute && substitutionFormData.finalQuantity
                    ? (
                        (Number.parseFloat(substitutionFormData.quantityToSubstitute) /
                          Number.parseFloat(substitutionFormData.finalQuantity)) *
                        100
                      ).toFixed(2) + "%"
                    : "0.00%"
                }
                readOnly
              />
            </div>

            <div>
              <Label htmlFor="reason">سبب الإحلال</Label>
              <Select
                value={substitutionFormData.reason}
                onValueChange={(value) => setSubstitutionFormData({ ...substitutionFormData, reason: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="اختر سبب الإحلال" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="quality_improvement">تحسين الجودة</SelectItem>
                  <SelectItem value="cost_reduction">تقليل التكلفة</SelectItem>
                  <SelectItem value="availability">توفر المادة</SelectItem>
                  <SelectItem value="customer_request">طلب العميل</SelectItem>
                  <SelectItem value="technical_requirements">متطلبات فنية</SelectItem>
                  <SelectItem value="other">أخرى</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="notes">ملاحظات إضافية</Label>
              <Input
                id="notes"
                value={substitutionFormData.notes}
                onChange={(e) => setSubstitutionFormData({ ...substitutionFormData, notes: e.target.value })}
                placeholder="ملاحظات حول عملية الإحلال"
              />
            </div>

            {substitutionFormData.originalMaterialId && substitutionFormData.quantityToSubstitute && (
              <div className="bg-yellow-50 p-3 rounded-md">
                <p className="text-yellow-800 text-sm">
                  <strong>تحذير:</strong> سيتم خصم {substitutionFormData.quantityToSubstitute}{" "}
                  {materials.find((m) => m.id.toString() === substitutionFormData.originalMaterialId)?.unit} من{" "}
                  {materials.find((m) => m.id.toString() === substitutionFormData.originalMaterialId)?.name} وإنشاء مادة
                  محلولة جديدة.
                </p>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowSubstitutionDialog(false)}>
              إلغاء
            </Button>
            <Button
              onClick={handleMaterialSubstitution}
              className="bg-purple-600 hover:bg-purple-700"
              disabled={
                !substitutionFormData.originalMaterialId ||
                !substitutionFormData.quantityToSubstitute ||
                !substitutionFormData.reason
              }
            >
              تنفيذ الإحلال
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Stock Movements History Dialog */}
      <Dialog open={showMovementsDialog} onOpenChange={setShowMovementsDialog}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>سجل حركات المخزون</DialogTitle>
            <DialogDescription>
              {selectedMaterial?.name} ({selectedMaterial?.nameAr})
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="text-right px-4 py-3 text-sm font-medium text-gray-600">التاريخ</th>
                    <th className="text-right px-4 py-3 text-sm font-medium text-gray-600">النوع</th>
                    <th className="text-right px-4 py-3 text-sm font-medium text-gray-600">الكمية</th>
                    <th className="text-right px-4 py-3 text-sm font-medium text-gray-600">سعر الوحدة</th>
                    <th className="text-right px-4 py-3 text-sm font-medium text-gray-600">الإجمالي</th>
                    <th className="text-right px-4 py-3 text-sm font-medium text-gray-600">المرجع</th>
                    <th className="text-right px-4 py-3 text-sm font-medium text-gray-600">ملاحظات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {materialMovements.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="text-center py-8 text-gray-500">
                        لا توجد حركات مخزون
                      </td>
                    </tr>
                  ) : (
                    materialMovements.map((movement) => (
                      <tr key={movement.id} className="hover:bg-gray-50">
                        <td className="px-4 py-3 text-right">{movement.date}</td>
                        <td className="px-4 py-3">
                          <Badge
                            className={
                              movement.type === "purchase"
                                ? "bg-green-100 text-green-800"
                                : movement.type === "usage"
                                  ? "bg-red-100 text-red-800"
                                  : movement.type === "substitution"
                                    ? "bg-purple-100 text-purple-800"
                                    : "bg-blue-100 text-blue-800"
                            }
                          >
                            {movement.type === "purchase"
                              ? "شراء"
                              : movement.type === "usage"
                                ? "استخدام"
                                : movement.type === "substitution"
                                  ? "إحلال"
                                  : "تسوية"}
                          </Badge>
                        </td>
                        <td className="px-4 py-3 text-right">
                          <span className={`font-medium ${movement.quantity < 0 ? "text-red-600" : "text-green-600"}`}>
                            {movement.quantity > 0 ? "+" : ""}
                            {movement.quantity} {movement.unit}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-right">
                          {movement.unitPrice ? `${movement.unitPrice.toFixed(2)} ج.م` : "—"}
                        </td>
                        <td className="px-4 py-3 text-right">
                          {movement.totalCost ? `${movement.totalCost.toFixed(2)} ج.م` : "—"}
                        </td>
                        <td className="px-4 py-3 text-right">{movement.reference}</td>
                        <td className="px-4 py-3 text-right">{movement.notes || "—"}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowMovementsDialog(false)}>
              إغلاق
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center text-red-600">
              <AlertTriangle className="w-5 h-5 mr-2" />
              تأكيد الحذف
            </DialogTitle>
            <DialogDescription>
              هل أنت متأكد من حذف "{selectedMaterial?.name}"؟
              <br />
              <span className="text-red-600 font-medium">لا يمكن التراجع عن هذا الإجراء!</span>
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>
              إلغاء
            </Button>
            <Button variant="destructive" onClick={handleDeleteMaterial}>
              <Trash2 className="w-4 h-4 mr-2" />
              حذف
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageLayout>
  )
}
