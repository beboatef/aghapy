"use client"

import { useState, useEffect } from "react"
import { PageLayout } from "@/components/page-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import {
  CreditCard,
  Plus,
  TrendingUp,
  DollarSign,
  Users,
  AlertTriangle,
  Search,
  Filter,
  Download,
  Eye,
  Edit,
  FileText,
} from "lucide-react"
import { dataManager } from "@/lib/data-manager"

interface CustomerAccount {
  id: string
  customerId: number
  customerName: string
  customerCode: string
  accountType: "credit" | "cash" | "prepaid"
  creditLimit: number
  currentBalance: number
  availableCredit: number
  totalInvoiced: number
  totalPaid: number
  totalOutstanding: number
  paymentTerms: number
  status: "active" | "suspended" | "closed"
  lastPaymentDate?: string
  lastPaymentAmount?: number
  createdAt: string
  updatedAt: string
}

interface AccountTransaction {
  id: string
  customerAccountId: string
  type: "invoice" | "payment" | "credit_note" | "debit_note" | "adjustment"
  amount: number
  description: string
  reference: string
  date: string
  dueDate?: string
  status: "pending" | "completed" | "overdue"
  createdBy: string
  createdAt: string
}

export default function CustomerAccountsPage() {
  const [customerAccounts, setCustomerAccounts] = useState<CustomerAccount[]>([])
  const [accountTransactions, setAccountTransactions] = useState<AccountTransaction[]>([])
  const [customers, setCustomers] = useState<any[]>([])
  const [activeTab, setActiveTab] = useState("overview")
  const [selectedAccount, setSelectedAccount] = useState<CustomerAccount | null>(null)
  const [showAddAccount, setShowAddAccount] = useState(false)
  const [showAddTransaction, setShowAddTransaction] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")

  const [accountForm, setAccountForm] = useState({
    customerId: "",
    accountType: "credit" as "credit" | "cash" | "prepaid",
    creditLimit: "",
    paymentTerms: "30",
  })

  const [transactionForm, setTransactionForm] = useState({
    type: "payment" as "invoice" | "payment" | "credit_note" | "debit_note" | "adjustment",
    amount: "",
    description: "",
    reference: "",
    date: new Date().toISOString().split("T")[0],
    dueDate: "",
  })

  useEffect(() => {
    // Load data
    const loadedCustomers = dataManager.getCustomers()
    const loadedAccounts = dataManager.getData("customerAccounts", [])
    const loadedTransactions = dataManager.getData("accountTransactions", [])

    setCustomers(loadedCustomers)

    if (loadedAccounts.length === 0) {
      // Initialize with sample data
      const sampleAccounts: CustomerAccount[] = [
        {
          id: "acc-001",
          customerId: 1,
          customerName: "شركة النسيج المتحدة",
          customerCode: "C001",
          accountType: "credit",
          creditLimit: 100000,
          currentBalance: -25000,
          availableCredit: 75000,
          totalInvoiced: 150000,
          totalPaid: 125000,
          totalOutstanding: 25000,
          paymentTerms: 30,
          status: "active",
          lastPaymentDate: "2024-03-10",
          lastPaymentAmount: 15000,
          createdAt: "2024-01-15",
          updatedAt: "2024-03-10",
        },
        {
          id: "acc-002",
          customerId: 2,
          customerName: "مصنع الألوان الحديث",
          customerCode: "C002",
          accountType: "credit",
          creditLimit: 75000,
          currentBalance: -12000,
          availableCredit: 63000,
          totalInvoiced: 85000,
          totalPaid: 73000,
          totalOutstanding: 12000,
          paymentTerms: 45,
          status: "active",
          lastPaymentDate: "2024-03-08",
          lastPaymentAmount: 8000,
          createdAt: "2024-01-20",
          updatedAt: "2024-03-08",
        },
      ]
      dataManager.setData("customerAccounts", sampleAccounts)
      setCustomerAccounts(sampleAccounts)
    } else {
      setCustomerAccounts(loadedAccounts)
    }

    if (loadedTransactions.length === 0) {
      // Initialize with sample transactions
      const sampleTransactions: AccountTransaction[] = [
        {
          id: "txn-001",
          customerAccountId: "acc-001",
          type: "invoice",
          amount: 15000,
          description: "فاتورة أمر تشغيل PO001",
          reference: "INV-001",
          date: "2024-03-01",
          dueDate: "2024-03-31",
          status: "pending",
          createdBy: "النظام",
          createdAt: "2024-03-01",
        },
        {
          id: "txn-002",
          customerAccountId: "acc-001",
          type: "payment",
          amount: -15000,
          description: "دفعة نقدية",
          reference: "PAY-001",
          date: "2024-03-10",
          status: "completed",
          createdBy: "أحمد محمد",
          createdAt: "2024-03-10",
        },
      ]
      dataManager.setData("accountTransactions", sampleTransactions)
      setAccountTransactions(sampleTransactions)
    } else {
      setAccountTransactions(loadedTransactions)
    }
  }, [])

  const handleAddAccount = () => {
    const customer = customers.find((c) => c.id.toString() === accountForm.customerId)
    if (!customer) return

    const newAccount: CustomerAccount = {
      id: `acc-${Date.now()}`,
      customerId: customer.id,
      customerName: customer.name,
      customerCode: customer.code,
      accountType: accountForm.accountType,
      creditLimit: Number.parseFloat(accountForm.creditLimit) || 0,
      currentBalance: 0,
      availableCredit: Number.parseFloat(accountForm.creditLimit) || 0,
      totalInvoiced: 0,
      totalPaid: 0,
      totalOutstanding: 0,
      paymentTerms: Number.parseInt(accountForm.paymentTerms),
      status: "active",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    const updatedAccounts = [...customerAccounts, newAccount]
    setCustomerAccounts(updatedAccounts)
    dataManager.setData("customerAccounts", updatedAccounts)

    setAccountForm({
      customerId: "",
      accountType: "credit",
      creditLimit: "",
      paymentTerms: "30",
    })
    setShowAddAccount(false)
  }

  // Filter accounts
  const filteredAccounts = customerAccounts.filter(
    (account) =>
      account.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      account.customerCode.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  // Calculate totals
  const totalOutstanding = customerAccounts.reduce((sum, acc) => sum + acc.totalOutstanding, 0)
  const totalCreditLimit = customerAccounts.reduce((sum, acc) => sum + acc.creditLimit, 0)
  const totalAvailableCredit = customerAccounts.reduce((sum, acc) => sum + acc.availableCredit, 0)
  const overdueAccounts = customerAccounts.filter((acc) => acc.totalOutstanding > 0 && acc.status === "active").length

  const getAccountStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "badge-success"
      case "suspended":
        return "badge-warning"
      case "closed":
        return "badge-danger"
      default:
        return "badge-info"
    }
  }

  return (
    <PageLayout title="حسابات العملاء" subtitle="إدارة حسابات العملاء والمعاملات المالية">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="overview">نظرة عامة</TabsTrigger>
          <TabsTrigger value="accounts">الحسابات</TabsTrigger>
          <TabsTrigger value="transactions">المعاملات</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="card-hover">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">إجمالي الحسابات</p>
                    <p className="text-2xl font-bold text-blue-600">{customerAccounts.length}</p>
                  </div>
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Users className="w-6 h-6 text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="card-hover">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">إجمالي المستحقات</p>
                    <p className="text-2xl font-bold text-red-600">{totalOutstanding.toLocaleString()} ج.م</p>
                  </div>
                  <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-red-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="card-hover">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">الائتمان المتاح</p>
                    <p className="text-2xl font-bold text-green-600">{totalAvailableCredit.toLocaleString()} ج.م</p>
                  </div>
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <DollarSign className="w-6 h-6 text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="card-hover">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">حسابات متأخرة</p>
                    <p className="text-2xl font-bold text-orange-600">{overdueAccounts}</p>
                  </div>
                  <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                    <AlertTriangle className="w-6 h-6 text-orange-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Account Status Overview */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>حالة الحسابات</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {filteredAccounts.slice(0, 5).map((account) => (
                    <div key={account.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center">
                        <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center ml-3">
                          <CreditCard className="w-5 h-5 text-blue-600" />
                        </div>
                        <div>
                          <div className="font-medium">{account.customerName}</div>
                          <div className="text-sm text-gray-500">{account.customerCode}</div>
                        </div>
                      </div>
                      <div className="text-left">
                        <div
                          className={`font-bold ${account.totalOutstanding > 0 ? "text-red-600" : "text-green-600"}`}
                        >
                          {account.totalOutstanding.toLocaleString()} ج.م
                        </div>
                        <Badge className={getAccountStatusColor(account.status)}>
                          {account.status === "active" ? "نشط" : account.status === "suspended" ? "معلق" : "مغلق"}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>آخر المعاملات</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {accountTransactions.slice(0, 5).map((transaction) => {
                    const account = customerAccounts.find((acc) => acc.id === transaction.customerAccountId)
                    return (
                      <div key={transaction.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div className="flex items-center">
                          <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center ml-3">
                            <FileText className="w-5 h-5 text-gray-600" />
                          </div>
                          <div>
                            <div className="font-medium">{transaction.description}</div>
                            <div className="text-sm text-gray-500">{account?.customerName}</div>
                          </div>
                        </div>
                        <div className="text-left">
                          <div className={`font-bold ${transaction.amount > 0 ? "text-blue-600" : "text-green-600"}`}>
                            {transaction.amount > 0 ? "+" : ""}
                            {transaction.amount.toLocaleString()} ج.م
                          </div>
                          <div className="text-sm text-gray-500">{transaction.date}</div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="accounts">
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center gap-4">
              <div className="relative">
                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="البحث في الحسابات..."
                  className="pr-10 w-80"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <Button variant="outline" size="sm">
                <Filter className="w-4 h-4 ml-2" />
                تصفية
              </Button>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 ml-2" />
                تصدير
              </Button>
              <Dialog open={showAddAccount} onOpenChange={setShowAddAccount}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="w-4 h-4 ml-2" />
                    إضافة حساب
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>إضافة حساب عميل جديد</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label>العميل</Label>
                      <Select
                        value={accountForm.customerId}
                        onValueChange={(value) => setAccountForm({ ...accountForm, customerId: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="اختر العميل" />
                        </SelectTrigger>
                        <SelectContent>
                          {customers.map((customer) => (
                            <SelectItem key={customer.id} value={customer.id.toString()}>
                              {customer.name} ({customer.code})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label>نوع الحساب</Label>
                      <Select
                        value={accountForm.accountType}
                        onValueChange={(value: "credit" | "cash" | "prepaid") =>
                          setAccountForm({ ...accountForm, accountType: value })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="credit">ائتماني</SelectItem>
                          <SelectItem value="cash">نقدي</SelectItem>
                          <SelectItem value="prepaid">مدفوع مقدماً</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {accountForm.accountType === "credit" && (
                      <div>
                        <Label>حد الائتمان</Label>
                        <Input
                          type="number"
                          value={accountForm.creditLimit}
                          onChange={(e) => setAccountForm({ ...accountForm, creditLimit: e.target.value })}
                          placeholder="0.00"
                        />
                      </div>
                    )}

                    <div>
                      <Label>شروط الدفع (أيام)</Label>
                      <Input
                        type="number"
                        value={accountForm.paymentTerms}
                        onChange={(e) => setAccountForm({ ...accountForm, paymentTerms: e.target.value })}
                        placeholder="30"
                      />
                    </div>

                    <Button onClick={handleAddAccount} className="w-full">
                      إضافة الحساب
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="text-right p-4 font-medium">العميل</th>
                      <th className="text-right p-4 font-medium">نوع الحساب</th>
                      <th className="text-right p-4 font-medium">حد الائتمان</th>
                      <th className="text-right p-4 font-medium">الرصيد الحالي</th>
                      <th className="text-right p-4 font-medium">المستحقات</th>
                      <th className="text-right p-4 font-medium">الائتمان المتاح</th>
                      <th className="text-right p-4 font-medium">الحالة</th>
                      <th className="text-right p-4 font-medium">الإجراءات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredAccounts.map((account) => (
                      <tr key={account.id} className="border-b hover:bg-gray-50">
                        <td className="p-4">
                          <div>
                            <div className="font-medium">{account.customerName}</div>
                            <div className="text-sm text-gray-500">{account.customerCode}</div>
                          </div>
                        </td>
                        <td className="p-4">
                          <Badge className="badge-info">
                            {account.accountType === "credit"
                              ? "ائتماني"
                              : account.accountType === "cash"
                                ? "نقدي"
                                : "مدفوع مقدماً"}
                          </Badge>
                        </td>
                        <td className="p-4">{account.creditLimit.toLocaleString()} ج.م</td>
                        <td className="p-4">
                          <span className={account.currentBalance >= 0 ? "text-green-600" : "text-red-600"}>
                            {account.currentBalance.toLocaleString()} ج.م
                          </span>
                        </td>
                        <td className="p-4">
                          <span
                            className={account.totalOutstanding > 0 ? "text-red-600 font-medium" : "text-green-600"}
                          >
                            {account.totalOutstanding.toLocaleString()} ج.م
                          </span>
                        </td>
                        <td className="p-4">{account.availableCredit.toLocaleString()} ج.م</td>
                        <td className="p-4">
                          <Badge className={getAccountStatusColor(account.status)}>
                            {account.status === "active" ? "نشط" : account.status === "suspended" ? "معلق" : "مغلق"}
                          </Badge>
                        </td>
                        <td className="p-4">
                          <div className="flex gap-2">
                            <Button variant="ghost" size="sm">
                              <Eye className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="sm">
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="sm">
                              <Plus className="w-4 h-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="transactions">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold">معاملات الحسابات</h2>
            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <Filter className="w-4 h-4 ml-2" />
                تصفية
              </Button>
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 ml-2" />
                تصدير
              </Button>
            </div>
          </div>

          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="text-right p-4 font-medium">التاريخ</th>
                      <th className="text-right p-4 font-medium">العميل</th>
                      <th className="text-right p-4 font-medium">النوع</th>
                      <th className="text-right p-4 font-medium">الوصف</th>
                      <th className="text-right p-4 font-medium">المرجع</th>
                      <th className="text-right p-4 font-medium">المبلغ</th>
                      <th className="text-right p-4 font-medium">الحالة</th>
                      <th className="text-right p-4 font-medium">الإجراءات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {accountTransactions.map((transaction) => {
                      const account = customerAccounts.find((acc) => acc.id === transaction.customerAccountId)
                      return (
                        <tr key={transaction.id} className="border-b hover:bg-gray-50">
                          <td className="p-4">{transaction.date}</td>
                          <td className="p-4">{account?.customerName}</td>
                          <td className="p-4">
                            <Badge className="badge-info">
                              {transaction.type === "invoice"
                                ? "فاتورة"
                                : transaction.type === "payment"
                                  ? "دفعة"
                                  : transaction.type === "credit_note"
                                    ? "إشعار دائن"
                                    : transaction.type === "debit_note"
                                      ? "إشعار مدين"
                                      : "تسوية"}
                            </Badge>
                          </td>
                          <td className="p-4">{transaction.description}</td>
                          <td className="p-4">{transaction.reference}</td>
                          <td className="p-4">
                            <span
                              className={`font-medium ${transaction.amount > 0 ? "text-blue-600" : "text-green-600"}`}
                            >
                              {transaction.amount > 0 ? "+" : ""}
                              {transaction.amount.toLocaleString()} ج.م
                            </span>
                          </td>
                          <td className="p-4">
                            <Badge
                              className={
                                transaction.status === "completed"
                                  ? "badge-success"
                                  : transaction.status === "pending"
                                    ? "badge-warning"
                                    : "badge-danger"
                              }
                            >
                              {transaction.status === "completed"
                                ? "مكتمل"
                                : transaction.status === "pending"
                                  ? "معلق"
                                  : "متأخر"}
                            </Badge>
                          </td>
                          <td className="p-4">
                            <div className="flex gap-2">
                              <Button variant="ghost" size="sm">
                                <Eye className="w-4 h-4" />
                              </Button>
                              <Button variant="ghost" size="sm">
                                <Edit className="w-4 h-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </PageLayout>
  )
}
