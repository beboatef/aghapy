export default function CustomerAccountsLoading() {
  return (
    <div className="dashboard-layout">
      <div className="sidebar">
        <div className="sidebar-content">
          <div className="sidebar-logo">
            <div className="skeleton w-10 h-10 rounded-lg"></div>
            <div className="skeleton w-32 h-6 rounded"></div>
          </div>
          <div className="space-y-2">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="skeleton h-12 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
      <div className="main-content">
        <div className="top-header">
          <div className="skeleton w-48 h-8 rounded"></div>
          <div className="skeleton w-80 h-10 rounded-lg"></div>
        </div>
        <div className="dashboard-content">
          <div className="stats-grid">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="stat-card">
                <div className="skeleton w-12 h-12 rounded-xl mb-4"></div>
                <div className="skeleton w-24 h-8 rounded mb-2"></div>
                <div className="skeleton w-32 h-4 rounded"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
