"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Form } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Textarea } from "@/components/ui/textarea"
import { zodResolver } from "@hookform/resolvers/zod"
import { Trash } from "lucide-react"
import { useState } from "react"
import { useForm } from "react-hook-form"
import * as z from "zod"

const formSchema = z.object({
  code: z.string().min(1, {
    message: "كود الصنف مطلوب",
  }),
  name: z.string().min(2, {
    message: "اسم الصنف مطلوب",
  }),
  unit: z.string().min(1, {
    message: "الوحدة مطلوبة",
  }),
  description: z.string().optional(),
})

type Material = z.infer<typeof formSchema> & { id: string }

const MaterialsPage = () => {
  const [materials, setMaterials] = useState<Material[]>([])
  const [editingMaterial, setEditingMaterial] = useState<Material | null>(null)

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      code: "",
      name: "",
      unit: "",
      description: "",
    },
  })

  const [formData, setFormData] = useState({
    code: "",
    name: "",
    unit: "",
    description: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // التحقق من عدم تكرار الكود
    const codeExists = materials.some(
      (material) =>
        material.code.toLowerCase() === formData.code.toLowerCase() &&
        (!editingMaterial || material.id !== editingMaterial.id),
    )

    if (codeExists) {
      alert("كود الصنف موجود مسبقاً! يرجى استخدام كود مختلف")
      return
    }

    if (editingMaterial) {
      // Update existing material
      setMaterials(
        materials.map((material) => (material.id === editingMaterial.id ? { ...formData, id: material.id } : material)),
      )
      setEditingMaterial(null)
    } else {
      // Add new material
      setMaterials([...materials, { ...formData, id: crypto.randomUUID() }])
    }

    setFormData({
      code: "",
      name: "",
      unit: "",
      description: "",
    })
  }

  const handleEdit = (material: Material) => {
    setFormData({
      code: material.code,
      name: material.name,
      unit: material.unit,
      description: material.description || "",
    })
    setEditingMaterial(material)
  }

  const handleDelete = (id: string) => {
    setMaterials(materials.filter((material) => material.id !== id))
  }

  return (
    <div className="container max-w-4xl mx-auto py-10">
      <h1 className="text-3xl font-bold mb-6">إدارة الأصناف</h1>

      <Form {...form}>
        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="code" className="text-right">
              كود الصنف *
            </Label>
            <div className="col-span-3">
              <Input
                id="code"
                value={formData.code}
                onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                required
                placeholder="مثال: M001"
              />
              <p className="text-xs text-gray-500 mt-1">يجب أن يكون الكود فريداً وغير مكرر</p>
            </div>
          </div>

          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="name" className="text-right">
              اسم الصنف *
            </Label>
            <div className="col-span-3">
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
                placeholder="مثال: حديد"
              />
            </div>
          </div>

          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="unit" className="text-right">
              الوحدة *
            </Label>
            <div className="col-span-3">
              <Select onValueChange={(value) => setFormData({ ...formData, unit: value })}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="اختر وحدة" defaultValue={formData.unit} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="kg">كيلو غرام</SelectItem>
                  <SelectItem value="m">متر</SelectItem>
                  <SelectItem value="piece">قطعة</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="description" className="text-right">
              الوصف
            </Label>
            <div className="col-span-3">
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="وصف إضافي عن الصنف"
              />
            </div>
          </div>

          <div className="grid grid-cols-4 items-center gap-4">
            <div></div>
            <div className="col-span-3 flex justify-end">
              <Button type="submit">{editingMaterial ? "تعديل الصنف" : "إضافة صنف"}</Button>
            </div>
          </div>
        </form>
      </Form>

      <div className="mt-12">
        <h2 className="text-2xl font-bold mb-4">قائمة الأصناف</h2>
        <Table>
          <TableCaption>قائمة بجميع الأصناف المسجلة.</TableCaption>
          <TableHeader>
            <TableRow>
              <TableHead>كود الصنف</TableHead>
              <TableHead>اسم الصنف</TableHead>
              <TableHead>الوحدة</TableHead>
              <TableHead className="text-right">إجراءات</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {materials.map((material) => (
              <TableRow key={material.id}>
                <TableCell>{material.code}</TableCell>
                <TableCell>{material.name}</TableCell>
                <TableCell>{material.unit}</TableCell>
                <TableCell className="text-right font-medium">
                  <Button variant="ghost" size="sm" onClick={() => handleEdit(material)}>
                    تعديل
                  </Button>
                  <Button variant="ghost" size="sm" className="text-red-500" onClick={() => handleDelete(material.id)}>
                    <Trash className="w-4 h-4 ml-2" />
                    حذف
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}

export default MaterialsPage
