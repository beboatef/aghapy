"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PageLayout } from "@/components/page-layout"
import { Settings, User, Shield, Bell, Database, Palette } from "lucide-react"
import { EditUserModal, AddUserModal } from "@/components/user-management-modals"
import { dataManager } from "@/lib/data-manager"
import { useUsers } from "@/hooks/use-data"

export default function SettingsPage() {
  const [settings, setSettings] = useState({
    // إعدادات عامة
    companyName: "Inventory System Aghapy dyeing",
    companyAddress: "الرياض، المملكة العربية السعودية",
    companyPhone: "+966 11 123 4567",
    companyEmail: "info@textile-factory.com",

    // إعدادات النظام
    autoBackup: true,
    emailNotifications: true,
    smsNotifications: false,

    // إعدادات المستخدم
    language: "ar",
    theme: "light",
    dateFormat: "dd/mm/yyyy",

    // إعدادات الأمان
    sessionTimeout: 30,
    passwordExpiry: 90,
    twoFactorAuth: false,
    loginAttempts: 3,
  })

  const [showEditModal, setShowEditModal] = useState(false)
  const [showAddModal, setShowAddModal] = useState(false)
  const [selectedUser, setSelectedUser] = useState(null)
  const [editForm, setEditForm] = useState({
    username: "",
    fullName: "",
    password: "",
    role: "user",
    active: true,
  })

  const [formErrors, setFormErrors] = useState({
    username: "",
    fullName: "",
    password: "",
  })

  const { users, updateUsers } = useUsers()

  const handleSettingChange = (key: string, value: any) => {
    setSettings((prev) => ({ ...prev, [key]: value }))
  }

  const handleFormChange = (field: string, value: any) => {
    setEditForm((prev) => ({ ...prev, [field]: value }))
  }

  const saveUser = () => {
    // Reset errors
    setFormErrors({ username: "", fullName: "", password: "" })

    // Validation
    const errors = { username: "", fullName: "", password: "" }
    let hasErrors = false

    if (!editForm.username.trim()) {
      errors.username = "اسم المستخدم مطلوب"
      hasErrors = true
    } else if (users.some((u) => u.username === editForm.username && (!selectedUser || u.id !== selectedUser.id))) {
      errors.username = "اسم المستخدم موجود بالفعل"
      hasErrors = true
    }

    if (!editForm.fullName.trim()) {
      errors.fullName = "الاسم الكامل مطلوب"
      hasErrors = true
    }

    if (!selectedUser && !editForm.password.trim()) {
      errors.password = "كلمة المرور مطلوبة للمستخدم الجديد"
      hasErrors = true
    }

    if (hasErrors) {
      setFormErrors(errors)
      return
    }

    let updatedUsers = []

    if (selectedUser) {
      // Update existing user
      updatedUsers = users.map((user) =>
        user.id === selectedUser.id
          ? {
              ...user,
              username: editForm.username,
              fullName: editForm.fullName,
              role: editForm.role,
              active: editForm.active,
              ...(editForm.password.trim() && { password: editForm.password }),
            }
          : user,
      )
      updateUsers(updatedUsers)
      alert(`تم تحديث بيانات المستخدم: ${editForm.fullName}`)
    } else {
      // Add new user
      const newUser = {
        id: Math.max(...users.map((u) => u.id)) + 1,
        username: editForm.username,
        fullName: editForm.fullName,
        password: editForm.password,
        role: editForm.role,
        active: editForm.active,
        lastLogin: "لم يسجل دخول بعد",
      }

      updatedUsers = [...users, newUser]
      updateUsers(updatedUsers)
      alert(`تم إضافة المستخدم الجديد: ${editForm.fullName}`)
    }

    // حفظ المستخدمين في localStorage
    localStorage.setItem("users", JSON.stringify(updatedUsers))

    // Reset form and close modals
    setEditForm({ username: "", fullName: "", password: "", role: "user", active: true })
    setShowEditModal(false)
    setShowAddModal(false)
    setSelectedUser(null)
  }

  const saveSettings = () => {
    // محاكاة حفظ الإعدادات
    alert("تم حفظ الإعدادات بنجاح")
  }

  const exportData = () => {
    const result = dataManager.exportAllData()
    if (result.success) {
      alert(result.message)
    } else {
      alert(result.message)
    }
  }

  const importData = () => {
    const input = document.createElement("input")
    input.type = "file"
    input.accept = ".json"

    input.onchange = async (event) => {
      const file = (event.target as HTMLInputElement).files?.[0]
      if (!file) return

      if (confirm("هل أنت متأكد من استيراد البيانات؟ سيتم استبدال جميع البيانات الحالية.")) {
        const result = await dataManager.importData(file)
        alert(result.message)
        if (result.success) {
          window.location.reload()
        }
      }
    }

    input.click()
  }

  const createBackup = () => {
    alert("تم إنشاء نسخة احتياطية بنجاح")
  }

  const editUser = (userId: number) => {
    const user = users.find((u) => u.id === userId)
    if (user) {
      setSelectedUser(user)
      setEditForm({
        username: user.username,
        fullName: user.fullName,
        password: "",
        role: user.role,
        active: user.active,
      })
      setFormErrors({ username: "", fullName: "", password: "" })
      setShowEditModal(true)
    }
  }

  const addUser = () => {
    setSelectedUser(null)
    setEditForm({
      username: "",
      fullName: "",
      password: "",
      role: "user",
      active: true,
    })
    setFormErrors({ username: "", fullName: "", password: "" })
    setShowAddModal(true)
  }

  const deleteUser = (userId: number) => {
    const user = users.find((u) => u.id === userId)
    if (user && confirm(`هل أنت متأكد من حذف المستخدم: ${user.fullName}؟`)) {
      const updatedUsers = users.filter((u) => u.id !== userId)
      updateUsers(updatedUsers)
      localStorage.setItem("users", JSON.stringify(updatedUsers))
      alert(`تم حذف المستخدم: ${user.fullName}`)
    }
  }

  const toggleUserStatus = (userId: number) => {
    const user = users.find((u) => u.id === userId)
    if (user) {
      const newStatus = !user.active
      const updatedUsers = users.map((u) => (u.id === userId ? { ...u, active: newStatus } : u))
      updateUsers(updatedUsers)
      localStorage.setItem("users", JSON.stringify(updatedUsers))
      alert(`تم ${newStatus ? "تفعيل" : "إلغاء تفعيل"} المستخدم: ${user.fullName}`)
    }
  }

  return (
    <PageLayout title="الإعدادات">
      {/* رأس الصفحة */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
        <h1 className="page-title mb-4 sm:mb-0">
          <Settings className="page-icon text-gray-600" />
          إعدادات النظام
        </h1>
        <Button onClick={saveSettings}>حفظ جميع الإعدادات</Button>
      </div>

      <Tabs defaultValue="general" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="general">عام</TabsTrigger>
          <TabsTrigger value="users">المستخدمون</TabsTrigger>
          <TabsTrigger value="notifications">الإشعارات</TabsTrigger>
          <TabsTrigger value="security">الأمان</TabsTrigger>
          <TabsTrigger value="backup">النسخ الاحتياطي</TabsTrigger>
        </TabsList>

        {/* الإعدادات العامة */}
        <TabsContent value="general">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <User className="h-5 w-5 ml-2" />
                  معلومات الشركة
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="companyName">اسم الشركة</Label>
                  <Input
                    id="companyName"
                    value={settings.companyName}
                    onChange={(e) => handleSettingChange("companyName", e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="companyAddress">العنوان</Label>
                  <Input
                    id="companyAddress"
                    value={settings.companyAddress}
                    onChange={(e) => handleSettingChange("companyAddress", e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="companyPhone">رقم الهاتف</Label>
                  <Input
                    id="companyPhone"
                    value={settings.companyPhone}
                    onChange={(e) => handleSettingChange("companyPhone", e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="companyEmail">البريد الإلكتروني</Label>
                  <Input
                    id="companyEmail"
                    type="email"
                    value={settings.companyEmail}
                    onChange={(e) => handleSettingChange("companyEmail", e.target.value)}
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Palette className="h-5 w-5 ml-2" />
                  إعدادات العرض
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="language">اللغة</Label>
                  <select
                    id="language"
                    className="w-full p-2 border rounded-md"
                    value={settings.language}
                    onChange={(e) => handleSettingChange("language", e.target.value)}
                  >
                    <option value="ar">العربية</option>
                    <option value="en">English</option>
                  </select>
                </div>
                <div>
                  <Label htmlFor="theme">السمة</Label>
                  <select
                    id="theme"
                    className="w-full p-2 border rounded-md"
                    value={settings.theme}
                    onChange={(e) => handleSettingChange("theme", e.target.value)}
                  >
                    <option value="light">فاتح</option>
                    <option value="dark">داكن</option>
                    <option value="auto">تلقائي</option>
                  </select>
                </div>
                <div>
                  <Label htmlFor="dateFormat">تنسيق التاريخ</Label>
                  <select
                    id="dateFormat"
                    className="w-full p-2 border rounded-md"
                    value={settings.dateFormat}
                    onChange={(e) => handleSettingChange("dateFormat", e.target.value)}
                  >
                    <option value="dd/mm/yyyy">يوم/شهر/سنة</option>
                    <option value="mm/dd/yyyy">شهر/يوم/سنة</option>
                    <option value="yyyy-mm-dd">سنة-شهر-يوم</option>
                  </select>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* إدارة المستخدمين */}
        <TabsContent value="users">
          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center">
                  <User className="h-5 w-5 ml-2" />
                  إدارة المستخدمين
                </div>
                <Button size="sm" onClick={addUser}>
                  إضافة مستخدم جديد
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-right p-3">اسم المستخدم</th>
                      <th className="text-right p-3">الاسم الكامل</th>
                      <th className="text-right p-3">الدور</th>
                      <th className="text-right p-3">الحالة</th>
                      <th className="text-right p-3">آخر دخول</th>
                      <th className="text-right p-3">الإجراءات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map((user) => (
                      <tr key={user.id} className="border-b hover:bg-gray-50">
                        <td className="p-3 font-mono">{user.username}</td>
                        <td className="p-3">{user.fullName}</td>
                        <td className="p-3">
                          <span className={`badge ${user.role === "admin" ? "badge-purple" : "badge-blue"}`}>
                            {user.role === "admin" ? "مدير" : "مستخدم"}
                          </span>
                        </td>
                        <td className="p-3">
                          <span className={`badge ${user.active ? "badge-green" : "badge-red"}`}>
                            {user.active ? "نشط" : "غير نشط"}
                          </span>
                        </td>
                        <td className="p-3">{user.lastLogin}</td>
                        <td className="p-3">
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline" onClick={() => editUser(user.id)}>
                              تعديل
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-blue-600"
                              onClick={() => toggleUserStatus(user.id)}
                            >
                              {user.active ? "إلغاء تفعيل" : "تفعيل"}
                            </Button>
                            {user.role !== "admin" && (
                              <Button
                                size="sm"
                                variant="outline"
                                className="text-red-600"
                                onClick={() => deleteUser(user.id)}
                              >
                                حذف
                              </Button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* إعدادات الإشعارات */}
        <TabsContent value="notifications">
          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Bell className="h-5 w-5 ml-2" />
                إعدادات الإشعارات
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="emailNotifications">إشعارات البريد الإلكتروني</Label>
                  <p className="text-sm text-gray-600">تلقي الإشعارات عبر البريد الإلكتروني</p>
                </div>
                <Switch
                  id="emailNotifications"
                  checked={settings.emailNotifications}
                  onCheckedChange={(checked) => handleSettingChange("emailNotifications", checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="smsNotifications">إشعارات الرسائل النصية</Label>
                  <p className="text-sm text-gray-600">تلقي الإشعارات عبر الرسائل النصية</p>
                </div>
                <Switch
                  id="smsNotifications"
                  checked={settings.smsNotifications}
                  onCheckedChange={(checked) => handleSettingChange("smsNotifications", checked)}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* إعدادات الأمان */}
        <TabsContent value="security">
          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Shield className="h-5 w-5 ml-2" />
                إعدادات الأمان
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label htmlFor="sessionTimeout">مهلة انتهاء الجلسة (بالدقائق)</Label>
                <Input
                  id="sessionTimeout"
                  type="number"
                  value={settings.sessionTimeout}
                  onChange={(e) => handleSettingChange("sessionTimeout", Number.parseInt(e.target.value))}
                  className="w-32"
                />
              </div>

              <div>
                <Label htmlFor="passwordExpiry">انتهاء صلاحية كلمة المرور (بالأيام)</Label>
                <Input
                  id="passwordExpiry"
                  type="number"
                  value={settings.passwordExpiry}
                  onChange={(e) => handleSettingChange("passwordExpiry", Number.parseInt(e.target.value))}
                  className="w-32"
                />
              </div>

              <div>
                <Label htmlFor="loginAttempts">عدد محاولات تسجيل الدخول المسموحة</Label>
                <Input
                  id="loginAttempts"
                  type="number"
                  value={settings.loginAttempts}
                  onChange={(e) => handleSettingChange("loginAttempts", Number.parseInt(e.target.value))}
                  className="w-32"
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="twoFactorAuth">المصادقة الثنائية</Label>
                  <p className="text-sm text-gray-600">تفعيل المصادقة الثنائية لحماية إضافية</p>
                </div>
                <Switch
                  id="twoFactorAuth"
                  checked={settings.twoFactorAuth}
                  onCheckedChange={(checked) => handleSettingChange("twoFactorAuth", checked)}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* النسخ الاحتياطي */}
        <TabsContent value="backup">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Database className="h-5 w-5 ml-2" />
                  النسخ الاحتياطي
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="autoBackup">النسخ الاحتياطي التلقائي</Label>
                    <p className="text-sm text-gray-600">إنشاء نسخة احتياطية تلقائياً كل يوم</p>
                  </div>
                  <Switch
                    id="autoBackup"
                    checked={settings.autoBackup}
                    onCheckedChange={(checked) => handleSettingChange("autoBackup", checked)}
                  />
                </div>

                <div className="space-y-2">
                  <Button onClick={createBackup} className="w-full">
                    إنشاء نسخة احتياطية الآن
                  </Button>
                  <p className="text-xs text-gray-500 text-center">آخر نسخة احتياطية: 2024-03-15 الساعة 02:00 ص</p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Database className="h-5 w-5 ml-2" />
                  استيراد وتصدير البيانات
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label>تصدير البيانات</Label>
                  <p className="text-sm text-gray-600 mb-2">تصدير جميع بيانات النظام</p>
                  <Button onClick={exportData} variant="outline" className="w-full">
                    تصدير البيانات
                  </Button>
                </div>

                <div>
                  <Label>استيراد البيانات</Label>
                  <p className="text-sm text-gray-600 mb-2">استيراد البيانات من ملف خارجي</p>
                  <Button onClick={importData} variant="outline" className="w-full">
                    استيراد البيانات
                  </Button>
                </div>

                <div className="bg-yellow-50 p-4 rounded-md">
                  <p className="text-yellow-800 text-sm">
                    <strong>تحذير:</strong> تأكد من إنشاء نسخة احتياطية قبل استيراد البيانات الجديدة
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
      {/* النوافذ المنبثقة */}
      <EditUserModal
        isOpen={showEditModal}
        onClose={() => setShowEditModal(false)}
        user={selectedUser}
        formData={editForm}
        onFormChange={handleFormChange}
        onSave={saveUser}
        formErrors={formErrors}
      />

      <AddUserModal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        formData={editForm}
        onFormChange={handleFormChange}
        onSave={saveUser}
        formErrors={formErrors}
      />
    </PageLayout>
  )
}
