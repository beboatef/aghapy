import { PageLayout } from "@/components/page-layout"
import { Skeleton } from "@/components/ui/skeleton"
import { Card, CardContent, CardHeader } from "@/components/ui/card"

export default function ChangePasswordLoading() {
  return (
    <PageLayout title="تغيير كلمة المرور">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
        <Skeleton className="h-8 w-64" />
      </div>

      <div className="max-w-md mx-auto">
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <Skeleton className="h-6 w-40 mx-auto" />
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-10 w-full" />
            </div>

            <div className="space-y-2">
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-10 w-full" />
            </div>

            <div className="space-y-2">
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-10 w-full" />
            </div>

            <Skeleton className="h-10 w-full" />
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  )
}
