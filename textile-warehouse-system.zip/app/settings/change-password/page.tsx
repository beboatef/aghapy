"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { PageLayout } from "@/components/page-layout"
import { Lock, AlertTriangle, CheckCircle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export default function ChangePasswordPage() {
  const { toast } = useToast()
  const [formData, setFormData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
    setError("")
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")
    setSuccess(false)

    // التحقق من تطابق كلمة المرور الجديدة
    if (formData.newPassword !== formData.confirmPassword) {
      setError("كلمة المرور الجديدة وتأكيدها غير متطابقين")
      setIsLoading(false)
      return
    }

    // التحقق من كلمة المرور الحالية (محاكاة)
    if (formData.currentPassword !== "123456") {
      setError("كلمة المرور الحالية غير صحيحة")
      setIsLoading(false)
      return
    }

    // محاكاة تغيير كلمة المرور
    setTimeout(() => {
      // إرسال إشعار للمسؤول
      notifyAdmin(formData.newPassword)

      // إعادة تعيين النموذج
      setFormData({
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      })

      setSuccess(true)
      setIsLoading(false)

      toast({
        title: "تم تغيير كلمة المرور بنجاح",
        description: "تم إرسال إشعار للمسؤول بالتغيير",
      })
    }, 1000)
  }

  // وظيفة لإشعار المسؤول بتغيير كلمة المرور
  const notifyAdmin = (newPassword: string) => {
    // في بيئة حقيقية، هنا سيتم إرسال إشعار للمسؤول عبر API
    console.log("تم إرسال إشعار للمسؤول بتغيير كلمة المرور:", newPassword)

    // محاكاة إرسال إشعار للمسؤول
    const notification = {
      type: "password_change",
      username: "المستخدم الحالي",
      newPassword: newPassword,
      timestamp: new Date().toISOString(),
    }

    // حفظ الإشعار في localStorage للمحاكاة
    const notifications = JSON.parse(localStorage.getItem("adminNotifications") || "[]")
    notifications.push(notification)
    localStorage.setItem("adminNotifications", JSON.stringify(notifications))
  }

  return (
    <PageLayout title="تغيير كلمة المرور">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
        <h1 className="page-title mb-4 sm:mb-0">
          <Lock className="page-icon text-gray-600" />
          تغيير كلمة المرور
        </h1>
      </div>

      <div className="max-w-md mx-auto">
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="text-center">تغيير كلمة المرور</CardTitle>
          </CardHeader>
          <CardContent>
            {error && (
              <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-600 rounded-md flex items-center gap-2">
                <AlertTriangle className="h-4 w-4" />
                <span>{error}</span>
              </div>
            )}

            {success && (
              <div className="mb-4 p-3 bg-green-50 border border-green-200 text-green-600 rounded-md flex items-center gap-2">
                <CheckCircle className="h-4 w-4" />
                <span>تم تغيير كلمة المرور بنجاح وإرسال إشعار للمسؤول</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="currentPassword">كلمة المرور الحالية</Label>
                <Input
                  id="currentPassword"
                  name="currentPassword"
                  type="password"
                  value={formData.currentPassword}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="newPassword">كلمة المرور الجديدة</Label>
                <Input
                  id="newPassword"
                  name="newPassword"
                  type="password"
                  value={formData.newPassword}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword">تأكيد كلمة المرور الجديدة</Label>
                <Input
                  id="confirmPassword"
                  name="confirmPassword"
                  type="password"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  required
                />
              </div>

              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? "جاري تغيير كلمة المرور..." : "تغيير كلمة المرور"}
              </Button>
            </form>

            <div className="mt-4 text-sm text-gray-500">
              <p>ملاحظة: سيتم إعلام مدير النظام بتغيير كلمة المرور الخاصة بك.</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  )
}
