"use client"

import { useState, useEffect, useMemo } from "react"
import { PageLayout } from "@/components/page-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area,
  LineChart,
  Line,
} from "recharts"
import {
  FileText,
  Download,
  Printer,
  Filter,
  TrendingUp,
  TrendingDown,
  Package,
  AlertTriangle,
  DollarSign,
  Calendar,
  BarChart3,
  Activity,
  Warehouse,
} from "lucide-react"
import { dataManager } from "@/lib/data-manager"
import { toast } from "@/components/ui/use-toast"

// Types
interface Material {
  id: number
  code: string
  name: string
  nameAr: string
  category: "dye" | "chemical" | "auxiliary" | "finishing"
  unit: "kg" | "gram" | "liter"
  purchasePrice: number
  currentStock: number
  minimumStock: number
}

interface MaterialIssuance {
  id: string
  issueNumber: string
  productionOrderId: string
  productionOrderNumber: string
  customerName: string
  issueDate: string
  requestedBy: string
  approvedBy?: string
  materials: {
    materialId: number
    materialCode: string
    materialName: string
    materialNameAr: string
    category: string
    unit: string
    requestedQuantity: number
    unitPrice: number
    totalCost: number
    notes?: string
  }[]
  totalCost: number
  status: "pending" | "approved" | "issued" | "completed" | "rejected"
  notes?: string
  createdAt: string
  updatedAt: string
}

interface ProcessingOrder {
  id: number
  orderNumber: string
  permitNumber: string
  date: string
  customerId: number
  customerName: string
  materialId: number
  materialName: string
  quantity: number
  separatedQuantity: number
  finalQuantity: number
  unit: string
  status: "in_production" | "completed"
  hasSeparations: boolean
  notes?: string
  createdAt: string
  completedAt?: string
  materialsUsed: any[]
  totalMaterialsCost: number
  costPerUnit: number
  costsCalculated: boolean
}

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8", "#82CA9D"]

export default function InventoryReportsPage() {
  const [materials, setMaterials] = useState<Material[]>([])
  const [issuances, setIssuances] = useState<MaterialIssuance[]>([])
  const [processingOrders, setProcessingOrders] = useState<ProcessingOrder[]>([])
  const [activeTab, setActiveTab] = useState("consumption-report")

  // Filters
  const [dateFrom, setDateFrom] = useState("")
  const [dateTo, setDateTo] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [selectedMaterial, setSelectedMaterial] = useState("all")
  const [reportPeriod, setReportPeriod] = useState("30") // days

  // Load data
  useEffect(() => {
    const loadedMaterials = dataManager.getDyeingMaterials()
    const loadedIssuances = dataManager.getData("materialIssuances", [])
    const loadedOrders = dataManager.getData("processingOrders", [])

    setMaterials(loadedMaterials)
    setIssuances(loadedIssuances)
    setProcessingOrders(loadedOrders)

    // Set default date range (last 30 days)
    const today = new Date()
    const thirtyDaysAgo = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000)
    setDateFrom(thirtyDaysAgo.toISOString().split("T")[0])
    setDateTo(today.toISOString().split("T")[0])
  }, [])

  // Filter issuances based on date range and filters
  const filteredIssuances = useMemo(() => {
    return issuances.filter((issuance) => {
      const issueDate = new Date(issuance.issueDate)
      const fromDate = dateFrom ? new Date(dateFrom) : new Date(0)
      const toDate = dateTo ? new Date(dateTo) : new Date()

      const dateMatch = issueDate >= fromDate && issueDate <= toDate
      const statusMatch = issuance.status === "completed" || issuance.status === "issued"

      return dateMatch && statusMatch
    })
  }, [issuances, dateFrom, dateTo])

  // Calculate consumption statistics
  const consumptionStats = useMemo(() => {
    const stats = {
      totalMaterials: 0,
      totalCost: 0,
      totalOrders: filteredIssuances.length,
      materialBreakdown: {} as Record<string, { quantity: number; cost: number; unit: string; category: string }>,
      categoryBreakdown: {} as Record<string, { quantity: number; cost: number; count: number }>,
      dailyConsumption: {} as Record<string, { cost: number; orders: number; materials: number }>,
    }

    filteredIssuances.forEach((issuance) => {
      stats.totalCost += issuance.totalCost

      // Daily breakdown
      const date = issuance.issueDate
      if (!stats.dailyConsumption[date]) {
        stats.dailyConsumption[date] = { cost: 0, orders: 0, materials: 0 }
      }
      stats.dailyConsumption[date].cost += issuance.totalCost
      stats.dailyConsumption[date].orders += 1
      stats.dailyConsumption[date].materials += issuance.materials.length

      issuance.materials.forEach((material) => {
        stats.totalMaterials += 1

        // Material breakdown
        const materialKey = `${material.materialId}-${material.materialName}`
        if (!stats.materialBreakdown[materialKey]) {
          stats.materialBreakdown[materialKey] = {
            quantity: 0,
            cost: 0,
            unit: material.unit,
            category: material.category,
          }
        }
        stats.materialBreakdown[materialKey].quantity += material.requestedQuantity
        stats.materialBreakdown[materialKey].cost += material.totalCost

        // Category breakdown
        if (!stats.categoryBreakdown[material.category]) {
          stats.categoryBreakdown[material.category] = { quantity: 0, cost: 0, count: 0 }
        }
        stats.categoryBreakdown[material.category].quantity += material.requestedQuantity
        stats.categoryBreakdown[material.category].cost += material.totalCost
        stats.categoryBreakdown[material.category].count += 1
      })
    })

    return stats
  }, [filteredIssuances])

  // Stock analysis
  const stockAnalysis = useMemo(() => {
    const analysis = {
      totalItems: materials.length,
      lowStock: materials.filter((m) => m.currentStock <= m.minimumStock && m.currentStock > 0).length,
      criticalStock: materials.filter((m) => m.currentStock <= 5 && m.currentStock > 0).length,
      outOfStock: materials.filter((m) => m.currentStock === 0).length,
      totalValue: materials.reduce((sum, m) => sum + m.currentStock * m.purchasePrice, 0),
      categoryDistribution: {} as Record<string, { count: number; value: number; stock: number }>,
    }

    materials.forEach((material) => {
      if (!analysis.categoryDistribution[material.category]) {
        analysis.categoryDistribution[material.category] = { count: 0, value: 0, stock: 0 }
      }
      analysis.categoryDistribution[material.category].count += 1
      analysis.categoryDistribution[material.category].value += material.currentStock * material.purchasePrice
      analysis.categoryDistribution[material.category].stock += material.currentStock
    })

    return analysis
  }, [materials])

  // Prepare chart data
  const categoryChartData = Object.entries(consumptionStats.categoryBreakdown).map(([category, data]) => ({
    name: category,
    cost: data.cost,
    quantity: data.quantity,
    count: data.count,
  }))

  const topMaterialsData = Object.entries(consumptionStats.materialBreakdown)
    .sort(([, a], [, b]) => b.cost - a.cost)
    .slice(0, 10)
    .map(([name, data]) => ({
      name: name.split("-")[1] || name,
      cost: data.cost,
      quantity: data.quantity,
      unit: data.unit,
    }))

  const dailyTrendData = Object.entries(consumptionStats.dailyConsumption)
    .sort(([a], [b]) => new Date(a).getTime() - new Date(b).getTime())
    .map(([date, data]) => ({
      date: new Date(date).toLocaleDateString("ar-SA"),
      cost: data.cost,
      orders: data.orders,
      materials: data.materials,
    }))

  const stockDistributionData = Object.entries(stockAnalysis.categoryDistribution).map(([category, data]) => ({
    name: category,
    value: data.value,
    count: data.count,
    stock: data.stock,
  }))

  // Export functions
  const exportToExcel = () => {
    toast({
      title: "تصدير إلى Excel",
      description: "سيتم تصدير التقرير إلى ملف Excel قريباً",
      duration: 3000,
    })
  }

  const exportToPDF = () => {
    toast({
      title: "تصدير إلى PDF",
      description: "سيتم تصدير التقرير إلى ملف PDF قريباً",
      duration: 3000,
    })
  }

  const printReport = () => {
    window.print()
  }

  return (
    <PageLayout title="تقارير المخزون والاستهلاك / Inventory & Consumption Reports">
      {/* Filters Section */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            فلاتر التقرير / Report Filters
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <Label>من تاريخ / From Date</Label>
              <Input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} />
            </div>
            <div>
              <Label>إلى تاريخ / To Date</Label>
              <Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} />
            </div>
            <div>
              <Label>الفئة / Category</Label>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger>
                  <SelectValue placeholder="اختر الفئة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الفئات</SelectItem>
                  <SelectItem value="dye">أصباغ</SelectItem>
                  <SelectItem value="chemical">كيماويات</SelectItem>
                  <SelectItem value="auxiliary">مساعدة</SelectItem>
                  <SelectItem value="finishing">تجهيز</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>فترة التقرير / Report Period</Label>
              <Select value={reportPeriod} onValueChange={setReportPeriod}>
                <SelectTrigger>
                  <SelectValue placeholder="اختر الفترة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7">آخر 7 أيام</SelectItem>
                  <SelectItem value="30">آخر 30 يوم</SelectItem>
                  <SelectItem value="90">آخر 3 أشهر</SelectItem>
                  <SelectItem value="365">آخر سنة</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4 mb-6">
          <TabsTrigger value="consumption-report">تقرير الاستهلاك</TabsTrigger>
          <TabsTrigger value="stock-analysis">تحليل المخزون</TabsTrigger>
          <TabsTrigger value="trends">اتجاهات الحركة</TabsTrigger>
          <TabsTrigger value="detailed-reports">تقارير مفصلة</TabsTrigger>
        </TabsList>

        {/* Consumption Report Tab */}
        <TabsContent value="consumption-report">
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">إجمالي المواد</p>
                    <p className="text-2xl font-bold text-blue-600">{consumptionStats.totalMaterials}</p>
                  </div>
                  <Package className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">إجمالي التكلفة</p>
                    <p className="text-2xl font-bold text-green-600">${consumptionStats.totalCost.toFixed(2)}</p>
                  </div>
                  <DollarSign className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">أوامر التشغيل</p>
                    <p className="text-2xl font-bold text-purple-600">{consumptionStats.totalOrders}</p>
                  </div>
                  <FileText className="h-8 w-8 text-purple-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">متوسط التكلفة</p>
                    <p className="text-2xl font-bold text-orange-600">
                      $
                      {consumptionStats.totalOrders > 0
                        ? (consumptionStats.totalCost / consumptionStats.totalOrders).toFixed(2)
                        : "0.00"}
                    </p>
                  </div>
                  <BarChart3 className="h-8 w-8 text-orange-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <Card>
              <CardHeader>
                <CardTitle>الاستهلاك حسب الفئة / Consumption by Category</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={categoryChartData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="cost"
                    >
                      {categoryChartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [`$${Number(value).toFixed(2)}`, "التكلفة"]} />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>أعلى المواد استهلاكاً / Top Consumed Materials</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={topMaterialsData.slice(0, 5)}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" angle={-45} textAnchor="end" height={80} />
                    <YAxis />
                    <Tooltip formatter={(value) => [`$${Number(value).toFixed(2)}`, "التكلفة"]} />
                    <Bar dataKey="cost" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Export Buttons */}
          <div className="flex justify-end gap-2 mb-6">
            <Button variant="outline" onClick={exportToExcel}>
              <Download className="h-4 w-4 mr-2" />
              تصدير Excel
            </Button>
            <Button variant="outline" onClick={exportToPDF}>
              <FileText className="h-4 w-4 mr-2" />
              تصدير PDF
            </Button>
            <Button variant="outline" onClick={printReport}>
              <Printer className="h-4 w-4 mr-2" />
              طباعة
            </Button>
          </div>

          {/* Detailed Table */}
          <Card>
            <CardHeader>
              <CardTitle>تفاصيل الاستهلاك / Consumption Details</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>المادة / Material</TableHead>
                      <TableHead>الفئة / Category</TableHead>
                      <TableHead className="text-right">الكمية المستهلكة</TableHead>
                      <TableHead className="text-right">التكلفة الإجمالية</TableHead>
                      <TableHead className="text-right">المخزون الحالي</TableHead>
                      <TableHead>حالة المخزون</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {Object.entries(consumptionStats.materialBreakdown).map(([materialKey, data]) => {
                      const materialId = Number.parseInt(materialKey.split("-")[0])
                      const material = materials.find((m) => m.id === materialId)
                      const stockStatus = material
                        ? material.currentStock === 0
                          ? "نفد"
                          : material.currentStock <= 5
                            ? "حرج"
                            : material.currentStock <= material.minimumStock
                              ? "منخفض"
                              : "جيد"
                        : "غير معروف"

                      return (
                        <TableRow key={materialKey}>
                          <TableCell>
                            <div>
                              <div className="font-medium">{materialKey.split("-")[1]}</div>
                              <div className="text-sm text-gray-500">{material?.nameAr}</div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">{data.category}</Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            {data.quantity.toFixed(2)} {data.unit}
                          </TableCell>
                          <TableCell className="text-right font-medium">${data.cost.toFixed(2)}</TableCell>
                          <TableCell className="text-right">
                            {material?.currentStock || 0} {data.unit}
                          </TableCell>
                          <TableCell>
                            <Badge
                              className={
                                stockStatus === "نفد"
                                  ? "bg-red-100 text-red-800"
                                  : stockStatus === "حرج"
                                    ? "bg-orange-100 text-orange-800"
                                    : stockStatus === "منخفض"
                                      ? "bg-yellow-100 text-yellow-800"
                                      : "bg-green-100 text-green-800"
                              }
                            >
                              {stockStatus}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Stock Analysis Tab */}
        <TabsContent value="stock-analysis">
          {/* Stock Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">إجمالي الأصناف</p>
                    <p className="text-2xl font-bold text-blue-600">{stockAnalysis.totalItems}</p>
                  </div>
                  <Warehouse className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">مخزون منخفض</p>
                    <p className="text-2xl font-bold text-yellow-600">{stockAnalysis.lowStock}</p>
                  </div>
                  <TrendingDown className="h-8 w-8 text-yellow-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">مخزون حرج</p>
                    <p className="text-2xl font-bold text-red-600">{stockAnalysis.criticalStock}</p>
                  </div>
                  <AlertTriangle className="h-8 w-8 text-red-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">نفد المخزون</p>
                    <p className="text-2xl font-bold text-gray-600">{stockAnalysis.outOfStock}</p>
                  </div>
                  <Package className="h-8 w-8 text-gray-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">قيمة المخزون</p>
                    <p className="text-2xl font-bold text-green-600">${stockAnalysis.totalValue.toFixed(2)}</p>
                  </div>
                  <DollarSign className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Stock Distribution Chart */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <Card>
              <CardHeader>
                <CardTitle>توزيع المخزون حسب الفئة / Stock Distribution by Category</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={stockDistributionData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {stockDistributionData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [`$${Number(value).toFixed(2)}`, "القيمة"]} />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>عدد الأصناف حسب الفئة / Items Count by Category</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={stockDistributionData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="count" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Critical Stock Alert */}
          {stockAnalysis.criticalStock > 0 && (
            <Card className="mb-6 border-red-200 bg-red-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-red-800">
                  <AlertTriangle className="h-5 w-5" />
                  تحذير: مواد بمخزون حرج ({stockAnalysis.criticalStock})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {materials
                    .filter((m) => m.currentStock <= 5 && m.currentStock > 0)
                    .map((material) => (
                      <div key={material.id} className="p-3 bg-white rounded-lg border border-red-200">
                        <div className="flex justify-between items-center">
                          <div>
                            <div className="font-medium text-sm">{material.name}</div>
                            <div className="text-xs text-gray-600">{material.nameAr}</div>
                          </div>
                          <div className="text-right">
                            <div className="font-bold text-red-600">
                              {material.currentStock} {material.unit}
                            </div>
                            <div className="text-xs text-gray-500">متبقي</div>
                          </div>
                        </div>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Stock Details Table */}
          <Card>
            <CardHeader>
              <CardTitle>تفاصيل المخزون / Stock Details</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>الكود / Code</TableHead>
                      <TableHead>المادة / Material</TableHead>
                      <TableHead>الفئة / Category</TableHead>
                      <TableHead className="text-right">المخزون الحالي</TableHead>
                      <TableHead className="text-right">الحد الأدنى</TableHead>
                      <TableHead className="text-right">سعر الوحدة</TableHead>
                      <TableHead className="text-right">القيمة الإجمالية</TableHead>
                      <TableHead>الحالة</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {materials.map((material) => {
                      const stockStatus =
                        material.currentStock === 0
                          ? "نفد"
                          : material.currentStock <= 5
                            ? "حرج"
                            : material.currentStock <= material.minimumStock
                              ? "منخفض"
                              : "جيد"

                      const totalValue = material.currentStock * material.purchasePrice

                      return (
                        <TableRow key={material.id}>
                          <TableCell className="font-medium">{material.code}</TableCell>
                          <TableCell>
                            <div>
                              <div className="font-medium">{material.name}</div>
                              <div className="text-sm text-gray-500">{material.nameAr}</div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">{material.category}</Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            {material.currentStock} {material.unit}
                          </TableCell>
                          <TableCell className="text-right">
                            {material.minimumStock} {material.unit}
                          </TableCell>
                          <TableCell className="text-right">${material.purchasePrice.toFixed(2)}</TableCell>
                          <TableCell className="text-right font-medium">${totalValue.toFixed(2)}</TableCell>
                          <TableCell>
                            <Badge
                              className={
                                stockStatus === "نفد"
                                  ? "bg-red-100 text-red-800"
                                  : stockStatus === "حرج"
                                    ? "bg-orange-100 text-orange-800"
                                    : stockStatus === "منخفض"
                                      ? "bg-yellow-100 text-yellow-800"
                                      : "bg-green-100 text-green-800"
                              }
                            >
                              {stockStatus}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Trends Tab */}
        <TabsContent value="trends">
          {/* Trend Summary */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">أيام النشاط</p>
                    <p className="text-2xl font-bold text-blue-600">
                      {Object.keys(consumptionStats.dailyConsumption).length}
                    </p>
                  </div>
                  <Calendar className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">متوسط التكلفة اليومية</p>
                    <p className="text-2xl font-bold text-green-600">
                      $
                      {Object.keys(consumptionStats.dailyConsumption).length > 0
                        ? (consumptionStats.totalCost / Object.keys(consumptionStats.dailyConsumption).length).toFixed(
                            2,
                          )
                        : "0.00"}
                    </p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">متوسط الأوامر اليومية</p>
                    <p className="text-2xl font-bold text-purple-600">
                      {Object.keys(consumptionStats.dailyConsumption).length > 0
                        ? (
                            consumptionStats.totalOrders / Object.keys(consumptionStats.dailyConsumption).length
                          ).toFixed(1)
                        : "0.0"}
                    </p>
                  </div>
                  <Activity className="h-8 w-8 text-purple-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">متوسط المواد اليومية</p>
                    <p className="text-2xl font-bold text-orange-600">
                      {Object.keys(consumptionStats.dailyConsumption).length > 0
                        ? (
                            consumptionStats.totalMaterials / Object.keys(consumptionStats.dailyConsumption).length
                          ).toFixed(1)
                        : "0.0"}
                    </p>
                  </div>
                  <Package className="h-8 w-8 text-orange-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Trend Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <Card>
              <CardHeader>
                <CardTitle>اتجاه التكلفة اليومية / Daily Cost Trend</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={dailyTrendData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`$${Number(value).toFixed(2)}`, "التكلفة"]} />
                    <Area type="monotone" dataKey="cost" stroke="#8884d8" fill="#8884d8" fillOpacity={0.6} />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>عدد أوامر التشغيل اليومية / Daily Orders Count</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={dailyTrendData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="orders" stroke="#82ca9d" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Daily Breakdown Table */}
          <Card>
            <CardHeader>
              <CardTitle>التفصيل اليومي / Daily Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>التاريخ / Date</TableHead>
                      <TableHead className="text-right">عدد الأوامر</TableHead>
                      <TableHead className="text-right">عدد المواد</TableHead>
                      <TableHead className="text-right">التكلفة الإجمالية</TableHead>
                      <TableHead className="text-right">متوسط تكلفة الأمر</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {dailyTrendData.map((day, index) => (
                      <TableRow key={index}>
                        <TableCell className="font-medium">{day.date}</TableCell>
                        <TableCell className="text-right">{day.orders}</TableCell>
                        <TableCell className="text-right">{day.materials}</TableCell>
                        <TableCell className="text-right">${day.cost.toFixed(2)}</TableCell>
                        <TableCell className="text-right">
                          ${day.orders > 0 ? (day.cost / day.orders).toFixed(2) : "0.00"}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Detailed Reports Tab */}
        <TabsContent value="detailed-reports">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* By Processing Orders */}
            <Card>
              <CardHeader>
                <CardTitle>الاستهلاك حسب أوامر التشغيل / Consumption by Processing Orders</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {filteredIssuances.map((issuance) => (
                    <div key={issuance.id} className="p-4 border rounded-lg">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <div className="font-medium">{issuance.productionOrderNumber}</div>
                          <div className="text-sm text-gray-500">{issuance.customerName}</div>
                        </div>
                        <div className="text-right">
                          <div className="font-bold text-green-600">${issuance.totalCost.toFixed(2)}</div>
                          <div className="text-sm text-gray-500">{issuance.issueDate}</div>
                        </div>
                      </div>
                      <div className="text-sm">
                        <span className="text-gray-600">المواد: </span>
                        <span>{issuance.materials.length} مادة</span>
                      </div>
                      <div className="mt-2">
                        <Badge
                          className={
                            issuance.status === "completed"
                              ? "bg-green-100 text-green-800"
                              : issuance.status === "issued"
                                ? "bg-blue-100 text-blue-800"
                                : "bg-yellow-100 text-yellow-800"
                          }
                        >
                          {issuance.status === "completed"
                            ? "مكتمل"
                            : issuance.status === "issued"
                              ? "تم الصرف"
                              : "قيد الانتظار"}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* By Category Analysis */}
            <Card>
              <CardHeader>
                <CardTitle>تحليل الفئات / Category Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {Object.entries(consumptionStats.categoryBreakdown).map(([category, data]) => {
                    const percentage =
                      consumptionStats.totalCost > 0 ? (data.cost / consumptionStats.totalCost) * 100 : 0

                    return (
                      <div key={category} className="p-4 border rounded-lg">
                        <div className="flex justify-between items-center mb-2">
                          <div className="font-medium capitalize">{category}</div>
                          <div className="font-bold text-blue-600">${data.cost.toFixed(2)}</div>
                        </div>
                        <div className="grid grid-cols-3 gap-4 text-sm">
                          <div>
                            <div className="text-gray-600">عدد المواد</div>
                            <div className="font-medium">{data.count}</div>
                          </div>
                          <div>
                            <div className="text-gray-600">الكمية الإجمالية</div>
                            <div className="font-medium">{data.quantity.toFixed(2)}</div>
                          </div>
                          <div>
                            <div className="text-gray-600">النسبة المئوية</div>
                            <div className="font-medium">{percentage.toFixed(1)}%</div>
                          </div>
                        </div>
                        <div className="mt-2">
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div className="bg-blue-600 h-2 rounded-full" style={{ width: `${percentage}%` }}></div>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </PageLayout>
  )
}
