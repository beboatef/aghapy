"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { BarChart3, TrendingUp, DollarSign, Package, Download, Filter, Search, Eye } from "lucide-react"
import { dataManager } from "@/lib/data-manager"

interface ProductionOrder {
  id: string
  orderNumber: string
  customerName: string
  fabricType: string
  color: string
  quantity: number
  unit: string
  orderDate: string
  dueDate: string
  status: "pending" | "in_progress" | "completed"
  priority: "low" | "medium" | "high"
}

interface MaterialIssuance {
  id: string
  issueNumber: string
  productionOrderId: string
  productionOrderNumber: string
  customerName: string
  issueDate: string
  materials: MaterialIssuanceItem[]
  totalCost: number
  status: "pending" | "approved" | "issued" | "completed" | "rejected"
}

interface MaterialIssuanceItem {
  materialId: number
  materialCode: string
  materialName: string
  materialNameAr: string
  category: string
  unit: string
  requestedQuantity: number
  unitPrice: number
  totalCost: number
}

interface ProductionCostSummary {
  productionOrderId: string
  orderNumber: string
  customerName: string
  fabricType: string
  color: string
  quantity: number
  unit: string
  orderDate: string
  status: string
  materialCosts: {
    dyes: number
    chemicals: number
    auxiliaries: number
    finishing: number
    total: number
  }
  materialBreakdown: MaterialIssuanceItem[]
  costPerUnit: number
  profitMargin?: number
  estimatedRevenue?: number
}

export default function ProductionCostAnalysisPage() {
  const [activeTab, setActiveTab] = useState("cost-summary")
  const [productionOrders, setProductionOrders] = useState<ProductionOrder[]>([])
  const [materialIssuances, setMaterialIssuances] = useState<MaterialIssuance[]>([])
  const [costSummaries, setCostSummaries] = useState<ProductionCostSummary[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [dateFrom, setDateFrom] = useState("")
  const [dateTo, setDateTo] = useState("")
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null)

  useEffect(() => {
    // Load data
    const orders = dataManager.getData("productionOrders", [])
    const issuances = dataManager.getData("materialIssuances", [])

    setProductionOrders(orders)
    setMaterialIssuances(issuances)

    // Calculate cost summaries
    const summaries = calculateCostSummaries(orders, issuances)
    setCostSummaries(summaries)
  }, [])

  const calculateCostSummaries = (
    orders: ProductionOrder[],
    issuances: MaterialIssuance[],
  ): ProductionCostSummary[] => {
    return orders.map((order) => {
      // Find all issuances for this production order
      const orderIssuances = issuances.filter(
        (issuance) =>
          issuance.productionOrderId === order.id && (issuance.status === "completed" || issuance.status === "issued"),
      )

      // Aggregate all materials used
      const allMaterials: MaterialIssuanceItem[] = []
      orderIssuances.forEach((issuance) => {
        allMaterials.push(...issuance.materials)
      })

      // Calculate costs by category
      const materialCosts = {
        dyes: allMaterials.filter((m) => m.category === "dye").reduce((sum, m) => sum + m.totalCost, 0),
        chemicals: allMaterials.filter((m) => m.category === "chemical").reduce((sum, m) => sum + m.totalCost, 0),
        auxiliaries: allMaterials.filter((m) => m.category === "auxiliary").reduce((sum, m) => sum + m.totalCost, 0),
        finishing: allMaterials.filter((m) => m.category === "finishing").reduce((sum, m) => sum + m.totalCost, 0),
        total: allMaterials.reduce((sum, m) => sum + m.totalCost, 0),
      }

      const costPerUnit = order.quantity > 0 ? materialCosts.total / order.quantity : 0

      // Estimated revenue (this would come from pricing data in a real system)
      const estimatedUnitPrice = costPerUnit * 1.3 // 30% markup example
      const estimatedRevenue = estimatedUnitPrice * order.quantity
      const profitMargin =
        estimatedRevenue > 0 ? ((estimatedRevenue - materialCosts.total) / estimatedRevenue) * 100 : 0

      return {
        productionOrderId: order.id,
        orderNumber: order.orderNumber,
        customerName: order.customerName,
        fabricType: order.fabricType,
        color: order.color,
        quantity: order.quantity,
        unit: order.unit,
        orderDate: order.orderDate,
        status: order.status,
        materialCosts,
        materialBreakdown: allMaterials,
        costPerUnit,
        profitMargin,
        estimatedRevenue,
      }
    })
  }

  const filteredSummaries = costSummaries.filter((summary) => {
    const matchesSearch =
      summary.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      summary.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      summary.fabricType.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus = statusFilter === "all" || summary.status === statusFilter

    const matchesDateFrom = dateFrom === "" || summary.orderDate >= dateFrom
    const matchesDateTo = dateTo === "" || summary.orderDate <= dateTo

    return matchesSearch && matchesStatus && matchesDateFrom && matchesDateTo
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "in_progress":
        return "bg-blue-100 text-blue-800"
      case "completed":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "pending":
        return { en: "Pending", ar: "في الانتظار" }
      case "in_progress":
        return { en: "In Progress", ar: "قيد التنفيذ" }
      case "completed":
        return { en: "Completed", ar: "مكتمل" }
      default:
        return { en: status, ar: status }
    }
  }

  // Calculate overall statistics
  const totalOrders = filteredSummaries.length
  const completedOrders = filteredSummaries.filter((s) => s.status === "completed").length
  const totalMaterialCost = filteredSummaries.reduce((sum, s) => sum + s.materialCosts.total, 0)
  const averageCostPerOrder = totalOrders > 0 ? totalMaterialCost / totalOrders : 0
  const totalEstimatedRevenue = filteredSummaries.reduce((sum, s) => sum + (s.estimatedRevenue || 0), 0)
  const averageProfitMargin =
    filteredSummaries.length > 0
      ? filteredSummaries.reduce((sum, s) => sum + (s.profitMargin || 0), 0) / filteredSummaries.length
      : 0

  // Get detailed view of a specific order
  const selectedOrder = selectedOrderId
    ? costSummaries.find((summary) => summary.productionOrderId === selectedOrderId)
    : null

  const applyFilters = () => {
    // This function would re-filter the data based on the current filter settings
    // For now, we're already filtering reactively, so this is just a placeholder
    console.log("Applying filters")
  }

  const exportData = () => {
    const csvContent = [
      ["Order Number", "Customer", "Product", "Quantity", "Material Cost", "Cost Per Unit", "Profit Margin", "Status"],
      ...filteredSummaries.map((summary) => [
        summary.orderNumber,
        summary.customerName,
        `${summary.fabricType} - ${summary.color}`,
        `${summary.quantity} ${summary.unit}`,
        `ج.م${summary.materialCosts.total.toFixed(2)}`,
        `ج.م${summary.costPerUnit.toFixed(2)}`,
        `${(summary.profitMargin || 0).toFixed(1)}%`,
        summary.status,
      ]),
    ]
      .map((row) => row.join(","))
      .join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "production-cost-analysis.csv"
    a.click()
    window.URL.revokeObjectURL(url)
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Production Cost Analysis</h1>
        <p className="text-lg text-gray-600 mb-1">تحليل تكاليف الإنتاج</p>
        <p className="text-gray-600">Comprehensive cost analysis for production orders</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Total Orders</p>
                <p className="text-sm text-gray-500 mb-2">إجمالي الأوامر</p>
                <p className="text-2xl font-bold text-gray-900">{totalOrders}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Package className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Completed Orders</p>
                <p className="text-sm text-gray-500 mb-2">الأوامر المكتملة</p>
                <p className="text-2xl font-bold text-green-600">{completedOrders}</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Total Material Cost</p>
                <p className="text-sm text-gray-500 mb-2">إجمالي تكلفة المواد</p>
                <p className="text-2xl font-bold text-red-600">ج.م{totalMaterialCost.toFixed(2)}</p>
              </div>
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-red-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Avg. Profit Margin</p>
                <p className="text-sm text-gray-500 mb-2">متوسط هامش الربح</p>
                <p className="text-2xl font-bold text-purple-600">{averageProfitMargin.toFixed(1)}%</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <BarChart3 className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="cost-summary">Cost Summary / ملخص التكاليف</TabsTrigger>
          <TabsTrigger value="detailed-analysis">Detailed Analysis / تحليل مفصل</TabsTrigger>
          <TabsTrigger value="cost-breakdown">Cost Breakdown / تفصيل التكاليف</TabsTrigger>
        </TabsList>

        <TabsContent value="cost-summary">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center">
                    <BarChart3 className="w-5 h-5 mr-2" />
                    Production Cost Summary
                  </CardTitle>
                  <p className="text-sm text-gray-600 mt-1">ملخص تكاليف الإنتاج</p>
                </div>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="sm" onClick={applyFilters}>
                    <Filter className="w-4 h-4 mr-2" />
                    Filter / تصفية
                  </Button>
                  <Button variant="outline" size="sm" onClick={exportData}>
                    <Download className="w-4 h-4 mr-2" />
                    Export / تصدير
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {/* Filters */}
              <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Search orders... / البحث في الأوامر"
                    className="pl-10"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Status / الحالة" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status / جميع الحالات</SelectItem>
                    <SelectItem value="pending">Pending / في الانتظار</SelectItem>
                    <SelectItem value="in_progress">In Progress / قيد التنفيذ</SelectItem>
                    <SelectItem value="completed">Completed / مكتمل</SelectItem>
                  </SelectContent>
                </Select>
                <Input
                  type="date"
                  value={dateFrom}
                  onChange={(e) => setDateFrom(e.target.value)}
                  placeholder="From Date"
                />
                <Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} placeholder="To Date" />
                <Button className="bg-blue-600 hover:bg-blue-700" onClick={applyFilters}>
                  Apply Filters / تطبيق التصفية
                </Button>
              </div>

              {/* Cost Summary Table */}
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="text-left px-4 py-3 text-sm font-medium text-gray-600">Order # / رقم الأمر</th>
                      <th className="text-left px-4 py-3 text-sm font-medium text-gray-600">Customer / العميل</th>
                      <th className="text-left px-4 py-3 text-sm font-medium text-gray-600">Product / المنتج</th>
                      <th className="text-right px-4 py-3 text-sm font-medium text-gray-600">Quantity / الكمية</th>
                      <th className="text-right px-4 py-3 text-sm font-medium text-gray-600">
                        Material Cost / تكلفة المواد
                      </th>
                      <th className="text-right px-4 py-3 text-sm font-medium text-gray-600">
                        Cost/Unit / التكلفة للوحدة
                      </th>
                      <th className="text-right px-4 py-3 text-sm font-medium text-gray-600">
                        Profit Margin / هامش الربح
                      </th>
                      <th className="text-left px-4 py-3 text-sm font-medium text-gray-600">Status / الحالة</th>
                      <th className="text-center px-4 py-3 text-sm font-medium text-gray-600">Actions / الإجراءات</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {filteredSummaries.length === 0 ? (
                      <tr>
                        <td colSpan={9} className="text-center py-8 text-gray-500">
                          No production orders found / لم يتم العثور على أوامر إنتاج
                        </td>
                      </tr>
                    ) : (
                      filteredSummaries.map((summary) => (
                        <tr key={summary.productionOrderId} className="hover:bg-gray-50">
                          <td className="px-4 py-3 text-sm font-medium text-blue-600">{summary.orderNumber}</td>
                          <td className="px-4 py-3 text-sm text-gray-900">{summary.customerName}</td>
                          <td className="px-4 py-3 text-sm text-gray-900">
                            {summary.fabricType} - {summary.color}
                          </td>
                          <td className="px-4 py-3 text-sm text-gray-900 text-right">
                            {summary.quantity} {summary.unit}
                          </td>
                          <td className="px-4 py-3 text-sm font-medium text-red-600 text-right">
                            ج.م${summary.materialCosts.total.toFixed(2)}
                          </td>
                          <td className="px-4 py-3 text-sm text-gray-900 text-right">
                            ج.م${summary.costPerUnit.toFixed(2)}
                          </td>
                          <td className="px-4 py-3 text-sm font-medium text-green-600 text-right">
                            {(summary.profitMargin || 0).toFixed(1)}%
                          </td>
                          <td className="px-4 py-3">
                            <span
                              className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(
                                summary.status,
                              )}`}
                            >
                              {getStatusLabel(summary.status).en}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-center">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setSelectedOrderId(summary.productionOrderId)}
                            >
                              <Eye className="w-4 h-4" />
                            </Button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="detailed-analysis">
          <Card>
            <CardHeader>
              <CardTitle>Detailed Cost Analysis / تحليل التكاليف المفصل</CardTitle>
            </CardHeader>
            <CardContent>
              {selectedOrder ? (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-lg font-semibold mb-4">Order Details / تفاصيل الأمر</h3>
                      <div className="space-y-2">
                        <p>
                          <strong>Order Number:</strong> {selectedOrder.orderNumber}
                        </p>
                        <p>
                          <strong>Customer:</strong> {selectedOrder.customerName}
                        </p>
                        <p>
                          <strong>Product:</strong> {selectedOrder.fabricType} - {selectedOrder.color}
                        </p>
                        <p>
                          <strong>Quantity:</strong> {selectedOrder.quantity} {selectedOrder.unit}
                        </p>
                        <p>
                          <strong>Order Date:</strong> {selectedOrder.orderDate}
                        </p>
                        <p>
                          <strong>Status:</strong> {selectedOrder.status}
                        </p>
                      </div>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-4">Cost Breakdown / تفصيل التكاليف</h3>
                      <div className="space-y-2">
                        <p>
                          <strong>Dyes:</strong> ج.م${selectedOrder.materialCosts.dyes.toFixed(2)}
                        </p>
                        <p>
                          <strong>Chemicals:</strong> ج.م${selectedOrder.materialCosts.chemicals.toFixed(2)}
                        </p>
                        <p>
                          <strong>Auxiliaries:</strong> ج.م${selectedOrder.materialCosts.auxiliaries.toFixed(2)}
                        </p>
                        <p>
                          <strong>Finishing:</strong> ج.م${selectedOrder.materialCosts.finishing.toFixed(2)}
                        </p>
                        <p className="border-t pt-2">
                          <strong>Total Material Cost:</strong> ج.م${selectedOrder.materialCosts.total.toFixed(2)}
                        </p>
                        <p>
                          <strong>Cost per Unit:</strong> ج.م${selectedOrder.costPerUnit.toFixed(2)}
                        </p>
                        <p>
                          <strong>Estimated Revenue:</strong> ج.م${(selectedOrder.estimatedRevenue || 0).toFixed(2)}
                        </p>
                        <p>
                          <strong>Profit Margin:</strong> {(selectedOrder.profitMargin || 0).toFixed(1)}%
                        </p>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold mb-4">Material Usage / استخدام المواد</h3>
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="text-left px-4 py-2 text-sm font-medium text-gray-600">Material / المادة</th>
                            <th className="text-left px-4 py-2 text-sm font-medium text-gray-600">Category / الفئة</th>
                            <th className="text-right px-4 py-2 text-sm font-medium text-gray-600">
                              Quantity / الكمية
                            </th>
                            <th className="text-right px-4 py-2 text-sm font-medium text-gray-600">
                              Unit Price / سعر الوحدة
                            </th>
                            <th className="text-right px-4 py-2 text-sm font-medium text-gray-600">
                              Total Cost / التكلفة الإجمالية
                            </th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                          {selectedOrder.materialBreakdown.map((material, index) => (
                            <tr key={index}>
                              <td className="px-4 py-2 text-sm text-gray-900">
                                {material.materialName}
                                <br />
                                <span className="text-xs text-gray-500">{material.materialNameAr}</span>
                              </td>
                              <td className="px-4 py-2 text-sm text-gray-600">{material.category}</td>
                              <td className="px-4 py-2 text-sm text-gray-900 text-right">
                                {material.requestedQuantity} {material.unit}
                              </td>
                              <td className="px-4 py-2 text-sm text-gray-900 text-right">
                                ج.م${material.unitPrice.toFixed(2)}
                              </td>
                              <td className="px-4 py-2 text-sm font-medium text-gray-900 text-right">
                                ج.م${material.totalCost.toFixed(2)}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  Select an order from the Cost Summary tab to view detailed analysis
                  <br />
                  اختر أمر من تبويب ملخص التكاليف لعرض التحليل المفصل
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="cost-breakdown">
          <Card>
            <CardHeader>
              <CardTitle>Cost Category Breakdown / تفصيل فئات التكاليف</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <Card className="border-0 shadow-sm bg-red-50">
                  <CardContent className="p-4">
                    <div className="text-center">
                      <p className="text-sm text-red-600 mb-1">Dyes Cost</p>
                      <p className="text-sm text-red-500 mb-2">تكلفة الأصباغ</p>
                      <p className="text-xl font-bold text-red-700">
                        ج.م${filteredSummaries.reduce((sum, s) => sum + s.materialCosts.dyes, 0).toFixed(2)}
                      </p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-sm bg-blue-50">
                  <CardContent className="p-4">
                    <div className="text-center">
                      <p className="text-sm text-blue-600 mb-1">Chemicals Cost</p>
                      <p className="text-sm text-blue-500 mb-2">تكلفة الكيماويات</p>
                      <p className="text-xl font-bold text-blue-700">
                        ج.م${filteredSummaries.reduce((sum, s) => sum + s.materialCosts.chemicals, 0).toFixed(2)}
                      </p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-sm bg-green-50">
                  <CardContent className="p-4">
                    <div className="text-center">
                      <p className="text-sm text-green-600 mb-1">Auxiliaries Cost</p>
                      <p className="text-sm text-green-500 mb-2">تكلفة المساعدات</p>
                      <p className="text-xl font-bold text-green-700">
                        ج.م${filteredSummaries.reduce((sum, s) => sum + s.materialCosts.auxiliaries, 0).toFixed(2)}
                      </p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-sm bg-purple-50">
                  <CardContent className="p-4">
                    <div className="text-center">
                      <p className="text-sm text-purple-600 mb-1">Finishing Cost</p>
                      <p className="text-sm text-purple-500 mb-2">تكلفة التشطيب</p>
                      <p className="text-xl font-bold text-purple-700">
                        ج.م${filteredSummaries.reduce((sum, s) => sum + s.materialCosts.finishing, 0).toFixed(2)}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Cost Distribution by Order / توزيع التكاليف حسب الأمر</h3>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="text-left px-4 py-3 text-sm font-medium text-gray-600">Order / الأمر</th>
                        <th className="text-right px-4 py-3 text-sm font-medium text-gray-600">Dyes / الأصباغ</th>
                        <th className="text-right px-4 py-3 text-sm font-medium text-gray-600">
                          Chemicals / الكيماويات
                        </th>
                        <th className="text-right px-4 py-3 text-sm font-medium text-gray-600">
                          Auxiliaries / المساعدات
                        </th>
                        <th className="text-right px-4 py-3 text-sm font-medium text-gray-600">Finishing / التشطيب</th>
                        <th className="text-right px-4 py-3 text-sm font-medium text-gray-600">Total / الإجمالي</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {filteredSummaries.map((summary) => (
                        <tr key={summary.productionOrderId} className="hover:bg-gray-50">
                          <td className="px-4 py-3 text-sm font-medium text-blue-600">
                            {summary.orderNumber}
                            <br />
                            <span className="text-xs text-gray-500">{summary.customerName}</span>
                          </td>
                          <td className="px-4 py-3 text-sm text-red-600 text-right">
                            ج.م${summary.materialCosts.dyes.toFixed(2)}
                          </td>
                          <td className="px-4 py-3 text-sm text-blue-600 text-right">
                            ج.م${summary.materialCosts.chemicals.toFixed(2)}
                          </td>
                          <td className="px-4 py-3 text-sm text-green-600 text-right">
                            ج.م${summary.materialCosts.auxiliaries.toFixed(2)}
                          </td>
                          <td className="px-4 py-3 text-sm text-purple-600 text-right">
                            ج.م${summary.materialCosts.finishing.toFixed(2)}
                          </td>
                          <td className="px-4 py-3 text-sm font-bold text-gray-900 text-right">
                            ج.م${summary.materialCosts.total.toFixed(2)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
