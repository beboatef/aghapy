"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  Package,
  Plus,
  Search,
  Edit,
  Trash2,
  MoreHorizontal,
  TrendingUp,
  DollarSign,
  AlertTriangle,
  Palette,
  Filter,
  Download,
} from "lucide-react"
import { useAuth } from "@/hooks/use-auth"
import { dataManager } from "@/lib/data-manager"

interface DyeingMaterial {
  id: number
  code: string
  name: string
  nameAr: string
  category: "dye" | "chemical" | "auxiliary" | "finishing"
  unit: "kg" | "gram" | "liter"
  purchasePrice: number
  currentStock: number
  minimumStock: number
  supplier: string
  lastPurchaseDate: string
  status: "active" | "inactive" | "low_stock"
  createdAt: string
  updatedAt: string
}

export default function DyeingInventoryPage() {
  const [activeTab, setActiveTab] = useState("all")
  const [showDialog, setShowDialog] = useState(false)
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all_categories")
  const [selectedMaterial, setSelectedMaterial] = useState<DyeingMaterial | null>(null)
  const [isEditMode, setIsEditMode] = useState(false)

  const { isAdmin, canDelete } = useAuth()

  const [materials, setMaterials] = useState<DyeingMaterial[]>([])

  const [formData, setFormData] = useState({
    code: "",
    name: "",
    nameAr: "",
    category: "dye" as "dye" | "chemical" | "auxiliary" | "finishing",
    unit: "kg" as "kg" | "gram" | "liter",
    purchasePrice: "",
    currentStock: "",
    minimumStock: "",
    supplier: "",
  })

  // Load materials from data manager
  useEffect(() => {
    const loadedMaterials = dataManager.getDyeingMaterials()
    if (loadedMaterials.length === 0) {
      // Initialize with sample data
      const sampleMaterials: DyeingMaterial[] = [
        {
          id: 1,
          code: "DYE001",
          name: "Direct Blue 86",
          nameAr: "أزرق مباشر 86",
          category: "dye",
          unit: "kg",
          purchasePrice: 45.5,
          currentStock: 125.5,
          minimumStock: 20,
          supplier: "Advanced Colors Co.",
          lastPurchaseDate: "2024-03-01",
          status: "active",
          createdAt: "2024-01-15",
          updatedAt: "2024-03-01",
        },
        {
          id: 2,
          code: "CHM001",
          name: "Acetic Acid",
          nameAr: "حمض الخليك",
          category: "chemical",
          unit: "liter",
          purchasePrice: 12.75,
          currentStock: 85.2,
          minimumStock: 15,
          supplier: "Industrial Chemicals Ltd.",
          lastPurchaseDate: "2024-02-28",
          status: "active",
          createdAt: "2024-01-10",
          updatedAt: "2024-02-28",
        },
        {
          id: 3,
          code: "AUX001",
          name: "Fabric Softener",
          nameAr: "منعم الأقمشة",
          category: "auxiliary",
          unit: "kg",
          purchasePrice: 28.9,
          currentStock: 15.8,
          minimumStock: 25,
          supplier: "Textile Auxiliaries Inc.",
          lastPurchaseDate: "2024-03-05",
          status: "low_stock",
          createdAt: "2024-01-20",
          updatedAt: "2024-03-05",
        },
        {
          id: 4,
          code: "DYE002",
          name: "Reactive Red 195",
          nameAr: "أحمر تفاعلي 195",
          category: "dye",
          unit: "kg",
          purchasePrice: 52.3,
          currentStock: 78.4,
          minimumStock: 20,
          supplier: "Advanced Colors Co.",
          lastPurchaseDate: "2024-03-03",
          status: "active",
          createdAt: "2024-01-18",
          updatedAt: "2024-03-03",
        },
        {
          id: 5,
          code: "CHM002",
          name: "Sodium Carbonate",
          nameAr: "كربونات الصوديوم",
          category: "chemical",
          unit: "kg",
          purchasePrice: 8.45,
          currentStock: 245.6,
          minimumStock: 50,
          supplier: "Industrial Chemicals Ltd.",
          lastPurchaseDate: "2024-02-25",
          status: "active",
          createdAt: "2024-01-12",
          updatedAt: "2024-02-25",
        },
        {
          id: 6,
          code: "FIN001",
          name: "Anti-Wrinkle Agent",
          nameAr: "مضاد التجعد",
          category: "finishing",
          unit: "liter",
          purchasePrice: 35.75,
          currentStock: 42.3,
          minimumStock: 15,
          supplier: "Finishing Solutions Co.",
          lastPurchaseDate: "2024-03-07",
          status: "active",
          createdAt: "2024-01-25",
          updatedAt: "2024-03-07",
        },
      ]
      dataManager.setDyeingMaterials(sampleMaterials)
      setMaterials(sampleMaterials)
    } else {
      setMaterials(loadedMaterials)
    }
  }, [])

  // Filter materials
  const filteredMaterials = materials.filter((material) => {
    const matchesTab =
      activeTab === "all" ||
      (activeTab === "active" && material.status === "active") ||
      (activeTab === "low_stock" && material.status === "low_stock") ||
      (activeTab === "inactive" && material.status === "inactive")

    const matchesSearch =
      material.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      material.nameAr.includes(searchTerm) ||
      material.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      material.supplier.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesCategory = categoryFilter === "all_categories" || material.category === categoryFilter

    return matchesTab && matchesSearch && matchesCategory
  })

  const handleOpenDialog = (material?: DyeingMaterial) => {
    if (material) {
      setIsEditMode(true)
      setSelectedMaterial(material)
      setFormData({
        code: material.code,
        name: material.name,
        nameAr: material.nameAr,
        category: material.category,
        unit: material.unit,
        purchasePrice: material.purchasePrice.toString(),
        currentStock: material.currentStock.toString(),
        minimumStock: material.minimumStock.toString(),
        supplier: material.supplier,
      })
    } else {
      setIsEditMode(false)
      setSelectedMaterial(null)
      setFormData({
        code: "",
        name: "",
        nameAr: "",
        category: "dye",
        unit: "kg",
        purchasePrice: "",
        currentStock: "",
        minimumStock: "",
        supplier: "",
      })
    }
    setShowDialog(true)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (isEditMode && selectedMaterial) {
      const updatedMaterial = {
        ...selectedMaterial,
        code: formData.code,
        name: formData.name,
        nameAr: formData.nameAr,
        category: formData.category,
        unit: formData.unit,
        purchasePrice: Number.parseFloat(formData.purchasePrice),
        currentStock: Number.parseFloat(formData.currentStock),
        minimumStock: Number.parseFloat(formData.minimumStock),
        supplier: formData.supplier,
        status:
          Number.parseFloat(formData.currentStock) <= Number.parseFloat(formData.minimumStock)
            ? ("low_stock" as const)
            : ("active" as const),
        updatedAt: new Date().toISOString().split("T")[0],
      }

      const updatedMaterials = materials.map((m) => (m.id === selectedMaterial.id ? updatedMaterial : m))
      setMaterials(updatedMaterials)
      dataManager.setDyeingMaterials(updatedMaterials)
    } else {
      const newMaterial: DyeingMaterial = {
        id: Date.now(),
        code: formData.code,
        name: formData.name,
        nameAr: formData.nameAr,
        category: formData.category,
        unit: formData.unit,
        purchasePrice: Number.parseFloat(formData.purchasePrice),
        currentStock: Number.parseFloat(formData.currentStock),
        minimumStock: Number.parseFloat(formData.minimumStock),
        supplier: formData.supplier,
        lastPurchaseDate: new Date().toISOString().split("T")[0],
        status:
          Number.parseFloat(formData.currentStock) <= Number.parseFloat(formData.minimumStock) ? "low_stock" : "active",
        createdAt: new Date().toISOString().split("T")[0],
        updatedAt: new Date().toISOString().split("T")[0],
      }

      const updatedMaterials = [...materials, newMaterial]
      setMaterials(updatedMaterials)
      dataManager.setDyeingMaterials(updatedMaterials)
    }

    setShowDialog(false)
  }

  const handleDeleteMaterial = () => {
    if (selectedMaterial) {
      const updatedMaterials = materials.filter((m) => m.id !== selectedMaterial.id)
      setMaterials(updatedMaterials)
      dataManager.setDyeingMaterials(updatedMaterials)
      setShowDeleteDialog(false)
      setSelectedMaterial(null)
    }
  }

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case "dye":
        return { en: "Dyes", ar: "أصباغ" }
      case "chemical":
        return { en: "Chemicals", ar: "كيماويات" }
      case "auxiliary":
        return { en: "Auxiliaries", ar: "مواد مساعدة" }
      case "finishing":
        return { en: "Finishing", ar: "تشطيب" }
      default:
        return { en: category, ar: category }
    }
  }

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "dye":
        return "bg-blue-100 text-blue-800"
      case "chemical":
        return "bg-red-100 text-red-800"
      case "auxiliary":
        return "bg-green-100 text-green-800"
      case "finishing":
        return "bg-purple-100 text-purple-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800"
      case "low_stock":
        return "bg-red-100 text-red-800"
      case "inactive":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "active":
        return { en: "Active", ar: "نشط" }
      case "low_stock":
        return { en: "Low Stock", ar: "مخزون منخفض" }
      case "inactive":
        return { en: "Inactive", ar: "غير نشط" }
      default:
        return { en: status, ar: status }
    }
  }

  // Calculate statistics
  const totalMaterials = materials.length
  const lowStockCount = materials.filter((m) => m.status === "low_stock").length
  const totalValue = materials.reduce((sum, m) => sum + m.currentStock * m.purchasePrice, 0)
  const activeCount = materials.filter((m) => m.status === "active").length

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Dyeing & Finishing Materials Inventory</h1>
        <p className="text-lg text-gray-600 mb-1">إدارة مخزون مواد الصباغة والتشطيب</p>
        <p className="text-gray-600">{filteredMaterials.length} materials found</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Total Materials</p>
                <p className="text-sm text-gray-500 mb-2">إجمالي المواد</p>
                <p className="text-2xl font-bold text-gray-900">{totalMaterials}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Package className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Active Materials</p>
                <p className="text-sm text-gray-500 mb-2">المواد النشطة</p>
                <p className="text-2xl font-bold text-green-600">{activeCount}</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Low Stock Items</p>
                <p className="text-sm text-gray-500 mb-2">مواد منخفضة المخزون</p>
                <p className="text-2xl font-bold text-red-600">{lowStockCount}</p>
              </div>
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                <AlertTriangle className="w-6 h-6 text-red-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Total Value</p>
                <p className="text-sm text-gray-500 mb-2">القيمة الإجمالية</p>
                <p className="text-2xl font-bold text-purple-600">${totalValue.toFixed(2)}</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="border-0 shadow-sm mb-6">
        <CardContent className="p-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
            <TabsList className="bg-gray-100">
              <TabsTrigger value="all" className="data-[state=active]:bg-white">
                All Materials / جميع المواد
              </TabsTrigger>
              <TabsTrigger value="active" className="data-[state=active]:bg-white">
                Active / نشط
              </TabsTrigger>
              <TabsTrigger value="low_stock" className="data-[state=active]:bg-white">
                Low Stock / مخزون منخفض
              </TabsTrigger>
              <TabsTrigger value="inactive" className="data-[state=active]:bg-white">
                Inactive / غير نشط
              </TabsTrigger>
            </TabsList>
          </Tabs>

          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center space-x-4 w-full md:w-auto">
              <div className="relative flex-1 md:w-64">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search materials... / البحث في المواد"
                  className="pl-10"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>

              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Category / الفئة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all_categories">All Categories / جميع الفئات</SelectItem>
                  <SelectItem value="dye">Dyes / أصباغ</SelectItem>
                  <SelectItem value="chemical">Chemicals / كيماويات</SelectItem>
                  <SelectItem value="auxiliary">Auxiliaries / مواد مساعدة</SelectItem>
                  <SelectItem value="finishing">Finishing / تشطيب</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm">
                <Filter className="w-4 h-4 mr-2" />
                Filter / تصفية
              </Button>
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                Export / تصدير
              </Button>
              <Button onClick={() => handleOpenDialog()} className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                Add Material / إضافة مادة
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Materials Table */}
      <Card className="border-0 shadow-sm">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="text-left px-6 py-4 text-sm font-medium text-gray-600">Code / الكود</th>
                  <th className="text-left px-6 py-4 text-sm font-medium text-gray-600">Material / المادة</th>
                  <th className="text-left px-6 py-4 text-sm font-medium text-gray-600">Category / الفئة</th>
                  <th className="text-left px-6 py-4 text-sm font-medium text-gray-600">Stock / المخزون</th>
                  <th className="text-left px-6 py-4 text-sm font-medium text-gray-600">Price / السعر</th>
                  <th className="text-left px-6 py-4 text-sm font-medium text-gray-600">Status / الحالة</th>
                  <th className="text-left px-6 py-4 text-sm font-medium text-gray-600">Actions / الإجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredMaterials.map((material) => (
                  <tr key={material.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <span className="text-sm font-medium text-gray-900">{material.code}</span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
                          <Palette className="w-4 h-4 text-gray-600" />
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-900">{material.name}</p>
                          <p className="text-xs text-gray-500">{material.nameAr}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <Badge className={getCategoryColor(material.category)}>
                        {getCategoryLabel(material.category).en}
                      </Badge>
                    </td>
                    <td className="px-6 py-4">
                      <div>
                        <span
                          className={`text-sm font-medium ${
                            material.currentStock <= material.minimumStock ? "text-red-600" : "text-gray-900"
                          }`}
                        >
                          {material.currentStock} {material.unit}
                        </span>
                        <p className="text-xs text-gray-500">
                          Min: {material.minimumStock} {material.unit}
                        </p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm font-medium text-gray-900">${material.purchasePrice.toFixed(2)}</span>
                      <p className="text-xs text-gray-500">per {material.unit}</p>
                    </td>
                    <td className="px-6 py-4">
                      <Badge className={getStatusColor(material.status)}>{getStatusLabel(material.status).en}</Badge>
                    </td>
                    <td className="px-6 py-4">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleOpenDialog(material)}>
                            <Edit className="w-4 h-4 mr-2" />
                            Edit / تعديل
                          </DropdownMenuItem>
                          {canDelete() && (
                            <DropdownMenuItem
                              onClick={() => {
                                setSelectedMaterial(material)
                                setShowDeleteDialog(true)
                              }}
                              className="text-red-600"
                            >
                              <Trash2 className="w-4 h-4 mr-2" />
                              Delete / حذف
                            </DropdownMenuItem>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Add/Edit Material Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {isEditMode ? "Edit Material / تعديل المادة" : "Add New Material / إضافة مادة جديدة"}
            </DialogTitle>
            <DialogDescription>
              {isEditMode
                ? "Update material information / تحديث معلومات المادة"
                : "Enter material details / أدخل تفاصيل المادة"}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="grid gap-6 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="code">Material Code / كود المادة</Label>
                  <Input
                    id="code"
                    value={formData.code}
                    onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                    placeholder="e.g., DYE001"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="supplier">Supplier / المورد</Label>
                  <Input
                    id="supplier"
                    value={formData.supplier}
                    onChange={(e) => setFormData({ ...formData, supplier: e.target.value })}
                    placeholder="Supplier name"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Name (English) / الاسم بالإنجليزية</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Material name in English"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="nameAr">Name (Arabic) / الاسم بالعربية</Label>
                  <Input
                    id="nameAr"
                    value={formData.nameAr}
                    onChange={(e) => setFormData({ ...formData, nameAr: e.target.value })}
                    placeholder="اسم المادة بالعربية"
                    dir="rtl"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="category">Category / الفئة</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value: "dye" | "chemical" | "auxiliary" | "finishing") =>
                      setFormData({ ...formData, category: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="dye">Dyes / أصباغ</SelectItem>
                      <SelectItem value="chemical">Chemicals / كيماويات</SelectItem>
                      <SelectItem value="auxiliary">Auxiliaries / مواد مساعدة</SelectItem>
                      <SelectItem value="finishing">Finishing / تشطيب</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="unit">Unit / الوحدة</Label>
                  <Select
                    value={formData.unit}
                    onValueChange={(value: "kg" | "gram" | "liter") => setFormData({ ...formData, unit: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="kg">Kilogram (kg) / كيلوجرام</SelectItem>
                      <SelectItem value="gram">Gram (g) / جرام</SelectItem>
                      <SelectItem value="liter">Liter (L) / لتر</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="purchasePrice">Purchase Price / سعر الشراء</Label>
                  <Input
                    id="purchasePrice"
                    type="number"
                    step="0.01"
                    value={formData.purchasePrice}
                    onChange={(e) => setFormData({ ...formData, purchasePrice: e.target.value })}
                    placeholder="0.00"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="currentStock">Current Stock / المخزون الحالي</Label>
                  <Input
                    id="currentStock"
                    type="number"
                    step="0.01"
                    value={formData.currentStock}
                    onChange={(e) => setFormData({ ...formData, currentStock: e.target.value })}
                    placeholder="0.00"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="minimumStock">Minimum Stock / الحد الأدنى</Label>
                  <Input
                    id="minimumStock"
                    type="number"
                    step="0.01"
                    value={formData.minimumStock}
                    onChange={(e) => setFormData({ ...formData, minimumStock: e.target.value })}
                    placeholder="0.00"
                    required
                  />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setShowDialog(false)}>
                Cancel / إلغاء
              </Button>
              <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                {isEditMode ? "Update Material / تحديث المادة" : "Add Material / إضافة المادة"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center text-red-600">
              <AlertTriangle className="w-5 h-5 mr-2" />
              Confirm Delete / تأكيد الحذف
            </DialogTitle>
            <DialogDescription>
              Are you sure you want to delete "{selectedMaterial?.name}"?
              <br />
              هل أنت متأكد من حذف "{selectedMaterial?.nameAr}"؟
              <br />
              <span className="text-red-600 font-medium">
                This action cannot be undone! / لا يمكن التراجع عن هذا الإجراء!
              </span>
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>
              Cancel / إلغاء
            </Button>
            <Button variant="destructive" onClick={handleDeleteMaterial}>
              <Trash2 className="w-4 h-4 mr-2" />
              Delete / حذف
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
