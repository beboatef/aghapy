"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { PageLayout } from "@/components/page-layout"
import { Upload, FileSpreadsheet, AlertCircle, CheckCircle2, FileDown } from "lucide-react"
import { Progress } from "@/components/ui/progress"

interface ImportResult {
  success: boolean
  totalRecords: number
  successCount: number
  errorCount: number
  errors: string[]
  importedCustomers?: string[]
  importedMaterials?: string[]
}

export default function ImportOpeningBalancesPage() {
  const [activeTab, setActiveTab] = useState("customers")
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [isUploading, setIsUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [importResult, setImportResult] = useState<ImportResult | null>(null)

  // معالجة اختيار الملف
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      // التحقق من نوع الملف
      if (file.name.endsWith(".xlsx") || file.name.endsWith(".xls") || file.name.endsWith(".csv")) {
        setSelectedFile(file)
        setImportResult(null)
      } else {
        alert("يرجى اختيار ملف Excel (.xlsx, .xls) أو CSV (.csv)")
        e.target.value = ""
        setSelectedFile(null)
      }
    }
  }

  // محاكاة عملية الاستيراد
  const handleImport = async () => {
    if (!selectedFile) return

    setIsUploading(true)
    setUploadProgress(0)

    // محاكاة تقدم الرفع
    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          return 100
        }
        return prev + 10
      })
    }, 300)

    // محاكاة استجابة الخادم بعد الانتهاء
    setTimeout(() => {
      clearInterval(interval)
      setUploadProgress(100)

      // محاكاة نتائج الاستيراد
      if (activeTab === "customers") {
        setImportResult({
          success: true,
          totalRecords: 15,
          successCount: 13,
          errorCount: 2,
          errors: ["العميل 'شركة الأمل' موجود بالفعل", "بيانات غير صالحة في السطر 8"],
          importedCustomers: [
            "شركة النسيج المتحدة",
            "مصنع الألوان الحديث",
            "شركة القطن السعودي",
            "مصنع الأقمشة الفاخرة",
            "شركة الحرير العربي",
          ],
        })
      } else {
        setImportResult({
          success: true,
          totalRecords: 20,
          successCount: 18,
          errorCount: 2,
          errors: ["الصنف 'قطن مصري' موجود بالفعل", "وحدة قياس غير صالحة في السطر 12"],
          importedMaterials: ["قطن أبيض خام", "بوليستر أزرق", "قطن ملون", "حرير طبيعي", "كتان مصري", "صوف خالص"],
        })
      }

      setIsUploading(false)
    }, 3000)
  }

  // تنزيل نموذج الاستيراد
  const downloadTemplate = () => {
    // في التطبيق الحقيقي، هذا سيقوم بتنزيل ملف Excel نموذجي
    alert(`تم تنزيل نموذج استيراد ${activeTab === "customers" ? "العملاء" : "الأصناف"} بنجاح`)
  }

  return (
    <PageLayout title="استيراد أرصدة أول المدة">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
        <h1 className="page-title mb-4 sm:mb-0">
          <FileSpreadsheet className="page-icon text-green-600" />
          استيراد أرصدة أول المدة
        </h1>
      </div>

      <Card className="mb-6 border-0 shadow-sm">
        <CardHeader>
          <CardTitle>استيراد أرصدة أول المدة من Excel</CardTitle>
          <CardDescription>
            يمكنك استيراد بيانات العملاء والأصناف مع أرصدتهم الافتتاحية من ملف Excel أو CSV
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="customers">استيراد أرصدة العملاء</TabsTrigger>
              <TabsTrigger value="materials">استيراد أرصدة الأصناف</TabsTrigger>
            </TabsList>

            <TabsContent value="customers" className="space-y-4">
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>تنبيه</AlertTitle>
                <AlertDescription>
                  سيتم استيراد بيانات العملاء مع أرصدتهم لكل صنف. يجب أن يحتوي الملف على الأعمدة التالية: كود العميل،
                  اسم العميل، كود الصنف، اسم الصنف، الوحدة، رصيد أول المدة.
                </AlertDescription>
              </Alert>

              <div className="flex items-center gap-4 mt-4">
                <Button variant="outline" onClick={downloadTemplate}>
                  <FileDown className="ml-2 h-4 w-4" />
                  تنزيل نموذج الاستيراد
                </Button>
              </div>

              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="customerFile" className="text-right">
                    ملف الاستيراد
                  </Label>
                  <div className="col-span-3">
                    <Input
                      id="customerFile"
                      type="file"
                      accept=".xlsx,.xls,.csv"
                      onChange={handleFileChange}
                      disabled={isUploading}
                    />
                  </div>
                </div>

                {selectedFile && (
                  <div className="grid grid-cols-4 items-center gap-4">
                    <div className="text-right">الملف المختار</div>
                    <div className="col-span-3 flex items-center">
                      <FileSpreadsheet className="h-4 w-4 ml-2 text-green-600" />
                      {selectedFile.name}
                    </div>
                  </div>
                )}

                {isUploading && (
                  <div className="grid grid-cols-4 items-center gap-4">
                    <div className="text-right">تقدم الاستيراد</div>
                    <div className="col-span-3">
                      <Progress value={uploadProgress} className="h-2" />
                      <div className="text-xs text-gray-500 mt-1">{uploadProgress}% مكتمل</div>
                    </div>
                  </div>
                )}

                <div className="flex justify-end">
                  <Button onClick={handleImport} disabled={!selectedFile || isUploading}>
                    <Upload className="ml-2 h-4 w-4" />
                    {isUploading ? "جاري الاستيراد..." : "استيراد البيانات"}
                  </Button>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="materials" className="space-y-4">
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>تنبيه</AlertTitle>
                <AlertDescription>
                  سيتم استيراد بيانات الأصناف مع أرصدتها الافتتاحية. يجب أن يحتوي الملف على الأعمدة التالية: كود الصنف،
                  اسم الصنف، الوحدة، رصيد أول المدة.
                </AlertDescription>
              </Alert>

              <div className="flex items-center gap-4 mt-4">
                <Button variant="outline" onClick={downloadTemplate}>
                  <FileDown className="ml-2 h-4 w-4" />
                  تنزيل نموذج الاستيراد
                </Button>
              </div>

              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="materialFile" className="text-right">
                    ملف الاستيراد
                  </Label>
                  <div className="col-span-3">
                    <Input
                      id="materialFile"
                      type="file"
                      accept=".xlsx,.xls,.csv"
                      onChange={handleFileChange}
                      disabled={isUploading}
                    />
                  </div>
                </div>

                {selectedFile && (
                  <div className="grid grid-cols-4 items-center gap-4">
                    <div className="text-right">الملف المختار</div>
                    <div className="col-span-3 flex items-center">
                      <FileSpreadsheet className="h-4 w-4 ml-2 text-green-600" />
                      {selectedFile.name}
                    </div>
                  </div>
                )}

                {isUploading && (
                  <div className="grid grid-cols-4 items-center gap-4">
                    <div className="text-right">تقدم الاستيراد</div>
                    <div className="col-span-3">
                      <Progress value={uploadProgress} className="h-2" />
                      <div className="text-xs text-gray-500 mt-1">{uploadProgress}% مكتمل</div>
                    </div>
                  </div>
                )}

                <div className="flex justify-end">
                  <Button onClick={handleImport} disabled={!selectedFile || isUploading}>
                    <Upload className="ml-2 h-4 w-4" />
                    {isUploading ? "جاري الاستيراد..." : "استيراد البيانات"}
                  </Button>
                </div>
              </div>
            </TabsContent>
          </Tabs>

          {importResult && (
            <div className="mt-6">
              <Alert variant={importResult.success ? "default" : "destructive"}>
                {importResult.success ? (
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                ) : (
                  <AlertCircle className="h-4 w-4" />
                )}
                <AlertTitle>
                  {importResult.success
                    ? `تم استيراد البيانات بنجاح (${importResult.successCount}/${importResult.totalRecords})`
                    : "فشل استيراد البيانات"}
                </AlertTitle>
                <AlertDescription>
                  <div className="mt-2">
                    <div>إجمالي السجلات: {importResult.totalRecords}</div>
                    <div className="text-green-600">تم استيراد: {importResult.successCount}</div>
                    {importResult.errorCount > 0 && (
                      <div className="text-red-600">فشل استيراد: {importResult.errorCount}</div>
                    )}
                  </div>

                  {importResult.errorCount > 0 && (
                    <div className="mt-2">
                      <div className="font-bold">الأخطاء:</div>
                      <ul className="list-disc list-inside">
                        {importResult.errors.map((error, index) => (
                          <li key={index} className="text-red-600">
                            {error}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {importResult.importedCustomers && (
                    <div className="mt-2">
                      <div className="font-bold">العملاء الذين تم استيرادهم:</div>
                      <ul className="list-disc list-inside">
                        {importResult.importedCustomers.map((customer, index) => (
                          <li key={index}>{customer}</li>
                        ))}
                        {importResult.importedCustomers.length > 5 && <li>... والمزيد</li>}
                      </ul>
                    </div>
                  )}

                  {importResult.importedMaterials && (
                    <div className="mt-2">
                      <div className="font-bold">الأصناف التي تم استيرادها:</div>
                      <ul className="list-disc list-inside">
                        {importResult.importedMaterials.map((material, index) => (
                          <li key={index}>{material}</li>
                        ))}
                        {importResult.importedMaterials.length > 5 && <li>... والمزيد</li>}
                      </ul>
                    </div>
                  )}
                </AlertDescription>
              </Alert>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle>تعليمات الاستيراد</CardTitle>
          <CardDescription>إرشادات لإعداد ملف الاستيراد بشكل صحيح</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-medium">استيراد أرصدة العملاء</h3>
              <ul className="list-disc list-inside mt-2 space-y-1">
                <li>يجب أن يكون الملف بتنسيق Excel (.xlsx, .xls) أو CSV (.csv)</li>
                <li>يجب أن يحتوي الملف على الأعمدة التالية:</li>
                <ul className="list-circle list-inside mr-6 space-y-1">
                  <li>
                    <strong>كود العميل</strong> - الكود الفريد للعميل (إذا كان العميل موجوداً بالفعل سيتم تحديثه)
                  </li>
                  <li>
                    <strong>اسم العميل</strong> - اسم العميل
                  </li>
                  <li>
                    <strong>كود الصنف</strong> - الكود الفريد للصنف
                  </li>
                  <li>
                    <strong>اسم الصنف</strong> - اسم الصنف
                  </li>
                  <li>
                    <strong>الوحدة</strong> - وحدة قياس الصنف (كجم، متر، قطعة)
                  </li>
                  <li>
                    <strong>رصيد أول المدة</strong> - الرصيد الافتتاحي للصنف لهذا العميل
                  </li>
                </ul>
                <li>يمكن للعميل الواحد أن يكون له عدة أصناف مختلفة</li>
                <li>سيتم التحقق من وجود العملاء والأصناف قبل الاستيراد</li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-medium">استيراد أرصدة الأصناف</h3>
              <ul className="list-disc list-inside mt-2 space-y-1">
                <li>يجب أن يكون الملف بتنسيق Excel (.xlsx, .xls) أو CSV (.csv)</li>
                <li>يجب أن يحتوي الملف على الأعمدة التالية:</li>
                <ul className="list-circle list-inside mr-6 space-y-1">
                  <li>
                    <strong>كود الصنف</strong> - الكود الفريد للصنف (إذا كان الصنف موجوداً بالفعل سيتم تحديثه)
                  </li>
                  <li>
                    <strong>اسم الصنف</strong> - اسم الصنف
                  </li>
                  <li>
                    <strong>الوحدة</strong> - وحدة قياس الصنف (كجم، متر، قطعة)
                  </li>
                  <li>
                    <strong>رصيد أول المدة</strong> - الرصيد الافتتاحي للصنف
                  </li>
                </ul>
                <li>سيتم التحقق من وجود الأصناف قبل الاستيراد</li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-medium">ملاحظات هامة</h3>
              <ul className="list-disc list-inside mt-2 space-y-1">
                <li>
                  <strong className="text-amber-600">تحذير:</strong> سيؤدي استيراد أرصدة أول المدة إلى استبدال أي أرصدة
                  افتتاحية موجودة مسبقاً
                </li>
                <li>تأكد من صحة البيانات قبل الاستيراد لتجنب أي أخطاء في الحسابات</li>
                <li>يمكنك تنزيل نموذج الاستيراد للتأكد من تنسيق البيانات بشكل صحيح</li>
                <li>في حالة وجود أخطاء في الاستيراد، سيتم عرض تفاصيل الأخطاء ليتم تصحيحها وإعادة المحاولة</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </PageLayout>
  )
}
