"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { PageLayout } from "@/components/page-layout"
import { Download, Search, History, Calendar, Filter, FileText, User } from "lucide-react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"

interface ActivityLog {
  id: number
  userId: number
  username: string
  action: string
  tableName: string
  recordId: number | string
  details: string
  oldValues?: Record<string, any>
  newValues?: Record<string, any>
  createdAt: string
  ip?: string
}

export default function ActivityLogPage() {
  // بيانات محاكاة
  const [activities, setActivities] = useState<ActivityLog[]>([
    {
      id: 1,
      userId: 1,
      username: "admin",
      action: "إضافة",
      tableName: "العملاء",
      recordId: "C001",
      details: "إضافة عميل جديد: شركة النسيج المتحدة",
      oldValues: null,
      newValues: { code: "C001", name: "شركة النسيج المتحدة", phone: "0501234567" },
      createdAt: "2024-03-15 09:15:22",
      ip: "192.168.1.100",
    },
    {
      id: 2,
      userId: 1,
      username: "admin",
      action: "تعديل",
      tableName: "الأصناف",
      recordId: "M001",
      details: "تعديل صنف: قطن أبيض خام",
      oldValues: { name: "قطن أبيض", unit: "كجم" },
      newValues: { name: "قطن أبيض خام", unit: "كجم" },
      createdAt: "2024-03-15 10:30:45",
      ip: "192.168.1.100",
    },
    {
      id: 3,
      userId: 2,
      username: "user1",
      action: "إضافة",
      tableName: "حركات المخزون",
      recordId: "IN001",
      details: "إضافة وارد جديد",
      oldValues: null,
      newValues: {
        permitNumber: "IN001",
        customerId: 1,
        materialId: 1,
        quantity: 150,
        rollsCount: 3,
      },
      createdAt: "2024-03-15 11:45:30",
      ip: "192.168.1.101",
    },
    {
      id: 4,
      userId: 1,
      username: "admin",
      action: "حذف",
      tableName: "أوامر التشغيل",
      recordId: "PO005",
      details: "حذف أمر تشغيل",
      oldValues: {
        orderNumber: "PO005",
        customerId: 2,
        materialId: 2,
        quantity: 75,
      },
      newValues: null,
      createdAt: "2024-03-16 09:20:15",
      ip: "192.168.1.100",
    },
    {
      id: 5,
      userId: 3,
      username: "user2",
      action: "إكمال",
      tableName: "أوامر التشغيل",
      recordId: "PO003",
      details: "إكمال أمر تشغيل",
      oldValues: { status: "in_production" },
      newValues: { status: "completed", completedAt: "2024-03-16" },
      createdAt: "2024-03-16 14:10:50",
      ip: "192.168.1.102",
    },
    {
      id: 6,
      userId: 2,
      username: "user1",
      action: "تسجيل دخول",
      tableName: "المستخدمين",
      recordId: "2",
      details: "تسجيل دخول المستخدم",
      oldValues: null,
      newValues: null,
      createdAt: "2024-03-17 08:00:25",
      ip: "192.168.1.101",
    },
  ])

  // متغيرات الحالة
  const [searchTerm, setSearchTerm] = useState("")
  const [userFilter, setUserFilter] = useState("all_users")
  const [actionFilter, setActionFilter] = useState("all_actions")
  const [tableFilter, setTableFilter] = useState("all_tables")
  const [dateFrom, setDateFrom] = useState("")
  const [dateTo, setDateTo] = useState("")
  const [showFiltersDialog, setShowFiltersDialog] = useState(false)
  const [showDetailsDialog, setShowDetailsDialog] = useState(false)
  const [selectedActivity, setSelectedActivity] = useState<ActivityLog | null>(null)

  // قائمة المستخدمين
  const users = [
    { id: 1, username: "admin" },
    { id: 2, username: "user1" },
    { id: 3, username: "user2" },
  ]

  // قائمة الإجراءات
  const actions = [
    { value: "إضافة", label: "إضافة" },
    { value: "تعديل", label: "تعديل" },
    { value: "حذف", label: "حذف" },
    { value: "إكمال", label: "إكمال" },
    { value: "تسجيل دخول", label: "تسجيل دخول" },
  ]

  // قائمة الجداول
  const tables = [
    { value: "العملاء", label: "العملاء" },
    { value: "الأصناف", label: "الأصناف" },
    { value: "حركات المخزون", label: "حركات المخزون" },
    { value: "أوامر التشغيل", label: "أوامر التشغيل" },
    { value: "المستخدمين", label: "المستخدمين" },
  ]

  // فلترة الأنشطة
  const filteredActivities = activities.filter((activity) => {
    const matchesSearch =
      activity.username.includes(searchTerm) ||
      activity.action.includes(searchTerm) ||
      activity.tableName.includes(searchTerm) ||
      activity.details.includes(searchTerm) ||
      activity.recordId.toString().includes(searchTerm)

    const matchesUser = userFilter === "all_users" || activity.userId.toString() === userFilter
    const matchesAction = actionFilter === "all_actions" || activity.action === actionFilter
    const matchesTable = tableFilter === "all_tables" || activity.tableName === tableFilter

    // فلترة حسب التاريخ
    const activityDate = new Date(activity.createdAt.split(" ")[0])
    const matchesDateFrom = dateFrom === "" || new Date(dateFrom) <= activityDate
    const matchesDateTo = dateTo === "" || new Date(dateTo) >= activityDate

    return matchesSearch && matchesUser && matchesAction && matchesTable && matchesDateFrom && matchesDateTo
  })

  // عرض تفاصيل النشاط
  const handleShowDetails = (activity: ActivityLog) => {
    setSelectedActivity(activity)
    setShowDetailsDialog(true)
  }

  // تصدير سجل النشاطات
  const exportActivities = (format: string) => {
    alert(`تم تصدير سجل النشاطات بتنسيق ${format}`)
  }

  // طباعة سجل النشاطات
  const printActivities = () => {
    window.print()
  }

  // تنسيق قيمة لعرضها بشكل أفضل
  const formatValue = (value: any): string => {
    if (value === null || value === undefined) return "—"
    if (typeof value === "object") return JSON.stringify(value, null, 2)
    return value.toString()
  }

  // تحديد لون الإجراء
  const getActionColor = (action: string): string => {
    switch (action) {
      case "إضافة":
        return "bg-green-100 text-green-800"
      case "تعديل":
        return "bg-blue-100 text-blue-800"
      case "حذف":
        return "bg-red-100 text-red-800"
      case "إكمال":
        return "bg-purple-100 text-purple-800"
      case "تسجيل دخول":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <PageLayout title="سجل النشاطات">
      {/* رأس الصفحة */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
        <h1 className="page-title mb-4 sm:mb-0">
          <History className="page-icon text-purple-600" />
          سجل النشاطات
        </h1>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm" onClick={() => setShowFiltersDialog(true)}>
            <Filter className="h-4 w-4 ml-2" />
            فلاتر متقدمة
          </Button>
          <Button variant="outline" size="sm" onClick={() => exportActivities("Excel")}>
            <Download className="h-4 w-4 ml-2" />
            تصدير Excel
          </Button>
          <Button variant="outline" size="sm" onClick={() => exportActivities("PDF")}>
            <FileText className="h-4 w-4 ml-2" />
            تصدير PDF
          </Button>
          <Button variant="outline" size="sm" onClick={printActivities}>
            <FileText className="h-4 w-4 ml-2" />
            طباعة
          </Button>
        </div>
      </div>

      {/* فلاتر سريعة */}
      <Card className="mb-6 border-0 shadow-sm">
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="البحث..."
                className="pr-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <Select value={userFilter} onValueChange={setUserFilter}>
              <SelectTrigger>
                <SelectValue placeholder="المستخدم" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all_users">جميع المستخدمين</SelectItem>
                {users.map((user) => (
                  <SelectItem key={user.id} value={user.id.toString()}>
                    {user.username}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={actionFilter} onValueChange={setActionFilter}>
              <SelectTrigger>
                <SelectValue placeholder="الإجراء" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all_actions">جميع الإجراءات</SelectItem>
                {actions.map((action) => (
                  <SelectItem key={action.value} value={action.value}>
                    {action.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={tableFilter} onValueChange={setTableFilter}>
              <SelectTrigger>
                <SelectValue placeholder="الجدول" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all_tables">جميع الجداول</SelectItem>
                {tables.map((table) => (
                  <SelectItem key={table.value} value={table.value}>
                    {table.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* جدول النشاطات */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-2">
          <CardTitle>سجل النشاطات ({filteredActivities.length})</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b bg-gray-50">
                  <th className="text-right p-3">التاريخ والوقت</th>
                  <th className="text-right p-3">المستخدم</th>
                  <th className="text-right p-3">الإجراء</th>
                  <th className="text-right p-3">القسم</th>
                  <th className="text-right p-3">رقم السجل</th>
                  <th className="text-right p-3">التفاصيل</th>
                  <th className="text-right p-3">عرض</th>
                </tr>
              </thead>
              <tbody>
                {filteredActivities.length > 0 ? (
                  filteredActivities.map((activity) => (
                    <tr key={activity.id} className="border-b hover:bg-gray-50">
                      <td className="p-3 whitespace-nowrap">
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 ml-1 text-gray-400" />
                          <span>{activity.createdAt}</span>
                        </div>
                      </td>
                      <td className="p-3">
                        <div className="flex items-center">
                          <User className="h-4 w-4 ml-1 text-gray-400" />
                          {activity.username}
                        </div>
                      </td>
                      <td className="p-3">
                        <span className={`badge ${getActionColor(activity.action)}`}>{activity.action}</span>
                      </td>
                      <td className="p-3">{activity.tableName}</td>
                      <td className="p-3 font-mono">{activity.recordId}</td>
                      <td className="p-3 max-w-xs truncate">{activity.details}</td>
                      <td className="p-3">
                        <Button size="sm" variant="ghost" onClick={() => handleShowDetails(activity)}>
                          عرض
                        </Button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={7} className="p-4 text-center text-gray-500">
                      لا توجد بيانات للعرض
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* نافذة الفلاتر المتقدمة */}
      <Dialog open={showFiltersDialog} onOpenChange={setShowFiltersDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>فلاتر متقدمة</DialogTitle>
            <DialogDescription>تحديد نطاق زمني وفلاتر إضافية للنشاطات</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="dateFrom" className="text-right">
                من تاريخ
              </Label>
              <Input
                id="dateFrom"
                type="date"
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="dateTo" className="text-right">
                إلى تاريخ
              </Label>
              <Input
                id="dateTo"
                type="date"
                value={dateTo}
                onChange={(e) => setDateTo(e.target.value)}
                className="col-span-3"
              />
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="user" className="text-right">
                المستخدم
              </Label>
              <Select value={userFilter} onValueChange={setUserFilter} className="col-span-3">
                <SelectTrigger>
                  <SelectValue placeholder="المستخدم" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all_users">جميع المستخدمين</SelectItem>
                  {users.map((user) => (
                    <SelectItem key={user.id} value={user.id.toString()}>
                      {user.username}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="action" className="text-right">
                الإجراء
              </Label>
              <Select value={actionFilter} onValueChange={setActionFilter} className="col-span-3">
                <SelectTrigger>
                  <SelectValue placeholder="الإجراء" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all_actions">جميع الإجراءات</SelectItem>
                  {actions.map((action) => (
                    <SelectItem key={action.value} value={action.value}>
                      {action.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="table" className="text-right">
                القسم
              </Label>
              <Select value={tableFilter} onValueChange={setTableFilter} className="col-span-3">
                <SelectTrigger>
                  <SelectValue placeholder="القسم" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all_tables">جميع الأقسام</SelectItem>
                  {tables.map((table) => (
                    <SelectItem key={table.value} value={table.value}>
                      {table.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button
              variant="outline"
              onClick={() => {
                setDateFrom("")
                setDateTo("")
                setUserFilter("all_users")
                setActionFilter("all_actions")
                setTableFilter("all_tables")
                setSearchTerm("")
              }}
            >
              إعادة تعيين
            </Button>
            <Button onClick={() => setShowFiltersDialog(false)}>تطبيق الفلاتر</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* نافذة تفاصيل النشاط */}
      <Dialog open={showDetailsDialog} onOpenChange={setShowDetailsDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>تفاصيل النشاط</DialogTitle>
            <DialogDescription>{selectedActivity?.details}</DialogDescription>
          </DialogHeader>
          {selectedActivity && (
            <div className="grid gap-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="block mb-2">المستخدم</Label>
                  <div className="p-2 bg-gray-50 rounded-md">{selectedActivity.username}</div>
                </div>
                <div>
                  <Label className="block mb-2">الإجراء</Label>
                  <div className="p-2 bg-gray-50 rounded-md">
                    <span className={`badge ${getActionColor(selectedActivity.action)}`}>
                      {selectedActivity.action}
                    </span>
                  </div>
                </div>
                <div>
                  <Label className="block mb-2">القسم</Label>
                  <div className="p-2 bg-gray-50 rounded-md">{selectedActivity.tableName}</div>
                </div>
                <div>
                  <Label className="block mb-2">رقم السجل</Label>
                  <div className="p-2 bg-gray-50 rounded-md font-mono">{selectedActivity.recordId}</div>
                </div>
                <div>
                  <Label className="block mb-2">التاريخ والوقت</Label>
                  <div className="p-2 bg-gray-50 rounded-md">{selectedActivity.createdAt}</div>
                </div>
                <div>
                  <Label className="block mb-2">عنوان IP</Label>
                  <div className="p-2 bg-gray-50 rounded-md font-mono">{selectedActivity.ip || "—"}</div>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 mt-2">
                <Label className="block">التفاصيل</Label>
                <div className="p-2 bg-gray-50 rounded-md">{selectedActivity.details}</div>
              </div>

              {(selectedActivity.oldValues || selectedActivity.newValues) && (
                <div className="grid grid-cols-2 gap-4 mt-2">
                  {selectedActivity.oldValues && (
                    <div>
                      <Label className="block mb-2">القيم القديمة</Label>
                      <pre className="p-2 bg-red-50 rounded-md text-xs overflow-auto max-h-40">
                        {JSON.stringify(selectedActivity.oldValues, null, 2)}
                      </pre>
                    </div>
                  )}
                  {selectedActivity.newValues && (
                    <div>
                      <Label className="block mb-2">القيم الجديدة</Label>
                      <pre className="p-2 bg-green-50 rounded-md text-xs overflow-auto max-h-40">
                        {JSON.stringify(selectedActivity.newValues, null, 2)}
                      </pre>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
          <div className="flex justify-end">
            <Button variant="outline" onClick={() => setShowDetailsDialog(false)}>
              إغلاق
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </PageLayout>
  )
}
