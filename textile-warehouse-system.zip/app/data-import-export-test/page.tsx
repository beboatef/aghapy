"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { PageLayout } from "@/components/page-layout"
import { Database, Download, Upload, CheckCircle, AlertCircle, RefreshCw } from "lucide-react"
import { dataManager } from "@/lib/data-manager"
import { runFullTest, testExportData, testImportData } from "@/scripts/data-export-import-test"
import { toast } from "@/components/ui/use-toast"

export default function DataImportExportTestPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [testResults, setTestResults] = useState<any>(null)
  const [testLog, setTestLog] = useState<string[]>([])

  // إضافة سجل إلى السجلات
  const addLog = (message: string) => {
    setTestLog((prev) => [...prev, `${new Date().toLocaleTimeString()}: ${message}`])
  }

  // اختبار تصدير البيانات
  const handleTestExport = async () => {
    setIsLoading(true)
    addLog("بدء اختبار تصدير البيانات...")

    try {
      const result = await testExportData()
      setTestResults({ export: result })
      addLog(`نتيجة اختبار التصدير: ${result.success ? "نجاح" : "فشل"} - ${result.message}`)

      toast({
        title: result.success ? "تم التصدير بنجاح" : "فشل التصدير",
        description: result.message,
        variant: result.success ? "default" : "destructive",
      })
    } catch (error) {
      addLog(`خطأ في اختبار التصدير: ${error.message}`)
      toast({
        title: "خطأ في الاختبار",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // اختبار استيراد البيانات
  const handleTestImport = async () => {
    setIsLoading(true)
    addLog("بدء اختبار استيراد البيانات...")

    try {
      const result = await testImportData()
      setTestResults({ import: result })
      addLog(`نتيجة اختبار الاستيراد: ${result.success ? "نجاح" : "فشل"} - ${result.message}`)

      toast({
        title: result.success ? "تم الاستيراد بنجاح" : "فشل الاستيراد",
        description: result.message,
        variant: result.success ? "default" : "destructive",
      })
    } catch (error) {
      addLog(`خطأ في اختبار الاستيراد: ${error.message}`)
      toast({
        title: "خطأ في الاختبار",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // اختبار كامل
  const handleFullTest = async () => {
    setIsLoading(true)
    addLog("بدء الاختبار الكامل لعمليات الاستيراد والتصدير...")

    try {
      const result = await runFullTest()
      setTestResults(result)
      addLog(`نتيجة الاختبار الكامل: ${result.success ? "نجاح" : "فشل"}`)

      toast({
        title: result.success ? "تم الاختبار بنجاح" : "فشل الاختبار",
        description: result.success
          ? "تم اختبار عمليات الاستيراد والتصدير بنجاح"
          : "فشل في اختبار عمليات الاستيراد والتصدير",
        variant: result.success ? "default" : "destructive",
      })
    } catch (error) {
      addLog(`خطأ في الاختبار الكامل: ${error.message}`)
      toast({
        title: "خطأ في الاختبار",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // تصدير البيانات الفعلية
  const handleRealExport = () => {
    addLog("بدء تصدير البيانات الفعلية...")

    try {
      const result = dataManager.exportAllData()
      addLog(`نتيجة التصدير الفعلي: ${result.success ? "نجاح" : "فشل"} - ${result.message}`)

      toast({
        title: result.success ? "تم التصدير بنجاح" : "فشل التصدير",
        description: result.message,
        variant: result.success ? "default" : "destructive",
      })
    } catch (error) {
      addLog(`خطأ في التصدير الفعلي: ${error.message}`)
      toast({
        title: "خطأ في التصدير",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  // استيراد البيانات الفعلية
  const handleRealImport = () => {
    addLog("بدء استيراد البيانات الفعلية...")

    const input = document.createElement("input")
    input.type = "file"
    input.accept = ".json"

    input.onchange = async (event) => {
      const file = (event.target as HTMLInputElement).files?.[0]
      if (!file) {
        addLog("لم يتم اختيار ملف")
        return
      }

      if (confirm("هل أنت متأكد من استيراد البيانات؟ سيتم استبدال جميع البيانات الحالية.")) {
        setIsLoading(true)
        try {
          const result = await dataManager.importData(file)
          addLog(`نتيجة الاستيراد الفعلي: ${result.success ? "نجاح" : "فشل"} - ${result.message}`)

          toast({
            title: result.success ? "تم الاستيراد بنجاح" : "فشل الاستيراد",
            description: result.message,
            variant: result.success ? "default" : "destructive",
          })

          if (result.success) {
            addLog("جاري إعادة تحميل الصفحة...")
            setTimeout(() => {
              window.location.reload()
            }, 2000)
          }
        } catch (error) {
          addLog(`خطأ في الاستيراد الفعلي: ${error.message}`)
          toast({
            title: "خطأ في الاستيراد",
            description: error.message,
            variant: "destructive",
          })
        } finally {
          setIsLoading(false)
        }
      }
    }

    input.click()
  }

  // مسح السجلات
  const clearLogs = () => {
    setTestLog([])
    setTestResults(null)
  }

  return (
    <PageLayout title="اختبار استيراد وتصدير البيانات">
      {/* رأس الصفحة */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
        <h1 className="page-title mb-4 sm:mb-0">
          <Database className="page-icon text-blue-600" />
          اختبار استيراد وتصدير البيانات
        </h1>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm" onClick={clearLogs} disabled={isLoading}>
            <RefreshCw className="h-4 w-4 ml-2" />
            مسح السجلات
          </Button>
        </div>
      </div>

      {/* بطاقات الاختبار */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Download className="h-5 w-5 ml-2 text-blue-600" />
              اختبار التصدير
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-gray-600">
              اختبار وظيفة تصدير البيانات باستخدام بيانات اختبار وهمية. لن يتم تغيير البيانات الفعلية.
            </p>
            <div className="flex flex-col gap-2">
              <Button onClick={handleTestExport} disabled={isLoading} className="w-full">
                {isLoading ? "جاري الاختبار..." : "اختبار التصدير"}
              </Button>
              <Button onClick={handleRealExport} disabled={isLoading} variant="outline" className="w-full">
                تصدير البيانات الفعلية
              </Button>
            </div>
            {testResults?.export && (
              <div className={`p-4 rounded-md ${testResults.export.success ? "bg-green-50" : "bg-red-50"}`}>
                <div className="flex items-center">
                  {testResults.export.success ? (
                    <CheckCircle className="h-5 w-5 text-green-600 ml-2" />
                  ) : (
                    <AlertCircle className="h-5 w-5 text-red-600 ml-2" />
                  )}
                  <p className={testResults.export.success ? "text-green-600" : "text-red-600"}>
                    {testResults.export.message}
                  </p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Upload className="h-5 w-5 ml-2 text-green-600" />
              اختبار الاستيراد
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-gray-600">
              اختبار وظيفة استيراد البيانات باستخدام بيانات اختبار وهمية. لن يتم تغيير البيانات الفعلية.
            </p>
            <div className="flex flex-col gap-2">
              <Button onClick={handleTestImport} disabled={isLoading} className="w-full">
                {isLoading ? "جاري الاختبار..." : "اختبار الاستيراد"}
              </Button>
              <Button onClick={handleRealImport} disabled={isLoading} variant="outline" className="w-full">
                استيراد بيانات فعلية
              </Button>
            </div>
            {testResults?.import && (
              <div className={`p-4 rounded-md ${testResults.import.success ? "bg-green-50" : "bg-red-50"}`}>
                <div className="flex items-center">
                  {testResults.import.success ? (
                    <CheckCircle className="h-5 w-5 text-green-600 ml-2" />
                  ) : (
                    <AlertCircle className="h-5 w-5 text-red-600 ml-2" />
                  )}
                  <p className={testResults.import.success ? "text-green-600" : "text-red-600"}>
                    {testResults.import.message}
                  </p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* اختبار كامل */}
      <Card className="border-0 shadow-sm mb-6">
        <CardHeader>
          <CardTitle className="flex items-center">
            <RefreshCw className="h-5 w-5 ml-2 text-purple-600" />
            اختبار كامل
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-gray-600">
            تنفيذ اختبار كامل لعمليات الاستيراد والتصدير معًا. سيتم إنشاء بيانات اختبار، تصديرها، ثم استيرادها مرة أخرى.
          </p>
          <Button onClick={handleFullTest} disabled={isLoading} className="w-full">
            {isLoading ? "جاري الاختبار..." : "تنفيذ الاختبار الكامل"}
          </Button>
        </CardContent>
      </Card>

      {/* سجل الاختبار */}
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle>سجل الاختبار</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="bg-gray-50 p-4 rounded-md h-64 overflow-y-auto font-mono text-sm">
            {testLog.length > 0 ? (
              testLog.map((log, index) => (
                <div key={index} className="mb-1">
                  {log}
                </div>
              ))
            ) : (
              <div className="text-gray-400 text-center py-10">
                لا توجد سجلات بعد. قم بتنفيذ اختبار لعرض النتائج هنا.
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </PageLayout>
  )
}
