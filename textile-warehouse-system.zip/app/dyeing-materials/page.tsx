"use client"

import { useState, useEffect } from "react"
import type React from "react"
import { PageLayout } from "@/components/page-layout"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Plus, Search, Edit, Trash2, MoreHorizontal, Filter, Download } from "lucide-react"
import { useAuth } from "@/hooks/use-auth"
import { dataManager } from "@/lib/data-manager"

// Define material types
type Material = {
  id: string
  name: string
  nameAr: string
  unit: "kg" | "gram" | "liter"
  price: number
  stock: number
  category: string
  lastUpdated: string
}

interface DyeingMaterial {
  id: number
  code: string
  name: string
  nameEn: string
  category: "dye" | "chemical" | "auxiliary"
  unit: "kg" | "gram" | "liter"
  purchasePrice: number
  currentStock: number
  minimumStock: number
  supplier: string
  lastPurchaseDate: string
  status: "active" | "inactive" | "low_stock"
  createdAt: string
}

export default function DyeingMaterialsPage() {
  const [materials, setMaterials] = useState<Material[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [newMaterial, setNewMaterial] = useState<Partial<Material>>({
    name: "",
    nameAr: "",
    unit: "kg",
    price: 0,
    stock: 0,
    category: "dye",
  })
  const [activeTab, setActiveTab] = useState("all")
  const [showDialog, setShowDialog] = useState(false)
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all_categories")
  const [selectedMaterial, setSelectedMaterial] = useState<DyeingMaterial | null>(null)
  const [isEditMode, setIsEditMode] = useState(false)

  const { isAdmin, canDelete } = useAuth()

  const [formData, setFormData] = useState({
    code: "",
    name: "",
    nameEn: "",
    category: "dye" as "dye" | "chemical" | "auxiliary",
    unit: "kg" as "kg" | "gram" | "liter",
    purchasePrice: "",
    currentStock: "",
    minimumStock: "",
    supplier: "",
  })

  // Load materials from data manager
  useEffect(() => {
    const loadedMaterials = dataManager.getData("dyeingMaterials", [])
    if (loadedMaterials.length === 0) {
      // Add some sample data if none exists
      const sampleMaterials: Material[] = [
        {
          id: "mat-001",
          name: "Reactive Blue 19",
          nameAr: "أزرق تفاعلي 19",
          unit: "kg",
          price: 85.5,
          stock: 120,
          category: "dye",
          lastUpdated: "2023-05-15",
        },
        {
          id: "mat-002",
          name: "Sodium Carbonate",
          nameAr: "كربونات الصوديوم",
          unit: "kg",
          price: 12.75,
          stock: 350,
          category: "chemical",
          lastUpdated: "2023-05-10",
        },
        {
          id: "mat-003",
          name: "Acetic Acid",
          nameAr: "حمض الخليك",
          unit: "liter",
          price: 18.25,
          stock: 75,
          category: "chemical",
          lastUpdated: "2023-05-12",
        },
        {
          id: "mat-004",
          name: "Disperse Red 60",
          nameAr: "أحمر مشتت 60",
          unit: "kg",
          price: 95.0,
          stock: 85,
          category: "dye",
          lastUpdated: "2023-05-08",
        },
        {
          id: "mat-005",
          name: "Softener Agent",
          nameAr: "عامل تنعيم",
          unit: "liter",
          price: 32.5,
          stock: 110,
          category: "finishing",
          lastUpdated: "2023-05-14",
        },
      ]
      dataManager.setData("dyeingMaterials", sampleMaterials)
      setMaterials(sampleMaterials)
    } else {
      setMaterials(loadedMaterials)
    }
  }, [])

  // Filter materials based on search query
  const filteredMaterials = materials.filter(
    (material) =>
      material.name.toLowerCase().includes(searchQuery.toLowerCase()) || material.nameAr.includes(searchQuery),
  )

  // Add new material
  const handleAddMaterial = () => {
    if (!newMaterial.name || !newMaterial.nameAr || !newMaterial.price) {
      return // Validate required fields
    }

    const newMaterialComplete: Material = {
      id: `mat-${String(materials.length + 1).padStart(3, "0")}`,
      name: newMaterial.name,
      nameAr: newMaterial.nameAr,
      unit: newMaterial.unit as "kg" | "gram" | "liter",
      price: Number(newMaterial.price),
      stock: Number(newMaterial.stock || 0),
      category: newMaterial.category || "dye",
      lastUpdated: new Date().toISOString().split("T")[0],
    }

    const updatedMaterials = [...materials, newMaterialComplete]
    dataManager.setData("dyeingMaterials", updatedMaterials)
    setMaterials(updatedMaterials)
    setIsAddDialogOpen(false)
    setNewMaterial({
      name: "",
      nameAr: "",
      unit: "kg",
      price: 0,
      stock: 0,
      category: "dye",
    })
  }

  // Get category badge color
  const getCategoryColor = (category: string) => {
    switch (category) {
      case "dye":
        return "bg-blue-100 text-blue-800"
      case "chemical":
        return "bg-purple-100 text-purple-800"
      case "finishing":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  // Filter materials
  // const filteredMaterials = materials.filter((material) => {
  //   const matchesTab =
  //     activeTab === "all" ||
  //     (activeTab === "active" && material.status === "active") ||
  //     (activeTab === "low_stock" && material.status === "low_stock") ||
  //     (activeTab === "inactive" && material.status === "inactive")

  //   const matchesSearch =
  //     material.name.includes(searchTerm) ||
  //     material.nameEn.toLowerCase().includes(searchTerm.toLowerCase()) ||
  //     material.code.includes(searchTerm) ||
  //     material.supplier.includes(searchTerm)

  //   const matchesCategory = categoryFilter === "all_categories" || material.category === categoryFilter

  //   return matchesTab && matchesSearch && matchesCategory
  // })

  const handleOpenDialog = (material?: DyeingMaterial) => {
    if (material) {
      setIsEditMode(true)
      setSelectedMaterial(material)
      setFormData({
        code: material.code,
        name: material.name,
        nameEn: material.nameEn,
        category: material.category,
        unit: material.unit,
        purchasePrice: material.purchasePrice.toString(),
        currentStock: material.currentStock.toString(),
        minimumStock: material.minimumStock.toString(),
        supplier: material.supplier,
      })
    } else {
      setIsEditMode(false)
      setSelectedMaterial(null)
      setFormData({
        code: "",
        name: "",
        nameEn: "",
        category: "dye",
        unit: "kg",
        purchasePrice: "",
        currentStock: "",
        minimumStock: "",
        supplier: "",
      })
    }
    setShowDialog(true)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (isEditMode && selectedMaterial) {
      const updatedMaterial = {
        ...selectedMaterial,
        code: formData.code,
        name: formData.name,
        nameEn: formData.nameEn,
        category: formData.category,
        unit: formData.unit,
        purchasePrice: Number.parseFloat(formData.purchasePrice),
        currentStock: Number.parseFloat(formData.currentStock),
        minimumStock: Number.parseFloat(formData.minimumStock),
        supplier: formData.supplier,
        status:
          Number.parseFloat(formData.currentStock) <= Number.parseFloat(formData.minimumStock)
            ? ("low_stock" as const)
            : ("active" as const),
      }

      // setMaterials(materials.map((m) => (m.id === selectedMaterial.id ? updatedMaterial : m)))
    } else {
      const newMaterial: DyeingMaterial = {
        id: Date.now(),
        code: formData.code,
        name: formData.name,
        nameEn: formData.nameEn,
        category: formData.category,
        unit: formData.unit,
        purchasePrice: Number.parseFloat(formData.purchasePrice),
        currentStock: Number.parseFloat(formData.currentStock),
        minimumStock: Number.parseFloat(formData.minimumStock),
        supplier: formData.supplier,
        lastPurchaseDate: new Date().toISOString().split("T")[0],
        status:
          Number.parseFloat(formData.currentStock) <= Number.parseFloat(formData.minimumStock) ? "low_stock" : "active",
        createdAt: new Date().toISOString().split("T")[0],
      }

      // setMaterials([...materials, newMaterial])
    }

    setShowDialog(false)
  }

  const handleDeleteMaterial = () => {
    if (selectedMaterial) {
      // setMaterials(materials.filter((m) => m.id !== selectedMaterial.id))
      setShowDeleteDialog(false)
      setSelectedMaterial(null)
    }
  }

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case "dye":
        return "أصباغ"
      case "chemical":
        return "كيماويات"
      case "auxiliary":
        return "مواد مساعدة"
      default:
        return category
    }
  }

  // const getCategoryColor = (category: string) => {
  //   switch (category) {
  //     case "dye":
  //       return "bg-blue-100 text-blue-800"
  //     case "chemical":
  //       return "bg-red-100 text-red-800"
  //     case "auxiliary":
  //       return "bg-green-100 text-green-800"
  //     default:
  //       return "bg-gray-100 text-gray-800"
  //   }
  // }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800"
      case "low_stock":
        return "bg-red-100 text-red-800"
      case "inactive":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "active":
        return "نشط"
      case "low_stock":
        return "مخزون منخفض"
      case "inactive":
        return "غير نشط"
      default:
        return status
    }
  }

  // Calculate statistics
  // const totalMaterials = materials.length
  // const lowStockCount = materials.filter((m) => m.status === "low_stock").length
  // const totalValue = materials.reduce((sum, m) => sum + m.currentStock * m.purchasePrice, 0)

  return (
    <PageLayout title="Dyeing Materials / مواد الصباغة">
      <div className="bg-white rounded-lg shadow">
        {/* Header with actions */}
        <div className="p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b">
          <div className="relative w-full sm:w-96">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search materials..."
              className="pl-10 bg-gray-50"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm">
              <Filter className="h-4 w-4 mr-2" />
              Filter
            </Button>
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Material
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Material</DialogTitle>
                  <DialogDescription>Add a new dyeing or finishing material to the inventory.</DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label htmlFor="name" className="text-sm font-medium">
                        Name (English)
                      </label>
                      <Input
                        id="name"
                        value={newMaterial.name}
                        onChange={(e) => setNewMaterial({ ...newMaterial, name: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="nameAr" className="text-sm font-medium">
                        Name (Arabic)
                      </label>
                      <Input
                        id="nameAr"
                        value={newMaterial.nameAr}
                        onChange={(e) => setNewMaterial({ ...newMaterial, nameAr: e.target.value })}
                        dir="rtl"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <label htmlFor="category" className="text-sm font-medium">
                        Category
                      </label>
                      <Select
                        value={newMaterial.category}
                        onValueChange={(value) => setNewMaterial({ ...newMaterial, category: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="dye">Dye</SelectItem>
                          <SelectItem value="chemical">Chemical</SelectItem>
                          <SelectItem value="finishing">Finishing</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="unit" className="text-sm font-medium">
                        Unit
                      </label>
                      <Select
                        value={newMaterial.unit}
                        onValueChange={(value: "kg" | "gram" | "liter") =>
                          setNewMaterial({ ...newMaterial, unit: value })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select unit" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="kg">Kilogram (kg)</SelectItem>
                          <SelectItem value="gram">Gram (g)</SelectItem>
                          <SelectItem value="liter">Liter (L)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="price" className="text-sm font-medium">
                        Price
                      </label>
                      <Input
                        id="price"
                        type="number"
                        value={newMaterial.price || ""}
                        onChange={(e) => setNewMaterial({ ...newMaterial, price: Number.parseFloat(e.target.value) })}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="stock" className="text-sm font-medium">
                      Initial Stock
                    </label>
                    <Input
                      id="stock"
                      type="number"
                      value={newMaterial.stock || ""}
                      onChange={(e) => setNewMaterial({ ...newMaterial, stock: Number.parseInt(e.target.value) })}
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleAddMaterial}>Add Material</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Materials table */}
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50">
                <TableHead className="w-[80px]">ID</TableHead>
                <TableHead>Name / الاسم</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Unit</TableHead>
                <TableHead className="text-right">Price</TableHead>
                <TableHead className="text-right">Stock</TableHead>
                <TableHead className="text-right">Last Updated</TableHead>
                <TableHead className="w-[100px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredMaterials.map((material) => (
                <TableRow key={material.id} className="hover:bg-gray-50">
                  <TableCell className="font-medium">{material.id}</TableCell>
                  <TableCell>
                    <div>
                      <div className="font-medium">{material.name}</div>
                      <div className="text-sm text-gray-500">{material.nameAr}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge className={getCategoryColor(material.category)}>
                      {material.category.charAt(0).toUpperCase() + material.category.slice(1)}
                    </Badge>
                  </TableCell>
                  <TableCell>{material.unit}</TableCell>
                  <TableCell className="text-right">${material.price.toFixed(2)}</TableCell>
                  <TableCell className="text-right">
                    <span className={`font-medium ${material.stock < 50 ? "text-red-600" : "text-green-600"}`}>
                      {material.stock} {material.unit}
                    </span>
                  </TableCell>
                  <TableCell className="text-right">{material.lastUpdated}</TableCell>
                  <TableCell>
                    <div className="flex items-center justify-end gap-2">
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between px-6 py-4 border-t">
          <div className="text-sm text-gray-500">
            Showing <span className="font-medium">{filteredMaterials.length}</span> of{" "}
            <span className="font-medium">{materials.length}</span> materials
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" disabled>
              Previous
            </Button>
            <Button variant="outline" size="sm" className="bg-blue-50">
              1
            </Button>
            <Button variant="outline" size="sm">
              2
            </Button>
            <Button variant="outline" size="sm">
              Next
            </Button>
          </div>
        </div>
      </div>
    </PageLayout>
  )
}
