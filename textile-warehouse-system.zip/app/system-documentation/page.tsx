"use client"

import { PageLayout } from "@/components/page-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Separator } from "@/components/ui/separator"
import { InfoIcon, Database, Calculator, FileText, AlertTriangle } from "lucide-react"

export default function SystemDocumentationPage() {
  return (
    <PageLayout title="توثيق النظام">
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
          <h1 className="text-2xl font-bold text-gray-900 mb-4 sm:mb-0">توثيق النظام</h1>
        </div>

        <Alert className="bg-blue-50 border-blue-200">
          <InfoIcon className="h-4 w-4 text-blue-500" />
          <AlertTitle>توثيق محدث</AlertTitle>
          <AlertDescription>
            تم تحديث هذا التوثيق ليعكس التغييرات الأخيرة في معادلة حساب الرصيد النهائي.
          </AlertDescription>
        </Alert>

        <Tabs defaultValue="balance">
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="balance">حساب الأرصدة</TabsTrigger>
            <TabsTrigger value="formulas">المعادلات</TabsTrigger>
            <TabsTrigger value="reports">التقارير</TabsTrigger>
          </TabsList>

          <TabsContent value="balance" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Database className="h-5 w-5 ml-2" />
                  حساب الأرصدة
                </CardTitle>
                <CardDescription>توثيق طريقة حساب الأرصدة في النظام</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="text-lg font-medium mb-2">معادلة الرصيد النهائي</h3>
                  <div className="bg-gray-50 p-4 rounded-md border">
                    <p className="font-mono text-lg">الرصيد النهائي = رصيد بداية المدة + الوارد - المنصرف + المرتجع</p>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">توضيح المعادلة</h3>
                  <ul className="list-disc list-inside space-y-2">
                    <li>
                      <strong>رصيد بداية المدة:</strong> الرصيد الافتتاحي للصنف لدى العميل في بداية الفترة
                    </li>
                    <li>
                      <strong>الوارد:</strong> كمية الصنف التي تم استلامها من العميل خلال الفترة
                    </li>
                    <li>
                      <strong>المنصرف:</strong> كمية الصنف التي تم صرفها للإنتاج خلال الفترة
                    </li>
                    <li>
                      <strong>المرتجع:</strong> كمية الصنف التي تم إرجاعها من الإنتاج خلال الفترة
                    </li>
                    <li>
                      <strong>المسلم:</strong> كمية الصنف التي تم تسليمها للعميل (تُعرض للمعلومات فقط ولا تؤثر على الرصيد
                      النهائي)
                    </li>
                  </ul>
                </div>

                <Alert className="bg-yellow-50 border-yellow-200">
                  <AlertTriangle className="h-4 w-4 text-yellow-500" />
                  <AlertTitle>ملاحظة هامة</AlertTitle>
                  <AlertDescription>
                    الكمية المسلمة تُعرض للمعلومات فقط ولا تؤثر على الرصيد النهائي. هذا تغيير عن السلوك السابق حيث كانت
                    الكمية المسلمة تُخصم من الرصيد النهائي.
                  </AlertDescription>
                </Alert>

                <div>
                  <h3 className="text-lg font-medium mb-2">مثال توضيحي</h3>
                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="border p-2 text-right">البند</th>
                          <th className="border p-2 text-right">القيمة</th>
                          <th className="border p-2 text-right">الشرح</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td className="border p-2">رصيد بداية المدة</td>
                          <td className="border p-2">100</td>
                          <td className="border p-2">الرصيد الافتتاحي</td>
                        </tr>
                        <tr>
                          <td className="border p-2">الوارد</td>
                          <td className="border p-2">400</td>
                          <td className="border p-2">استلام من العميل</td>
                        </tr>
                        <tr>
                          <td className="border p-2">المنصرف</td>
                          <td className="border p-2">240</td>
                          <td className="border p-2">صرف للإنتاج</td>
                        </tr>
                        <tr>
                          <td className="border p-2">المرتجع</td>
                          <td className="border p-2">50</td>
                          <td className="border p-2">إرجاع من الإنتاج</td>
                        </tr>
                        <tr>
                          <td className="border p-2">المسلم</td>
                          <td className="border p-2">180</td>
                          <td className="border p-2">تسليم للعميل (للمعلومات فقط)</td>
                        </tr>
                        <tr className="bg-gray-50 font-medium">
                          <td className="border p-2">الرصيد النهائي</td>
                          <td className="border p-2">310</td>
                          <td className="border p-2">100 + 400 - 240 + 50 = 310</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="formulas" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calculator className="h-5 w-5 ml-2" />
                  المعادلات المستخدمة في النظام
                </CardTitle>
                <CardDescription>توثيق المعادلات الرئيسية المستخدمة في النظام</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="text-lg font-medium mb-2">معادلة الرصيد النهائي</h3>
                  <div className="bg-gray-50 p-4 rounded-md border">
                    <p className="font-mono text-lg">الرصيد النهائي = رصيد بداية المدة + الوارد - المنصرف + المرتجع</p>
                  </div>
                </div>

                <Separator />

                <div>
                  <h3 className="text-lg font-medium mb-2">معادلة الرصيد مخصوم منه الجاهز</h3>
                  <div className="bg-gray-50 p-4 rounded-md border">
                    <p className="font-mono text-lg">الرصيد مخصوم منه الجاهز = الرصيد النهائي - الكمية الجاهزة</p>
                  </div>
                </div>

                <Separator />

                <div>
                  <h3 className="text-lg font-medium mb-2">معادلة نسبة الإنجاز</h3>
                  <div className="bg-gray-50 p-4 rounded-md border">
                    <p className="font-mono text-lg">نسبة الإنجاز = (الكمية المنتجة / الكمية المطلوبة) × 100%</p>
                  </div>
                </div>

                <Separator />

                <div>
                  <h3 className="text-lg font-medium mb-2">معادلة نسبة المنفصلات</h3>
                  <div className="bg-gray-50 p-4 rounded-md border">
                    <p className="font-mono text-lg">نسبة المنفصلات = (كمية المنفصلات / إجمالي الكمية) × 100%</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reports" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <FileText className="h-5 w-5 ml-2" />
                  التقارير
                </CardTitle>
                <CardDescription>توثيق التقارير المتاحة في النظام</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="text-lg font-medium mb-2">تقرير الأرصدة</h3>
                  <p>
                    يعرض هذا التقرير أرصدة الأصناف لدى العملاء، ويمكن تصفيته حسب العميل أو الصنف أو الفترة الزمنية. يعرض
                    التقرير الرصيد النهائي وفقاً للمعادلة المحدثة.
                  </p>
                </div>

                <Separator />

                <div>
                  <h3 className="text-lg font-medium mb-2">تقرير حركة الصنف</h3>
                  <p>
                    يعرض هذا التقرير تفاصيل حركة صنف معين لدى عميل معين، بما في ذلك جميع عمليات الاستلام والصرف والإرجاع
                    والتسليم.
                  </p>
                </div>

                <Separator />

                <div>
                  <h3 className="text-lg font-medium mb-2">تقرير المنفصلات</h3>
                  <p>
                    يعرض هذا التقرير تفاصيل منفصلات الإنتاج، ويمكن تصفيته حسب العميل أو الصنف أو سبب الفصل أو الفترة
                    الزمنية.
                  </p>
                </div>

                <Separator />

                <div>
                  <h3 className="text-lg font-medium mb-2">تقرير أوامر التشغيل</h3>
                  <p>
                    يعرض هذا التقرير تفاصيل أوامر التشغيل، ويمكن تصفيته حسب العميل أو الصنف أو حالة الأمر أو الفترة
                    الزمنية.
                  </p>
                </div>

                <Separator />

                <div>
                  <h3 className="text-lg font-medium mb-2">تقرير بيانات التسليم</h3>
                  <p>
                    يعرض هذا التقرير تفاصيل بيانات التسليم، ويمكن تصفيته حسب العميل أو الصنف أو حالة البيان أو الفترة
                    الزمنية.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PageLayout>
  )
}
