"use client"

import { useState, useEffect } from "react"
import { PageLayout } from "@/components/page-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import {
  Wallet,
  Plus,
  TrendingUp,
  TrendingDown,
  DollarSign,
  CreditCard,
  Banknote,
  ArrowUpRight,
  ArrowDownLeft,
  Filter,
  Download,
  Eye,
  Edit,
  Trash2,
} from "lucide-react"
import { dataManager } from "@/lib/data-manager"

interface TreasuryTransaction {
  id: string
  type: "income" | "expense" | "transfer"
  amount: number
  description: string
  category: string
  paymentMethod: "cash" | "bank" | "check" | "card"
  date: string
  reference?: string
  notes?: string
  createdBy: string
  createdAt: string
}

interface TreasuryAccount {
  id: string
  name: string
  type: "cash" | "bank" | "savings"
  balance: number
  currency: string
  accountNumber?: string
  bankName?: string
  isActive: boolean
}

export default function TreasuryPage() {
  const [transactions, setTransactions] = useState<TreasuryTransaction[]>([])
  const [accounts, setAccounts] = useState<TreasuryAccount[]>([])
  const [activeTab, setActiveTab] = useState("overview")
  const [showAddTransaction, setShowAddTransaction] = useState(false)
  const [showAddAccount, setShowAddAccount] = useState(false)

  const [transactionForm, setTransactionForm] = useState({
    type: "income" as "income" | "expense" | "transfer",
    amount: "",
    description: "",
    category: "",
    paymentMethod: "cash" as "cash" | "bank" | "check" | "card",
    date: new Date().toISOString().split("T")[0],
    reference: "",
    notes: "",
  })

  const [accountForm, setAccountForm] = useState({
    name: "",
    type: "cash" as "cash" | "bank" | "savings",
    balance: "",
    currency: "EGP",
    accountNumber: "",
    bankName: "",
  })

  useEffect(() => {
    // Load existing data
    const loadedTransactions = dataManager.getData("treasuryTransactions", [])
    const loadedAccounts = dataManager.getData("treasuryAccounts", [])

    if (loadedAccounts.length === 0) {
      // Initialize with default accounts
      const defaultAccounts: TreasuryAccount[] = [
        {
          id: "acc-001",
          name: "الخزينة الرئيسية",
          type: "cash",
          balance: 50000,
          currency: "EGP",
          isActive: true,
        },
        {
          id: "acc-002",
          name: "البنك الأهلي المصري",
          type: "bank",
          balance: 150000,
          currency: "EGP",
          accountNumber: "123456789",
          bankName: "البنك الأهلي المصري",
          isActive: true,
        },
        {
          id: "acc-003",
          name: "حساب التوفير",
          type: "savings",
          balance: 75000,
          currency: "EGP",
          accountNumber: "987654321",
          bankName: "بنك مصر",
          isActive: true,
        },
      ]
      dataManager.setData("treasuryAccounts", defaultAccounts)
      setAccounts(defaultAccounts)
    } else {
      setAccounts(loadedAccounts)
    }

    if (loadedTransactions.length === 0) {
      // Initialize with sample transactions
      const sampleTransactions: TreasuryTransaction[] = [
        {
          id: "txn-001",
          type: "income",
          amount: 25000,
          description: "دفعة من عميل شركة النسيج المتحدة",
          category: "مبيعات",
          paymentMethod: "bank",
          date: "2024-03-15",
          reference: "INV-001",
          notes: "دفعة جزئية للفاتورة",
          createdBy: "أحمد محمد",
          createdAt: "2024-03-15T10:30:00Z",
        },
        {
          id: "txn-002",
          type: "expense",
          amount: 5000,
          description: "شراء مواد صباغة",
          category: "مشتريات",
          paymentMethod: "cash",
          date: "2024-03-14",
          reference: "PO-001",
          notes: "مواد للإنتاج الشهري",
          createdBy: "سارة أحمد",
          createdAt: "2024-03-14T14:20:00Z",
        },
        {
          id: "txn-003",
          type: "expense",
          amount: 3500,
          description: "رواتب العمال",
          category: "رواتب",
          paymentMethod: "cash",
          date: "2024-03-13",
          notes: "رواتب أسبوعية",
          createdBy: "محمد علي",
          createdAt: "2024-03-13T16:45:00Z",
        },
      ]
      dataManager.setData("treasuryTransactions", sampleTransactions)
      setTransactions(sampleTransactions)
    } else {
      setTransactions(loadedTransactions)
    }
  }, [])

  const handleAddTransaction = () => {
    const newTransaction: TreasuryTransaction = {
      id: `txn-${Date.now()}`,
      type: transactionForm.type,
      amount: Number.parseFloat(transactionForm.amount),
      description: transactionForm.description,
      category: transactionForm.category,
      paymentMethod: transactionForm.paymentMethod,
      date: transactionForm.date,
      reference: transactionForm.reference,
      notes: transactionForm.notes,
      createdBy: "المستخدم الحالي",
      createdAt: new Date().toISOString(),
    }

    const updatedTransactions = [...transactions, newTransaction]
    setTransactions(updatedTransactions)
    dataManager.setData("treasuryTransactions", updatedTransactions)

    // Reset form
    setTransactionForm({
      type: "income",
      amount: "",
      description: "",
      category: "",
      paymentMethod: "cash",
      date: new Date().toISOString().split("T")[0],
      reference: "",
      notes: "",
    })
    setShowAddTransaction(false)
  }

  const handleAddAccount = () => {
    const newAccount: TreasuryAccount = {
      id: `acc-${Date.now()}`,
      name: accountForm.name,
      type: accountForm.type,
      balance: Number.parseFloat(accountForm.balance),
      currency: accountForm.currency,
      accountNumber: accountForm.accountNumber,
      bankName: accountForm.bankName,
      isActive: true,
    }

    const updatedAccounts = [...accounts, newAccount]
    setAccounts(updatedAccounts)
    dataManager.setData("treasuryAccounts", updatedAccounts)

    // Reset form
    setAccountForm({
      name: "",
      type: "cash",
      balance: "",
      currency: "EGP",
      accountNumber: "",
      bankName: "",
    })
    setShowAddAccount(false)
  }

  // Calculate totals
  const totalBalance = accounts.reduce((sum, account) => sum + account.balance, 0)
  const totalIncome = transactions.filter((t) => t.type === "income").reduce((sum, t) => sum + t.amount, 0)
  const totalExpenses = transactions.filter((t) => t.type === "expense").reduce((sum, t) => sum + t.amount, 0)
  const netFlow = totalIncome - totalExpenses

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case "income":
        return <ArrowUpRight className="w-4 h-4 text-green-600" />
      case "expense":
        return <ArrowDownLeft className="w-4 h-4 text-red-600" />
      default:
        return <TrendingUp className="w-4 h-4 text-blue-600" />
    }
  }

  const getPaymentMethodIcon = (method: string) => {
    switch (method) {
      case "cash":
        return <Banknote className="w-4 h-4" />
      case "bank":
        return <CreditCard className="w-4 h-4" />
      case "card":
        return <CreditCard className="w-4 h-4" />
      default:
        return <DollarSign className="w-4 h-4" />
    }
  }

  const formatCurrency = (amount: number) => {
    return `${amount.toLocaleString("ar-EG")} ج.م`
  }

  return (
    <PageLayout title="الخزينة" subtitle="إدارة الأموال والحسابات المالية">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4 mb-6">
          <TabsTrigger value="overview">نظرة عامة</TabsTrigger>
          <TabsTrigger value="transactions">المعاملات</TabsTrigger>
          <TabsTrigger value="accounts">الحسابات</TabsTrigger>
          <TabsTrigger value="reports">التقارير</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="card-hover">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">إجمالي الرصيد</p>
                    <p className="text-2xl font-bold text-blue-600">{formatCurrency(totalBalance)}</p>
                  </div>
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Wallet className="w-6 h-6 text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="card-hover">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">إجمالي الإيرادات</p>
                    <p className="text-2xl font-bold text-green-600">{formatCurrency(totalIncome)}</p>
                  </div>
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="card-hover">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">إجمالي المصروفات</p>
                    <p className="text-2xl font-bold text-red-600">{formatCurrency(totalExpenses)}</p>
                  </div>
                  <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                    <TrendingDown className="w-6 h-6 text-red-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="card-hover">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">صافي التدفق</p>
                    <p className="text-2xl font-bold text-purple-600">{formatCurrency(netFlow)}</p>
                  </div>
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                    <DollarSign className="w-6 h-6 text-purple-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Accounts Overview */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>الحسابات النشطة</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {accounts
                    .filter((acc) => acc.isActive)
                    .map((account) => (
                      <div key={account.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div className="flex items-center">
                          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center ml-3">
                            <Wallet className="w-5 h-5 text-blue-600" />
                          </div>
                          <div>
                            <div className="font-medium">{account.name}</div>
                            <div className="text-sm text-gray-500">
                              {account.type === "cash" ? "نقدي" : account.type === "bank" ? "بنكي" : "توفير"}
                            </div>
                          </div>
                        </div>
                        <div className="text-left">
                          <div className="font-bold text-lg">{formatCurrency(account.balance)}</div>
                          <div className="text-sm text-gray-500">{account.currency}</div>
                        </div>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>آخر المعاملات</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {transactions.slice(0, 5).map((transaction) => (
                    <div key={transaction.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center">
                        <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center ml-3">
                          {getTransactionIcon(transaction.type)}
                        </div>
                        <div>
                          <div className="font-medium">{transaction.description}</div>
                          <div className="text-sm text-gray-500">{transaction.category}</div>
                        </div>
                      </div>
                      <div className="text-left">
                        <div
                          className={`font-bold ${transaction.type === "income" ? "text-green-600" : "text-red-600"}`}
                        >
                          {transaction.type === "income" ? "+" : "-"}
                          {formatCurrency(transaction.amount)}
                        </div>
                        <div className="text-sm text-gray-500">{transaction.date}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="transactions">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold">المعاملات المالية</h2>
            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <Filter className="w-4 h-4 ml-2" />
                تصفية
              </Button>
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 ml-2" />
                تصدير
              </Button>
              <Dialog open={showAddTransaction} onOpenChange={setShowAddTransaction}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="w-4 h-4 ml-2" />
                    إضافة معاملة
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>إضافة معاملة جديدة</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label>نوع المعاملة</Label>
                      <Select
                        value={transactionForm.type}
                        onValueChange={(value: "income" | "expense" | "transfer") =>
                          setTransactionForm({ ...transactionForm, type: value })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="income">إيراد</SelectItem>
                          <SelectItem value="expense">مصروف</SelectItem>
                          <SelectItem value="transfer">تحويل</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label>المبلغ</Label>
                      <Input
                        type="number"
                        value={transactionForm.amount}
                        onChange={(e) => setTransactionForm({ ...transactionForm, amount: e.target.value })}
                        placeholder="0.00"
                      />
                    </div>

                    <div>
                      <Label>الوصف</Label>
                      <Input
                        value={transactionForm.description}
                        onChange={(e) => setTransactionForm({ ...transactionForm, description: e.target.value })}
                        placeholder="وصف المعاملة"
                      />
                    </div>

                    <div>
                      <Label>الفئة</Label>
                      <Input
                        value={transactionForm.category}
                        onChange={(e) => setTransactionForm({ ...transactionForm, category: e.target.value })}
                        placeholder="فئة المعاملة"
                      />
                    </div>

                    <div>
                      <Label>طريقة الدفع</Label>
                      <Select
                        value={transactionForm.paymentMethod}
                        onValueChange={(value: "cash" | "bank" | "check" | "card") =>
                          setTransactionForm({ ...transactionForm, paymentMethod: value })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="cash">نقدي</SelectItem>
                          <SelectItem value="bank">بنكي</SelectItem>
                          <SelectItem value="check">شيك</SelectItem>
                          <SelectItem value="card">بطاقة</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label>التاريخ</Label>
                      <Input
                        type="date"
                        value={transactionForm.date}
                        onChange={(e) => setTransactionForm({ ...transactionForm, date: e.target.value })}
                      />
                    </div>

                    <div>
                      <Label>المرجع</Label>
                      <Input
                        value={transactionForm.reference}
                        onChange={(e) => setTransactionForm({ ...transactionForm, reference: e.target.value })}
                        placeholder="رقم المرجع (اختياري)"
                      />
                    </div>

                    <div>
                      <Label>ملاحظات</Label>
                      <Input
                        value={transactionForm.notes}
                        onChange={(e) => setTransactionForm({ ...transactionForm, notes: e.target.value })}
                        placeholder="ملاحظات إضافية"
                      />
                    </div>

                    <Button onClick={handleAddTransaction} className="w-full">
                      إضافة المعاملة
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="text-right p-4 font-medium">التاريخ</th>
                      <th className="text-right p-4 font-medium">النوع</th>
                      <th className="text-right p-4 font-medium">الوصف</th>
                      <th className="text-right p-4 font-medium">الفئة</th>
                      <th className="text-right p-4 font-medium">المبلغ</th>
                      <th className="text-right p-4 font-medium">طريقة الدفع</th>
                      <th className="text-right p-4 font-medium">الإجراءات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {transactions.map((transaction) => (
                      <tr key={transaction.id} className="border-b hover:bg-gray-50">
                        <td className="p-4">{transaction.date}</td>
                        <td className="p-4">
                          <Badge
                            className={
                              transaction.type === "income"
                                ? "badge-success"
                                : transaction.type === "expense"
                                  ? "badge-danger"
                                  : "badge-info"
                            }
                          >
                            {transaction.type === "income"
                              ? "إيراد"
                              : transaction.type === "expense"
                                ? "مصروف"
                                : "تحويل"}
                          </Badge>
                        </td>
                        <td className="p-4">{transaction.description}</td>
                        <td className="p-4">{transaction.category}</td>
                        <td className="p-4">
                          <span
                            className={`font-medium ${
                              transaction.type === "income" ? "text-green-600" : "text-red-600"
                            }`}
                          >
                            {transaction.type === "income" ? "+" : "-"}
                            {formatCurrency(transaction.amount)}
                          </span>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center">
                            {getPaymentMethodIcon(transaction.paymentMethod)}
                            <span className="mr-2">
                              {transaction.paymentMethod === "cash"
                                ? "نقدي"
                                : transaction.paymentMethod === "bank"
                                  ? "بنكي"
                                  : transaction.paymentMethod === "card"
                                    ? "بطاقة"
                                    : "شيك"}
                            </span>
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="flex gap-2">
                            <Button variant="ghost" size="sm">
                              <Eye className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="sm">
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="sm" className="text-red-600">
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="accounts">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold">الحسابات المالية</h2>
            <Dialog open={showAddAccount} onOpenChange={setShowAddAccount}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="w-4 h-4 ml-2" />
                  إضافة حساب
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>إضافة حساب جديد</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label>اسم الحساب</Label>
                    <Input
                      value={accountForm.name}
                      onChange={(e) => setAccountForm({ ...accountForm, name: e.target.value })}
                      placeholder="اسم الحساب"
                    />
                  </div>

                  <div>
                    <Label>نوع الحساب</Label>
                    <Select
                      value={accountForm.type}
                      onValueChange={(value: "cash" | "bank" | "savings") =>
                        setAccountForm({ ...accountForm, type: value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cash">نقدي</SelectItem>
                        <SelectItem value="bank">بنكي</SelectItem>
                        <SelectItem value="savings">توفير</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>الرصيد الافتتاحي</Label>
                    <Input
                      type="number"
                      value={accountForm.balance}
                      onChange={(e) => setAccountForm({ ...accountForm, balance: e.target.value })}
                      placeholder="0.00"
                    />
                  </div>

                  <div>
                    <Label>العملة</Label>
                    <Select
                      value={accountForm.currency}
                      onValueChange={(value) => setAccountForm({ ...accountForm, currency: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="EGP">جنيه مصري</SelectItem>
                        <SelectItem value="USD">دولار أمريكي</SelectItem>
                        <SelectItem value="EUR">يورو</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {accountForm.type !== "cash" && (
                    <>
                      <div>
                        <Label>رقم الحساب</Label>
                        <Input
                          value={accountForm.accountNumber}
                          onChange={(e) => setAccountForm({ ...accountForm, accountNumber: e.target.value })}
                          placeholder="رقم الحساب"
                        />
                      </div>

                      <div>
                        <Label>اسم البنك</Label>
                        <Input
                          value={accountForm.bankName}
                          onChange={(e) => setAccountForm({ ...accountForm, bankName: e.target.value })}
                          placeholder="اسم البنك"
                        />
                      </div>
                    </>
                  )}

                  <Button onClick={handleAddAccount} className="w-full">
                    إضافة الحساب
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {accounts.map((account) => (
              <Card key={account.id} className="card-hover">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <Wallet className="w-6 h-6 text-blue-600" />
                    </div>
                    <Badge className={account.isActive ? "badge-success" : "badge-danger"}>
                      {account.isActive ? "نشط" : "غير نشط"}
                    </Badge>
                  </div>
                  <h3 className="font-semibold text-lg mb-2">{account.name}</h3>
                  <p className="text-gray-500 text-sm mb-4">
                    {account.type === "cash" ? "حساب نقدي" : account.type === "bank" ? "حساب بنكي" : "حساب توفير"}
                  </p>
                  <div className="text-2xl font-bold text-blue-600 mb-4">{formatCurrency(account.balance)}</div>
                  {account.accountNumber && (
                    <p className="text-sm text-gray-500 mb-2">رقم الحساب: {account.accountNumber}</p>
                  )}
                  {account.bankName && <p className="text-sm text-gray-500 mb-4">{account.bankName}</p>}
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" className="flex-1">
                      <Edit className="w-4 h-4 ml-2" />
                      تعديل
                    </Button>
                    <Button variant="outline" size="sm" className="text-red-600">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="reports">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>تقرير التدفق النقدي</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-4 bg-green-50 rounded-lg">
                    <span className="font-medium">إجمالي الإيرادات</span>
                    <span className="text-green-600 font-bold">{formatCurrency(totalIncome)}</span>
                  </div>
                  <div className="flex justify-between items-center p-4 bg-red-50 rounded-lg">
                    <span className="font-medium">إجمالي المصروفات</span>
                    <span className="text-red-600 font-bold">{formatCurrency(totalExpenses)}</span>
                  </div>
                  <div className="flex justify-between items-center p-4 bg-blue-50 rounded-lg">
                    <span className="font-medium">صافي التدفق</span>
                    <span className={`font-bold ${netFlow >= 0 ? "text-green-600" : "text-red-600"}`}>
                      {formatCurrency(netFlow)}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>تقرير الحسابات</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {accounts.map((account) => (
                    <div key={account.id} className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                      <div>
                        <div className="font-medium">{account.name}</div>
                        <div className="text-sm text-gray-500">
                          {account.type === "cash" ? "نقدي" : account.type === "bank" ? "بنكي" : "توفير"}
                        </div>
                      </div>
                      <div className="text-left">
                        <div className="font-bold">{formatCurrency(account.balance)}</div>
                        <div className="text-sm text-gray-500">{account.currency}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </PageLayout>
  )
}
