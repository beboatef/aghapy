"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { PageLayout } from "@/components/page-layout"
import { CheckCircle, XCircle, Calculator, Database } from "lucide-react"

// نموذج بيانات الرصيد
interface BalanceRecord {
  customerId: number
  customerName: string
  materialId: number
  materialName: string
  unit: string
  openingBalance: number
  incoming: number
  outgoing: number
  returned: number
  delivered: number
  separatedQuantity: number
  readyQuantity: number
  final: number
}

// نموذج نتيجة التحقق
interface VerificationResult {
  record: BalanceRecord
  expectedFinal: number
  isCorrect: boolean
}

export default function BalanceVerificationPage() {
  const [verificationResults, setVerificationResults] = useState<VerificationResult[]>([])
  const [isVerifying, setIsVerifying] = useState(false)
  const [allCorrect, setAllCorrect] = useState(false)

  // بيانات الأرصدة للتحقق
  const testBalances: BalanceRecord[] = [
    {
      customerId: 1,
      customerName: "شركة النسيج المتحدة",
      materialId: 1,
      materialName: "قطن أبيض خام",
      unit: "كجم",
      openingBalance: 100,
      incoming: 400,
      outgoing: 240,
      returned: 50,
      delivered: 180,
      separatedQuantity: 15,
      readyQuantity: 20,
      final: 310, // 100 + 400 - 240 + 50 = 310
    },
    {
      customerId: 1,
      customerName: "شركة النسيج المتحدة",
      materialId: 2,
      materialName: "بوليستر أزرق",
      unit: "متر",
      openingBalance: 50,
      incoming: 200,
      outgoing: 150,
      returned: 20,
      delivered: 120,
      separatedQuantity: 5,
      readyQuantity: 10,
      final: 120, // 50 + 200 - 150 + 20 = 120
    },
    {
      customerId: 2,
      customerName: "مصنع الألوان الحديث",
      materialId: 1,
      materialName: "قطن أبيض خام",
      unit: "كجم",
      openingBalance: 75,
      incoming: 300,
      outgoing: 280,
      returned: 30,
      delivered: 250,
      separatedQuantity: 10,
      readyQuantity: 15,
      final: 125, // 75 + 300 - 280 + 30 = 125
    },
    {
      customerId: 2,
      customerName: "مصنع الألوان الحديث",
      materialId: 3,
      materialName: "قطن ملون",
      unit: "كجم",
      openingBalance: 200,
      incoming: 500,
      outgoing: 350,
      returned: 40,
      delivered: 300,
      separatedQuantity: 20,
      readyQuantity: 25,
      final: 390, // 200 + 500 - 350 + 40 = 390
    },
    {
      customerId: 3,
      customerName: "شركة القطن السعودي",
      materialId: 2,
      materialName: "بوليستر أزرق",
      unit: "متر",
      openingBalance: 150,
      incoming: 600,
      outgoing: 450,
      returned: 45,
      delivered: 400,
      separatedQuantity: 25,
      readyQuantity: 30,
      final: 345, // 150 + 600 - 450 + 45 = 345
    },
  ]

  // التحقق من صحة حساب الرصيد النهائي
  const verifyBalanceCalculation = () => {
    setIsVerifying(true)

    const results = testBalances.map((balance) => {
      // الرصيد النهائي = رصيد بداية المدة + الوارد - المنصرف + المرتجع
      const expectedFinal = balance.openingBalance + balance.incoming - balance.outgoing + balance.returned
      const isCorrect = balance.final === expectedFinal

      return {
        record: balance,
        expectedFinal,
        isCorrect,
      }
    })

    setVerificationResults(results)
    setAllCorrect(results.every((result) => result.isCorrect))
    setIsVerifying(false)
  }

  // تنفيذ التحقق عند تحميل الصفحة
  useEffect(() => {
    verifyBalanceCalculation()
  }, [])

  return (
    <PageLayout title="التحقق من حساب الأرصدة">
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
          <h1 className="text-2xl font-bold text-gray-900 mb-4 sm:mb-0">التحقق من حساب الأرصدة</h1>
          <Button onClick={verifyBalanceCalculation} disabled={isVerifying} className="flex items-center">
            <Calculator className="h-4 w-4 ml-2" />
            إعادة التحقق
          </Button>
        </div>

        {allCorrect ? (
          <Alert className="bg-green-50 border-green-200">
            <CheckCircle className="h-4 w-4 text-green-500" />
            <AlertTitle>جميع الحسابات صحيحة</AlertTitle>
            <AlertDescription>
              تم التحقق من جميع حسابات الرصيد النهائي وتأكيد أنها تتبع المعادلة الصحيحة:
              <br />
              <strong>الرصيد النهائي = رصيد بداية المدة + الوارد - المنصرف + المرتجع</strong>
            </AlertDescription>
          </Alert>
        ) : (
          <Alert variant="destructive">
            <XCircle className="h-4 w-4" />
            <AlertTitle>هناك أخطاء في حساب الأرصدة</AlertTitle>
            <AlertDescription>تم العثور على أخطاء في حساب الرصيد النهائي. يرجى مراجعة التفاصيل أدناه.</AlertDescription>
          </Alert>
        )}

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Database className="h-5 w-5 ml-2" />
              معادلة حساب الرصيد النهائي
            </CardTitle>
            <CardDescription>
              الرصيد النهائي = رصيد بداية المدة + الوارد - المنصرف + المرتجع
              <br />
              <strong>ملاحظة:</strong> الكمية المسلمة تُعرض للمعلومات فقط ولا تؤثر على الرصيد النهائي
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="text-right p-2">العميل</th>
                    <th className="text-right p-2">الصنف</th>
                    <th className="text-right p-2">رصيد البداية</th>
                    <th className="text-right p-2">الوارد</th>
                    <th className="text-right p-2">المنصرف</th>
                    <th className="text-right p-2">المرتجع</th>
                    <th className="text-right p-2">المسلم</th>
                    <th className="text-right p-2">الرصيد المحسوب</th>
                    <th className="text-right p-2">الرصيد المتوقع</th>
                    <th className="text-right p-2">النتيجة</th>
                  </tr>
                </thead>
                <tbody>
                  {verificationResults.map((result, index) => (
                    <tr key={index} className="border-t">
                      <td className="p-2">{result.record.customerName}</td>
                      <td className="p-2">{result.record.materialName}</td>
                      <td className="p-2">{result.record.openingBalance}</td>
                      <td className="p-2">{result.record.incoming}</td>
                      <td className="p-2">{result.record.outgoing}</td>
                      <td className="p-2">{result.record.returned}</td>
                      <td className="p-2 text-gray-500">{result.record.delivered}</td>
                      <td className="p-2 font-medium">{result.record.final}</td>
                      <td className="p-2 font-medium">{result.expectedFinal}</td>
                      <td className="p-2">
                        {result.isCorrect ? (
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                            صحيح
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                            خطأ
                          </Badge>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>توضيح المعادلة</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-medium mb-2">المعادلة الصحيحة:</h3>
                <div className="bg-green-50 p-4 rounded-md border border-green-200">
                  <p className="font-mono">الرصيد النهائي = رصيد بداية المدة + الوارد - المنصرف + المرتجع</p>
                  <p className="mt-2 text-sm text-gray-600">
                    الكمية المسلمة تُعرض للمعلومات فقط ولا تؤثر على الرصيد النهائي
                  </p>
                </div>
              </div>
              <div>
                <h3 className="font-medium mb-2">المعادلة القديمة (غير صحيحة):</h3>
                <div className="bg-red-50 p-4 rounded-md border border-red-200">
                  <p className="font-mono">الرصيد النهائي = رصيد بداية المدة + الوارد - المنصرف + المرتجع - المسلم</p>
                  <p className="mt-2 text-sm text-gray-600">
                    هذه المعادلة غير صحيحة لأن الكمية المسلمة لا يجب أن تؤثر على الرصيد النهائي
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  )
}
