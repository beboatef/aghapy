"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { toast } from "@/components/ui/use-toast"
import { PageLayout } from "@/components/page-layout"
import {
  CheckCircle,
  XCircle,
  AlertTriangle,
  Play,
  RefreshCw,
  Database,
  Users,
  Package,
  ClipboardList,
  Scissors,
  TruckIcon,
  FileDown,
  BarChart3,
} from "lucide-react"
import {
  runFullSystemTest,
  testBalanceCalculation,
  testCustomerManagement,
  testMaterialManagement,
  testInventoryManagement,
  testProductionOrderManagement,
  testSeparationsManagement,
  testDeliveryStatementManagement,
  testDataExportImport,
} from "@/scripts/system-test"

// تعريف أنواع الاختبارات
interface TestResult {
  success: boolean
  message: string
  expected?: any
  calculated?: any
  details?: any
}

interface FullTestResult {
  success: boolean
  passedTests: number
  totalTests: number
  results: Record<string, TestResult>
  message: string
}

export default function ComprehensiveTestPage() {
  const [activeTab, setActiveTab] = useState("dashboard")
  const [testResults, setTestResults] = useState<FullTestResult | null>(null)
  const [isRunningTest, setIsRunningTest] = useState(false)
  const [testLogs, setTestLogs] = useState<string[]>([])
  const [testProgress, setTestProgress] = useState(0)
  const [testStartTime, setTestStartTime] = useState<Date | null>(null)
  const [testEndTime, setTestEndTime] = useState<Date | null>(null)

  // تنفيذ الاختبار الشامل
  const runComprehensiveTest = async () => {
    setIsRunningTest(true)
    setTestLogs(["بدء الاختبار الشامل للنظام..."])
    setTestProgress(0)
    setTestStartTime(new Date())
    setTestEndTime(null)

    try {
      // اختبار حساب الرصيد النهائي
      setTestLogs((prev) => [...prev, "اختبار حساب الرصيد النهائي..."])
      setTestProgress(10)
      const balanceResult = await testBalanceCalculation()
      setTestLogs((prev) => [...prev, `اختبار حساب الرصيد النهائي: ${balanceResult.success ? "ناجح ✅" : "فاشل ❌"}`])

      // اختبار إدارة العملاء
      setTestLogs((prev) => [...prev, "اختبار إدارة العملاء..."])
      setTestProgress(20)
      const customerResult = await testCustomerManagement()
      setTestLogs((prev) => [...prev, `اختبار إدارة العملاء: ${customerResult.success ? "ناجح ✅" : "فاشل ❌"}`])

      // اختبار إدارة الأصناف
      setTestLogs((prev) => [...prev, "اختبار إدارة الأصناف..."])
      setTestProgress(30)
      const materialResult = await testMaterialManagement()
      setTestLogs((prev) => [...prev, `اختبار إدارة الأصناف: ${materialResult.success ? "ناجح ✅" : "فاشل ❌"}`])

      // اختبار إدارة المخزون
      setTestLogs((prev) => [...prev, "اختبار إدارة المخزون..."])
      setTestProgress(40)
      const inventoryResult = await testInventoryManagement()
      setTestLogs((prev) => [...prev, `اختبار إدارة المخزون: ${inventoryResult.success ? "ناجح ✅" : "فاشل ❌"}`])

      // اختبار إدارة أوامر التشغيل
      setTestLogs((prev) => [...prev, "اختبار إدارة أوامر التشغيل..."])
      setTestProgress(50)
      const productionResult = await testProductionOrderManagement()
      setTestLogs((prev) => [
        ...prev,
        `اختبار إدارة أوامر التشغيل: ${productionResult.success ? "ناجح ✅" : "فاشل ❌"}`,
      ])

      // اختبار إدارة المنفصلات
      setTestLogs((prev) => [...prev, "اختبار إدارة المنفصلات..."])
      setTestProgress(60)
      const separationsResult = await testSeparationsManagement()
      setTestLogs((prev) => [...prev, `اختبار إدارة المنفصلات: ${separationsResult.success ? "ناجح ✅" : "فاشل ❌"}`])

      // اختبار إدارة بيانات التسليم
      setTestLogs((prev) => [...prev, "اختبار إدارة بيانات التسليم..."])
      setTestProgress(70)
      const deliveryResult = await testDeliveryStatementManagement()
      setTestLogs((prev) => [...prev, `اختبار إدارة بيانات التسليم: ${deliveryResult.success ? "ناجح ✅" : "فاشل ❌"}`])

      // اختبار تصدير واستيراد البيانات
      setTestLogs((prev) => [...prev, "اختبار تصدير واستيراد البيانات..."])
      setTestProgress(80)
      const exportImportResult = await testDataExportImport()
      setTestLogs((prev) => [
        ...prev,
        `اختبار تصدير واستيراد البيانات: ${exportImportResult.success ? "ناجح ✅" : "فاشل ❌"}`,
      ])

      // اختبار شامل
      setTestLogs((prev) => [...prev, "تجميع نتائج الاختبارات..."])
      setTestProgress(90)
      const fullResult = await runFullSystemTest()
      setTestResults(fullResult)
      setTestLogs((prev) => [...prev, `اكتمل الاختبار الشامل: ${fullResult.success ? "ناجح ✅" : "فاشل ❌"}`])
      setTestProgress(100)

      toast({
        title: fullResult.success ? "تم اجتياز الاختبار الشامل بنجاح" : "فشل في بعض الاختبارات",
        description: fullResult.message,
        variant: fullResult.success ? "default" : "destructive",
      })
    } catch (error) {
      console.error("خطأ في تنفيذ الاختبار الشامل:", error)
      setTestLogs((prev) => [...prev, `خطأ: ${error.message}`])
      toast({
        title: "فشل الاختبار",
        description: `حدث خطأ أثناء تنفيذ الاختبار: ${error.message}`,
        variant: "destructive",
      })
    } finally {
      setIsRunningTest(false)
      setTestEndTime(new Date())
    }
  }

  // حساب مدة الاختبار
  const getTestDuration = () => {
    if (!testStartTime || !testEndTime) return "غير متاح"
    const durationMs = testEndTime.getTime() - testStartTime.getTime()
    const seconds = Math.floor(durationMs / 1000)
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    return `${minutes}:${remainingSeconds.toString().padStart(2, "0")}`
  }

  // عرض نتائج الاختبار
  const renderTestResults = () => {
    if (!testResults) return null

    return (
      <div className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className={`border-2 ${testResults.success ? "border-green-500" : "border-red-500"}`}>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">النتيجة الإجمالية</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center">
                {testResults.success ? (
                  <CheckCircle className="h-12 w-12 text-green-500" />
                ) : (
                  <XCircle className="h-12 w-12 text-red-500" />
                )}
              </div>
              <p className="text-center mt-2">
                {testResults.passedTests} / {testResults.totalTests} اختبار ناجح
              </p>
              <p className="text-center text-sm text-gray-500">
                ({((testResults.passedTests / testResults.totalTests) * 100).toFixed(2)}%)
              </p>
            </CardContent>
            <CardFooter className="flex justify-center">
              <div className="text-sm text-gray-500">مدة الاختبار: {getTestDuration()}</div>
            </CardFooter>
          </Card>

          <Card className="col-span-2">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">تفاصيل الاختبارات</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="text-right p-2">الاختبار</th>
                      <th className="text-right p-2">النتيجة</th>
                      <th className="text-right p-2">الرسالة</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Object.entries(testResults.results).map(([testName, result]) => (
                      <tr key={testName} className="border-t">
                        <td className="p-2">{getTestName(testName)}</td>
                        <td className="p-2">
                          {result.success ? (
                            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                              ناجح
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                              فاشل
                            </Badge>
                          )}
                        </td>
                        <td className="p-2 text-sm">{result.message}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* عرض تفاصيل اختبار حساب الرصيد النهائي */}
        {testResults.results.balanceCalculation && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Database className="h-5 w-5 ml-2" />
                تفاصيل اختبار حساب الرصيد النهائي
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h3 className="font-medium mb-2">المعادلة المستخدمة:</h3>
                  <div className="bg-gray-50 p-3 rounded-md">
                    <p className="font-mono">الرصيد النهائي = رصيد بداية المدة + الوارد - المنصرف + المرتجع</p>
                  </div>
                </div>
                <div>
                  <h3 className="font-medium mb-2">نتيجة الاختبار:</h3>
                  <div
                    className={`p-3 rounded-md ${
                      testResults.results.balanceCalculation.success ? "bg-green-50" : "bg-red-50"
                    }`}
                  >
                    <p>
                      <strong>القيمة المتوقعة:</strong> {testResults.results.balanceCalculation.expected}
                    </p>
                    <p>
                      <strong>القيمة المحسوبة:</strong> {testResults.results.balanceCalculation.calculated}
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    )
  }

  // الحصول على اسم الاختبار
  const getTestName = (testType: string) => {
    switch (testType) {
      case "balanceCalculation":
        return "حساب الرصيد النهائي"
      case "customerManagement":
        return "إدارة العملاء"
      case "materialManagement":
        return "إدارة الأصناف"
      case "inventoryManagement":
        return "إدارة المخزون"
      case "productionOrderManagement":
        return "إدارة أوامر التشغيل"
      case "separationsManagement":
        return "إدارة المنفصلات"
      case "deliveryStatementManagement":
        return "إدارة بيانات التسليم"
      case "dataExportImport":
        return "تصدير واستيراد البيانات"
      default:
        return testType
    }
  }

  // الحصول على أيقونة الاختبار
  const getTestIcon = (testType: string) => {
    switch (testType) {
      case "balanceCalculation":
        return <Database className="h-5 w-5" />
      case "customerManagement":
        return <Users className="h-5 w-5" />
      case "materialManagement":
        return <Package className="h-5 w-5" />
      case "inventoryManagement":
        return <Database className="h-5 w-5" />
      case "productionOrderManagement":
        return <ClipboardList className="h-5 w-5" />
      case "separationsManagement":
        return <Scissors className="h-5 w-5" />
      case "deliveryStatementManagement":
        return <TruckIcon className="h-5 w-5" />
      case "dataExportImport":
        return <FileDown className="h-5 w-5" />
      default:
        return <BarChart3 className="h-5 w-5" />
    }
  }

  return (
    <PageLayout title="اختبار شامل للنظام">
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
          <h1 className="text-2xl font-bold text-gray-900 mb-4 sm:mb-0">اختبار شامل للنظام بعد التصحيح</h1>
          <Button onClick={runComprehensiveTest} disabled={isRunningTest} className="flex items-center">
            {isRunningTest ? (
              <>
                <RefreshCw className="h-4 w-4 ml-2 animate-spin" />
                جاري الاختبار...
              </>
            ) : (
              <>
                <Play className="h-4 w-4 ml-2" />
                تشغيل الاختبار الشامل
              </>
            )}
          </Button>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-2 md:grid-cols-3 mb-4">
            <TabsTrigger value="dashboard">لوحة المعلومات</TabsTrigger>
            <TabsTrigger value="details">تفاصيل الاختبارات</TabsTrigger>
            <TabsTrigger value="logs">سجل الاختبار</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-4">
            {isRunningTest && (
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">تقدم الاختبار</CardTitle>
                </CardHeader>
                <CardContent>
                  <Progress value={testProgress} className="h-2" />
                  <p className="text-center mt-2 text-sm text-gray-500">{testProgress}%</p>
                </CardContent>
              </Card>
            )}

            {renderTestResults()}

            {!testResults && !isRunningTest && (
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>لم يتم تشغيل الاختبار بعد</AlertTitle>
                <AlertDescription>اضغط على زر "تشغيل الاختبار الشامل" لبدء الاختبار</AlertDescription>
              </Alert>
            )}
          </TabsContent>

          <TabsContent value="details" className="space-y-4">
            {testResults ? (
              <div className="space-y-4">
                {Object.entries(testResults.results).map(([testName, result]) => (
                  <Card key={testName}>
                    <CardHeader className="pb-2">
                      <CardTitle className="flex items-center">
                        {getTestIcon(testName)}
                        <span className="mr-2">{getTestName(testName)}</span>
                        {result.success ? (
                          <Badge variant="outline" className="mr-auto bg-green-50 text-green-700 border-green-200">
                            ناجح
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="mr-auto bg-red-50 text-red-700 border-red-200">
                            فاشل
                          </Badge>
                        )}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p>{result.message}</p>
                      {result.expected !== undefined && (
                        <div className="mt-2 p-3 bg-gray-50 rounded-md">
                          <p>
                            <strong>القيمة المتوقعة:</strong> {result.expected}
                          </p>
                          <p>
                            <strong>القيمة المحسوبة:</strong> {result.calculated}
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>لم يتم تشغيل الاختبار بعد</AlertTitle>
                <AlertDescription>اضغط على زر "تشغيل الاختبار الشامل" لبدء الاختبار</AlertDescription>
              </Alert>
            )}
          </TabsContent>

          <TabsContent value="logs">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">سجل الاختبار</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-gray-900 text-gray-100 p-4 rounded-md h-96 overflow-y-auto font-mono text-sm">
                  {testLogs.map((log, index) => (
                    <div key={index} className="mb-1">
                      {log}
                    </div>
                  ))}
                  {isRunningTest && <div className="animate-pulse">جاري التنفيذ...</div>}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {testResults && testResults.success && (
          <Alert className="bg-green-50 border-green-200">
            <CheckCircle className="h-4 w-4 text-green-500" />
            <AlertTitle>تم اجتياز جميع الاختبارات بنجاح</AlertTitle>
            <AlertDescription>
              تم التحقق من جميع وظائف النظام وتأكيد أنها تعمل بشكل صحيح بعد تصحيح معادلة الرصيد النهائي.
            </AlertDescription>
          </Alert>
        )}

        {testResults && !testResults.success && (
          <Alert variant="destructive">
            <XCircle className="h-4 w-4" />
            <AlertTitle>فشل في بعض الاختبارات</AlertTitle>
            <AlertDescription>يرجى مراجعة تفاصيل الاختبارات لمعرفة المشاكل التي تحتاج إلى إصلاح.</AlertDescription>
          </Alert>
        )}
      </div>
    </PageLayout>
  )
}
