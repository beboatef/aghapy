"use client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { PageLayout } from "@/components/page-layout"
import Link from "next/link"
import {
  Database,
  BarChart3,
  FileText,
  ArrowRight,
  Calculator,
  ClipboardList,
  Users,
  Package,
  Truck,
  Scissors,
} from "lucide-react"

export default function SystemTestPage() {
  return (
    <PageLayout title="اختبار النظام">
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
          <h1 className="text-2xl font-bold text-gray-900 mb-4 sm:mb-0">اختبار النظام</h1>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <ClipboardList className="h-5 w-5 ml-2" />
                اختبار شامل للنظام
              </CardTitle>
              <CardDescription>
                اختبار شامل لجميع وظائف النظام للتأكد من أنها تعمل بشكل صحيح بعد تصحيح معادلة الرصيد النهائي
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p>
                يقوم هذا الاختبار بفحص جميع وظائف النظام بما في ذلك إدارة العملاء، الأصناف، المخزون، أوامر التشغيل،
                المنفصلات، بيانات التسليم، وتصدير واستيراد البيانات.
              </p>
            </CardContent>
            <CardFooter>
              <Link href="/system-test/comprehensive-test" className="w-full">
                <Button className="w-full">
                  بدء الاختبار الشامل
                  <ArrowRight className="h-4 w-4 mr-2" />
                </Button>
              </Link>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Calculator className="h-5 w-5 ml-2" />
                التحقق من حساب الأرصدة
              </CardTitle>
              <CardDescription>التحقق من صحة حساب الرصيد النهائي وفقاً للمعادلة المصححة</CardDescription>
            </CardHeader>
            <CardContent>
              <p>
                يقوم هذا الاختبار بالتحقق من صحة حساب الرصيد النهائي وفقاً للمعادلة الصحيحة:
                <br />
                <strong>الرصيد النهائي = رصيد بداية المدة + الوارد - المنصرف + المرتجع</strong>
              </p>
            </CardContent>
            <CardFooter>
              <Link href="/system-test/balance-verification" className="w-full">
                <Button variant="outline" className="w-full">
                  التحقق من الأرصدة
                  <ArrowRight className="h-4 w-4 mr-2" />
                </Button>
              </Link>
            </CardFooter>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>اختبارات الوظائف الفردية</CardTitle>
            <CardDescription>اختبار كل وظيفة من وظائف النظام بشكل منفصل</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              <Button variant="outline" className="justify-start h-auto py-3">
                <Database className="h-4 w-4 ml-2" />
                <div className="text-right">
                  <div>اختبار حساب الرصيد النهائي</div>
                  <div className="text-xs text-gray-500">التحقق من صحة المعادلة</div>
                </div>
              </Button>

              <Button variant="outline" className="justify-start h-auto py-3">
                <Users className="h-4 w-4 ml-2" />
                <div className="text-right">
                  <div>اختبار إدارة العملاء</div>
                  <div className="text-xs text-gray-500">إضافة، تعديل، حذف العملاء</div>
                </div>
              </Button>

              <Button variant="outline" className="justify-start h-auto py-3">
                <Package className="h-4 w-4 ml-2" />
                <div className="text-right">
                  <div>اختبار إدارة الأصناف</div>
                  <div className="text-xs text-gray-500">إضافة، تعديل، حذف الأصناف</div>
                </div>
              </Button>

              <Button variant="outline" className="justify-start h-auto py-3">
                <Database className="h-4 w-4 ml-2" />
                <div className="text-right">
                  <div>اختبار إدارة المخزون</div>
                  <div className="text-xs text-gray-500">إضافة، تعديل حركات المخزون</div>
                </div>
              </Button>

              <Button variant="outline" className="justify-start h-auto py-3">
                <ClipboardList className="h-4 w-4 ml-2" />
                <div className="text-right">
                  <div>اختبار أوامر التشغيل</div>
                  <div className="text-xs text-gray-500">إنشاء، تعديل، متابعة أوامر التشغيل</div>
                </div>
              </Button>

              <Button variant="outline" className="justify-start h-auto py-3">
                <Scissors className="h-4 w-4 ml-2" />
                <div className="text-right">
                  <div>اختبار إدارة المنفصلات</div>
                  <div className="text-xs text-gray-500">تسجيل ومتابعة منفصلات الإنتاج</div>
                </div>
              </Button>

              <Button variant="outline" className="justify-start h-auto py-3">
                <Truck className="h-4 w-4 ml-2" />
                <div className="text-right">
                  <div>اختبار بيانات التسليم</div>
                  <div className="text-xs text-gray-500">إنشاء ومتابعة بيانات التسليم</div>
                </div>
              </Button>

              <Button variant="outline" className="justify-start h-auto py-3">
                <FileText className="h-4 w-4 ml-2" />
                <div className="text-right">
                  <div>اختبار التصدير والاستيراد</div>
                  <div className="text-xs text-gray-500">تصدير واستيراد بيانات النظام</div>
                </div>
              </Button>

              <Button variant="outline" className="justify-start h-auto py-3">
                <BarChart3 className="h-4 w-4 ml-2" />
                <div className="text-right">
                  <div>اختبار التقارير</div>
                  <div className="text-xs text-gray-500">إنشاء وعرض تقارير النظام</div>
                </div>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  )
}
