"use client"

import { useState, useEffect } from "react"
import { PageLayout } from "@/components/page-layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from "recharts"
import { DollarSign, TrendingUp, Package, Zap, Calendar, Download, Filter, PieChartIcon, BarChart3 } from "lucide-react"
import { dataManager } from "@/lib/data-manager"

type ProductionOrder = {
  id: number
  orderNumber: string
  customerName: string
  materialName: string
  quantity: number
  finalQuantity: number
  unit: string
  status: string
  date: string
  materialsUsed: any[]
  totalMaterialsCost: number
  costPerUnit: number
  costsCalculated: boolean
}

type MaterialIssuance = {
  id: string
  productionOrderId: number
  productionOrderNumber: string
  date: string
  materials: any[]
  totalCost: number
  status: string
}

type IndirectCost = {
  id: string
  categoryId: string
  categoryName: string
  date: string
  amount: number
  description: string
}

type DailyCostSummary = {
  date: string
  directCosts: number
  indirectCosts: number
  totalCosts: number
  productionOrders: number
}

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8", "#82CA9D", "#FFC658"]

export default function ProductionCostReportsPage() {
  const [productionOrders, setProductionOrders] = useState<ProductionOrder[]>([])
  const [materialIssuances, setMaterialIssuances] = useState<MaterialIssuance[]>([])
  const [indirectCosts, setIndirectCosts] = useState<IndirectCost[]>([])
  const [activeTab, setActiveTab] = useState("daily-summary")
  const [selectedPeriod, setSelectedPeriod] = useState("week")
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split("T")[0])

  useEffect(() => {
    loadData()
  }, [])

  const loadData = () => {
    const orders = dataManager.getData("productionOrders", [])
    const issuances = dataManager.getData("materialIssuances", [])
    const costs = dataManager.getData("indirectCosts", [])

    setProductionOrders(orders)
    setMaterialIssuances(issuances)
    setIndirectCosts(costs)
  }

  // Get daily cost summary
  const getDailyCostSummary = (date: string): DailyCostSummary => {
    const dayIssuances = materialIssuances.filter((issuance) => issuance.date === date)
    const dayIndirectCosts = indirectCosts.filter((cost) => cost.date === date)
    const dayOrders = productionOrders.filter((order) => order.date === date)

    const directCosts = dayIssuances.reduce((sum, issuance) => sum + issuance.totalCost, 0)
    const indirectCostsTotal = dayIndirectCosts.reduce((sum, cost) => sum + cost.amount, 0)

    return {
      date,
      directCosts,
      indirectCosts: indirectCostsTotal,
      totalCosts: directCosts + indirectCostsTotal,
      productionOrders: dayOrders.length,
    }
  }

  // Get period data
  const getPeriodData = (period: string) => {
    const today = new Date()
    const dates: string[] = []

    if (period === "week") {
      for (let i = 6; i >= 0; i--) {
        const date = new Date(today.getTime() - i * 24 * 60 * 60 * 1000)
        dates.push(date.toISOString().split("T")[0])
      }
    } else if (period === "month") {
      for (let i = 29; i >= 0; i--) {
        const date = new Date(today.getTime() - i * 24 * 60 * 60 * 1000)
        dates.push(date.toISOString().split("T")[0])
      }
    }

    return dates.map((date) => getDailyCostSummary(date))
  }

  // Get today's summary
  const getTodaySummary = () => {
    return getDailyCostSummary(new Date().toISOString().split("T")[0])
  }

  // Get week summary
  const getWeekSummary = () => {
    const weekData = getPeriodData("week")
    return {
      directCosts: weekData.reduce((sum, day) => sum + day.directCosts, 0),
      indirectCosts: weekData.reduce((sum, day) => sum + day.indirectCosts, 0),
      totalCosts: weekData.reduce((sum, day) => sum + day.totalCosts, 0),
      productionOrders: weekData.reduce((sum, day) => sum + day.productionOrders, 0),
    }
  }

  // Get indirect costs breakdown
  const getIndirectCostsBreakdown = (period: string) => {
    const today = new Date()
    let startDate: Date

    if (period === "today") {
      startDate = today
    } else if (period === "week") {
      startDate = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000)
    } else {
      startDate = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000)
    }

    const filteredCosts = indirectCosts.filter((cost) => {
      const costDate = new Date(cost.date)
      return costDate >= startDate && costDate <= today
    })

    const breakdown = filteredCosts.reduce(
      (acc, cost) => {
        const existing = acc.find((item) => item.category === cost.categoryName)
        if (existing) {
          existing.amount += cost.amount
        } else {
          acc.push({
            category: cost.categoryName,
            amount: cost.amount,
          })
        }
        return acc
      },
      [] as { category: string; amount: number }[],
    )

    return breakdown.sort((a, b) => b.amount - a.amount)
  }

  // Get production orders with costs
  const getProductionOrdersWithCosts = () => {
    return productionOrders
      .filter((order) => order.costsCalculated)
      .map((order) => {
        const orderDate = order.date
        const dayIndirectCosts = indirectCosts.filter((cost) => cost.date === orderDate)
        const totalIndirectCosts = dayIndirectCosts.reduce((sum, cost) => sum + cost.amount, 0)
        const dayOrders = productionOrders.filter((o) => o.date === orderDate && o.costsCalculated)
        const indirectCostPerOrder = dayOrders.length > 0 ? totalIndirectCosts / dayOrders.length : 0

        return {
          ...order,
          indirectCostAllocation: indirectCostPerOrder,
          totalCostWithIndirect: order.totalMaterialsCost + indirectCostPerOrder,
          costPerUnitWithIndirect:
            order.finalQuantity > 0 ? (order.totalMaterialsCost + indirectCostPerOrder) / order.finalQuantity : 0,
        }
      })
  }

  const todaySummary = getTodaySummary()
  const weekSummary = getWeekSummary()
  const periodData = getPeriodData(selectedPeriod)
  const indirectBreakdown = getIndirectCostsBreakdown("week")
  const ordersWithCosts = getProductionOrdersWithCosts()

  return (
    <PageLayout title="تقارير تكاليف الإنتاج الشاملة">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4 mb-6">
          <TabsTrigger value="daily-summary">الملخص اليومي</TabsTrigger>
          <TabsTrigger value="cost-analysis">تحليل التكاليف</TabsTrigger>
          <TabsTrigger value="production-orders">أوامر الإنتاج</TabsTrigger>
          <TabsTrigger value="charts">الرسوم البيانية</TabsTrigger>
        </TabsList>

        <TabsContent value="daily-summary">
          <div className="space-y-6">
            {/* Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Package className="h-5 w-5 text-blue-600" />
                    التكاليف المباشرة - اليوم
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-blue-600">{todaySummary.directCosts.toFixed(2)} ج.م</div>
                  <div className="text-sm text-gray-500">مواد الصباغة والتجهيز</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="h-5 w-5 text-orange-600" />
                    التكاليف غير المباشرة - اليوم
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-orange-600">{todaySummary.indirectCosts.toFixed(2)} ج.م</div>
                  <div className="text-sm text-gray-500">كهرباء، مياه، غاز، إلخ</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="h-5 w-5 text-green-600" />
                    إجمالي التكاليف - اليوم
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">{todaySummary.totalCosts.toFixed(2)} ج.م</div>
                  <div className="text-sm text-gray-500">مباشرة + غير مباشرة</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-purple-600" />
                    أوامر الإنتاج - اليوم
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-purple-600">{todaySummary.productionOrders}</div>
                  <div className="text-sm text-gray-500">أمر تشغيل</div>
                </CardContent>
              </Card>
            </div>

            {/* Weekly Summary */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  ملخص الأسبوع
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  <div className="text-center">
                    <div className="text-xl font-bold text-blue-600">{weekSummary.directCosts.toFixed(2)} ج.م</div>
                    <div className="text-sm text-gray-500">التكاليف المباشرة</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-bold text-orange-600">{weekSummary.indirectCosts.toFixed(2)} ج.م</div>
                    <div className="text-sm text-gray-500">التكاليف غير المباشرة</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-bold text-green-600">{weekSummary.totalCosts.toFixed(2)} ج.م</div>
                    <div className="text-sm text-gray-500">إجمالي التكاليف</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-bold text-purple-600">{weekSummary.productionOrders}</div>
                    <div className="text-sm text-gray-500">أوامر الإنتاج</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Daily Breakdown */}
            <Card>
              <CardHeader>
                <CardTitle>التفصيل اليومي - آخر 7 أيام</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>التاريخ</TableHead>
                        <TableHead className="text-right">التكاليف المباشرة</TableHead>
                        <TableHead className="text-right">التكاليف غير المباشرة</TableHead>
                        <TableHead className="text-right">الإجمالي</TableHead>
                        <TableHead className="text-right">أوامر الإنتاج</TableHead>
                        <TableHead className="text-right">متوسط التكلفة/أمر</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {periodData.slice(-7).map((day) => (
                        <TableRow key={day.date}>
                          <TableCell>{day.date}</TableCell>
                          <TableCell className="text-right text-blue-600 font-medium">
                            {day.directCosts.toFixed(2)} ج.م
                          </TableCell>
                          <TableCell className="text-right text-orange-600 font-medium">
                            {day.indirectCosts.toFixed(2)} ج.م
                          </TableCell>
                          <TableCell className="text-right text-green-600 font-bold">
                            {day.totalCosts.toFixed(2)} ج.م
                          </TableCell>
                          <TableCell className="text-right">{day.productionOrders}</TableCell>
                          <TableCell className="text-right">
                            {day.productionOrders > 0 ? (day.totalCosts / day.productionOrders).toFixed(2) : "0.00"} ج.م
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="cost-analysis">
          <div className="space-y-6">
            {/* Cost Breakdown */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>تفصيل التكاليف غير المباشرة - الأسبوع</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {indirectBreakdown.map((item, index) => {
                      const total = indirectBreakdown.reduce((sum, i) => sum + i.amount, 0)
                      const percentage = total > 0 ? (item.amount / total) * 100 : 0
                      return (
                        <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                          <div>
                            <div className="font-medium">{item.category}</div>
                            <div className="text-sm text-gray-500">{percentage.toFixed(1)}%</div>
                          </div>
                          <div className="text-right">
                            <div className="font-bold text-blue-600">{item.amount.toFixed(2)} ج.م</div>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>نسبة التكاليف</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-blue-50 rounded">
                      <div>
                        <div className="font-medium text-blue-800">التكاليف المباشرة</div>
                        <div className="text-sm text-blue-600">مواد الصباغة والتجهيز</div>
                      </div>
                      <div className="text-right">
                        <div className="text-xl font-bold text-blue-600">{weekSummary.directCosts.toFixed(2)} ج.م</div>
                        <div className="text-sm text-blue-500">
                          {weekSummary.totalCosts > 0
                            ? ((weekSummary.directCosts / weekSummary.totalCosts) * 100).toFixed(1)
                            : "0"}
                          %
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-orange-50 rounded">
                      <div>
                        <div className="font-medium text-orange-800">التكاليف غير المباشرة</div>
                        <div className="text-sm text-orange-600">كهرباء، مياه، غاز، إلخ</div>
                      </div>
                      <div className="text-right">
                        <div className="text-xl font-bold text-orange-600">
                          {weekSummary.indirectCosts.toFixed(2)} ج.م
                        </div>
                        <div className="text-sm text-orange-500">
                          {weekSummary.totalCosts > 0
                            ? ((weekSummary.indirectCosts / weekSummary.totalCosts) * 100).toFixed(1)
                            : "0"}
                          %
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-green-50 rounded border-2 border-green-200">
                      <div>
                        <div className="font-medium text-green-800">إجمالي التكاليف</div>
                        <div className="text-sm text-green-600">مباشرة + غير مباشرة</div>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-green-600">{weekSummary.totalCosts.toFixed(2)} ج.م</div>
                        <div className="text-sm text-green-500">100%</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="production-orders">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>أوامر الإنتاج مع التكاليف الشاملة</CardTitle>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  <Filter className="h-4 w-4 mr-2" />
                  تصفية
                </Button>
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  تصدير
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>رقم الأمر</TableHead>
                      <TableHead>العميل</TableHead>
                      <TableHead>المادة</TableHead>
                      <TableHead className="text-right">الكمية</TableHead>
                      <TableHead className="text-right">التكلفة المباشرة</TableHead>
                      <TableHead className="text-right">التكلفة غير المباشرة</TableHead>
                      <TableHead className="text-right">إجمالي التكلفة</TableHead>
                      <TableHead className="text-right">تكلفة الوحدة</TableHead>
                      <TableHead>الحالة</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {ordersWithCosts.map((order) => (
                      <TableRow key={order.id}>
                        <TableCell className="font-mono">{order.orderNumber}</TableCell>
                        <TableCell>{order.customerName}</TableCell>
                        <TableCell>{order.materialName}</TableCell>
                        <TableCell className="text-right">
                          {order.finalQuantity} {order.unit}
                        </TableCell>
                        <TableCell className="text-right text-blue-600 font-medium">
                          {order.totalMaterialsCost.toFixed(2)} ج.م
                        </TableCell>
                        <TableCell className="text-right text-orange-600 font-medium">
                          {order.indirectCostAllocation.toFixed(2)} ج.م
                        </TableCell>
                        <TableCell className="text-right text-green-600 font-bold">
                          {order.totalCostWithIndirect.toFixed(2)} ج.م
                        </TableCell>
                        <TableCell className="text-right text-purple-600 font-medium">
                          {order.costPerUnitWithIndirect.toFixed(2)} ج.م
                        </TableCell>
                        <TableCell>
                          <Badge variant={order.status === "completed" ? "default" : "secondary"}>
                            {order.status === "completed" ? "مكتمل" : "قيد التشغيل"}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="charts">
          <div className="space-y-6">
            {/* Period Selection */}
            <Card>
              <CardHeader>
                <CardTitle>إعدادات الرسوم البيانية</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex gap-4">
                  <div>
                    <Label>الفترة الزمنية</Label>
                    <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                      <SelectTrigger className="w-40">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="week">آخر 7 أيام</SelectItem>
                        <SelectItem value="month">آخر 30 يوم</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Daily Costs Chart */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5" />
                    التكاليف اليومية
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={periodData.slice(-7)}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="directCosts" fill="#3B82F6" name="التكاليف المباشرة" />
                      <Bar dataKey="indirectCosts" fill="#F97316" name="التكاليف غير المباشرة" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Cost Distribution Pie Chart */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <PieChartIcon className="h-5 w-5" />
                    توزيع التكاليف غير المباشرة
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={indirectBreakdown}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ category, amount }) => `${category}: ${amount.toFixed(0)} ج.م`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="amount"
                      >
                        {indirectBreakdown.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Trend Line Chart */}
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    اتجاه التكاليف
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={400}>
                    <LineChart data={periodData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line
                        type="monotone"
                        dataKey="directCosts"
                        stroke="#3B82F6"
                        strokeWidth={2}
                        name="التكاليف المباشرة"
                      />
                      <Line
                        type="monotone"
                        dataKey="indirectCosts"
                        stroke="#F97316"
                        strokeWidth={2}
                        name="التكاليف غير المباشرة"
                      />
                      <Line
                        type="monotone"
                        dataKey="totalCosts"
                        stroke="#10B981"
                        strokeWidth={3}
                        name="إجمالي التكاليف"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </PageLayout>
  )
}
