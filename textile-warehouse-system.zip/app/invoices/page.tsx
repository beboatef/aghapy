"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  FileText,
  Plus,
  Search,
  Download,
  Printer,
  Eye,
  CheckCircle,
  Trash2,
  Edit,
  AlertTriangle,
  X,
  Filter,
  Calendar,
} from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { useCustomers, useMaterials } from "@/hooks/use-data"
import { useAuth } from "@/hooks/use-auth"
import { Navbar } from "@/components/navbar"

interface Customer {
  id: number
  code: string
  name: string
}

interface Material {
  id: number
  code: string
  name: string
  unit: string
}

interface ProductionOrder {
  id: number
  orderNumber: string
  customerId: number
  customerName: string
  materialId: number
  materialName: string
  quantity: number
  unit: string
  status: "in_production" | "completed"
  separationsQuantity?: number
}

interface DeliveryItem {
  id: number
  productionOrderId: number
  productionOrderNumber: string
  materialId: number
  materialName: string
  color: string
  originalQuantity: number
  readyQuantityKg: number
  readyQuantityMeter: number
  rollsCount: number
  unit: string
  notes?: string
}

interface DeliveryStatement {
  id: number
  statementNumber: number
  date: string
  customerId: number
  customerName: string
  items: DeliveryItem[]
  notes?: string
  createdAt: string
  status: "pending" | "delivered"
  deliveredAt?: string
}

export default function DeliveryStatementsPage() {
  const [showStatementDialog, setShowStatementDialog] = useState(false)
  const [showStatementPreviewDialog, setShowStatementPreviewDialog] = useState(false)
  const [showDeliveryDialog, setShowDeliveryDialog] = useState(false)
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [dateFilter, setDateFilter] = useState("")
  const [customerFilter, setCustomerFilter] = useState("all_customers")
  const [statusFilter, setStatusFilter] = useState("all_status")
  const [selectedStatement, setSelectedStatement] = useState<DeliveryStatement | null>(null)
  const [editMode, setEditMode] = useState(false)

  // بيانات محاكاة
  const { customers } = useCustomers()
  const { materials } = useMaterials()
  const { isAdmin, canDelete, logout } = useAuth()

  // أوامر التشغيل المكتملة
  const productionOrders: ProductionOrder[] = [
    {
      id: 1,
      orderNumber: "PO001",
      customerId: 1,
      customerName: "شركة النسيج المتحدة",
      materialId: 1,
      materialName: "قطن أبيض خام",
      quantity: 150,
      unit: "كجم",
      status: "completed",
      separationsQuantity: 5,
    },
    {
      id: 2,
      orderNumber: "PO002",
      customerId: 2,
      customerName: "مصنع الألوان الحديث",
      materialId: 2,
      materialName: "بوليستر أزرق",
      quantity: 75,
      unit: "متر",
      status: "completed",
      separationsQuantity: 3,
    },
    {
      id: 3,
      orderNumber: "PO003",
      customerId: 3,
      customerName: "شركة القطن السعودي",
      materialId: 3,
      materialName: "قطن ملون",
      quantity: 100,
      unit: "كجم",
      status: "completed",
      separationsQuantity: 2,
    },
    {
      id: 4,
      orderNumber: "PO004",
      customerId: 1,
      customerName: "شركة النسيج المتحدة",
      materialId: 1,
      materialName: "قطن أبيض خام",
      quantity: 200,
      unit: "كجم",
      status: "completed",
      separationsQuantity: 8,
    },
  ]

  const [statements, setStatements] = useState<DeliveryStatement[]>([
    {
      id: 1,
      statementNumber: 1001,
      date: "2024-03-05",
      customerId: 1,
      customerName: "شركة النسيج المتحدة",
      items: [
        {
          id: 1,
          productionOrderId: 1,
          productionOrderNumber: "PO001",
          materialId: 1,
          materialName: "قطن أبيض خام",
          color: "أزرق",
          originalQuantity: 145,
          readyQuantityKg: 140,
          readyQuantityMeter: 280,
          rollsCount: 3,
          unit: "كجم",
          notes: "تم التجهيز بنجاح",
        },
        {
          id: 2,
          productionOrderId: 4,
          productionOrderNumber: "PO004",
          materialId: 1,
          materialName: "قطن أبيض خام",
          color: "أحمر",
          originalQuantity: 192,
          readyQuantityKg: 190,
          readyQuantityMeter: 380,
          rollsCount: 4,
          unit: "كجم",
          notes: "تم تخفيض الكمية بسبب عيب في النسيج",
        },
      ],
      notes: "بيان تسليم للعميل",
      createdAt: "2024-03-05",
      status: "delivered",
      deliveredAt: "2024-03-06",
    },
    {
      id: 2,
      statementNumber: 1002,
      date: "2024-03-07",
      customerId: 2,
      customerName: "مصنع الألوان الحديث",
      items: [
        {
          id: 3,
          productionOrderId: 2,
          productionOrderNumber: "PO002",
          materialId: 2,
          materialName: "بوليستر أزرق",
          color: "أحمر",
          originalQuantity: 72,
          readyQuantityKg: 36,
          readyQuantityMeter: 70,
          rollsCount: 2,
          unit: "متر",
          notes: "تم التجهيز بنجاح",
        },
      ],
      notes: "بيان تسليم للعميل",
      createdAt: "2024-03-07",
      status: "pending",
    },
  ])

  const [statementFormData, setStatementFormData] = useState({
    date: new Date().toISOString().split("T")[0],
    customerId: "",
    notes: "",
    items: [] as {
      productionOrderId: number
      productionOrderNumber: string
      materialName: string
      unit: string
      originalQuantity: number
      color: string
      readyQuantityKg: number
      readyQuantityMeter: number
      rollsCount: number
      notes: string
    }[],
  })

  const [currentItemFormData, setCurrentItemFormData] = useState({
    productionOrderId: 0,
    color: "",
    readyQuantityKg: 0,
    readyQuantityMeter: 0,
    rollsCount: 1,
    notes: "",
  })

  // فلترة بيانات التسليم
  const filteredStatements = statements.filter((statement) => {
    const matchesSearch =
      statement.statementNumber.toString().includes(searchTerm) ||
      statement.customerName.includes(searchTerm) ||
      statement.items.some(
        (item) => item.productionOrderNumber.includes(searchTerm) || item.materialName.includes(searchTerm),
      )
    const matchesDate = dateFilter === "" || statement.date === dateFilter
    const matchesCustomer = customerFilter === "all_customers" || statement.customerId.toString() === customerFilter
    const matchesStatus = statusFilter === "all_status" || statement.status === statusFilter

    return matchesSearch && matchesDate && matchesCustomer && matchesStatus
  })

  // حذف بيان تسليم
  const handleDeleteStatement = () => {
    if (selectedStatement) {
      setStatements(statements.filter((statement) => statement.id !== selectedStatement.id))
      setShowDeleteDialog(false)
      setSelectedStatement(null)
      toast({
        title: "تم الحذف",
        description: `تم حذف بيان التسليم رقم ${selectedStatement.statementNumber} بنجاح`,
      })
    }
  }

  // فتح نافذة تأكيد الحذف
  const openDeleteDialog = (statement: DeliveryStatement) => {
    setSelectedStatement(statement)
    setShowDeleteDialog(true)
  }

  // فتح نافذة إضافة بيان تسليم
  const handleOpenStatementDialog = () => {
    setStatementFormData({
      date: new Date().toISOString().split("T")[0],
      customerId: "",
      notes: "",
      items: [],
    })
    setCurrentItemFormData({
      productionOrderId: 0,
      color: "",
      readyQuantityKg: 0,
      readyQuantityMeter: 0,
      rollsCount: 1,
      notes: "",
    })
    setEditMode(false)
    setShowStatementDialog(true)
  }

  // الحصول على أوامر التشغيل المكتملة للعميل المحدد
  const getFilteredOrders = () => {
    if (!statementFormData.customerId) return []

    const usedOrderIds = statementFormData.items.map((item) => item.productionOrderId)

    return productionOrders.filter(
      (order) =>
        order.customerId === Number.parseInt(statementFormData.customerId) &&
        order.status === "completed" &&
        !usedOrderIds.includes(order.id),
    )
  }

  // تعديل دالة handleSelectProductionOrder لإظهار أصل الخام
  const handleSelectProductionOrder = (orderId: string) => {
    const selectedOrder = productionOrders.find((order) => order.id === Number.parseInt(orderId))
    if (!selectedOrder) return

    setCurrentItemFormData({
      ...currentItemFormData,
      productionOrderId: selectedOrder.id,
    })
  }

  // تعديل دالة handleAddOrderToStatement لإزالة الحساب التلقائي للكمية بالمتر
  const handleAddOrderToStatement = () => {
    if (currentItemFormData.productionOrderId === 0) {
      toast({
        title: "خطأ",
        description: "يرجى اختيار أمر تشغيل",
        variant: "destructive",
      })
      return
    }

    if (!currentItemFormData.color.trim()) {
      toast({
        title: "خطأ",
        description: "يرجى إدخال اللون",
        variant: "destructive",
      })
      return
    }

    if (currentItemFormData.readyQuantityKg <= 0) {
      toast({
        title: "خطأ",
        description: "يرجى إدخال الكمية الجاهزة بالكيلوجرام",
        variant: "destructive",
      })
      return
    }

    const selectedOrder = productionOrders.find((order) => order.id === currentItemFormData.productionOrderId)
    if (!selectedOrder) return

    // حساب الكمية المتاحة بعد فصل المنفصلات
    const availableQuantity = selectedOrder.quantity - (selectedOrder.separationsQuantity || 0)

    const newItem = {
      productionOrderId: currentItemFormData.productionOrderId,
      productionOrderNumber: selectedOrder.orderNumber,
      materialName: selectedOrder.materialName,
      unit: selectedOrder.unit,
      originalQuantity: availableQuantity,
      color: currentItemFormData.color,
      readyQuantityKg: currentItemFormData.readyQuantityKg,
      readyQuantityMeter: currentItemFormData.readyQuantityMeter,
      rollsCount: currentItemFormData.rollsCount,
      notes: currentItemFormData.notes,
    }

    setStatementFormData({
      ...statementFormData,
      items: [...statementFormData.items, newItem],
    })

    // إعادة تعيين نموذج العنصر الحالي
    setCurrentItemFormData({
      productionOrderId: 0,
      color: "",
      readyQuantityKg: 0,
      readyQuantityMeter: 0,
      rollsCount: 1,
      notes: "",
    })

    toast({
      title: "تمت الإضافة",
      description: `تم إضافة أمر التشغيل ${selectedOrder.orderNumber} إلى البيان`,
    })
  }

  // إزالة أمر تشغيل من بيان التسليم
  const handleRemoveOrderFromStatement = (index: number) => {
    const updatedItems = [...statementFormData.items]
    const removedItem = updatedItems.splice(index, 1)[0]

    setStatementFormData({
      ...statementFormData,
      items: updatedItems,
    })

    toast({
      title: "تم الحذف",
      description: `تم حذف أمر التشغيل ${removedItem.productionOrderNumber} من البيان`,
    })
  }

  // إضافة بيان تسليم جديد
  const handleSubmitStatement = (e: React.FormEvent) => {
    e.preventDefault()

    if (!statementFormData.customerId) {
      toast({
        title: "خطأ",
        description: "يرجى اختيار العميل",
        variant: "destructive",
      })
      return
    }

    if (statementFormData.items.length === 0) {
      toast({
        title: "خطأ",
        description: "يرجى إضافة أمر تشغيل واحد على الأقل",
        variant: "destructive",
      })
      return
    }

    // توليد رقم بيان تسليم فريد
    const generateStatementNumber = () => {
      const existingNumbers = statements.map((s) => s.statementNumber)
      let newStatementNumber = 1001

      while (existingNumbers.includes(newStatementNumber)) {
        newStatementNumber++
      }

      return newStatementNumber
    }

    const selectedCustomer = customers.find((c) => c.id === Number.parseInt(statementFormData.customerId))
    if (!selectedCustomer) return

    const newStatementItems: DeliveryItem[] = statementFormData.items.map((item, index) => ({
      id: Date.now() + index,
      productionOrderId: item.productionOrderId,
      productionOrderNumber: item.productionOrderNumber,
      materialId: productionOrders.find((o) => o.id === item.productionOrderId)?.materialId || 0,
      materialName: item.materialName,
      color: item.color,
      originalQuantity: item.originalQuantity,
      readyQuantityKg: item.readyQuantityKg,
      readyQuantityMeter: item.readyQuantityMeter,
      rollsCount: item.rollsCount,
      unit: item.unit,
      notes: item.notes,
    }))

    const newStatement: DeliveryStatement = {
      id: Date.now(),
      statementNumber: generateStatementNumber(),
      date: statementFormData.date,
      customerId: Number.parseInt(statementFormData.customerId),
      customerName: selectedCustomer.name,
      items: newStatementItems,
      notes: statementFormData.notes,
      createdAt: new Date().toISOString().split("T")[0],
      status: "pending",
    }

    if (editMode && selectedStatement) {
      // تحديث بيان موجود
      setStatements(
        statements.map((statement) =>
          statement.id === selectedStatement.id ? { ...newStatement, id: statement.id } : statement,
        ),
      )

      toast({
        title: "تم التحديث",
        description: `تم تحديث بيان التسليم رقم ${selectedStatement.statementNumber} بنجاح`,
      })
    } else {
      // إضافة بيان جديد
      setStatements([...statements, newStatement])

      toast({
        title: "تمت الإضافة",
        description: `تم إضافة بيان التسليم رقم ${newStatement.statementNumber} بنجاح`,
      })
    }

    setShowStatementDialog(false)
    setSelectedStatement(newStatement)
    setShowStatementPreviewDialog(true)
  }

  // معاينة بيان تسليم
  const handlePreviewStatement = (statement: DeliveryStatement) => {
    setSelectedStatement(statement)
    setShowStatementPreviewDialog(true)
  }

  // تعديل بيان تسليم
  const handleEditStatement = (statement: DeliveryStatement) => {
    // تحويل بيانات البيان إلى نموذج التعديل
    const formItems = statement.items.map((item) => ({
      productionOrderId: item.productionOrderId,
      productionOrderNumber: item.productionOrderNumber,
      materialName: item.materialName,
      unit: item.unit,
      originalQuantity: item.originalQuantity,
      color: item.color,
      readyQuantityKg: item.readyQuantityKg,
      readyQuantityMeter: item.readyQuantityMeter,
      rollsCount: item.rollsCount,
      notes: item.notes || "",
    }))

    setStatementFormData({
      date: statement.date,
      customerId: statement.customerId.toString(),
      notes: statement.notes || "",
      items: formItems,
    })

    setSelectedStatement(statement)
    setEditMode(true)
    setShowStatementDialog(true)
  }

  // تأكيد تسليم بيان
  const handleMarkAsDelivered = () => {
    if (selectedStatement) {
      setStatements(
        statements.map((statement) =>
          statement.id === selectedStatement.id
            ? {
                ...statement,
                status: "delivered",
                deliveredAt: new Date().toISOString().split("T")[0],
              }
            : statement,
        ),
      )
      setShowDeliveryDialog(false)
      setSelectedStatement(null)

      toast({
        title: "تم التسليم",
        description: `تم تأكيد تسليم البيان رقم ${selectedStatement.statementNumber} بنجاح`,
      })
    }
  }

  // فتح نافذة تأكيد التسليم
  const openDeliveryDialog = (statement: DeliveryStatement) => {
    setSelectedStatement(statement)
    setShowDeliveryDialog(true)
  }

  // طباعة
  const printDocument = () => {
    window.print()
  }

  // الحصول على حالة بيان التسليم
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
            في الانتظار
          </span>
        )
      case "delivered":
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
            تم التسليم
          </span>
        )
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
            {status}
          </span>
        )
    }
  }

  // حساب الإجماليات
  const calculateTotals = (items: DeliveryItem[]) => {
    return items.reduce(
      (totals, item) => ({
        totalKg: totals.totalKg + item.readyQuantityKg,
        totalMeter: totals.totalMeter + item.readyQuantityMeter,
        totalRolls: totals.totalRolls + item.rollsCount,
      }),
      { totalKg: 0, totalMeter: 0, totalRolls: 0 },
    )
  }

  // حساب الإجماليات العامة لجميع البيانات
  const calculateGrandTotals = () => {
    return filteredStatements.reduce(
      (grandTotals, statement) => {
        const statementTotals = calculateTotals(statement.items)
        return {
          totalKg: grandTotals.totalKg + statementTotals.totalKg,
          totalMeter: grandTotals.totalMeter + statementTotals.totalMeter,
          totalRolls: grandTotals.totalRolls + statementTotals.totalRolls,
          totalItems: grandTotals.totalItems + statement.items.length,
        }
      },
      { totalKg: 0, totalMeter: 0, totalRolls: 0, totalItems: 0 },
    )
  }

  const grandTotals = calculateGrandTotals()

  return (
    <div className="min-h-screen bg-gray-50">
      {/* إضافة Navbar يدوياً */}
      <div className="bg-white border-b border-gray-200">
        <Navbar onLogout={logout} />
      </div>

      {/* باقي المحتوى */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        {/* رأس الصفحة */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">بيان تسليم الجاهز</h1>
            <p className="text-sm text-gray-500 mt-1">{filteredStatements.length} بيان موجود</p>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="outline" size="sm" className="text-gray-600">
              <Download className="h-4 w-4 ml-2" />
              تصدير
            </Button>
            <Button onClick={handleOpenStatementDialog} size="sm" className="bg-blue-600 hover:bg-blue-700">
              <Plus className="h-4 w-4 ml-2" />
              إضافة بيان
            </Button>
          </div>
        </div>

        {/* فلاتر الحالة */}
        <div className="flex items-center gap-6 mt-6">
          <button
            onClick={() => setStatusFilter("all_status")}
            className={`text-sm font-medium pb-2 border-b-2 transition-colors ${
              statusFilter === "all_status"
                ? "text-blue-600 border-blue-600"
                : "text-gray-500 border-transparent hover:text-gray-700"
            }`}
          >
            جميع البيانات
          </button>
          <button
            onClick={() => setStatusFilter("pending")}
            className={`text-sm font-medium pb-2 border-b-2 transition-colors ${
              statusFilter === "pending"
                ? "text-blue-600 border-blue-600"
                : "text-gray-500 border-transparent hover:text-gray-700"
            }`}
          >
            في الانتظار
          </button>
          <button
            onClick={() => setStatusFilter("delivered")}
            className={`text-sm font-medium pb-2 border-b-2 transition-colors ${
              statusFilter === "delivered"
                ? "text-blue-600 border-blue-600"
                : "text-gray-500 border-transparent hover:text-gray-700"
            }`}
          >
            تم التسليم
          </button>
        </div>
      </div>

      <div className="p-6">
        {/* شريط البحث والفلاتر */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="البحث في البيانات..."
                className="pr-10 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="relative">
              <Calendar className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                type="date"
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value)}
                className="pr-10 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
              />
            </div>
            <Select value={customerFilter} onValueChange={setCustomerFilter}>
              <SelectTrigger className="border-gray-300 focus:border-blue-500 focus:ring-blue-500">
                <SelectValue placeholder="اختر العميل" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all_customers">جميع العملاء</SelectItem>
                {customers.map((customer) => (
                  <SelectItem key={customer.id} value={customer.id.toString()}>
                    {customer.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="relative">
              <Filter className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="pr-10 border-gray-300 focus:border-blue-500 focus:ring-blue-500">
                  <SelectValue placeholder="الحالة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all_status">جميع الحالات</SelectItem>
                  <SelectItem value="pending">في الانتظار</SelectItem>
                  <SelectItem value="delivered">تم التسليم</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* الجدول الرئيسي */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="text-right py-3 px-4 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    رقم البيان
                  </th>
                  <th className="text-right py-3 px-4 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    العميل
                  </th>
                  <th className="text-right py-3 px-4 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    التاريخ
                  </th>
                  <th className="text-right py-3 px-4 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    عدد الأصناف
                  </th>
                  <th className="text-right py-3 px-4 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    إجمالي كجم
                  </th>
                  <th className="text-right py-3 px-4 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    إجمالي متر
                  </th>
                  <th className="text-right py-3 px-4 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    إجمالي الأتواب
                  </th>
                  <th className="text-right py-3 px-4 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    الحالة
                  </th>
                  <th className="text-right py-3 px-4 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    الإجراءات
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredStatements.length > 0 ? (
                  filteredStatements.map((statement, index) => {
                    const totals = calculateTotals(statement.items)
                    return (
                      <tr
                        key={statement.id}
                        className={`hover:bg-gray-50 transition-colors ${
                          index % 2 === 0 ? "bg-white" : "bg-gray-50/50"
                        }`}
                      >
                        <td className="py-4 px-4">
                          <span className="text-sm font-mono font-medium text-gray-900">
                            #{statement.statementNumber}
                          </span>
                        </td>
                        <td className="py-4 px-4">
                          <div className="flex items-center">
                            <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center ml-3">
                              <span className="text-sm font-medium text-blue-600">
                                {statement.customerName.charAt(0)}
                              </span>
                            </div>
                            <span className="text-sm font-medium text-gray-900">{statement.customerName}</span>
                          </div>
                        </td>
                        <td className="py-4 px-4 text-sm text-gray-500">{statement.date}</td>
                        <td className="py-4 px-4 text-sm text-gray-900">{statement.items.length}</td>
                        <td className="py-4 px-4 text-sm font-medium text-gray-900">{totals.totalKg} كجم</td>
                        <td className="py-4 px-4 text-sm font-medium text-gray-900">{totals.totalMeter} متر</td>
                        <td className="py-4 px-4 text-sm font-medium text-gray-900">{totals.totalRolls}</td>
                        <td className="py-4 px-4">{getStatusBadge(statement.status)}</td>
                        <td className="py-4 px-4">
                          <div className="flex items-center gap-2">
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-8 w-8 p-0 text-gray-400 hover:text-blue-600 hover:bg-blue-50"
                              onClick={() => handlePreviewStatement(statement)}
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                            {statement.status === "pending" && (
                              <>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="h-8 w-8 p-0 text-gray-400 hover:text-amber-600 hover:bg-amber-50"
                                  onClick={() => handleEditStatement(statement)}
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="h-8 w-8 p-0 text-gray-400 hover:text-green-600 hover:bg-green-50"
                                  onClick={() => openDeliveryDialog(statement)}
                                >
                                  <CheckCircle className="h-4 w-4" />
                                </Button>
                              </>
                            )}
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-8 w-8 p-0 text-gray-400 hover:text-purple-600 hover:bg-purple-50"
                              onClick={() => {
                                handlePreviewStatement(statement)
                                setTimeout(printDocument, 500)
                              }}
                            >
                              <Printer className="h-4 w-4" />
                            </Button>
                            {canDelete() && (
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-8 w-8 p-0 text-gray-400 hover:text-red-600 hover:bg-red-50"
                                onClick={() => openDeleteDialog(statement)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        </td>
                      </tr>
                    )
                  })
                ) : (
                  <tr>
                    <td colSpan={9} className="py-12 text-center">
                      <div className="flex flex-col items-center">
                        <FileText className="h-12 w-12 text-gray-300 mb-4" />
                        <p className="text-gray-500 text-lg font-medium">لا توجد بيانات للعرض</p>
                        <p className="text-gray-400 text-sm mt-1">قم بإضافة بيان تسليم جديد للبدء</p>
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
              {/* صف الإجماليات */}
              {filteredStatements.length > 0 && (
                <tfoot className="bg-blue-50 border-t-2 border-blue-200">
                  <tr>
                    <td colSpan={3} className="py-4 px-4 text-sm font-bold text-blue-900">
                      الإجمالي العام:
                    </td>
                    <td className="py-4 px-4 text-sm font-bold text-blue-900">{grandTotals.totalItems}</td>
                    <td className="py-4 px-4 text-sm font-bold text-blue-900">{grandTotals.totalKg} كجم</td>
                    <td className="py-4 px-4 text-sm font-bold text-blue-900">{grandTotals.totalMeter} متر</td>
                    <td className="py-4 px-4 text-sm font-bold text-blue-900">{grandTotals.totalRolls}</td>
                    <td colSpan={2} className="py-4 px-4"></td>
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        </div>
      </div>

      {/* نافذة إضافة/تعديل بيان تسليم */}
      <Dialog open={showStatementDialog} onOpenChange={setShowStatementDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editMode ? "تعديل بيان تسليم" : "إضافة بيان تسليم جديد"}</DialogTitle>
            <DialogDescription>
              {editMode ? "قم بتعديل بيانات البيان ثم اضغط على حفظ" : "أدخل بيانات البيان ثم اضغط على إضافة"}
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSubmitStatement}>
            <div className="grid gap-6 py-4">
              {/* معلومات البيان الأساسية */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="date">التاريخ</Label>
                  <Input
                    id="date"
                    type="date"
                    value={statementFormData.date}
                    onChange={(e) => setStatementFormData({ ...statementFormData, date: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="customer">العميل</Label>
                  <Select
                    value={statementFormData.customerId}
                    onValueChange={(value) => setStatementFormData({ ...statementFormData, customerId: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="اختر العميل" />
                    </SelectTrigger>
                    <SelectContent>
                      {customers.map((customer) => (
                        <SelectItem key={customer.id} value={customer.id.toString()}>
                          {customer.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="notes">ملاحظات البيان</Label>
                <Input
                  id="notes"
                  value={statementFormData.notes}
                  onChange={(e) => setStatementFormData({ ...statementFormData, notes: e.target.value })}
                  placeholder="ملاحظات عامة على البيان"
                />
              </div>

              {/* تعديل نموذج إضافة أمر تشغيل لإظهار أصل الخام وجعل الكمية بالمتر قابلة للتعديل */}
              {statementFormData.customerId && (
                <Card className="border-2 border-dashed border-gray-300">
                  <CardHeader>
                    <CardTitle className="text-lg">إضافة أمر تشغيل</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <Label htmlFor="productionOrder">أمر التشغيل</Label>
                        <Select
                          value={currentItemFormData.productionOrderId.toString()}
                          onValueChange={handleSelectProductionOrder}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="اختر أمر التشغيل" />
                          </SelectTrigger>
                          <SelectContent>
                            {getFilteredOrders().map((order) => (
                              <SelectItem key={order.id} value={order.id.toString()}>
                                {order.orderNumber} - {order.materialName} (
                                {order.quantity - (order.separationsQuantity || 0)} {order.unit})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        {currentItemFormData.productionOrderId > 0 && (
                          <div className="mt-2 text-xs bg-blue-50 p-2 rounded-md">
                            <p className="font-medium">
                              أصل الخام:{" "}
                              {
                                productionOrders.find((o) => o.id === currentItemFormData.productionOrderId)
                                  ?.materialName
                              }
                            </p>
                            <p>
                              الكمية الأصلية:{" "}
                              {productionOrders.find((o) => o.id === currentItemFormData.productionOrderId)?.quantity}{" "}
                              {productionOrders.find((o) => o.id === currentItemFormData.productionOrderId)?.unit}
                            </p>
                            <p>
                              الكمية المتاحة:{" "}
                              {(productionOrders.find((o) => o.id === currentItemFormData.productionOrderId)
                                ?.quantity || 0) -
                                (productionOrders.find((o) => o.id === currentItemFormData.productionOrderId)
                                  ?.separationsQuantity || 0)}{" "}
                              {productionOrders.find((o) => o.id === currentItemFormData.productionOrderId)?.unit}
                            </p>
                          </div>
                        )}
                      </div>

                      <div>
                        <Label htmlFor="color">اللون</Label>
                        <Input
                          id="color"
                          value={currentItemFormData.color}
                          onChange={(e) => setCurrentItemFormData({ ...currentItemFormData, color: e.target.value })}
                          placeholder="أدخل اللون"
                        />
                      </div>

                      <div>
                        <Label htmlFor="readyQuantityKg">الكمية الجاهزة (كجم)</Label>
                        <Input
                          id="readyQuantityKg"
                          type="number"
                          step="0.1"
                          value={currentItemFormData.readyQuantityKg}
                          onChange={(e) =>
                            setCurrentItemFormData({
                              ...currentItemFormData,
                              readyQuantityKg: Number.parseFloat(e.target.value) || 0,
                            })
                          }
                          placeholder="0.0"
                        />
                      </div>

                      <div>
                        <Label htmlFor="readyQuantityMeter">الكمية الجاهزة (متر)</Label>
                        <Input
                          id="readyQuantityMeter"
                          type="number"
                          step="0.1"
                          value={currentItemFormData.readyQuantityMeter}
                          onChange={(e) =>
                            setCurrentItemFormData({
                              ...currentItemFormData,
                              readyQuantityMeter: Number.parseFloat(e.target.value) || 0,
                            })
                          }
                          placeholder="0.0"
                        />
                      </div>

                      <div>
                        <Label htmlFor="rollsCount">عدد الأتواب</Label>
                        <Input
                          id="rollsCount"
                          type="number"
                          value={currentItemFormData.rollsCount}
                          onChange={(e) =>
                            setCurrentItemFormData({
                              ...currentItemFormData,
                              rollsCount: Number.parseInt(e.target.value) || 1,
                            })
                          }
                          min="1"
                        />
                      </div>

                      <div>
                        <Label htmlFor="itemNotes">ملاحظات</Label>
                        <Input
                          id="itemNotes"
                          value={currentItemFormData.notes}
                          onChange={(e) => setCurrentItemFormData({ ...currentItemFormData, notes: e.target.value })}
                          placeholder="ملاحظات على هذا الصنف"
                        />
                      </div>
                    </div>

                    <div className="mt-4">
                      <Button type="button" onClick={handleAddOrderToStatement} className="w-full">
                        <Plus className="h-4 w-4 ml-2" />
                        إضافة إلى البيان
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* تعديل جدول الأصناف المضافة لإظهار أصل الخام */}
              {statementFormData.items.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">الأصناف المضافة ({statementFormData.items.length})</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="border-b">
                            <th className="text-right p-2">أمر التشغيل</th>
                            <th className="text-right p-2">أصل الخام</th>
                            <th className="text-right p-2">اللون</th>
                            <th className="text-right p-2">كجم</th>
                            <th className="text-right p-2">متر</th>
                            <th className="text-right p-2">أتواب</th>
                            <th className="text-right p-2">ملاحظات</th>
                            <th className="text-right p-2">حذف</th>
                          </tr>
                        </thead>
                        <tbody>
                          {statementFormData.items.map((item, index) => (
                            <tr key={index} className="border-b">
                              <td className="p-2 font-mono">{item.productionOrderNumber}</td>
                              <td className="p-2">{item.materialName}</td>
                              <td className="p-2">{item.color}</td>
                              <td className="p-2">{item.readyQuantityKg} كجم</td>
                              <td className="p-2">{item.readyQuantityMeter} متر</td>
                              <td className="p-2">{item.rollsCount}</td>
                              <td className="p-2">{item.notes || "—"}</td>
                              <td className="p-2">
                                <Button
                                  type="button"
                                  size="sm"
                                  variant="ghost"
                                  className="text-red-600 hover:text-red-700"
                                  onClick={() => handleRemoveOrderFromStatement(index)}
                                >
                                  <X className="h-4 w-4" />
                                </Button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                        <tfoot>
                          <tr className="border-t-2 font-bold bg-blue-50">
                            <td colSpan={3} className="p-2 text-right">
                              الإجمالي:
                            </td>
                            <td className="p-2">
                              {statementFormData.items.reduce((sum, item) => sum + item.readyQuantityKg, 0)} كجم
                            </td>
                            <td className="p-2">
                              {statementFormData.items.reduce((sum, item) => sum + item.readyQuantityMeter, 0)} متر
                            </td>
                            <td className="p-2">
                              {statementFormData.items.reduce((sum, item) => sum + item.rollsCount, 0)}
                            </td>
                            <td colSpan={2}></td>
                          </tr>
                        </tfoot>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setShowStatementDialog(false)}>
                إلغاء
              </Button>
              <Button type="submit" disabled={statementFormData.items.length === 0}>
                {editMode ? "حفظ التغييرات" : "إضافة البيان"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* نافذة معاينة بيان التسليم */}
      <Dialog open={showStatementPreviewDialog} onOpenChange={setShowStatementPreviewDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-center">
              بيان تسليم الجاهز رقم {selectedStatement?.statementNumber}
            </DialogTitle>
          </DialogHeader>

          {selectedStatement && (
            <div className="space-y-6 print:space-y-4">
              {/* معلومات البيان */}
              <div className="grid grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg print:bg-white print:border">
                <div>
                  <p>
                    <strong>رقم البيان:</strong> {selectedStatement.statementNumber}
                  </p>
                  <p>
                    <strong>التاريخ:</strong> {selectedStatement.date}
                  </p>
                </div>
                <div>
                  <p>
                    <strong>العميل:</strong> {selectedStatement.customerName}
                  </p>
                  <p>
                    <strong>الحالة:</strong> {selectedStatement.status === "pending" ? "في الانتظار" : "تم التسليم"}
                  </p>
                </div>
              </div>

              {/* تعديل جدول معاينة بيان التسليم لإظهار أصل الخام */}
              <div>
                <h3 className="text-lg font-bold mb-4">تفاصيل الأصناف</h3>
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse border border-gray-300">
                    <thead>
                      <tr className="bg-gray-100">
                        <th className="border border-gray-300 p-3 text-right">أمر التشغيل</th>
                        <th className="border border-gray-300 p-3 text-right">أصل الخام</th>
                        <th className="border border-gray-300 p-3 text-right">اللون</th>
                        <th className="border border-gray-300 p-3 text-right">الكمية الأصلية</th>
                        <th className="border border-gray-300 p-3 text-right">الكمية الجاهزة (كجم)</th>
                        <th className="border border-gray-300 p-3 text-right">الكمية الجاهزة (متر)</th>
                        <th className="border border-gray-300 p-3 text-right">عدد الأتواب</th>
                        <th className="border border-gray-300 p-3 text-right">ملاحظات</th>
                      </tr>
                    </thead>
                    <tbody>
                      {selectedStatement.items.map((item) => (
                        <tr key={item.id}>
                          <td className="border border-gray-300 p-3 font-mono">{item.productionOrderNumber}</td>
                          <td className="border border-gray-300 p-3">{item.materialName}</td>
                          <td className="border border-gray-300 p-3">{item.color}</td>
                          <td className="border border-gray-300 p-3">
                            {item.originalQuantity} {item.unit}
                          </td>
                          <td className="border border-gray-300 p-3 font-medium">{item.readyQuantityKg} كجم</td>
                          <td className="border border-gray-300 p-3 font-medium">{item.readyQuantityMeter} متر</td>
                          <td className="border border-gray-300 p-3">{item.rollsCount}</td>
                          <td className="border border-gray-300 p-3">{item.notes || "—"}</td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot>
                      <tr className="bg-blue-100 font-bold">
                        <td colSpan={4} className="border border-gray-300 p-3 text-right">
                          الإجمالي:
                        </td>
                        <td className="border border-gray-300 p-3">
                          {calculateTotals(selectedStatement.items).totalKg} كجم
                        </td>
                        <td className="border border-gray-300 p-3">
                          {calculateTotals(selectedStatement.items).totalMeter} متر
                        </td>
                        <td className="border border-gray-300 p-3">
                          {calculateTotals(selectedStatement.items).totalRolls}
                        </td>
                        <td className="border border-gray-300 p-3">—</td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>

              {/* ملاحظات */}
              {selectedStatement.notes && (
                <div>
                  <h3 className="text-lg font-bold mb-2">ملاحظات</h3>
                  <p className="p-3 bg-gray-50 rounded-lg print:bg-white print:border">{selectedStatement.notes}</p>
                </div>
              )}

              {/* توقيعات */}
              <div className="grid grid-cols-2 gap-8 mt-8 print:mt-12">
                <div className="text-center">
                  <div className="border-t border-gray-400 pt-2 mt-16">
                    <p>توقيع المسؤول</p>
                  </div>
                </div>
                <div className="text-center">
                  <div className="border-t border-gray-400 pt-2 mt-16">
                    <p>توقيع العميل</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          <DialogFooter className="print:hidden">
            <Button variant="outline" onClick={() => setShowStatementPreviewDialog(false)}>
              إغلاق
            </Button>
            <Button onClick={printDocument}>
              <Printer className="h-4 w-4 ml-2" />
              طباعة
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* نافذة تأكيد التسليم */}
      <Dialog open={showDeliveryDialog} onOpenChange={setShowDeliveryDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تأكيد التسليم</DialogTitle>
            <DialogDescription>
              هل أنت متأكد من تأكيد تسليم البيان رقم {selectedStatement?.statementNumber}؟
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeliveryDialog(false)}>
              إلغاء
            </Button>
            <Button onClick={handleMarkAsDelivered}>
              <CheckCircle className="h-4 w-4 ml-2" />
              تأكيد التسليم
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* نافذة تأكيد الحذف */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center text-red-600">
              <AlertTriangle className="h-5 w-5 ml-2" />
              تأكيد حذف بيان التسليم
            </DialogTitle>
            <DialogDescription>
              هل أنت متأكد من حذف بيان التسليم رقم {selectedStatement?.statementNumber}؟
              <br />
              <span className="text-red-600 font-medium">هذا الإجراء لا يمكن التراجع عنه!</span>
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="bg-red-50 border border-red-200 rounded-md p-4">
              <div className="flex items-center">
                <AlertTriangle className="h-5 w-5 text-red-600 ml-2" />
                <div className="text-sm text-red-800">
                  <p className="font-medium">تفاصيل بيان التسليم المراد حذفه:</p>
                  <p>العميل: {selectedStatement?.customerName}</p>
                  <p>التاريخ: {selectedStatement?.date}</p>
                  <p>عدد الأصناف: {selectedStatement?.items.length}</p>
                  <p>الحالة: {selectedStatement?.status === "pending" ? "في الانتظار" : "تم التسليم"}</p>
                  {selectedStatement?.status === "delivered" && (
                    <p className="text-orange-600 font-medium">تم تسليم هذا البيان بالفعل!</p>
                  )}
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>
              إلغاء
            </Button>
            <Button variant="destructive" onClick={handleDeleteStatement}>
              <Trash2 className="h-4 w-4 ml-2" />
              تأكيد الحذف
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
