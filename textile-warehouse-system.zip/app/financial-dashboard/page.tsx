"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { PageLayout } from "@/components/page-layout"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  DollarSign,
  TrendingUp,
  PieChart,
  BarChart3,
  Calculator,
  FileText,
  Download,
  Calendar,
  ArrowUpRight,
  ArrowDownRight,
} from "lucide-react"
import {
  Line,
  LineChart,
  Pie,
  PieChart as RechartsPieChart,
  Cell,
  ResponsiveContainer,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts"
import { dataManager } from "@/lib/data-manager"

// بيانات مالية تجريبية
const monthlyRevenue = [
  { month: "يناير", revenue: 45000, expenses: 32000, profit: 13000 },
  { month: "فبراير", revenue: 52000, expenses: 35000, profit: 17000 },
  { month: "مارس", revenue: 48000, expenses: 33000, profit: 15000 },
  { month: "أبريل", revenue: 61000, expenses: 38000, profit: 23000 },
  { month: "مايو", revenue: 55000, expenses: 36000, profit: 19000 },
  { month: "يونيو", revenue: 67000, expenses: 41000, profit: 26000 },
]

const expenseCategories = [
  { name: "المواد الخام", value: 45, color: "#3b82f6" },
  { name: "الصباغة", value: 25, color: "#ef4444" },
  { name: "التجهيز", value: 15, color: "#10b981" },
  { name: "النقل", value: 10, color: "#f59e0b" },
  { name: "أخرى", value: 5, color: "#8b5cf6" },
]

const customerProfitability = [
  { customer: "شركة النسيج المتحدة", revenue: 125000, profit: 28000, margin: 22.4 },
  { customer: "مصنع الألوان الحديث", revenue: 98000, profit: 19600, margin: 20.0 },
  { customer: "شركة القطن السعودي", revenue: 87000, profit: 15660, margin: 18.0 },
  { customer: "مصنع الأقمشة الفاخرة", revenue: 76000, profit: 12160, margin: 16.0 },
]

export default function FinancialDashboardPage() {
  const [selectedPeriod, setSelectedPeriod] = useState("monthly")
  const [financialData, setFinancialData] = useState({
    totalRevenue: 328000,
    totalExpenses: 215000,
    netProfit: 113000,
    profitMargin: 34.5,
    monthlyGrowth: 12.5,
    outstandingReceivables: 45000,
    cashFlow: 68000,
  })

  // حساب المؤشرات المالية من البيانات الفعلية
  useEffect(() => {
    const calculateFinancials = () => {
      const productionOrders = dataManager.getData("productionOrders", [])
      const invoices = dataManager.getData("invoices", [])

      // حساب الإيرادات من الفواتير
      const totalRevenue = invoices.reduce((sum: number, invoice: any) => sum + (invoice.totalAmount || 0), 0)

      // حساب تكاليف الإنتاج
      const totalProductionCosts = productionOrders.reduce((sum: number, order: any) => {
        return sum + (order.dyeingCost || 0) + (order.processingCost || 0)
      }, 0)

      const netProfit = totalRevenue - totalProductionCosts
      const profitMargin = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0

      setFinancialData((prev) => ({
        ...prev,
        totalRevenue,
        totalExpenses: totalProductionCosts,
        netProfit,
        profitMargin,
      }))
    }

    calculateFinancials()
  }, [])

  const kpiCards = [
    {
      title: "إجمالي الإيرادات",
      value: `${financialData.totalRevenue.toLocaleString()} ج.م`,
      change: `+${financialData.monthlyGrowth}%`,
      trend: "up",
      icon: DollarSign,
      color: "text-green-600",
      bgColor: "bg-green-50",
    },
    {
      title: "صافي الربح",
      value: `${financialData.netProfit.toLocaleString()} ج.م`,
      change: "+8.2%",
      trend: "up",
      icon: TrendingUp,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
    },
    {
      title: "هامش الربح",
      value: `${financialData.profitMargin.toFixed(1)}%`,
      change: "+2.1%",
      trend: "up",
      icon: Calculator,
      color: "text-purple-600",
      bgColor: "bg-purple-50",
    },
    {
      title: "التدفق النقدي",
      value: `${financialData.cashFlow.toLocaleString()} ج.م`,
      change: "-3.5%",
      trend: "down",
      icon: BarChart3,
      color: "text-orange-600",
      bgColor: "bg-orange-50",
    },
  ]

  return (
    <PageLayout title="اللوحة المالية">
      {/* فلاتر الفترة الزمنية */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Button
            variant={selectedPeriod === "monthly" ? "default" : "outline"}
            size="sm"
            onClick={() => setSelectedPeriod("monthly")}
          >
            شهري
          </Button>
          <Button
            variant={selectedPeriod === "quarterly" ? "default" : "outline"}
            size="sm"
            onClick={() => setSelectedPeriod("quarterly")}
          >
            ربع سنوي
          </Button>
          <Button
            variant={selectedPeriod === "yearly" ? "default" : "outline"}
            size="sm"
            onClick={() => setSelectedPeriod("yearly")}
          >
            سنوي
          </Button>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Calendar className="h-4 w-4 ml-2" />
            اختيار الفترة
          </Button>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 ml-2" />
            تصدير التقرير
          </Button>
        </div>
      </div>

      {/* المؤشرات الرئيسية */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {kpiCards.map((kpi, index) => (
          <Card key={index} className="border-0 shadow-sm hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{kpi.title}</p>
                  <p className="text-2xl font-bold text-gray-900 mt-1">{kpi.value}</p>
                  <div className="flex items-center mt-2">
                    {kpi.trend === "up" ? (
                      <ArrowUpRight className="h-4 w-4 text-green-500 mr-1" />
                    ) : (
                      <ArrowDownRight className="h-4 w-4 text-red-500 mr-1" />
                    )}
                    <span className={`text-sm font-medium ${kpi.trend === "up" ? "text-green-600" : "text-red-600"}`}>
                      {kpi.change}
                    </span>
                    <span className="text-sm text-gray-500 mr-1">من الشهر الماضي</span>
                  </div>
                </div>
                <div className={`p-3 rounded-full ${kpi.bgColor}`}>
                  <kpi.icon className={`h-6 w-6 ${kpi.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* الرسوم البيانية */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* الإيرادات والأرباح الشهرية */}
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUp className="h-5 w-5 ml-2 text-blue-600" />
              الإيرادات والأرباح الشهرية
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={monthlyRevenue}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip formatter={(value) => [`${value.toLocaleString()} ج.م`, ""]} />
                  <Legend />
                  <Line type="monotone" dataKey="revenue" stroke="#3b82f6" strokeWidth={3} name="الإيرادات" />
                  <Line type="monotone" dataKey="profit" stroke="#10b981" strokeWidth={3} name="الأرباح" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* توزيع المصروفات */}
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center">
              <PieChart className="h-5 w-5 ml-2 text-purple-600" />
              توزيع المصروفات
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <RechartsPieChart>
                  <Pie
                    data={expenseCategories}
                    cx="50%"
                    cy="50%"
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, value }) => `${name}: ${value}%`}
                  >
                    {expenseCategories.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </RechartsPieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ربحية العملاء */}
      <Card className="border-0 shadow-sm mb-8">
        <CardHeader>
          <CardTitle className="flex items-center">
            <BarChart3 className="h-5 w-5 ml-2 text-green-600" />
            ربحية العملاء
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-right py-3 px-4 font-medium text-gray-700">العميل</th>
                  <th className="text-right py-3 px-4 font-medium text-gray-700">الإيرادات</th>
                  <th className="text-right py-3 px-4 font-medium text-gray-700">الأرباح</th>
                  <th className="text-right py-3 px-4 font-medium text-gray-700">هامش الربح</th>
                  <th className="text-right py-3 px-4 font-medium text-gray-700">الحالة</th>
                </tr>
              </thead>
              <tbody>
                {customerProfitability.map((customer, index) => (
                  <tr key={index} className="border-b hover:bg-gray-50">
                    <td className="py-3 px-4 font-medium">{customer.customer}</td>
                    <td className="py-3 px-4">{customer.revenue.toLocaleString()} ج.م</td>
                    <td className="py-3 px-4 text-green-600 font-medium">{customer.profit.toLocaleString()} ج.م</td>
                    <td className="py-3 px-4">
                      <Badge
                        variant={customer.margin > 20 ? "default" : customer.margin > 15 ? "secondary" : "destructive"}
                      >
                        {customer.margin.toFixed(1)}%
                      </Badge>
                    </td>
                    <td className="py-3 px-4">
                      <Badge variant={customer.margin > 20 ? "default" : "secondary"}>
                        {customer.margin > 20 ? "ممتاز" : customer.margin > 15 ? "جيد" : "يحتاج تحسين"}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* التقارير المالية السريعة */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer">
          <CardContent className="p-6 text-center">
            <FileText className="h-12 w-12 text-blue-600 mx-auto mb-4" />
            <h3 className="font-semibold text-gray-900 mb-2">تقرير الأرباح والخسائر</h3>
            <p className="text-sm text-gray-600 mb-4">تقرير شامل للأرباح والخسائر الشهرية</p>
            <Button variant="outline" size="sm">
              عرض التقرير
            </Button>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer">
          <CardContent className="p-6 text-center">
            <Calculator className="h-12 w-12 text-green-600 mx-auto mb-4" />
            <h3 className="font-semibold text-gray-900 mb-2">تحليل التكاليف</h3>
            <p className="text-sm text-gray-600 mb-4">تحليل مفصل لتكاليف الإنتاج والعمليات</p>
            <Button variant="outline" size="sm">
              عرض التحليل
            </Button>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer">
          <CardContent className="p-6 text-center">
            <TrendingUp className="h-12 w-12 text-purple-600 mx-auto mb-4" />
            <h3 className="font-semibold text-gray-900 mb-2">توقعات الأرباح</h3>
            <p className="text-sm text-gray-600 mb-4">توقعات الأرباح للأشهر القادمة</p>
            <Button variant="outline" size="sm">
              عرض التوقعات
            </Button>
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  )
}
