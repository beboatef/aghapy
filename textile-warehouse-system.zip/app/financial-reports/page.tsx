"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { PageLayout } from "@/components/page-layout"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { FileText, Download, Filter, TrendingUp, TrendingDown, DollarSign, Calculator } from "lucide-react"
import { dataManager } from "@/lib/data-manager"

export default function FinancialReportsPage() {
  const [selectedReport, setSelectedReport] = useState("profit-loss")
  const [dateRange, setDateRange] = useState({ from: "", to: "" })

  // حساب البيانات المالية
  const financialSummary = dataManager.calculateProfitFromOrders()

  const reportTypes = [
    {
      id: "profit-loss",
      name: "تقرير الأرباح والخسائر",
      description: "تقرير شامل للإيرادات والمصروفات والأرباح",
      icon: TrendingUp,
    },
    {
      id: "cost-analysis",
      name: "تحليل التكاليف",
      description: "تحليل مفصل لتكاليف الإنتاج والعمليات",
      icon: Calculator,
    },
    {
      id: "customer-profitability",
      name: "ربحية العملاء",
      description: "تحليل ربحية كل عميل على حدة",
      icon: DollarSign,
    },
    {
      id: "cash-flow",
      name: "التدفق النقدي",
      description: "تقرير التدفقات النقدية الداخلة والخارجة",
      icon: FileText,
    },
  ]

  const generateReport = () => {
    // منطق توليد التقرير
    console.log("Generating report:", selectedReport, dateRange)
  }

  return (
    <PageLayout title="التقارير المالية">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* قائمة أنواع التقارير */}
        <div className="lg:col-span-1">
          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg">أنواع التقارير</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {reportTypes.map((report) => (
                <Button
                  key={report.id}
                  variant={selectedReport === report.id ? "default" : "ghost"}
                  className="w-full justify-start h-auto p-3"
                  onClick={() => setSelectedReport(report.id)}
                >
                  <div className="flex items-start gap-3">
                    <report.icon className="h-5 w-5 mt-0.5 flex-shrink-0" />
                    <div className="text-right">
                      <div className="font-medium text-sm">{report.name}</div>
                      <div className="text-xs text-gray-500 mt-1">{report.description}</div>
                    </div>
                  </div>
                </Button>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* محتوى التقرير */}
        <div className="lg:col-span-3 space-y-6">
          {/* فلاتر التقرير */}
          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Filter className="h-5 w-5 ml-2" />
                فلاتر التقرير
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="from-date">من تاريخ</Label>
                  <Input
                    id="from-date"
                    type="date"
                    value={dateRange.from}
                    onChange={(e) => setDateRange((prev) => ({ ...prev, from: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="to-date">إلى تاريخ</Label>
                  <Input
                    id="to-date"
                    type="date"
                    value={dateRange.to}
                    onChange={(e) => setDateRange((prev) => ({ ...prev, to: e.target.value }))}
                  />
                </div>
                <div className="flex items-end">
                  <Button onClick={generateReport} className="w-full">
                    <FileText className="h-4 w-4 ml-2" />
                    إنشاء التقرير
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* ملخص مالي سريع */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="border-0 shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">إجمالي الإيرادات</p>
                    <p className="text-xl font-bold text-green-600">{financialSummary.revenue.toLocaleString()} ج.م</p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-green-500" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">إجمالي التكاليف</p>
                    <p className="text-xl font-bold text-red-600">{financialSummary.costs.toLocaleString()} ج.م</p>
                  </div>
                  <TrendingDown className="h-8 w-8 text-red-500" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">صافي الربح</p>
                    <p className="text-xl font-bold text-blue-600">{financialSummary.profit.toLocaleString()} ج.م</p>
                  </div>
                  <DollarSign className="h-8 w-8 text-blue-500" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">هامش الربح</p>
                    <p className="text-xl font-bold text-purple-600">{financialSummary.margin.toFixed(1)}%</p>
                  </div>
                  <Calculator className="h-8 w-8 text-purple-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* محتوى التقرير المحدد */}
          <Card className="border-0 shadow-sm">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>{reportTypes.find((r) => r.id === selectedReport)?.name}</CardTitle>
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 ml-2" />
                  تصدير PDF
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {selectedReport === "profit-loss" && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-semibold text-green-600 mb-2">الإيرادات</h4>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span>مبيعات المنتجات</span>
                          <span>{financialSummary.revenue.toLocaleString()} ج.م</span>
                        </div>
                        <div className="flex justify-between">
                          <span>خدمات إضافية</span>
                          <span>0 ج.م</span>
                        </div>
                        <hr />
                        <div className="flex justify-between font-semibold">
                          <span>إجمالي الإيرادات</span>
                          <span>{financialSummary.revenue.toLocaleString()} ج.م</span>
                        </div>
                      </div>
                    </div>
                    <div>
                      <h4 className="font-semibold text-red-600 mb-2">المصروفات</h4>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span>تكاليف الإنتاج</span>
                          <span>{financialSummary.costs.toLocaleString()} ج.م</span>
                        </div>
                        <div className="flex justify-between">
                          <span>مصروفات إدارية</span>
                          <span>0 ج.م</span>
                        </div>
                        <hr />
                        <div className="flex justify-between font-semibold">
                          <span>إجمالي المصروفات</span>
                          <span>{financialSummary.costs.toLocaleString()} ج.م</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <hr />
                  <div className="flex justify-between text-lg font-bold">
                    <span>صافي الربح</span>
                    <span className="text-blue-600">{financialSummary.profit.toLocaleString()} ج.م</span>
                  </div>
                </div>
              )}

              {selectedReport === "cost-analysis" && (
                <div className="space-y-4">
                  <p className="text-gray-600">تحليل مفصل لتكاليف الإنتاج والعمليات سيتم عرضه هنا.</p>
                </div>
              )}

              {selectedReport === "customer-profitability" && (
                <div className="space-y-4">
                  <p className="text-gray-600">تحليل ربحية العملاء سيتم عرضه هنا.</p>
                </div>
              )}

              {selectedReport === "cash-flow" && (
                <div className="space-y-4">
                  <p className="text-gray-600">تقرير التدفق النقدي سيتم عرضه هنا.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </PageLayout>
  )
}
