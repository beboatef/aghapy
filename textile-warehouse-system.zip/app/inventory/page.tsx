"use client"

import { DialogFooter } from "@/components/ui/dialog"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { PageLayout } from "@/components/page-layout"
import {
  ArrowRightLeft,
  Plus,
  Search,
  Download,
  Upload,
  ArrowDown,
  ArrowUp,
  RotateCcw,
  Trash2,
  AlertTriangle,
  Edit,
} from "lucide-react"
import { useCustomers, useMaterials } from "@/hooks/use-data"
import { useAuth } from "@/hooks/use-auth"

interface Customer {
  id: number
  code: string
  name: string
}

interface Material {
  id: number
  code: string
  name: string
  unit: string
}

interface InventoryMovement {
  id: number
  permitNumber: string
  type: "incoming" | "outgoing" | "return"
  date: string
  customerId: number
  customerName: string
  materialId: number
  materialName: string
  quantity: number
  unit: string
  rollsCount: number
  customerPermitNumber?: string
  notes?: string
  createdAt: string
}

export default function InventoryPage() {
  const [activeTab, setActiveTab] = useState("all")
  const [showDialog, setShowDialog] = useState(false)
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const [movementType, setMovementType] = useState<"incoming" | "outgoing" | "return">("incoming")
  const [searchTerm, setSearchTerm] = useState("")
  const [dateFilter, setDateFilter] = useState("")
  const [customerFilter, setCustomerFilter] = useState("all_customers")
  const [materialFilter, setMaterialFilter] = useState("all_materials")
  const [selectedMovement, setSelectedMovement] = useState<InventoryMovement | null>(null)
  const [isEditMode, setIsEditMode] = useState(false)
  const [editingMovementId, setEditingMovementId] = useState<number | null>(null)

  // بيانات محاكاة
  const { customers } = useCustomers()
  const { materials } = useMaterials()
  const { isAdmin, canDelete } = useAuth()

  const [movements, setMovements] = useState<InventoryMovement[]>([
    {
      id: 1,
      permitNumber: "IN001",
      type: "incoming",
      date: "2024-03-01",
      customerId: 1,
      customerName: "شركة النسيج المتحدة",
      materialId: 1,
      materialName: "قطن أبيض خام",
      quantity: 150,
      unit: "كجم",
      rollsCount: 3,
      customerPermitNumber: "CP123",
      notes: "استلام بحالة جيدة",
      createdAt: "2024-03-01",
    },
    {
      id: 2,
      permitNumber: "OUT001",
      type: "outgoing",
      date: "2024-03-02",
      customerId: 2,
      customerName: "مصنع الألوان الحديث",
      materialId: 2,
      materialName: "بوليستر أزرق",
      quantity: 75,
      unit: "متر",
      rollsCount: 2,
      notes: "أمر تشغيل رقم 123",
      createdAt: "2024-03-02",
    },
    {
      id: 3,
      permitNumber: "RET001",
      type: "return",
      date: "2024-03-03",
      customerId: 3,
      customerName: "شركة القطن السعودي",
      materialId: 3,
      materialName: "قطن ملون",
      quantity: 30,
      unit: "كجم",
      rollsCount: 1,
      customerPermitNumber: "CP456",
      notes: "مرتجع بسبب عيوب في الصباغة",
      createdAt: "2024-03-03",
    },
    {
      id: 4,
      permitNumber: "IN002",
      type: "incoming",
      date: "2024-03-04",
      customerId: 2,
      customerName: "مصنع الألوان الحديث",
      materialId: 1,
      materialName: "قطن أبيض خام",
      quantity: 200,
      unit: "كجم",
      rollsCount: 4,
      customerPermitNumber: "CP789",
      createdAt: "2024-03-04",
    },
    {
      id: 5,
      permitNumber: "OUT002",
      type: "outgoing",
      date: "2024-03-05",
      customerId: 1,
      customerName: "شركة النسيج المتحدة",
      materialId: 3,
      materialName: "قطن ملون",
      quantity: 100,
      unit: "كجم",
      rollsCount: 2,
      notes: "أمر تشغيل رقم 124",
      createdAt: "2024-03-05",
    },
  ])

  const [formData, setFormData] = useState({
    permitNumber: "",
    date: new Date().toISOString().split("T")[0],
    customerId: "select_customer",
    materials: [
      {
        // تغيير من materialId واحد إلى مصفوفة materials
        materialId: "select_material",
        quantity: "",
        rollsCount: "",
        notes: "",
      },
    ],
    customerPermitNumber: "",
    generalNotes: "",
  })

  // إضافة صنف جديد
  const addMaterial = () => {
    setFormData({
      ...formData,
      materials: [
        ...formData.materials,
        {
          materialId: "select_material",
          quantity: "",
          rollsCount: "",
          notes: "",
        },
      ],
    })
  }

  // حذف صنف
  const removeMaterial = (index: number) => {
    if (formData.materials.length > 1) {
      const newMaterials = formData.materials.filter((_, i) => i !== index)
      setFormData({ ...formData, materials: newMaterials })
    }
  }

  // تحديث بيانات صنف معين
  const updateMaterial = (index: number, field: string, value: string) => {
    const newMaterials = [...formData.materials]
    newMaterials[index] = { ...newMaterials[index], [field]: value }
    setFormData({ ...formData, materials: newMaterials })
  }

  const checkPermitNumberExists = (permitNumber: string) => {
    return movements.some((movement) => movement.permitNumber === permitNumber)
  }

  // فلترة الحركات
  const filteredMovements = movements.filter((movement) => {
    const matchesTab = activeTab === "all" || movement.type === activeTab
    const matchesSearch =
      movement.permitNumber.includes(searchTerm) ||
      movement.materialName.includes(searchTerm) ||
      movement.customerName.includes(searchTerm)
    const matchesDate = dateFilter === "" || movement.date === dateFilter
    const matchesCustomer = customerFilter === "all_customers" || movement.customerId.toString() === customerFilter
    const matchesMaterial = materialFilter === "all_materials" || movement.materialId.toString() === materialFilter

    return matchesTab && matchesSearch && matchesDate && matchesCustomer && matchesMaterial
  })

  const handleEditMovement = (movement: InventoryMovement) => {
    // البحث عن جميع الحركات بنفس رقم الإذن
    const relatedMovements = movements.filter((m) => m.permitNumber === movement.permitNumber)

    setIsEditMode(true)
    setEditingMovementId(movement.id)
    setMovementType(movement.type)

    // تحميل بيانات الحركة في النموذج
    setFormData({
      permitNumber: movement.permitNumber,
      date: movement.date,
      customerId: movement.customerId.toString(),
      materials: relatedMovements.map((m) => ({
        materialId: m.materialId.toString(),
        quantity: m.quantity.toString(),
        rollsCount: m.rollsCount.toString(),
        notes: m.notes || "",
      })),
      customerPermitNumber: movement.customerPermitNumber || "",
      generalNotes: "",
    })

    setShowDialog(true)
  }

  const handleOpenDialog = (type: "incoming" | "outgoing" | "return") => {
    setIsEditMode(false)
    setEditingMovementId(null)
    setMovementType(type)
    setFormData({
      permitNumber: "",
      date: new Date().toISOString().split("T")[0],
      customerId: "select_customer",
      materials: [
        {
          materialId: "select_material",
          quantity: "",
          rollsCount: "",
          notes: "",
        },
      ],
      customerPermitNumber: "",
      generalNotes: "",
    })
    setShowDialog(true)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (isEditMode) {
      // في حالة التعديل
      const originalMovement = movements.find((m) => m.id === editingMovementId)
      if (!originalMovement) return

      // التحقق من تكرار رقم الإذن إذا تم تغييره
      if (formData.permitNumber !== originalMovement.permitNumber && checkPermitNumberExists(formData.permitNumber)) {
        alert("رقم الإذن موجود مسبقاً! يرجى استخدام رقم مختلف")
        return
      }

      // حذف الحركات القديمة بنفس رقم الإذن
      const filteredMovements = movements.filter((m) => m.permitNumber !== originalMovement.permitNumber)

      // إنشاء الحركات المحدثة
      const updatedMovements = formData.materials.map((material, index) => ({
        id: index === 0 ? editingMovementId : Date.now() + index,
        permitNumber: formData.permitNumber,
        type: movementType,
        date: formData.date,
        customerId: Number.parseInt(formData.customerId),
        customerName: customers.find((c) => c.id === Number.parseInt(formData.customerId))?.name || "",
        materialId: Number.parseInt(material.materialId),
        materialName: materials.find((m) => m.id === Number.parseInt(material.materialId))?.name || "",
        quantity: Number.parseFloat(material.quantity),
        unit: materials.find((m) => m.id === Number.parseInt(material.materialId))?.unit || "",
        rollsCount: Number.parseInt(material.rollsCount),
        customerPermitNumber: formData.customerPermitNumber,
        notes: material.notes || formData.generalNotes,
        createdAt: originalMovement.createdAt,
      }))

      setMovements([...filteredMovements, ...updatedMovements])
      alert("تم تحديث الحركة بنجاح")
    } else {
      // الكود الأصلي للإضافة
      if (checkPermitNumberExists(formData.permitNumber)) {
        alert("رقم الإذن موجود مسبقاً! يرجى استخدام رقم مختلف")
        return
      }

      const newMovements = formData.materials.map((material, index) => ({
        id: Date.now() + index,
        permitNumber: formData.permitNumber,
        type: movementType,
        date: formData.date,
        customerId: Number.parseInt(formData.customerId),
        customerName: customers.find((c) => c.id === Number.parseInt(formData.customerId))?.name || "",
        materialId: Number.parseInt(material.materialId),
        materialName: materials.find((m) => m.id === Number.parseInt(material.materialId))?.name || "",
        quantity: Number.parseFloat(material.quantity),
        unit: materials.find((m) => m.id === Number.parseInt(material.materialId))?.unit || "",
        rollsCount: Number.parseInt(material.rollsCount),
        customerPermitNumber: formData.customerPermitNumber,
        notes: material.notes || formData.generalNotes,
        createdAt: new Date().toISOString().split("T")[0],
      }))

      setMovements([...movements, ...newMovements])
    }

    setShowDialog(false)
    setIsEditMode(false)
    setEditingMovementId(null)
  }

  // حذف حركة مخزون
  const handleDeleteMovement = () => {
    if (selectedMovement) {
      setMovements(movements.filter((movement) => movement.id !== selectedMovement.id))
      setShowDeleteDialog(false)
      setSelectedMovement(null)
      alert(`تم حذف الحركة ${selectedMovement.permitNumber} بنجاح`)
    }
  }

  // فتح نافذة تأكيد الحذف
  const openDeleteDialog = (movement: InventoryMovement) => {
    setSelectedMovement(movement)
    setShowDeleteDialog(true)
  }

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "incoming":
        return "وارد"
      case "outgoing":
        return "منصرف"
      case "return":
        return "مرتجع"
      default:
        return type
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "incoming":
        return <ArrowDown className="h-4 w-4 text-green-600" />
      case "outgoing":
        return <ArrowUp className="h-4 w-4 text-red-600" />
      case "return":
        return <RotateCcw className="h-4 w-4 text-orange-600" />
      default:
        return null
    }
  }

  const getTypeClass = (type: string) => {
    switch (type) {
      case "incoming":
        return "badge-green"
      case "outgoing":
        return "badge-red"
      case "return":
        return "badge-orange"
      default:
        return "badge-gray"
    }
  }

  return (
    <PageLayout title="حركات المخزون">
      {/* رأس الصفحة */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
        <h1 className="page-title mb-4 sm:mb-0">
          <ArrowRightLeft className="page-icon text-purple-600" />
          حركات المخزون
        </h1>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm">
            <Upload className="h-4 w-4 ml-2" />
            استيراد Excel
          </Button>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 ml-2" />
            تصدير Excel
          </Button>
          <Button onClick={() => handleOpenDialog("incoming")} size="sm" className="bg-green-600 hover:bg-green-700">
            <Plus className="h-4 w-4 ml-2" />
            إضافة وارد
          </Button>
          <Button onClick={() => handleOpenDialog("outgoing")} size="sm" className="bg-red-600 hover:bg-red-700">
            <Plus className="h-4 w-4 ml-2" />
            إضافة منصرف
          </Button>
          <Button onClick={() => handleOpenDialog("return")} size="sm" className="bg-orange-600 hover:bg-orange-700">
            <Plus className="h-4 w-4 ml-2" />
            إضافة مرتجع
          </Button>
        </div>
      </div>

      {/* تبويبات وفلاتر */}
      <Card className="mb-6 border-0 shadow-sm">
        <CardContent className="p-4">
          <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="mb-4">
            <TabsList className="grid grid-cols-4 mb-4">
              <TabsTrigger value="all">الكل</TabsTrigger>
              <TabsTrigger value="incoming" className="text-green-600">
                وارد
              </TabsTrigger>
              <TabsTrigger value="outgoing" className="text-red-600">
                منصرف
              </TabsTrigger>
              <TabsTrigger value="return" className="text-orange-600">
                مرتجع
              </TabsTrigger>
            </TabsList>
          </Tabs>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="بحث..."
                className="pr-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Input
              type="date"
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              placeholder="التاريخ"
            />
            <Select value={customerFilter} onValueChange={setCustomerFilter}>
              <SelectTrigger>
                <SelectValue placeholder="العميل" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all_customers">جميع العملاء</SelectItem>
                {customers?.map((customer) => (
                  <SelectItem key={customer.id} value={customer.id.toString()}>
                    {customer.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={materialFilter} onValueChange={setMaterialFilter}>
              <SelectTrigger>
                <SelectValue placeholder="الصنف" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all_materials">جميع الأصناف</SelectItem>
                {materials?.map((material) => (
                  <SelectItem key={material.id} value={material.id.toString()}>
                    {material.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* جدول الحركات */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-2">
          <CardTitle>سجل الحركات ({filteredMovements.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-right p-3">رقم الإذن</th>
                  <th className="text-right p-3">النوع</th>
                  <th className="text-right p-3">التاريخ</th>
                  <th className="text-right p-3">العميل</th>
                  <th className="text-right p-3">الصنف</th>
                  <th className="text-right p-3">الكمية</th>
                  <th className="text-right p-3">عدد الأتواب</th>
                  <th className="text-right p-3">ملاحظات</th>
                  {(canDelete() || isAdmin()) && <th className="text-right p-3">الإجراءات</th>}
                </tr>
              </thead>
              <tbody>
                {filteredMovements.length > 0 ? (
                  filteredMovements.map((movement) => (
                    <tr key={movement.id} className="border-b hover:bg-gray-50">
                      <td className="p-3 font-mono">{movement.permitNumber}</td>
                      <td className="p-3">
                        <div className="flex items-center">
                          {getTypeIcon(movement.type)}
                          <span className={`badge ${getTypeClass(movement.type)} mr-2`}>
                            {getTypeLabel(movement.type)}
                          </span>
                        </div>
                      </td>
                      <td className="p-3">{movement.date}</td>
                      <td className="p-3 font-medium">{movement.customerName}</td>
                      <td className="p-3">{movement.materialName}</td>
                      <td className="p-3">
                        {movement.quantity} {movement.unit}
                      </td>
                      <td className="p-3">{movement.rollsCount}</td>
                      <td className="p-3 text-gray-600 truncate max-w-xs">{movement.notes || "-"}</td>
                      {(canDelete() || isAdmin()) && (
                        <td className="p-3">
                          <div className="flex gap-1">
                            {isAdmin() && (
                              <Button
                                size="sm"
                                variant="ghost"
                                className="text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                                onClick={() => handleEditMovement(movement)}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                            )}
                            {canDelete() && (
                              <Button
                                size="sm"
                                variant="ghost"
                                className="text-red-600 hover:text-red-700 hover:bg-red-50"
                                onClick={() => openDeleteDialog(movement)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        </td>
                      )}
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={canDelete() ? 9 : 8} className="p-4 text-center text-gray-500">
                      لا توجد بيانات للعرض
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* نافذة إضافة حركة */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {isEditMode
                ? `تعديل ${movementType === "incoming" ? "وارد" : movementType === "outgoing" ? "منصرف" : "مرتجع"}`
                : movementType === "incoming"
                  ? "إضافة وارد جديد"
                  : movementType === "outgoing"
                    ? "إضافة منصرف جديد"
                    : "إضافة مرتجع جديد"}
            </DialogTitle>
            <DialogDescription>
              {isEditMode ? "عدّل بيانات الحركة ثم اضغط على حفظ" : "أدخل بيانات الحركة ثم اضغط على إضافة"}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="permitNumber" className="text-right">
                  رقم الإذن
                </Label>
                <Input
                  id="permitNumber"
                  value={formData.permitNumber}
                  onChange={(e) => setFormData({ ...formData, permitNumber: e.target.value })}
                  className="col-span-3"
                  required
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="date" className="text-right">
                  التاريخ
                </Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  className="col-span-3"
                  required
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="customer" className="text-right">
                  العميل
                </Label>
                <Select
                  value={formData.customerId}
                  onValueChange={(value) => setFormData({ ...formData, customerId: value })}
                >
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="اختر العميل" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="select_customer">اختر العميل</SelectItem>
                    {customers?.map((customer) => (
                      <SelectItem key={customer.id} value={customer.id.toString() || " "}>
                        {customer.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label className="text-right font-medium">الأصناف</Label>
                  <Button type="button" size="sm" onClick={addMaterial} className="text-xs">
                    <Plus className="h-3 w-3 ml-1" />
                    إضافة صنف
                  </Button>
                </div>

                {formData.materials.map((material, index) => (
                  <div key={index} className="border rounded-lg p-4 space-y-3 bg-gray-50">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">الصنف {index + 1}</span>
                      {formData.materials.length > 1 && (
                        <Button
                          type="button"
                          size="sm"
                          variant="ghost"
                          onClick={() => removeMaterial(index)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Label className="text-xs">الصنف</Label>
                        <Select
                          value={material.materialId}
                          onValueChange={(value) => updateMaterial(index, "materialId", value)}
                        >
                          <SelectTrigger className="h-8">
                            <SelectValue placeholder="اختر الصنف" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="select_material">اختر الصنف</SelectItem>
                            {materials?.map((mat) => (
                              <SelectItem key={mat.id} value={mat.id.toString()}>
                                {mat.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label className="text-xs">الكمية</Label>
                        <Input
                          type="number"
                          value={material.quantity}
                          onChange={(e) => updateMaterial(index, "quantity", e.target.value)}
                          className="h-8"
                          required
                        />
                      </div>

                      <div>
                        <Label className="text-xs">عدد الأتواب</Label>
                        <Input
                          type="number"
                          value={material.rollsCount}
                          onChange={(e) => updateMaterial(index, "rollsCount", e.target.value)}
                          className="h-8"
                          required
                        />
                      </div>

                      <div>
                        <Label className="text-xs">ملاحظات خاصة</Label>
                        <Input
                          value={material.notes}
                          onChange={(e) => updateMaterial(index, "notes", e.target.value)}
                          className="h-8"
                          placeholder="ملاحظات للصنف"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              {(movementType === "incoming" || movementType === "return") && (
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="customerPermitNumber" className="text-right">
                    رقم إذن العميل
                  </Label>
                  <Input
                    id="customerPermitNumber"
                    value={formData.customerPermitNumber}
                    onChange={(e) => setFormData({ ...formData, customerPermitNumber: e.target.value })}
                    className="col-span-3"
                  />
                </div>
              )}
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="notes" className="text-right">
                  ملاحظات
                </Label>
                <Input
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="col-span-3"
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setShowDialog(false)}>
                إلغاء
              </Button>
              <Button type="submit">{isEditMode ? "حفظ التعديل" : "إضافة"}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* نافذة تأكيد الحذف */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center text-red-600">
              <AlertTriangle className="h-5 w-5 ml-2" />
              تأكيد الحذف
            </DialogTitle>
            <DialogDescription>
              هل أنت متأكد من حذف الحركة رقم {selectedMovement?.permitNumber}؟
              <br />
              <span className="text-red-600 font-medium">هذا الإجراء لا يمكن التراجع عنه!</span>
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="bg-red-50 border border-red-200 rounded-md p-4">
              <div className="flex items-center">
                <AlertTriangle className="h-5 w-5 text-red-600 ml-2" />
                <div className="text-sm text-red-800">
                  <p className="font-medium">تفاصيل الحركة المراد حذفها:</p>
                  <p>النوع: {selectedMovement && getTypeLabel(selectedMovement.type)}</p>
                  <p>العميل: {selectedMovement?.customerName}</p>
                  <p>الصنف: {selectedMovement?.materialName}</p>
                  <p>
                    الكمية: {selectedMovement?.quantity} {selectedMovement?.unit}
                  </p>
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>
              إلغاء
            </Button>
            <Button variant="destructive" onClick={handleDeleteMovement}>
              <Trash2 className="h-4 w-4 ml-2" />
              تأكيد الحذف
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageLayout>
  )
}
