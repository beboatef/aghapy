"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { PageLayout } from "@/components/page-layout"
import { Badge } from "@/components/ui/badge"
import {
  ShoppingCart,
  Plus,
  Search,
  Download,
  CheckCircle,
  Clock,
  Scissors,
  RotateCcw,
  Trash2,
  AlertTriangle,
  DollarSign,
  Package,
  Calculator,
} from "lucide-react"
import { useCustomers, useMaterials } from "@/hooks/use-data"
import { useAuth } from "@/hooks/use-auth"
import { dataManager } from "@/lib/data-manager"

interface Customer {
  id: number
  code: string
  name: string
}

interface Material {
  id: number
  code: string
  name: string
  unit: string
}

interface DyeingMaterial {
  id: number
  code: string
  name: string
  nameAr: string
  category: "dye" | "chemical" | "auxiliary" | "finishing"
  unit: "kg" | "gram" | "liter"
  purchasePrice: number
  currentStock: number
  minimumStock: number
}

interface MaterialUsage {
  materialId: number
  materialCode: string
  materialName: string
  materialNameAr: string
  category: string
  unit: string
  quantity: number
  unitPrice: number
  totalCost: number
}

interface ProductionOrder {
  id: number
  orderNumber: string
  permitNumber: string
  date: string
  customerId: number
  customerName: string
  materialId: number
  materialName: string
  quantity: number
  separatedQuantity: number
  finalQuantity: number
  unit: string
  status: "in_production" | "completed"
  hasSeparations: boolean
  notes?: string
  createdAt: string
  completedAt?: string
  // تفاصيل التكلفة الجديدة
  materialsUsed: MaterialUsage[]
  totalMaterialsCost: number
  costPerUnit: number
  costsCalculated: boolean
}

interface ProductionSeparation {
  id: number
  separationNumber: string
  productionOrderId: number
  productionOrderNumber: string
  materialId: number
  materialName: string
  customerId: number
  customerName: string
  separatedQuantity: number
  rollsCount: number
  separationReason: string
  separationDate: string
  status: "separated" | "reprocessed"
  notes?: string
  createdAt: string
  reprocessedAt?: string
  newProductionOrderId?: number
}

export default function ProductionOrdersPage() {
  const [activeTab, setActiveTab] = useState("all")
  const [showDialog, setShowDialog] = useState(false)
  const [showCompleteDialog, setShowCompleteDialog] = useState(false)
  const [showSeparationDialog, setShowSeparationDialog] = useState(false)
  const [showSeparationsListDialog, setShowSeparationsListDialog] = useState(false)
  const [showReprocessDialog, setShowReprocessDialog] = useState(false)
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const [showMaterialsDialog, setShowMaterialsDialog] = useState(false)
  const [showCostDetailsDialog, setShowCostDetailsDialog] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [dateFilter, setDateFilter] = useState("")
  const [customerFilter, setCustomerFilter] = useState("all_customers")
  const [selectedOrder, setSelectedOrder] = useState<ProductionOrder | null>(null)
  const [selectedSeparations, setSelectedSeparations] = useState<number[]>([])

  // بيانات محاكاة
  const { customers } = useCustomers()
  const { materials } = useMaterials()
  const { isAdmin, canDelete } = useAuth()

  // مواد الصباغة والتجهيز
  const [dyeingMaterials, setDyeingMaterials] = useState<DyeingMaterial[]>([])

  // حالة إضافة المواد
  const [selectedMaterials, setSelectedMaterials] = useState<MaterialUsage[]>([])
  const [currentMaterial, setCurrentMaterial] = useState({
    materialId: "",
    quantity: "",
  })

  const [orders, setOrders] = useState<ProductionOrder[]>([
    {
      id: 1,
      orderNumber: "PO001",
      permitNumber: "OUT001",
      date: "2024-03-01",
      customerId: 1,
      customerName: "شركة النسيج المتحدة",
      materialId: 1,
      materialName: "قطن أبيض خام",
      quantity: 150,
      separatedQuantity: 25.5,
      finalQuantity: 124.5,
      unit: "كجم",
      status: "in_production",
      hasSeparations: true,
      notes: "صباغة باللون الأزرق",
      createdAt: "2024-03-01",
      materialsUsed: [
        {
          materialId: 1,
          materialCode: "DYE001",
          materialName: "Direct Blue 86",
          materialNameAr: "أزرق مباشر 86",
          category: "dye",
          unit: "kg",
          quantity: 5.2,
          unitPrice: 45.5,
          totalCost: 236.6,
        },
        {
          materialId: 2,
          materialCode: "CHM001",
          materialName: "Acetic Acid",
          materialNameAr: "حمض الخليك",
          category: "chemical",
          unit: "liter",
          quantity: 3.5,
          unitPrice: 12.75,
          totalCost: 44.625,
        },
      ],
      totalMaterialsCost: 281.225,
      costPerUnit: 1.875,
      costsCalculated: true,
    },
    {
      id: 2,
      orderNumber: "PO002",
      permitNumber: "OUT002",
      date: "2024-03-02",
      customerId: 2,
      customerName: "مصنع الألوان الحديث",
      materialId: 2,
      materialName: "بوليستر أزرق",
      quantity: 75,
      separatedQuantity: 15,
      finalQuantity: 60,
      unit: "متر",
      status: "completed",
      hasSeparations: true,
      notes: "صباغة باللون الأحمر",
      createdAt: "2024-03-02",
      completedAt: "2024-03-05",
      materialsUsed: [],
      totalMaterialsCost: 0,
      costPerUnit: 0,
      costsCalculated: false,
    },
    {
      id: 3,
      orderNumber: "PO003",
      permitNumber: "OUT003",
      date: "2024-03-03",
      customerId: 3,
      customerName: "شركة القطن السعودي",
      materialId: 3,
      materialName: "قطن ملون",
      quantity: 100,
      separatedQuantity: 30,
      finalQuantity: 70,
      unit: "كجم",
      status: "in_production",
      hasSeparations: true,
      notes: "صباغة باللون الأخضر",
      createdAt: "2024-03-03",
      materialsUsed: [],
      totalMaterialsCost: 0,
      costPerUnit: 0,
      costsCalculated: false,
    },
    {
      id: 4,
      orderNumber: "PO004",
      permitNumber: "OUT004",
      date: "2024-03-04",
      customerId: 1,
      customerName: "شركة النسيج المتحدة",
      materialId: 1,
      materialName: "قطن أبيض خام",
      quantity: 200,
      separatedQuantity: 0,
      finalQuantity: 200,
      unit: "كجم",
      status: "in_production",
      hasSeparations: false,
      createdAt: "2024-03-04",
      materialsUsed: [],
      totalMaterialsCost: 0,
      costPerUnit: 0,
      costsCalculated: false,
    },
  ])

  const [separations, setSeparations] = useState<ProductionSeparation[]>([
    {
      id: 1,
      separationNumber: "SEP001",
      productionOrderId: 1,
      productionOrderNumber: "PO001",
      materialId: 1,
      materialName: "قطن أبيض خام",
      customerId: 1,
      customerName: "شركة النسيج المتحدة",
      separatedQuantity: 25.5,
      rollsCount: 1,
      separationReason: "عيوب في الصباغة",
      separationDate: "2024-03-10",
      status: "separated",
      notes: "لون غير متطابق مع المطلوب",
      createdAt: "2024-03-10",
    },
    {
      id: 2,
      separationNumber: "SEP002",
      productionOrderId: 2,
      productionOrderNumber: "PO002",
      materialId: 2,
      materialName: "بوليستر أزرق",
      customerId: 2,
      customerName: "مصنع الألوان الحديث",
      separatedQuantity: 15,
      rollsCount: 1,
      separationReason: "عيوب في النسيج",
      separationDate: "2024-03-12",
      status: "separated",
      notes: "خيوط مقطوعة",
      createdAt: "2024-03-12",
    },
    {
      id: 3,
      separationNumber: "SEP003",
      productionOrderId: 3,
      productionOrderNumber: "PO003",
      materialId: 3,
      materialName: "قطن ملون",
      customerId: 3,
      customerName: "شركة القطن السعودي",
      separatedQuantity: 30,
      rollsCount: 2,
      separationReason: "عيوب في الصباغة",
      separationDate: "2024-03-14",
      status: "separated",
      notes: "درجة لون فاتحة",
      createdAt: "2024-03-14",
    },
  ])

  const [formData, setFormData] = useState({
    orderNumber: "",
    permitNumber: "",
    date: new Date().toISOString().split("T")[0],
    customerId: "select_customer",
    materialId: "select_material",
    quantity: "",
    notes: "",
  })

  const [separationFormData, setSeparationFormData] = useState({
    separatedQuantity: "",
    rollsCount: "",
    separationReason: "",
    notes: "",
  })

  const [completionFormData, setCompletionFormData] = useState({
    separatedQuantity: "",
    rollsCount: "",
    separationReason: "",
    separationNotes: "",
    hasSeparation: false,
  })

  // تحميل مواد الصباغة والتجهيز
  useEffect(() => {
    const materials = dataManager.getDyeingMaterials()
    if (materials.length === 0) {
      // إنشاء بيانات تجريبية
      const sampleMaterials: DyeingMaterial[] = [
        {
          id: 1,
          code: "DYE001",
          name: "Direct Blue 86",
          nameAr: "أزرق مباشر 86",
          category: "dye",
          unit: "kg",
          purchasePrice: 45.5,
          currentStock: 125.5,
          minimumStock: 20,
        },
        {
          id: 2,
          code: "CHM001",
          name: "Acetic Acid",
          nameAr: "حمض الخليك",
          category: "chemical",
          unit: "liter",
          purchasePrice: 12.75,
          currentStock: 85.2,
          minimumStock: 15,
        },
        {
          id: 3,
          code: "AUX001",
          name: "Fabric Softener",
          nameAr: "منعم الأقمشة",
          category: "auxiliary",
          unit: "kg",
          purchasePrice: 28.9,
          currentStock: 45.8,
          minimumStock: 25,
        },
        {
          id: 4,
          code: "DYE002",
          name: "Reactive Red 195",
          nameAr: "أحمر تفاعلي 195",
          category: "dye",
          unit: "kg",
          purchasePrice: 52.3,
          currentStock: 78.4,
          minimumStock: 20,
        },
        {
          id: 5,
          code: "CHM002",
          name: "Sodium Carbonate",
          nameAr: "كربونات الصوديوم",
          category: "chemical",
          unit: "kg",
          purchasePrice: 8.45,
          currentStock: 245.6,
          minimumStock: 50,
        },
        {
          id: 6,
          code: "FIN001",
          name: "Anti-Wrinkle Agent",
          nameAr: "مضاد التجعد",
          category: "finishing",
          unit: "liter",
          purchasePrice: 35.75,
          currentStock: 42.3,
          minimumStock: 15,
        },
      ]
      dataManager.setDyeingMaterials(sampleMaterials)
      setDyeingMaterials(sampleMaterials)
    } else {
      setDyeingMaterials(materials)
    }
  }, [])

  // فلترة أوامر التشغيل
  const filteredOrders = orders.filter((order) => {
    const matchesTab =
      activeTab === "all" ||
      (activeTab === "in_production" && order.status === "in_production") ||
      (activeTab === "completed" && order.status === "completed") ||
      (activeTab === "with_separations" && order.hasSeparations)
    const matchesSearch =
      order.orderNumber.includes(searchTerm) ||
      order.permitNumber.includes(searchTerm) ||
      order.materialName.includes(searchTerm) ||
      order.customerName.includes(searchTerm)
    const matchesDate = dateFilter === "" || order.date === dateFilter
    const matchesCustomer = customerFilter === "all_customers" || order.customerId.toString() === customerFilter

    return matchesTab && matchesSearch && matchesDate && matchesCustomer
  })

  // الحصول على المنفصلات المتاحة للإعادة تشغيل
  const availableSeparations = separations.filter((sep) => sep.status === "separated")

  // توليد رقم أمر تشغيل فريد
  const generateOrderNumber = () => {
    const existingNumbers = orders.map((o) => o.orderNumber)
    let newOrderNumber = 1
    let newNumber = ""

    do {
      newNumber = `PO${newOrderNumber.toString().padStart(3, "0")}`
      newOrderNumber++
    } while (existingNumbers.includes(newNumber))

    return newNumber
  }

  const handleOpenDialog = () => {
    const newOrderNumber = generateOrderNumber()
    setFormData({
      orderNumber: newOrderNumber,
      permitNumber: "",
      date: new Date().toISOString().split("T")[0],
      customerId: "select_customer",
      materialId: "select_material",
      quantity: "",
      notes: "",
    })
    setShowDialog(true)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const newOrder: ProductionOrder = {
      id: Date.now(),
      orderNumber: formData.orderNumber || generateOrderNumber(),
      permitNumber: formData.permitNumber,
      date: formData.date,
      customerId: Number.parseInt(formData.customerId),
      customerName: customers.find((c) => c.id === Number.parseInt(formData.customerId))?.name || "",
      materialId: Number.parseInt(formData.materialId),
      materialName: materials.find((m) => m.id === Number.parseInt(formData.materialId))?.name || "",
      quantity: Number.parseFloat(formData.quantity),
      separatedQuantity: 0,
      finalQuantity: Number.parseFloat(formData.quantity),
      unit: materials.find((m) => m.id === Number.parseInt(formData.materialId))?.unit || "",
      status: "in_production",
      hasSeparations: false,
      notes: formData.notes,
      createdAt: new Date().toISOString().split("T")[0],
      materialsUsed: [],
      totalMaterialsCost: 0,
      costPerUnit: 0,
      costsCalculated: false,
    }

    setOrders([...orders, newOrder])
    setShowDialog(false)
  }

  // إضافة مادة للقائمة
  const addMaterialToOrder = () => {
    if (!currentMaterial.materialId || !currentMaterial.quantity) return

    const material = dyeingMaterials.find((m) => m.id === Number.parseInt(currentMaterial.materialId))
    if (!material) return

    const quantity = Number.parseFloat(currentMaterial.quantity)

    // التحقق من توفر الكمية في المخزن
    if (quantity > material.currentStock) {
      alert(
        `الكمية المطلوبة (${quantity} ${material.unit}) أكبر من المتاح في المخزن (${material.currentStock} ${material.unit})`,
      )
      return
    }

    const totalCost = quantity * material.purchasePrice

    const newMaterialUsage: MaterialUsage = {
      materialId: material.id,
      materialCode: material.code,
      materialName: material.name,
      materialNameAr: material.nameAr,
      category: material.category,
      unit: material.unit,
      quantity: quantity,
      unitPrice: material.purchasePrice,
      totalCost: totalCost,
    }

    // التحقق من وجود المادة مسبقاً
    const existingIndex = selectedMaterials.findIndex((item) => item.materialId === material.id)

    if (existingIndex >= 0) {
      // تحديث المادة الموجودة
      const updatedMaterials = [...selectedMaterials]
      const existingItem = updatedMaterials[existingIndex]
      const newQuantity = existingItem.quantity + quantity

      // التحقق من توفر الكمية الجديدة
      if (newQuantity > material.currentStock) {
        alert(
          `إجمالي الكمية (${newQuantity} ${material.unit}) أكبر من المتاح في المخزن (${material.currentStock} ${material.unit})`,
        )
        return
      }

      updatedMaterials[existingIndex] = {
        ...existingItem,
        quantity: newQuantity,
        totalCost: newQuantity * existingItem.unitPrice,
      }

      setSelectedMaterials(updatedMaterials)
    } else {
      // إضافة مادة جديدة
      setSelectedMaterials([...selectedMaterials, newMaterialUsage])
    }

    setCurrentMaterial({ materialId: "", quantity: "" })
  }

  // حذف مادة من القائمة
  const removeMaterialFromOrder = (index: number) => {
    const updatedMaterials = selectedMaterials.filter((_, i) => i !== index)
    setSelectedMaterials(updatedMaterials)
  }

  // حساب إجمالي التكلفة
  const calculateTotalCost = () => {
    return selectedMaterials.reduce((sum, item) => sum + item.totalCost, 0)
  }

  // حفظ المواد وحساب التكلفة
  const saveMaterialsAndCalculateCost = () => {
    if (!selectedOrder || selectedMaterials.length === 0) return

    const totalCost = calculateTotalCost()
    const costPerUnit = selectedOrder.quantity > 0 ? totalCost / selectedOrder.quantity : 0

    // تحديث أمر التشغيل
    const updatedOrder = {
      ...selectedOrder,
      materialsUsed: selectedMaterials,
      totalMaterialsCost: totalCost,
      costPerUnit: costPerUnit,
      costsCalculated: true,
    }

    // خصم المواد من المخزن
    const updatedDyeingMaterials = dyeingMaterials.map((material) => {
      const usedMaterial = selectedMaterials.find((used) => used.materialId === material.id)
      if (usedMaterial) {
        return {
          ...material,
          currentStock: material.currentStock - usedMaterial.quantity,
        }
      }
      return material
    })

    // تحديث البيانات
    setOrders(orders.map((order) => (order.id === selectedOrder.id ? updatedOrder : order)))
    setDyeingMaterials(updatedDyeingMaterials)
    dataManager.setDyeingMaterials(updatedDyeingMaterials)

    // إعادة تعيين الحالة
    setSelectedMaterials([])
    setShowMaterialsDialog(false)
    setSelectedOrder(null)

    alert(
      `تم حساب تكلفة المواد لأمر التشغيل ${selectedOrder.orderNumber} بنجاح\nإجمالي التكلفة: ${totalCost.toFixed(2)} ج.م\nالتكلفة للوحدة: ${costPerUnit.toFixed(2)} ج.م`,
    )
  }

  // فتح نافذة إضافة المواد
  const openMaterialsDialog = (order: ProductionOrder) => {
    setSelectedOrder(order)
    setSelectedMaterials(order.materialsUsed || [])
    setShowMaterialsDialog(true)
  }

  // فتح نافذة تفاصيل التكلفة
  const openCostDetailsDialog = (order: ProductionOrder) => {
    setSelectedOrder(order)
    setShowCostDetailsDialog(true)
  }

  // حذف أمر تشغيل
  const handleDeleteOrder = () => {
    if (selectedOrder) {
      // حذف المنفصلات المرتبطة بالأمر
      setSeparations(separations.filter((sep) => sep.productionOrderId !== selectedOrder.id))
      // حذف الأمر
      setOrders(orders.filter((order) => order.id !== selectedOrder.id))
      setShowDeleteDialog(false)
      setSelectedOrder(null)
      alert(`تم حذف أمر التشغيل ${selectedOrder.orderNumber} وجميع المنفصلات المرتبطة به بنجاح`)
    }
  }

  // فتح نافذة تأكيد الحذف
  const openDeleteDialog = (order: ProductionOrder) => {
    setSelectedOrder(order)
    setShowDeleteDialog(true)
  }

  // إكمال أمر التشغيل مع إمكانية الفصل
  const handleCompleteOrder = () => {
    if (selectedOrder) {
      let updatedOrder = { ...selectedOrder }

      // إذا كان هناك فصل
      if (completionFormData.hasSeparation && Number.parseFloat(completionFormData.separatedQuantity) > 0) {
        const separatedQty = Number.parseFloat(completionFormData.separatedQuantity)
        const newSeparation: ProductionSeparation = {
          id: Date.now(),
          separationNumber: `SEP${(separations.length + 1).toString().padStart(3, "0")}`,
          productionOrderId: selectedOrder.id,
          productionOrderNumber: selectedOrder.orderNumber,
          materialId: selectedOrder.materialId,
          materialName: selectedOrder.materialName,
          customerId: selectedOrder.customerId,
          customerName: selectedOrder.customerName,
          separatedQuantity: separatedQty,
          rollsCount: Number.parseInt(completionFormData.rollsCount),
          separationReason: completionFormData.separationReason,
          separationDate: new Date().toISOString().split("T")[0],
          status: "separated",
          notes: completionFormData.separationNotes,
          createdAt: new Date().toISOString().split("T")[0],
        }

        setSeparations([...separations, newSeparation])

        updatedOrder = {
          ...updatedOrder,
          separatedQuantity: updatedOrder.separatedQuantity + separatedQty,
          finalQuantity: updatedOrder.quantity - (updatedOrder.separatedQuantity + separatedQty),
          hasSeparations: true,
        }
      }

      // إكمال الأمر
      updatedOrder = {
        ...updatedOrder,
        status: "completed",
        completedAt: new Date().toISOString().split("T")[0],
      }

      setOrders(orders.map((order) => (order.id === selectedOrder.id ? updatedOrder : order)))
      setShowCompleteDialog(false)
      setSelectedOrder(null)
      setCompletionFormData({
        separatedQuantity: "",
        rollsCount: "",
        separationReason: "",
        separationNotes: "",
        hasSeparation: false,
      })
    }
  }

  // فصل كمية من أمر تشغيل قيد التنفيذ
  const handleSeparateQuantity = () => {
    if (selectedOrder && Number.parseFloat(separationFormData.separatedQuantity) > 0) {
      const separatedQty = Number.parseFloat(separationFormData.separatedQuantity)

      const newSeparation: ProductionSeparation = {
        id: Date.now(),
        separationNumber: `SEP${(separations.length + 1).toString().padStart(3, "0")}`,
        productionOrderId: selectedOrder.id,
        productionOrderNumber: selectedOrder.orderNumber,
        materialId: selectedOrder.materialId,
        materialName: selectedOrder.materialName,
        customerId: selectedOrder.customerId,
        customerName: selectedOrder.customerName,
        separatedQuantity: separatedQty,
        rollsCount: Number.parseInt(separationFormData.rollsCount),
        separationReason: separationFormData.separationReason,
        separationDate: new Date().toISOString().split("T")[0],
        status: "separated",
        notes: separationFormData.notes,
        createdAt: new Date().toISOString().split("T")[0],
      }

      setSeparations([...separations, newSeparation])

      // تحديث أمر التشغيل
      const updatedOrder = {
        ...selectedOrder,
        separatedQuantity: selectedOrder.separatedQuantity + separatedQty,
        finalQuantity: selectedOrder.quantity - (selectedOrder.separatedQuantity + separatedQty),
        hasSeparations: true,
      }

      setOrders(orders.map((order) => (order.id === selectedOrder.id ? updatedOrder : order)))
      setShowSeparationDialog(false)
      setSelectedOrder(null)
      setSeparationFormData({
        separatedQuantity: "",
        rollsCount: "",
        separationReason: "",
        notes: "",
      })
    }
  }

  // إعادة تشغيل المنفصلات
  const handleReprocessSeparations = () => {
    if (selectedSeparations.length === 0) return

    const selectedSeps = separations.filter((sep) => selectedSeparations.includes(sep.id))
    const totalQuantity = selectedSeps.reduce((sum, sep) => sum + sep.separatedQuantity, 0)
    const firstSep = selectedSeps[0]

    // إنشاء أمر تشغيل جديد
    const newOrder: ProductionOrder = {
      id: Date.now(),
      orderNumber: `PO${(orders.length + 1).toString().padStart(3, "0")}`,
      permitNumber: `REP${Date.now()}`,
      date: new Date().toISOString().split("T")[0],
      customerId: firstSep.customerId,
      customerName: firstSep.customerName,
      materialId: firstSep.materialId,
      materialName: firstSep.materialName,
      quantity: totalQuantity,
      separatedQuantity: 0,
      finalQuantity: totalQuantity,
      unit: materials.find((m) => m.id === firstSep.materialId)?.unit || "",
      status: "in_production",
      hasSeparations: false,
      notes: `إعادة تشغيل منفصلات: ${selectedSeps.map((s) => s.separationNumber).join(", ")}`,
      createdAt: new Date().toISOString().split("T")[0],
      materialsUsed: [],
      totalMaterialsCost: 0,
      costPerUnit: 0,
      costsCalculated: false,
    }

    setOrders([...orders, newOrder])

    // تحديث حالة المنفصلات
    const updatedSeparations = separations.map((sep) =>
      selectedSeparations.includes(sep.id)
        ? {
            ...sep,
            status: "reprocessed" as const,
            reprocessedAt: new Date().toISOString().split("T")[0],
            newProductionOrderId: newOrder.id,
          }
        : sep,
    )

    setSeparations(updatedSeparations)
    setSelectedSeparations([])
    setShowReprocessDialog(false)
  }

  const openCompleteDialog = (order: ProductionOrder) => {
    setSelectedOrder(order)
    setCompletionFormData({
      separatedQuantity: "",
      rollsCount: "",
      separationReason: "",
      separationNotes: "",
      hasSeparation: false,
    })
    setShowCompleteDialog(true)
  }

  const openSeparationDialog = (order: ProductionOrder) => {
    setSelectedOrder(order)
    setSeparationFormData({
      separatedQuantity: "",
      rollsCount: "",
      separationReason: "",
      notes: "",
    })
    setShowSeparationDialog(true)
  }

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "dye":
        return "bg-blue-100 text-blue-800"
      case "chemical":
        return "bg-red-100 text-red-800"
      case "auxiliary":
        return "bg-green-100 text-green-800"
      case "finishing":
        return "bg-purple-100 text-purple-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <PageLayout title="أوامر التشغيل">
      {/* رأس الصفحة */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
        <h1 className="page-title mb-4 sm:mb-0">
          <ShoppingCart className="page-icon text-orange-600" />
          أوامر التشغيل
        </h1>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm" onClick={() => setShowSeparationsListDialog(true)}>
            <Scissors className="h-4 w-4 ml-2" />
            إدارة المنفصلات
          </Button>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 ml-2" />
            تصدير Excel
          </Button>
          <Button onClick={handleOpenDialog} size="sm">
            <Plus className="h-4 w-4 ml-2" />
            إضافة أمر تشغيل
          </Button>
        </div>
      </div>

      {/* تبويبات وفلاتر */}
      <Card className="mb-6 border-0 shadow-sm">
        <CardContent className="p-4">
          <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="mb-4">
            <TabsList className="grid grid-cols-4 mb-4">
              <TabsTrigger value="all">الكل</TabsTrigger>
              <TabsTrigger value="in_production" className="text-blue-600">
                قيد التشغيل
              </TabsTrigger>
              <TabsTrigger value="completed" className="text-green-600">
                مكتمل
              </TabsTrigger>
              <TabsTrigger value="with_separations" className="text-orange-600">
                بها منفصلات
              </TabsTrigger>
            </TabsList>
          </Tabs>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="relative">
              <Search className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="بحث..."
                className="pr-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Input
              type="date"
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              placeholder="التاريخ"
            />
            <Select value={customerFilter} onValueChange={setCustomerFilter}>
              <SelectTrigger>
                <SelectValue placeholder="العميل" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all_customers">جميع العملاء</SelectItem>
                {customers.map((customer) => (
                  <SelectItem key={customer.id} value={customer.id.toString()}>
                    {customer.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* جدول أوامر التشغيل */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-2">
          <CardTitle>أوامر التشغيل ({filteredOrders.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-right p-3">رقم الأمر</th>
                  <th className="text-right p-3">رقم الإذن</th>
                  <th className="text-right p-3">التاريخ</th>
                  <th className="text-right p-3">العميل</th>
                  <th className="text-right p-3">الصنف</th>
                  <th className="text-right p-3">الكمية الأصلية</th>
                  <th className="text-right p-3">المنفصلات</th>
                  <th className="text-right p-3">الكمية النهائية</th>
                  <th className="text-right p-3">تكلفة المواد</th>
                  <th className="text-right p-3">التكلفة للوحدة</th>
                  <th className="text-right p-3">الحالة</th>
                  <th className="text-right p-3">الإجراءات</th>
                </tr>
              </thead>
              <tbody>
                {filteredOrders.length > 0 ? (
                  filteredOrders.map((order) => (
                    <tr key={order.id} className="border-b hover:bg-gray-50">
                      <td className="p-3 font-mono">{order.orderNumber}</td>
                      <td className="p-3 font-mono">{order.permitNumber}</td>
                      <td className="p-3">{order.date}</td>
                      <td className="p-3 font-medium">{order.customerName}</td>
                      <td className="p-3">{order.materialName}</td>
                      <td className="p-3">
                        {order.quantity} {order.unit}
                      </td>
                      <td className="p-3">
                        {order.separatedQuantity > 0 ? (
                          <span className="text-orange-600 font-medium">
                            {order.separatedQuantity} {order.unit}
                          </span>
                        ) : (
                          <span className="text-gray-400">—</span>
                        )}
                      </td>
                      <td className="p-3 font-medium">
                        {order.finalQuantity} {order.unit}
                      </td>
                      <td className="p-3">
                        {order.costsCalculated ? (
                          <div className="flex items-center gap-2">
                            <span className="text-green-600 font-medium">
                              {order.totalMaterialsCost.toFixed(2)} ج.م
                            </span>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => openCostDetailsDialog(order)}
                              className="text-blue-600 hover:text-blue-700 p-1"
                            >
                              <Calculator className="h-3 w-3" />
                            </Button>
                          </div>
                        ) : (
                          <span className="text-gray-400">غير محسوبة</span>
                        )}
                      </td>
                      <td className="p-3">
                        {order.costsCalculated ? (
                          <span className="text-purple-600 font-medium">{order.costPerUnit.toFixed(2)} ج.م</span>
                        ) : (
                          <span className="text-gray-400">—</span>
                        )}
                      </td>
                      <td className="p-3">
                        <div className="flex items-center gap-2">
                          {order.status === "in_production" ? (
                            <div className="flex items-center">
                              <Clock className="h-4 w-4 text-blue-600 ml-1" />
                              <span className="badge badge-blue">قيد التشغيل</span>
                            </div>
                          ) : (
                            <div className="flex items-center">
                              <CheckCircle className="h-4 w-4 text-green-600 ml-1" />
                              <span className="badge badge-green">مكتمل</span>
                            </div>
                          )}
                          {order.hasSeparations && (
                            <span className="badge badge-orange">
                              <Scissors className="h-3 w-3 ml-1" />
                              منفصلات
                            </span>
                          )}
                          {!order.costsCalculated && order.status === "in_production" && (
                            <span className="badge badge-yellow">
                              <DollarSign className="h-3 w-3 ml-1" />
                              بدون تكاليف
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="p-3">
                        <div className="flex gap-1">
                          {order.status === "in_production" && (
                            <>
                              <Button
                                size="sm"
                                variant="outline"
                                className="text-purple-600 hover:text-purple-700"
                                onClick={() => openMaterialsDialog(order)}
                                title="إضافة/تعديل مواد الصباغة والتجهيز"
                              >
                                <Package className="h-4 w-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                className="text-orange-600 hover:text-orange-700"
                                onClick={() => openSeparationDialog(order)}
                              >
                                <Scissors className="h-4 w-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                className="text-green-600 hover:text-green-700"
                                onClick={() => openCompleteDialog(order)}
                              >
                                <CheckCircle className="h-4 w-4" />
                              </Button>
                            </>
                          )}
                          {order.status === "completed" && order.costsCalculated && (
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-blue-600 hover:text-blue-700"
                              onClick={() => openCostDetailsDialog(order)}
                              title="عرض تفاصيل التكلفة"
                            >
                              <Calculator className="h-4 w-4" />
                            </Button>
                          )}
                          {canDelete() && (
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-red-600 hover:text-red-700 hover:bg-red-50"
                              onClick={() => openDeleteDialog(order)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={12} className="p-4 text-center text-gray-500">
                      لا توجد بيانات للعرض
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* نافذة إضافة أمر تشغيل */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>إضافة أمر تشغيل جديد</DialogTitle>
            <DialogDescription>أدخل بيانات أمر التشغيل ثم اضغط على إضافة</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="orderNumber" className="text-right">
                  رقم الأمر
                </Label>
                <Input
                  id="orderNumber"
                  value={formData.orderNumber}
                  onChange={(e) => setFormData({ ...formData, orderNumber: e.target.value })}
                  className="col-span-3"
                  required
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="permitNumber" className="text-right">
                  رقم الإذن
                </Label>
                <Input
                  id="permitNumber"
                  value={formData.permitNumber}
                  onChange={(e) => setFormData({ ...formData, permitNumber: e.target.value })}
                  className="col-span-3"
                  required
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="date" className="text-right">
                  التاريخ
                </Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  className="col-span-3"
                  required
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="customer" className="text-right">
                  العميل
                </Label>
                <Select
                  value={formData.customerId}
                  onValueChange={(value) => setFormData({ ...formData, customerId: value })}
                >
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="اختر العميل" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="select_customer">اختر العميل</SelectItem>
                    {customers.map((customer) => (
                      <SelectItem key={customer.id} value={customer.id.toString()}>
                        {customer.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="material" className="text-right">
                  الصنف
                </Label>
                <Select
                  value={formData.materialId}
                  onValueChange={(value) => setFormData({ ...formData, materialId: value })}
                >
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="اختر الصنف" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="select_material">اختر الصنف</SelectItem>
                    {materials.map((material) => (
                      <SelectItem key={material.id} value={material.id.toString()}>
                        {material.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="quantity" className="text-right">
                  الكمية
                </Label>
                <Input
                  id="quantity"
                  type="number"
                  value={formData.quantity}
                  onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                  className="col-span-3"
                  required
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="notes" className="text-right">
                  ملاحظات
                </Label>
                <Input
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="col-span-3"
                />
              </div>
              <div className="bg-blue-50 p-4 rounded-md">
                <p className="text-blue-800 text-sm">
                  <strong>ملاحظة:</strong> يمكن إضافة مواد الصباغة والتجهيز وحساب التكلفة بعد إنشاء الأمر
                </p>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setShowDialog(false)}>
                إلغاء
              </Button>
              <Button type="submit">إضافة</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* نافذة إضافة مواد الصباغة والتجهيز */}
      <Dialog open={showMaterialsDialog} onOpenChange={setShowMaterialsDialog}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>إضافة مواد الصباغة والتجهيز</DialogTitle>
            <DialogDescription>
              أمر التشغيل رقم {selectedOrder?.orderNumber} - {selectedOrder?.customerName}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-6 py-4">
            {/* إضافة مادة جديدة */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 bg-gray-50 rounded-lg">
              <div className="md:col-span-2">
                <Label>المادة</Label>
                <Select
                  value={currentMaterial.materialId}
                  onValueChange={(value) => setCurrentMaterial({ ...currentMaterial, materialId: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="اختر المادة..." />
                  </SelectTrigger>
                  <SelectContent>
                    {dyeingMaterials.map((material) => (
                      <SelectItem key={material.id} value={material.id.toString()}>
                        {material.name} ({material.nameAr}) - متاح: {material.currentStock} {material.unit} - سعر:{" "}
                        {material.purchasePrice} ج.م
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>الكمية</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={currentMaterial.quantity}
                  onChange={(e) => setCurrentMaterial({ ...currentMaterial, quantity: e.target.value })}
                  placeholder="0.00"
                />
              </div>
              <div className="flex items-end">
                <Button
                  onClick={addMaterialToOrder}
                  disabled={!currentMaterial.materialId || !currentMaterial.quantity}
                  className="w-full"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  إضافة
                </Button>
              </div>
            </div>

            {/* جدول المواد المختارة */}
            <div className="border rounded-lg overflow-hidden">
              <div className="bg-gray-50 px-4 py-3 border-b">
                <h3 className="font-medium">المواد المختارة</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="text-right px-4 py-3 text-sm font-medium text-gray-600">المادة</th>
                      <th className="text-right px-4 py-3 text-sm font-medium text-gray-600">الفئة</th>
                      <th className="text-right px-4 py-3 text-sm font-medium text-gray-600">الكمية</th>
                      <th className="text-right px-4 py-3 text-sm font-medium text-gray-600">سعر الوحدة</th>
                      <th className="text-right px-4 py-3 text-sm font-medium text-gray-600">الإجمالي</th>
                      <th className="w-16 px-4 py-3"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {selectedMaterials.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="text-center py-8 text-gray-500">
                          لم يتم إضافة مواد بعد
                        </td>
                      </tr>
                    ) : (
                      selectedMaterials.map((item, index) => (
                        <tr key={index} className="hover:bg-gray-50">
                          <td className="px-4 py-3">
                            <div>
                              <p className="font-medium text-sm">{item.materialName}</p>
                              <p className="text-xs text-gray-500">{item.materialNameAr}</p>
                            </div>
                          </td>
                          <td className="px-4 py-3">
                            <Badge className={getCategoryColor(item.category)}>{item.category}</Badge>
                          </td>
                          <td className="px-4 py-3 text-right">
                            <span className="font-medium">
                              {item.quantity} {item.unit}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-right">{item.unitPrice.toFixed(2)} ج.م</td>
                          <td className="px-4 py-3 text-right font-medium text-blue-600">
                            {item.totalCost.toFixed(2)} ج.م
                          </td>
                          <td className="px-4 py-3">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => removeMaterialFromOrder(index)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </td>
                        </tr>
                      ))
                    )}
                    {selectedMaterials.length > 0 && (
                      <tr className="bg-blue-50 font-medium">
                        <td colSpan={4} className="px-4 py-3 text-right">
                          إجمالي التكلفة:
                        </td>
                        <td className="px-4 py-3 text-right text-blue-600 font-bold">
                          {calculateTotalCost().toFixed(2)} ج.م
                        </td>
                        <td></td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {selectedOrder && selectedMaterials.length > 0 && (
              <div className="bg-green-50 p-4 rounded-md">
                <p className="text-green-800 text-sm">
                  <strong>ملخص التكلفة:</strong>
                  <br />
                  إجمالي تكلفة المواد: {calculateTotalCost().toFixed(2)} ج.م
                  <br />
                  التكلفة للوحدة: {(calculateTotalCost() / selectedOrder.quantity).toFixed(2)} ج.م
                  <br />
                  <span className="text-red-600">ملاحظة: سيتم خصم المواد من المخزن عند الحفظ</span>
                </p>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowMaterialsDialog(false)}>
              إلغاء
            </Button>
            <Button
              onClick={saveMaterialsAndCalculateCost}
              disabled={selectedMaterials.length === 0}
              className="bg-purple-600 hover:bg-purple-700"
            >
              حفظ وحساب التكلفة
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* نافذة تفاصيل التكلفة */}
      <Dialog open={showCostDetailsDialog} onOpenChange={setShowCostDetailsDialog}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>تفاصيل تكلفة المواد</DialogTitle>
            <DialogDescription>
              أمر التشغيل رقم {selectedOrder?.orderNumber} - {selectedOrder?.customerName}
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            {selectedOrder?.materialsUsed && selectedOrder.materialsUsed.length > 0 ? (
              <div className="space-y-4">
                {/* ملخص التكلفة */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card className="p-4">
                    <div className="text-center">
                      <p className="text-sm text-gray-600">إجمالي التكلفة</p>
                      <p className="text-2xl font-bold text-blue-600">
                        {selectedOrder.totalMaterialsCost.toFixed(2)} ج.م
                      </p>
                    </div>
                  </Card>
                  <Card className="p-4">
                    <div className="text-center">
                      <p className="text-sm text-gray-600">التكلفة للوحدة</p>
                      <p className="text-2xl font-bold text-green-600">{selectedOrder.costPerUnit.toFixed(2)} ج.م</p>
                    </div>
                  </Card>
                  <Card className="p-4">
                    <div className="text-center">
                      <p className="text-sm text-gray-600">عدد المواد</p>
                      <p className="text-2xl font-bold text-purple-600">{selectedOrder.materialsUsed.length}</p>
                    </div>
                  </Card>
                </div>

                {/* تفاصيل المواد */}
                <div className="border rounded-lg overflow-hidden">
                  <div className="bg-gray-50 px-4 py-3 border-b">
                    <h3 className="font-medium">تفاصيل المواد المستخدمة</h3>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-gray-50 border-b">
                        <tr>
                          <th className="text-right px-4 py-3 text-sm font-medium text-gray-600">المادة</th>
                          <th className="text-right px-4 py-3 text-sm font-medium text-gray-600">الفئة</th>
                          <th className="text-right px-4 py-3 text-sm font-medium text-gray-600">الكمية</th>
                          <th className="text-right px-4 py-3 text-sm font-medium text-gray-600">سعر الوحدة</th>
                          <th className="text-right px-4 py-3 text-sm font-medium text-gray-600">الإجمالي</th>
                          <th className="text-right px-4 py-3 text-sm font-medium text-gray-600">النسبة</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200">
                        {selectedOrder.materialsUsed.map((item, index) => (
                          <tr key={index} className="hover:bg-gray-50">
                            <td className="px-4 py-3">
                              <div>
                                <p className="font-medium text-sm">{item.materialName}</p>
                                <p className="text-xs text-gray-500">{item.materialNameAr}</p>
                              </div>
                            </td>
                            <td className="px-4 py-3">
                              <Badge className={getCategoryColor(item.category)}>{item.category}</Badge>
                            </td>
                            <td className="px-4 py-3 text-right">
                              <span className="font-medium">
                                {item.quantity} {item.unit}
                              </span>
                            </td>
                            <td className="px-4 py-3 text-right">{item.unitPrice.toFixed(2)} ج.م</td>
                            <td className="px-4 py-3 text-right font-medium text-blue-600">
                              {item.totalCost.toFixed(2)} ج.م
                            </td>
                            <td className="px-4 py-3 text-right">
                              {((item.totalCost / selectedOrder.totalMaterialsCost) * 100).toFixed(1)}%
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">لم يتم إضافة مواد لهذا الأمر بعد</div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCostDetailsDialog(false)}>
              إغلاق
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* نافذة تأكيد الحذف */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center text-red-600">
              <AlertTriangle className="h-5 w-5 ml-2" />
              تأكيد حذف أمر التشغيل
            </DialogTitle>
            <DialogDescription>
              هل أنت متأكد من حذف أمر التشغيل رقم {selectedOrder?.orderNumber}؟
              <br />
              <span className="text-red-600 font-medium">سيتم حذف جميع المنفصلات المرتبطة بهذا الأمر أيضاً!</span>
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="bg-red-50 border border-red-200 rounded-md p-4">
              <div className="flex items-center">
                <AlertTriangle className="h-5 w-5 text-red-600 ml-2" />
                <div className="text-sm text-red-800">
                  <p className="font-medium">تفاصيل أمر التشغيل المراد حذفه:</p>
                  <p>العميل: {selectedOrder?.customerName}</p>
                  <p>الصنف: {selectedOrder?.materialName}</p>
                  <p>
                    الكمية: {selectedOrder?.quantity} {selectedOrder?.unit}
                  </p>
                  <p>الحالة: {selectedOrder?.status === "in_production" ? "قيد التشغيل" : "مكتمل"}</p>
                  {selectedOrder?.hasSeparations && (
                    <p className="text-orange-600 font-medium">يحتوي على منفصلات سيتم حذفها</p>
                  )}
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>
              إلغاء
            </Button>
            <Button variant="destructive" onClick={handleDeleteOrder}>
              <Trash2 className="h-4 w-4 ml-2" />
              تأكيد الحذف
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* نافذة إكمال أمر تشغيل مع إمكانية الفصل */}
      <Dialog open={showCompleteDialog} onOpenChange={setShowCompleteDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>إكمال أمر التشغيل</DialogTitle>
            <DialogDescription>
              أمر التشغيل رقم {selectedOrder?.orderNumber} - هل تريد فصل كمية قبل الإكمال؟
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="hasSeparation"
                checked={completionFormData.hasSeparation}
                onChange={(e) => setCompletionFormData({ ...completionFormData, hasSeparation: e.target.checked })}
              />
              <Label htmlFor="hasSeparation">يوجد كمية منفصلة</Label>
            </div>

            {completionFormData.hasSeparation && (
              <>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="separatedQuantity" className="text-right">
                    الكمية المنفصلة
                  </Label>
                  <Input
                    id="separatedQuantity"
                    type="number"
                    value={completionFormData.separatedQuantity}
                    onChange={(e) =>
                      setCompletionFormData({ ...completionFormData, separatedQuantity: e.target.value })
                    }
                    className="col-span-3"
                    max={selectedOrder?.finalQuantity}
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="rollsCount" className="text-right">
                    عدد الأتواب
                  </Label>
                  <Input
                    id="rollsCount"
                    type="number"
                    value={completionFormData.rollsCount}
                    onChange={(e) => setCompletionFormData({ ...completionFormData, rollsCount: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="separationReason" className="text-right">
                    سبب الفصل
                  </Label>
                  <Select
                    value={completionFormData.separationReason}
                    onValueChange={(value) => setCompletionFormData({ ...completionFormData, separationReason: value })}
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="اختر السبب" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="عيوب في الصباغة">عيوب في الصباغة</SelectItem>
                      <SelectItem value="عيوب في النسيج">عيوب في النسيج</SelectItem>
                      <SelectItem value="عيوب في القطع">عيوب في القطع</SelectItem>
                      <SelectItem value="مواصفات غير مطابقة">مواصفات غير مطابقة</SelectItem>
                      <SelectItem value="أخرى">أخرى</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="separationNotes" className="text-right">
                    ملاحظات الفصل
                  </Label>
                  <Input
                    id="separationNotes"
                    value={completionFormData.separationNotes}
                    onChange={(e) => setCompletionFormData({ ...completionFormData, separationNotes: e.target.value })}
                    className="col-span-3"
                  />
                </div>
              </>
            )}

            <div className="bg-blue-50 p-4 rounded-md">
              <p className="text-blue-800 text-sm">
                <strong>ملاحظة:</strong> سيتم ترحيل الكمية النهائية إلى مخزن الجاهز، والمنفصلات ستبقى في مخزن الإنتاج.
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCompleteDialog(false)}>
              إلغاء
            </Button>
            <Button onClick={handleCompleteOrder} className="bg-green-600 hover:bg-green-700">
              تأكيد الإكمال
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* نافذة فصل كمية من أمر قيد التشغيل */}
      <Dialog open={showSeparationDialog} onOpenChange={setShowSeparationDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>فصل كمية من الإنتاج</DialogTitle>
            <DialogDescription>
              فصل كمية من أمر التشغيل رقم {selectedOrder?.orderNumber} (متاح: {selectedOrder?.finalQuantity}{" "}
              {selectedOrder?.unit})
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="separatedQuantity" className="text-right">
                الكمية المنفصلة
              </Label>
              <Input
                id="separatedQuantity"
                type="number"
                value={separationFormData.separatedQuantity}
                onChange={(e) => setSeparationFormData({ ...separationFormData, separatedQuantity: e.target.value })}
                className="col-span-3"
                max={selectedOrder?.finalQuantity}
                required
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="rollsCount" className="text-right">
                عدد الأتواب
              </Label>
              <Input
                id="rollsCount"
                type="number"
                value={separationFormData.rollsCount}
                onChange={(e) => setSeparationFormData({ ...separationFormData, rollsCount: e.target.value })}
                className="col-span-3"
                required
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="separationReason" className="text-right">
                سبب الفصل
              </Label>
              <Select
                value={separationFormData.separationReason}
                onValueChange={(value) => setSeparationFormData({ ...separationFormData, separationReason: value })}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="اختر السبب" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="عيوب في الصباغة">عيوب في الصباغة</SelectItem>
                  <SelectItem value="عيوب في النسيج">عيوب في النسيج</SelectItem>
                  <SelectItem value="عيوب في القطع">عيوب في القطع</SelectItem>
                  <SelectItem value="مواصفات غير مطابقة">مواصفات غير مطابقة</SelectItem>
                  <SelectItem value="أخرى">أخرى</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="notes" className="text-right">
                ملاحظات
              </Label>
              <Input
                id="notes"
                value={separationFormData.notes}
                onChange={(e) => setSeparationFormData({ ...separationFormData, notes: e.target.value })}
                className="col-span-3"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowSeparationDialog(false)}>
              إلغاء
            </Button>
            <Button onClick={handleSeparateQuantity} className="bg-orange-600 hover:bg-orange-700">
              فصل الكمية
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* نافذة إدارة المنفصلات */}
      <Dialog open={showSeparationsListDialog} onOpenChange={setShowSeparationsListDialog}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between">
              <span>إدارة المنفصلات</span>
              <Button
                onClick={() => setShowReprocessDialog(true)}
                disabled={selectedSeparations.length === 0}
                size="sm"
              >
                <RotateCcw className="h-4 w-4 ml-2" />
                إعادة تشغيل المحدد
              </Button>
            </DialogTitle>
            <DialogDescription>جميع المنفصلات المتاحة في مخزن الإنتاج</DialogDescription>
          </DialogHeader>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-right p-3">
                    <input
                      type="checkbox"
                      onChange={(e) => {
                        if (e.target.checked) {
                          setSelectedSeparations(availableSeparations.map((s) => s.id))
                        } else {
                          setSelectedSeparations([])
                        }
                      }}
                      checked={
                        selectedSeparations.length === availableSeparations.length && availableSeparations.length > 0
                      }
                    />
                  </th>
                  <th className="text-right p-3">رقم المنفصل</th>
                  <th className="text-right p-3">أمر التشغيل</th>
                  <th className="text-right p-3">العميل</th>
                  <th className="text-right p-3">الصنف</th>
                  <th className="text-right p-3">الكمية</th>
                  <th className="text-right p-3">السبب</th>
                  <th className="text-right p-3">التاريخ</th>
                  <th className="text-right p-3">الحالة</th>
                </tr>
              </thead>
              <tbody>
                {separations.map((separation) => (
                  <tr key={separation.id} className="border-b hover:bg-gray-50">
                    <td className="p-3">
                      {separation.status === "separated" && (
                        <input
                          type="checkbox"
                          checked={selectedSeparations.includes(separation.id)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedSeparations([...selectedSeparations, separation.id])
                            } else {
                              setSelectedSeparations(selectedSeparations.filter((id) => id !== separation.id))
                            }
                          }}
                        />
                      )}
                    </td>
                    <td className="p-3 font-mono">{separation.separationNumber}</td>
                    <td className="p-3 font-mono">{separation.productionOrderNumber}</td>
                    <td className="p-3">{separation.customerName}</td>
                    <td className="p-3">{separation.materialName}</td>
                    <td className="p-3">
                      {separation.separatedQuantity} {materials.find((m) => m.id === separation.materialId)?.unit}
                    </td>
                    <td className="p-3">{separation.separationReason}</td>
                    <td className="p-3">{separation.separationDate}</td>
                    <td className="p-3">
                      {separation.status === "separated" ? (
                        <span className="badge badge-orange">متاح</span>
                      ) : (
                        <span className="badge badge-green">تم إعادة التشغيل</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowSeparationsListDialog(false)}>
              إغلاق
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* نافذة تأكيد إعادة التشغيل */}
      <Dialog open={showReprocessDialog} onOpenChange={setShowReprocessDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>تأكيد إعادة التشغيل</DialogTitle>
            <DialogDescription>
              هل أنت متأكد من إعادة تشغيل {selectedSeparations.length} منفصل؟ سيتم إنشاء أمر تشغيل جديد.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="bg-blue-50 p-4 rounded-md">
              <p className="text-blue-800 text-sm">
                <strong>سيتم:</strong>
                <br />• إنشاء أمر تشغيل جديد بإجمالي الكميات المحددة
                <br />• تغيير حالة المنفصلات إلى "تم إعادة التشغيل"
                <br />• ربط المنفصلات بالأمر الجديد
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowReprocessDialog(false)}>
              إلغاء
            </Button>
            <Button onClick={handleReprocessSeparations} className="bg-blue-600 hover:bg-blue-700">
              تأكيد إعادة التشغيل
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageLayout>
  )
}
