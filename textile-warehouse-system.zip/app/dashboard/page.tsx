"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Users,
  Package,
  ShoppingCart,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Clock,
  DollarSign,
  BarChart3,
  FileText,
} from "lucide-react"
import { useAuth } from "@/components/auth-provider"
import Link from "next/link"

export default function DashboardPage() {
  const { currentUser, isAdmin } = useAuth()

  const stats = [
    {
      title: "إجمالي العملاء",
      value: "24",
      change: "+2.5%",
      icon: Users,
      color: "text-blue-600",
      bgColor: "bg-blue-100",
    },
    {
      title: "أوامر التشغيل النشطة",
      value: "12",
      change: "+5.2%",
      icon: ShoppingCart,
      color: "text-green-600",
      bgColor: "bg-green-100",
    },
    {
      title: "إجمالي الأصناف",
      value: "156",
      change: "+1.8%",
      icon: Package,
      color: "text-purple-600",
      bgColor: "bg-purple-100",
    },
    {
      title: "المبيعات الشهرية",
      value: "₹ 45,230",
      change: "+12.3%",
      icon: DollarSign,
      color: "text-orange-600",
      bgColor: "bg-orange-100",
    },
  ]

  const recentOrders = [
    {
      id: "PO001",
      customer: "شركة النسيج المتحدة",
      status: "قيد التنفيذ",
      amount: "₹ 15,000",
      progress: 75,
    },
    {
      id: "PO002",
      customer: "مصنع القطن السعودي",
      status: "مكتمل",
      amount: "₹ 22,500",
      progress: 100,
    },
    {
      id: "PO003",
      customer: "شركة الألياف الحديثة",
      status: "في الانتظار",
      amount: "₹ 8,750",
      progress: 25,
    },
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "مكتمل":
        return "bg-green-100 text-green-800"
      case "قيد التنفيذ":
        return "bg-blue-100 text-blue-800"
      case "في الانتظار":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "مكتمل":
        return <CheckCircle className="h-4 w-4" />
      case "قيد التنفيذ":
        return <Clock className="h-4 w-4" />
      case "في الانتظار":
        return <AlertTriangle className="h-4 w-4" />
      default:
        return <Clock className="h-4 w-4" />
    }
  }

  return (
    <div className="space-y-6">
      {/* Welcome Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">مرحباً، {currentUser?.fullName}</h1>
          <p className="text-gray-600 mt-1">إليك نظرة عامة على أداء النظام اليوم</p>
        </div>
        <div className="flex items-center space-x-2 space-x-reverse">
          <Badge variant="outline" className="text-green-600 border-green-600">
            متصل
          </Badge>
          {isAdmin() && <Badge variant="secondary">مدير النظام</Badge>}
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <Card key={index} className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                  <p className="text-2xl font-bold text-gray-900 mt-2">{stat.value}</p>
                  <p className="text-sm text-green-600 mt-1">{stat.change} من الشهر الماضي</p>
                </div>
                <div className={`p-3 rounded-full ${stat.bgColor}`}>
                  <stat.icon className={`h-6 w-6 ${stat.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Orders */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <ShoppingCart className="h-5 w-5 ml-2" />
              أوامر التشغيل الأخيرة
            </CardTitle>
            <CardDescription>آخر أوامر التشغيل في النظام</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentOrders.map((order) => (
                <div
                  key={order.id}
                  className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-gray-900">{order.id}</h4>
                      <Badge className={getStatusColor(order.status)}>
                        <div className="flex items-center space-x-1 space-x-reverse">
                          {getStatusIcon(order.status)}
                          <span>{order.status}</span>
                        </div>
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{order.customer}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-gray-900">{order.amount}</span>
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <Progress value={order.progress} className="w-20" />
                        <span className="text-xs text-gray-500">{order.progress}%</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-4">
              <Button asChild variant="outline" className="w-full">
                <Link href="/production-orders">عرض جميع أوامر التشغيل</Link>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUp className="h-5 w-5 ml-2" />
              الإجراءات السريعة
            </CardTitle>
            <CardDescription>الوظائف الأكثر استخداماً</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <Button asChild variant="outline" className="h-20 flex-col">
                <Link href="/customers">
                  <Users className="h-6 w-6 mb-2" />
                  إدارة العملاء
                </Link>
              </Button>
              <Button asChild variant="outline" className="h-20 flex-col">
                <Link href="/production-orders">
                  <ShoppingCart className="h-6 w-6 mb-2" />
                  أوامر التشغيل
                </Link>
              </Button>
              <Button asChild variant="outline" className="h-20 flex-col">
                <Link href="/materials">
                  <Package className="h-6 w-6 mb-2" />
                  إدارة الأصناف
                </Link>
              </Button>
              <Button asChild variant="outline" className="h-20 flex-col">
                <Link href="/reports">
                  <BarChart3 className="h-6 w-6 mb-2" />
                  التقارير
                </Link>
              </Button>
              <Button asChild variant="outline" className="h-20 flex-col">
                <Link href="/inventory">
                  <Package className="h-6 w-6 mb-2" />
                  المخزون
                </Link>
              </Button>
              <Button asChild variant="outline" className="h-20 flex-col">
                <Link href="/invoices">
                  <FileText className="h-6 w-6 mb-2" />
                  الفواتير
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* System Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <BarChart3 className="h-5 w-5 ml-2" />
            حالة النظام
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">98.5%</div>
              <div className="text-sm text-gray-600">وقت التشغيل</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">1.2s</div>
              <div className="text-sm text-gray-600">متوسط الاستجابة</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">156</div>
              <div className="text-sm text-gray-600">المعاملات اليومية</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
