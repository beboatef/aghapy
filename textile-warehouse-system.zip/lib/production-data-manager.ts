/**
 * مدير البيانات للإنتاج مع قاعدة البيانات الحقيقية
 * Production Data Manager with Real Database
 */

import { executeQuery, executeInsert } from "./database-connection"
import { verifyPassword } from "./auth-utils"

export class ProductionDataManager {
  // ==================== إدارة العملاء ====================

  async getCustomers(filters?: {
    active?: boolean
    search?: string
    city?: string
    limit?: number
    offset?: number
  }) {
    let query = `
      SELECT c.*, u.full_name as created_by_name
      FROM customers c
      LEFT JOIN users u ON c.created_by = u.id
      WHERE 1=1
    `
    const params: any[] = []

    if (filters?.active !== undefined) {
      query += " AND c.is_active = ?"
      params.push(filters.active)
    }

    if (filters?.search) {
      query += " AND (c.name LIKE ? OR c.code LIKE ? OR c.phone LIKE ?)"
      const searchTerm = `%${filters.search}%`
      params.push(searchTerm, searchTerm, searchTerm)
    }

    if (filters?.city) {
      query += " AND c.city = ?"
      params.push(filters.city)
    }

    query += " ORDER BY c.name"

    if (filters?.limit) {
      query += " LIMIT ?"
      params.push(filters.limit)

      if (filters?.offset) {
        query += " OFFSET ?"
        params.push(filters.offset)
      }
    }

    return await executeQuery(query, params)
  }

  async addCustomer(customer: any, userId: number) {
    const query = `
      INSERT INTO customers (
        code, name, name_en, phone, email, address, city, country,
        tax_number, credit_limit, payment_terms, notes, created_by
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `

    const params = [
      customer.code,
      customer.name,
      customer.nameEn || null,
      customer.phone || null,
      customer.email || null,
      customer.address || null,
      customer.city || null,
      customer.country || "Saudi Arabia",
      customer.taxNumber || null,
      customer.creditLimit || 0,
      customer.paymentTerms || 30,
      customer.notes || null,
      userId,
    ]

    const result = await executeInsert(query, params)

    // تسجيل النشاط
    await this.logActivity(userId, "CREATE", "customers", result.insertId, null, customer)

    return result
  }

  async updateCustomer(customerId: number, customer: any, userId: number) {
    // الحصول على البيانات القديمة للمراجعة
    const oldData = await executeQuery("SELECT * FROM customers WHERE id = ?", [customerId])

    const query = `
      UPDATE customers SET
        code = ?, name = ?, name_en = ?, phone = ?, email = ?, address = ?,
        city = ?, country = ?, tax_number = ?, credit_limit = ?, payment_terms = ?,
        is_active = ?, notes = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `

    const params = [
      customer.code,
      customer.name,
      customer.nameEn || null,
      customer.phone || null,
      customer.email || null,
      customer.address || null,
      customer.city || null,
      customer.country || "Saudi Arabia",
      customer.taxNumber || null,
      customer.creditLimit || 0,
      customer.paymentTerms || 30,
      customer.isActive !== undefined ? customer.isActive : true,
      customer.notes || null,
      customerId,
    ]

    const result = await executeQuery(query, params)

    // تسجيل النشاط
    await this.logActivity(userId, "UPDATE", "customers", customerId, oldData[0], customer)

    return result
  }

  async deleteCustomer(customerId: number, userId: number) {
    // التحقق من وجود بيانات مرتبطة
    const relatedData = await executeQuery(
      `
      SELECT 
        (SELECT COUNT(*) FROM inventory_movements WHERE customer_id = ?) as movements,
        (SELECT COUNT(*) FROM production_orders WHERE customer_id = ?) as orders,
        (SELECT COUNT(*) FROM delivery_statements WHERE customer_id = ?) as deliveries
    `,
      [customerId, customerId, customerId],
    )

    if (relatedData[0].movements > 0 || relatedData[0].orders > 0 || relatedData[0].deliveries > 0) {
      throw new Error("لا يمكن حذف العميل لوجود بيانات مرتبطة به")
    }

    // الحصول على البيانات للمراجعة
    const oldData = await executeQuery("SELECT * FROM customers WHERE id = ?", [customerId])

    const result = await executeQuery("DELETE FROM customers WHERE id = ?", [customerId])

    // تسجيل النشاط
    await this.logActivity(userId, "DELETE", "customers", customerId, oldData[0], null)

    return result
  }

  // ==================== إدارة الأصناف ====================

  async getMaterials(filters?: {
    active?: boolean
    category?: string
    search?: string
    limit?: number
    offset?: number
  }) {
    let query = `
      SELECT m.*, u.full_name as created_by_name
      FROM materials m
      LEFT JOIN users u ON m.created_by = u.id
      WHERE 1=1
    `
    const params: any[] = []

    if (filters?.active !== undefined) {
      query += " AND m.is_active = ?"
      params.push(filters.active)
    }

    if (filters?.category) {
      query += " AND m.category = ?"
      params.push(filters.category)
    }

    if (filters?.search) {
      query += " AND (m.name LIKE ? OR m.code LIKE ? OR m.name_en LIKE ?)"
      const searchTerm = `%${filters.search}%`
      params.push(searchTerm, searchTerm, searchTerm)
    }

    query += " ORDER BY m.name"

    if (filters?.limit) {
      query += " LIMIT ?"
      params.push(filters.limit)

      if (filters?.offset) {
        query += " OFFSET ?"
        params.push(filters.offset)
      }
    }

    return await executeQuery(query, params)
  }

  // ==================== حركات المخزون ====================

  async getInventoryMovements(filters?: {
    customerId?: number
    materialId?: number
    type?: string
    dateFrom?: string
    dateTo?: string
    status?: string
    limit?: number
    offset?: number
  }) {
    let query = `
      SELECT 
        im.*,
        c.name as customer_name,
        c.code as customer_code,
        m.name as material_name,
        m.code as material_code,
        m.unit as material_unit,
        u.full_name as created_by_name
      FROM inventory_movements im
      LEFT JOIN customers c ON im.customer_id = c.id
      LEFT JOIN materials m ON im.material_id = m.id
      LEFT JOIN users u ON im.created_by = u.id
      WHERE 1=1
    `
    const params: any[] = []

    if (filters?.customerId) {
      query += " AND im.customer_id = ?"
      params.push(filters.customerId)
    }

    if (filters?.materialId) {
      query += " AND im.material_id = ?"
      params.push(filters.materialId)
    }

    if (filters?.type) {
      query += " AND im.movement_type = ?"
      params.push(filters.type)
    }

    if (filters?.dateFrom) {
      query += " AND im.date >= ?"
      params.push(filters.dateFrom)
    }

    if (filters?.dateTo) {
      query += " AND im.date <= ?"
      params.push(filters.dateTo)
    }

    if (filters?.status) {
      query += " AND im.status = ?"
      params.push(filters.status)
    }

    query += " ORDER BY im.date DESC, im.created_at DESC"

    if (filters?.limit) {
      query += " LIMIT ?"
      params.push(filters.limit)

      if (filters?.offset) {
        query += " OFFSET ?"
        params.push(filters.offset)
      }
    }

    return await executeQuery(query, params)
  }

  // ==================== الأرصدة ====================

  async getCurrentBalances(filters?: {
    customerId?: number
    materialId?: number
    nonZeroOnly?: boolean
  }) {
    let query = "SELECT * FROM v_current_balances WHERE 1=1"
    const params: any[] = []

    if (filters?.customerId) {
      query += " AND customer_id = ?"
      params.push(filters.customerId)
    }

    if (filters?.materialId) {
      query += " AND material_id = ?"
      params.push(filters.materialId)
    }

    if (filters?.nonZeroOnly) {
      query += " AND current_balance != 0"
    }

    query += " ORDER BY customer_name, material_name"

    return await executeQuery(query, params)
  }

  // ==================== إحصائيات لوحة التحكم ====================

  async getDashboardStats() {
    const stats = await executeQuery("SELECT * FROM v_dashboard_stats")
    return stats[0] || {}
  }

  // ==================== تسجيل النشاطات ====================

  async logActivity(
    userId: number,
    action: string,
    tableName: string,
    recordId: number | null,
    oldValues: any,
    newValues: any,
    ipAddress?: string,
    userAgent?: string,
  ) {
    const query = `
      INSERT INTO activity_log (
        user_id, action, table_name, record_id, old_values, new_values, ip_address, user_agent
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `

    const params = [
      userId,
      action,
      tableName,
      recordId,
      oldValues ? JSON.stringify(oldValues) : null,
      newValues ? JSON.stringify(newValues) : null,
      ipAddress || null,
      userAgent || null,
    ]

    return await executeInsert(query, params)
  }

  // ==================== إدارة المستخدمين ====================

  async authenticateUser(username: string, password: string) {
    const users = await executeQuery("SELECT * FROM users WHERE username = ? AND is_active = TRUE", [username])

    if (users.length === 0) {
      return null
    }

    const user = users[0]

    // التحقق من القفل
    if (user.locked_until && new Date(user.locked_until) > new Date()) {
      throw new Error("الحساب مقفل مؤقتاً بسبب محاولات تسجيل دخول فاشلة")
    }

    // التحقق من كلمة المرور
    const isValidPassword = await verifyPassword(password, user.password_hash)

    if (!isValidPassword) {
      // زيادة عدد المحاولات الفاشلة
      await this.incrementFailedLoginAttempts(user.id)
      return null
    }

    // إعادة تعيين المحاولات الفاشلة وتحديث آخر دخول
    await executeQuery(
      "UPDATE users SET failed_login_attempts = 0, locked_until = NULL, last_login = CURRENT_TIMESTAMP WHERE id = ?",
      [user.id],
    )

    // إزالة كلمة المرور من النتيجة
    delete user.password_hash
    return user
  }

  async incrementFailedLoginAttempts(userId: number) {
    const maxAttempts = 3
    const lockoutDuration = 15 // minutes

    await executeQuery(
      `
      UPDATE users SET 
        failed_login_attempts = failed_login_attempts + 1,
        locked_until = CASE 
          WHEN failed_login_attempts + 1 >= ? 
          THEN DATE_ADD(CURRENT_TIMESTAMP, INTERVAL ? MINUTE)
          ELSE locked_until
        END
      WHERE id = ?
    `,
      [maxAttempts, lockoutDuration, userId],
    )
  }

  // ==================== النسخ الاحتياطي ====================

  async createBackup(userId: number, backupType: "manual" | "automatic" = "manual") {
    const backupName = `backup_${new Date().toISOString().replace(/[:.]/g, "-")}`

    const result = await executeInsert(
      `
      INSERT INTO backups (backup_name, backup_type, status, created_by)
      VALUES (?, ?, 'in_progress', ?)
    `,
      [backupName, backupType, userId],
    )

    // هنا يمكن إضافة منطق النسخ الاحتياطي الفعلي
    // مثل تصدير البيانات إلى ملف أو رفعها إلى التخزين السحابي

    return { backupId: result.insertId, backupName }
  }

  // ==================== فحص صحة النظام ====================

  async getSystemHealth() {
    try {
      const stats = await this.getDashboardStats()
      const recentActivity = await executeQuery(
        "SELECT COUNT(*) as count FROM activity_log WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)",
        [],
      )

      return {
        status: "healthy",
        database: "connected",
        stats,
        recentActivity: recentActivity[0].count,
        timestamp: new Date().toISOString(),
      }
    } catch (error) {
      return {
        status: "unhealthy",
        error: error.message,
        timestamp: new Date().toISOString(),
      }
    }
  }
}

// إنشاء instance واحد للاستخدام
export const productionDataManager = new ProductionDataManager()
