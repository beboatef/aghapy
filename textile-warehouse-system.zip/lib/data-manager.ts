class DataManager {
  private data: { [key: string]: any[] } = {}
  private listeners: { [key: string]: (() => void)[] } = {}

  constructor() {
    this.initializeSystemWithSampleData()
  }

  private initializeSystemWithSampleData() {
    // إنشاء بيانات وهمية متسقة ومترابطة
    this.createSampleCustomers()
    this.createSampleMaterials()
    this.createSampleUsers()
    this.createSampleProductionOrders()
    this.createSampleDyeingMaterials()
    this.createSampleInventoryMovements()
    this.createSampleInvoices()
  }

  private createSampleCustomers() {
    const customers = [
      {
        id: 1,
        code: "C001",
        name: "شركة النسيج المتحدة",
        phone: "0112345678",
        email: "info@textile-united.com",
        address: "الرياض، المملكة العربية السعودية",
        city: "الرياض",
        isActive: true,
        createdAt: "2024-01-15",
      },
      {
        id: 2,
        code: "C002",
        name: "مصنع الألوان الحديث",
        phone: "0123456789",
        email: "contact@modern-colors.com",
        address: "جدة، المملكة العربية السعودية",
        city: "جدة",
        isActive: true,
        createdAt: "2024-01-20",
      },
      {
        id: 3,
        code: "C003",
        name: "شركة القطن السعودي",
        phone: "0134567890",
        email: "sales@saudi-cotton.com",
        address: "الدمام، المملكة العربية السعودية",
        city: "الدمام",
        isActive: true,
        createdAt: "2024-02-01",
      },
      {
        id: 4,
        code: "C004",
        name: "مؤسسة الخيوط الذهبية",
        phone: "0145678901",
        email: "info@golden-threads.com",
        address: "مكة المكرمة، المملكة العربية السعودية",
        city: "مكة المكرمة",
        isActive: true,
        createdAt: "2024-02-10",
      },
    ]
    this.data.customers = customers
  }

  private createSampleMaterials() {
    const materials = [
      {
        id: 1,
        code: "M001",
        name: "قطن أبيض خام",
        unit: "كجم",
        category: "خام",
        isActive: true,
        createdAt: "2024-01-10",
      },
      {
        id: 2,
        code: "M002",
        name: "بوليستر أزرق",
        unit: "متر",
        category: "مصبوغ",
        isActive: true,
        createdAt: "2024-01-12",
      },
      {
        id: 3,
        code: "M003",
        name: "قطن ملون",
        unit: "كجم",
        category: "مصبوغ",
        isActive: true,
        createdAt: "2024-01-15",
      },
      {
        id: 4,
        code: "M004",
        name: "حرير طبيعي",
        unit: "متر",
        category: "فاخر",
        isActive: true,
        createdAt: "2024-01-18",
      },
    ]
    this.data.materials = materials
  }

  private createSampleUsers() {
    const users = [
      {
        id: 1,
        username: "admin",
        password: "admin123",
        fullName: "مدير النظام",
        role: "admin",
        permissions: { all: true },
        active: true,
        lastLogin: "2024-03-15 10:30:00",
        createdAt: "2024-01-01",
      },
      {
        id: 2,
        username: "operator1",
        password: "op123",
        fullName: "أحمد محمد",
        role: "operator",
        permissions: { production: true, materials: true },
        active: true,
        lastLogin: "2024-03-15 09:15:00",
        createdAt: "2024-01-05",
      },
    ]
    this.data.users = users
  }

  private createSampleProductionOrders() {
    const productionOrders = [
      {
        id: 1,
        orderNumber: "PO001",
        permitNumber: "OUT001",
        date: "2024-03-01",
        customerId: 1,
        customerName: "شركة النسيج المتحدة",
        materialId: 1,
        materialName: "قطن أبيض خام",
        quantity: 150,
        separatedQuantity: 25.5,
        finalQuantity: 124.5,
        unit: "كجم",
        status: "in_production",
        hasSeparations: true,
        notes: "صباغة باللون الأزرق",
        createdAt: "2024-03-01",
        materialsUsed: [],
        totalMaterialsCost: 0,
        costPerUnit: 0,
        costsCalculated: false,
      },
      {
        id: 2,
        orderNumber: "PO002",
        permitNumber: "OUT002",
        date: "2024-03-02",
        customerId: 2,
        customerName: "مصنع الألوان الحديث",
        materialId: 2,
        materialName: "بوليستر أزرق",
        quantity: 75,
        separatedQuantity: 15,
        finalQuantity: 60,
        unit: "متر",
        status: "in_production",
        hasSeparations: true,
        notes: "صباغة باللون الأحمر",
        createdAt: "2024-03-02",
        materialsUsed: [],
        totalMaterialsCost: 0,
        costPerUnit: 0,
        costsCalculated: false,
      },
      {
        id: 3,
        orderNumber: "PO003",
        permitNumber: "OUT003",
        date: "2024-03-03",
        customerId: 3,
        customerName: "شركة القطن السعودي",
        materialId: 3,
        materialName: "قطن ملون",
        quantity: 100,
        separatedQuantity: 30,
        finalQuantity: 70,
        unit: "كجم",
        status: "in_production",
        hasSeparations: true,
        notes: "صباغة باللون الأخضر",
        createdAt: "2024-03-03",
        materialsUsed: [],
        totalMaterialsCost: 0,
        costPerUnit: 0,
        costsCalculated: false,
      },
      {
        id: 4,
        orderNumber: "PO004",
        permitNumber: "OUT004",
        date: "2024-03-04",
        customerId: 4,
        customerName: "مؤسسة الخيوط الذهبية",
        materialId: 4,
        materialName: "حرير طبيعي",
        quantity: 50,
        separatedQuantity: 0,
        finalQuantity: 50,
        unit: "متر",
        status: "in_production",
        hasSeparations: false,
        notes: "تجهيز للتصدير",
        createdAt: "2024-03-04",
        materialsUsed: [],
        totalMaterialsCost: 0,
        costPerUnit: 0,
        costsCalculated: false,
      },
    ]
    this.data.productionOrders = productionOrders
  }

  private createSampleDyeingMaterials() {
    const dyeingMaterials = [
      {
        id: "dye001",
        code: "DYE001",
        name: "Direct Blue 86",
        nameAr: "أزرق مباشر 86",
        category: "dye",
        unit: "kg",
        purchasePrice: 45.5,
        currentStock: 125.5,
        minimumStock: 20,
      },
      {
        id: "chm001",
        code: "CHM001",
        name: "Acetic Acid",
        nameAr: "حمض الخليك",
        category: "chemical",
        unit: "liter",
        purchasePrice: 12.75,
        currentStock: 85.2,
        minimumStock: 15,
      },
      {
        id: "aux001",
        code: "AUX001",
        name: "Fabric Softener",
        nameAr: "منعم الأقمشة",
        category: "auxiliary",
        unit: "kg",
        purchasePrice: 28.9,
        currentStock: 45.8,
        minimumStock: 25,
      },
      {
        id: "dye002",
        code: "DYE002",
        name: "Reactive Red 195",
        nameAr: "أحمر تفاعلي 195",
        category: "dye",
        unit: "kg",
        purchasePrice: 52.3,
        currentStock: 78.4,
        minimumStock: 20,
      },
      {
        id: "chm002",
        code: "CHM002",
        name: "Sodium Carbonate",
        nameAr: "كربونات الصوديوم",
        category: "chemical",
        unit: "kg",
        purchasePrice: 8.45,
        currentStock: 245.6,
        minimumStock: 50,
      },
    ]
    this.data.dyeingMaterials = dyeingMaterials
  }

  private createSampleInventoryMovements() {
    const inventoryMovements = [
      {
        id: 1,
        permitNumber: "IN001",
        type: "incoming",
        date: "2024-03-01",
        customerId: 1,
        customerName: "شركة النسيج المتحدة",
        materialId: 1,
        materialName: "قطن أبيض خام",
        quantity: 200,
        unit: "كجم",
        rollsCount: 4,
        notes: "استلام دفعة جديدة",
        createdAt: "2024-03-01",
      },
      {
        id: 2,
        permitNumber: "IN002",
        type: "incoming",
        date: "2024-03-02",
        customerId: 2,
        customerName: "مصنع الألوان الحديث",
        materialId: 2,
        materialName: "بوليستر أزرق",
        quantity: 100,
        unit: "متر",
        rollsCount: 2,
        notes: "استلام للصباغة",
        createdAt: "2024-03-02",
      },
    ]
    this.data.inventory = inventoryMovements
  }

  private createSampleInvoices() {
    const invoices = [
      {
        id: 1,
        invoiceNumber: "INV001",
        date: "2024-03-10",
        customerId: 1,
        customerName: "شركة النسيج المتحدة",
        items: [
          {
            materialId: 1,
            materialName: "قطن أبيض خام",
            quantity: 124.5,
            unit: "كجم",
            unitPrice: 25.0,
            totalPrice: 3112.5,
          },
        ],
        totalAmount: 3112.5,
        status: "paid",
        notes: "تسليم أمر PO001",
        createdAt: "2024-03-10",
      },
    ]
    this.data.invoices = invoices
  }

  // Generic methods
  getData(key: string, defaultValue: any[] = []): any[] {
    return this.data[key] || defaultValue
  }

  setData(key: string, value: any[]): void {
    this.data[key] = value
    this.notifyListeners(key)
  }

  addItem(key: string, item: any): void {
    if (!this.data[key]) {
      this.data[key] = []
    }
    this.data[key].push(item)
    this.notifyListeners(key)
  }

  updateItem(key: string, itemId: any, updatedItem: any): void {
    const items = this.getData(key)
    const index = items.findIndex((item: any) => item.id === itemId)
    if (index !== -1) {
      items[index] = { ...items[index], ...updatedItem }
      this.setData(key, items)
    }
  }

  deleteItem(key: string, itemId: any): void {
    let items = this.getData(key)
    items = items.filter((item: any) => item.id !== itemId)
    this.setData(key, items)
  }

  // Specific methods for customers
  getCustomers(): any[] {
    return this.getData("customers", [])
  }

  setCustomers(customers: any[]): void {
    this.setData("customers", customers)
  }

  addCustomer(customer: any): void {
    this.addItem("customers", customer)
  }

  updateCustomer(customerId: any, updatedCustomer: any): void {
    this.updateItem("customers", customerId, updatedCustomer)
  }

  deleteCustomer(customerId: any): void {
    this.deleteItem("customers", customerId)
  }

  // Specific methods for materials
  getMaterials(): any[] {
    return this.getData("materials", [])
  }

  setMaterials(materials: any[]): void {
    this.setData("materials", materials)
  }

  addMaterial(material: any): void {
    this.addItem("materials", material)
  }

  updateMaterial(materialId: any, updatedMaterial: any): void {
    this.updateItem("materials", materialId, updatedMaterial)
  }

  deleteMaterial(materialId: any): void {
    this.deleteItem("materials", materialId)
  }

  // Specific methods for users
  getUsers(): any[] {
    return this.getData("users", [])
  }

  setUsers(users: any[]): void {
    this.setData("users", users)
  }

  addUser(user: any): void {
    this.addItem("users", user)
  }

  updateUser(userId: any, updatedUser: any): void {
    this.updateItem("users", userId, updatedUser)
  }

  deleteUser(userId: any): void {
    this.deleteItem("users", userId)
  }

  // Specific methods for dyeing materials
  getDyeingMaterials(): any[] {
    return this.getData("dyeingMaterials", [])
  }

  setDyeingMaterials(materials: any[]): void {
    this.setData("dyeingMaterials", materials)
  }

  addDyeingMaterial(material: any): void {
    this.addItem("dyeingMaterials", material)
  }

  updateDyeingMaterial(materialId: any, updatedMaterial: any): void {
    this.updateItem("dyeingMaterials", materialId, updatedMaterial)
  }

  deleteDyeingMaterial(materialId: any): void {
    this.deleteItem("dyeingMaterials", materialId)
  }

  // Specific methods for material issuances
  getMaterialIssuances(): any[] {
    return this.getData("materialIssuances", [])
  }

  setMaterialIssuances(issuances: any[]): void {
    this.setData("materialIssuances", issuances)
  }

  addMaterialIssuance(issuance: any): void {
    this.addItem("materialIssuances", issuance)
  }

  // Event listener system
  addListener(key: string, callback: () => void): void {
    if (!this.listeners[key]) {
      this.listeners[key] = []
    }
    this.listeners[key].push(callback)
  }

  removeListener(key: string, callback: () => void): void {
    if (this.listeners[key]) {
      this.listeners[key] = this.listeners[key].filter((cb) => cb !== callback)
    }
  }

  private notifyListeners(key: string): void {
    if (this.listeners[key]) {
      this.listeners[key].forEach((callback) => callback())
    }
  }

  // حساب الأرباح من الأوامر
  calculateProfitFromOrders() {
    const productionOrders = this.getData("productionOrders", [])
    const invoices = this.getData("invoices", [])

    // حساب الإيرادات من الفواتير
    const totalRevenue = invoices.reduce((sum: number, invoice: any) => {
      return sum + (invoice.totalAmount || 0)
    }, 0)

    // حساب تكاليف الإنتاج
    const totalCosts = productionOrders.reduce((sum: number, order: any) => {
      return sum + (order.dyeingMaterialsCost || 0) + (order.processingMaterialsCost || 0)
    }, 0)

    const netProfit = totalRevenue - totalCosts
    const profitMargin = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0

    return {
      revenue: totalRevenue,
      costs: totalCosts,
      profit: netProfit,
      margin: profitMargin,
    }
  }

  // تصدير جميع البيانات
  exportAllData() {
    try {
      const exportData = {
        customers: this.getCustomers(),
        materials: this.getMaterials(),
        users: this.getUsers(),
        inventory: this.getData("inventory", []),
        productionOrders: this.getData("productionOrders", []),
        invoices: this.getData("invoices", []),
        deliveryStatements: this.getData("deliveryStatements", []),
        separations: this.getData("separations", []),
        dyeingMaterials: this.getDyeingMaterials(),
        materialIssuances: this.getMaterialIssuances(),
        openingBalances: this.getData("openingBalances", []),
        settings: this.getData("settings", []),
        activityLog: this.getData("activityLog", []),
        exportDate: new Date().toISOString(),
        version: "1.0",
      }

      const jsonString = JSON.stringify(exportData, null, 2)
      const blob = new Blob([jsonString], { type: "application/json" })
      const url = URL.createObjectURL(blob)

      const link = document.createElement("a")
      link.href = url
      link.download = `textile-warehouse-backup-${new Date().toISOString().split("T")[0]}.json`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      URL.revokeObjectURL(url)

      return {
        success: true,
        message: "تم تصدير البيانات بنجاح",
      }
    } catch (error) {
      return {
        success: false,
        message: `فشل في تصدير البيانات: ${error.message}`,
      }
    }
  }

  // استيراد البيانات
  async importData(file: File) {
    try {
      const text = await file.text()
      const importedData = JSON.parse(text)

      // التحقق من صحة البيانات
      if (!importedData.version) {
        throw new Error("ملف البيانات غير صالح - لا يحتوي على رقم إصدار")
      }

      // استيراد البيانات
      if (importedData.customers) this.setCustomers(importedData.customers)
      if (importedData.materials) this.setMaterials(importedData.materials)
      if (importedData.users) this.setUsers(importedData.users)
      if (importedData.inventory) this.setData("inventory", importedData.inventory)
      if (importedData.productionOrders) this.setData("productionOrders", importedData.productionOrders)
      if (importedData.invoices) this.setData("invoices", importedData.invoices)
      if (importedData.deliveryStatements) this.setData("deliveryStatements", importedData.deliveryStatements)
      if (importedData.separations) this.setData("separations", importedData.separations)
      if (importedData.dyeingMaterials) this.setDyeingMaterials(importedData.dyeingMaterials)
      if (importedData.materialIssuances) this.setMaterialIssuances(importedData.materialIssuances)
      if (importedData.openingBalances) this.setData("openingBalances", importedData.openingBalances)
      if (importedData.settings) this.setData("settings", importedData.settings)
      if (importedData.activityLog) this.setData("activityLog", importedData.activityLog)

      return {
        success: true,
        message: "تم استيراد البيانات بنجاح",
      }
    } catch (error) {
      return {
        success: false,
        message: `فشل في استيراد البيانات: ${error.message}`,
      }
    }
  }

  // تنظيف جميع البيانات
  clearAllData() {
    this.initializeSystemWithSampleData()
    return {
      success: true,
      message: "تم تنظيف جميع البيانات بنجاح",
    }
  }

  // الحصول على إحصائيات النظام
  getSystemStats() {
    return {
      customers: this.getCustomers().length,
      materials: this.getMaterials().length,
      users: this.getUsers().length,
      inventory: this.getData("inventory", []).length,
      productionOrders: this.getData("productionOrders", []).length,
      invoices: this.getData("invoices", []).length,
      deliveryStatements: this.getData("deliveryStatements", []).length,
      separations: this.getData("separations", []).length,
      dyeingMaterials: this.getDyeingMaterials().length,
      materialIssuances: this.getMaterialIssuances().length,
      totalRecords: Object.values(this.data).reduce((sum, arr) => sum + arr.length, 0),
    }
  }
}

// Create and export a singleton instance of DataManager
export const dataManager = new DataManager()
