/**
 * اتصال قاعدة البيانات
 * Database Connection Manager
 */

import mysql from "mysql2/promise"
import { DATABASE_CONFIG, validateEnvironment } from "./database-config"

// التحقق من متغيرات البيئة
validateEnvironment()

// إنشاء pool الاتصالات
let connectionPool: mysql.Pool | null = null

/**
 * إنشاء pool اتصالات قاعدة البيانات
 */
function createConnectionPool(): mysql.Pool {
  if (connectionPool) {
    return connectionPool
  }

  const config = DATABASE_CONFIG.mysql

  connectionPool = mysql.createPool({
    host: config.host,
    port: config.port,
    user: config.user,
    password: config.password,
    database: config.database,
    charset: config.charset,
    timezone: config.timezone,
    acquireTimeout: config.acquireTimeout,
    timeout: config.timeout,
    reconnect: config.reconnect,
    ...config.pool,
  })

  // معالجة أخطاء الاتصال
  connectionPool.on("connection", (connection) => {
    console.log(`✅ Database connected as id ${connection.threadId}`)
  })

  connectionPool.on("error", (err) => {
    console.error("❌ Database connection error:", err)
    if (err.code === "PROTOCOL_CONNECTION_LOST") {
      connectionPool = null
      createConnectionPool()
    } else {
      throw err
    }
  })

  return connectionPool
}

/**
 * الحصول على اتصال قاعدة البيانات
 */
export async function getConnection(): Promise<mysql.PoolConnection> {
  const pool = createConnectionPool()
  return await pool.getConnection()
}

/**
 * تنفيذ استعلام SQL
 */
export async function executeQuery<T = any>(query: string, params: any[] = []): Promise<T[]> {
  const connection = await getConnection()

  try {
    const [rows] = await connection.execute(query, params)
    return rows as T[]
  } catch (error) {
    console.error("❌ Query execution error:", error)
    console.error("Query:", query)
    console.error("Params:", params)
    throw error
  } finally {
    connection.release()
  }
}

/**
 * تنفيذ استعلام مع إرجاع معرف السجل الجديد
 */
export async function executeInsert(
  query: string,
  params: any[] = [],
): Promise<{ insertId: number; affectedRows: number }> {
  const connection = await getConnection()

  try {
    const [result] = (await connection.execute(query, params)) as any
    return {
      insertId: result.insertId,
      affectedRows: result.affectedRows,
    }
  } catch (error) {
    console.error("❌ Insert execution error:", error)
    throw error
  } finally {
    connection.release()
  }
}

/**
 * تنفيذ معاملة (Transaction)
 */
export async function executeTransaction<T>(callback: (connection: mysql.PoolConnection) => Promise<T>): Promise<T> {
  const connection = await getConnection()

  try {
    await connection.beginTransaction()
    const result = await callback(connection)
    await connection.commit()
    return result
  } catch (error) {
    await connection.rollback()
    console.error("❌ Transaction error:", error)
    throw error
  } finally {
    connection.release()
  }
}

/**
 * فحص حالة قاعدة البيانات
 */
export async function checkDatabaseHealth(): Promise<{
  status: "healthy" | "unhealthy"
  message: string
  details?: any
}> {
  try {
    const result = await executeQuery("SELECT 1 as test, NOW() as current_time")

    if (result.length > 0) {
      return {
        status: "healthy",
        message: "Database connection is healthy",
        details: result[0],
      }
    } else {
      return {
        status: "unhealthy",
        message: "Database query returned no results",
      }
    }
  } catch (error) {
    return {
      status: "unhealthy",
      message: "Database connection failed",
      details: error.message,
    }
  }
}

/**
 * إغلاق جميع الاتصالات
 */
export async function closeAllConnections(): Promise<void> {
  if (connectionPool) {
    await connectionPool.end()
    connectionPool = null
    console.log("✅ All database connections closed")
  }
}

// معالجة إغلاق التطبيق
process.on("SIGINT", async () => {
  console.log("🔄 Closing database connections...")
  await closeAllConnections()
  process.exit(0)
})

process.on("SIGTERM", async () => {
  console.log("🔄 Closing database connections...")
  await closeAllConnections()
  process.exit(0)
})
