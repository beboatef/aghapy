/**
 * إعدادات قاعدة البيانات للإنتاج
 * Production Database Configuration
 */

// إعدادات قاعدة البيانات
export const DATABASE_CONFIG = {
  // إعدادات MySQL/MariaDB
  mysql: {
    host: process.env.DB_HOST || "localhost",
    port: Number.parseInt(process.env.DB_PORT || "3306"),
    user: process.env.DB_USER || "textile_app",
    password: process.env.DB_PASSWORD || "SecurePassword123!",
    database: process.env.DB_NAME || "textile_warehouse_production",
    charset: "utf8mb4",
    timezone: "+03:00", // توقيت الرياض
    acquireTimeout: 60000,
    timeout: 60000,
    reconnect: true,
    pool: {
      min: 2,
      max: 10,
      acquireTimeoutMillis: 30000,
      createTimeoutMillis: 30000,
      destroyTimeoutMillis: 5000,
      idleTimeoutMillis: 30000,
      reapIntervalMillis: 1000,
      createRetryIntervalMillis: 100,
    },
  },

  // إعدادات PostgreSQL (بديل)
  postgresql: {
    host: process.env.POSTGRES_HOST || "localhost",
    port: Number.parseInt(process.env.POSTGRES_PORT || "5432"),
    user: process.env.POSTGRES_USER || "textile_app",
    password: process.env.POSTGRES_PASSWORD || "SecurePassword123!",
    database: process.env.POSTGRES_DB || "textile_warehouse_production",
    ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
    pool: {
      min: 2,
      max: 10,
    },
  },

  // إعدادات Supabase (خيار سحابي)
  supabase: {
    url: process.env.NEXT_PUBLIC_SUPABASE_URL || "",
    anonKey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "",
    serviceKey: process.env.SUPABASE_SERVICE_ROLE_KEY || "",
  },

  // إعدادات PlanetScale (خيار سحابي آخر)
  planetscale: {
    host: process.env.PLANETSCALE_HOST || "",
    username: process.env.PLANETSCALE_USERNAME || "",
    password: process.env.PLANETSCALE_PASSWORD || "",
  },
}

// نوع قاعدة البيانات المستخدمة
export const DB_TYPE = process.env.DB_TYPE || "mysql" // mysql, postgresql, supabase, planetscale

// إعدادات الأمان
export const SECURITY_CONFIG = {
  jwtSecret: process.env.JWT_SECRET || "your-super-secret-jwt-key-change-in-production",
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || "24h",
  bcryptRounds: Number.parseInt(process.env.BCRYPT_ROUNDS || "12"),
  sessionTimeout: Number.parseInt(process.env.SESSION_TIMEOUT || "30"), // minutes
  maxLoginAttempts: Number.parseInt(process.env.MAX_LOGIN_ATTEMPTS || "3"),
  lockoutDuration: Number.parseInt(process.env.LOCKOUT_DURATION || "15"), // minutes
}

// إعدادات النسخ الاحتياطي
export const BACKUP_CONFIG = {
  enabled: process.env.BACKUP_ENABLED === "true",
  frequency: process.env.BACKUP_FREQUENCY || "24", // hours
  retention: Number.parseInt(process.env.BACKUP_RETENTION || "30"), // days
  storage: process.env.BACKUP_STORAGE || "local", // local, s3, gcs
  s3: {
    bucket: process.env.S3_BACKUP_BUCKET || "",
    region: process.env.S3_REGION || "us-east-1",
    accessKeyId: process.env.S3_ACCESS_KEY_ID || "",
    secretAccessKey: process.env.S3_SECRET_ACCESS_KEY || "",
  },
}

// إعدادات التطبيق
export const APP_CONFIG = {
  name: "نظام إدارة مخازن النسيج",
  version: "2.0.0",
  environment: process.env.NODE_ENV || "development",
  port: Number.parseInt(process.env.PORT || "3000"),
  baseUrl: process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3000",
  apiUrl: process.env.NEXT_PUBLIC_API_URL || "/api",
}

// التحقق من المتغيرات المطلوبة
export function validateEnvironment() {
  const requiredVars = ["DB_HOST", "DB_USER", "DB_PASSWORD", "DB_NAME", "JWT_SECRET"]

  const missing = requiredVars.filter((varName) => !process.env[varName])

  if (missing.length > 0) {
    throw new Error(`Missing required environment variables: ${missing.join(", ")}`)
  }
}

// إعدادات التطوير المحلي
export const DEVELOPMENT_CONFIG = {
  seedData: process.env.SEED_DATA === "true",
  debugMode: process.env.DEBUG_MODE === "true",
  logLevel: process.env.LOG_LEVEL || "info",
  enableCors: process.env.ENABLE_CORS === "true",
}
