/**
 * أدوات المصادقة والأمان
 * Authentication and Security Utilities
 */

import bcrypt from "bcryptjs"
import jwt from "jsonwebtoken"
import { SECURITY_CONFIG } from "./database-config"

/**
 * تشفير كلمة المرور
 */
export async function hashPassword(password: string): Promise<string> {
  return await bcrypt.hash(password, SECURITY_CONFIG.bcryptRounds)
}

/**
 * التحقق من كلمة المرور
 */
export async function verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
  return await bcrypt.compare(password, hashedPassword)
}

/**
 * إنشاء JWT token
 */
export function generateToken(payload: any): string {
  return jwt.sign(payload, SECURITY_CONFIG.jwtSecret, {
    expiresIn: SECURITY_CONFIG.jwtExpiresIn,
  })
}

/**
 * التحقق من JWT token
 */
export function verifyToken(token: string): any {
  try {
    return jwt.verify(token, SECURITY_CONFIG.jwtSecret)
  } catch (error) {
    throw new Error("Invalid or expired token")
  }
}

/**
 * إنشاء كلمة مرور عشوائية
 */
export function generateRandomPassword(length = 12): string {
  const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*"
  let password = ""

  for (let i = 0; i < length; i++) {
    password += charset.charAt(Math.floor(Math.random() * charset.length))
  }

  return password
}

/**
 * التحقق من قوة كلمة المرور
 */
export function validatePasswordStrength(password: string): {
  isValid: boolean
  score: number
  feedback: string[]
} {
  const feedback: string[] = []
  let score = 0

  if (password.length < 8) {
    feedback.push("كلمة المرور يجب أن تكون 8 أحرف على الأقل")
  } else {
    score += 1
  }

  if (!/[a-z]/.test(password)) {
    feedback.push("يجب أن تحتوي على حرف صغير واحد على الأقل")
  } else {
    score += 1
  }

  if (!/[A-Z]/.test(password)) {
    feedback.push("يجب أن تحتوي على حرف كبير واحد على الأقل")
  } else {
    score += 1
  }

  if (!/[0-9]/.test(password)) {
    feedback.push("يجب أن تحتوي على رقم واحد على الأقل")
  } else {
    score += 1
  }

  if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
    feedback.push("يجب أن تحتوي على رمز خاص واحد على الأقل")
  } else {
    score += 1
  }

  return {
    isValid: score >= 4,
    score,
    feedback,
  }
}
