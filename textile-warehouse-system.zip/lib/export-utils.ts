/**
 * أدوات تصدير البيانات
 *
 * هذا الملف يحتوي على وظائف لتصدير البيانات بتنسيقات مختلفة
 * مثل Excel و PDF وطباعة البيانات
 */

// تصدير البيانات إلى Excel
export function exportToExcel(data: any[], fileName: string, sheetName = "Sheet1") {
  try {
    // محاكاة تصدير البيانات إلى Excel
    console.log(`تصدير ${data.length} سجل إلى Excel باسم ${fileName}`)

    // في بيئة حقيقية، يمكن استخدام مكتبة مثل xlsx
    // const XLSX = require('xlsx')
    // const ws = XLSX.utils.json_to_sheet(data)
    // const wb = XLSX.utils.book_new()
    // XLSX.utils.book_append_sheet(wb, ws, sheetName)
    // XLSX.writeFile(wb, `${fileName}.xlsx`)

    // محاكاة تنزيل الملف
    const jsonString = JSON.stringify(data, null, 2)
    const blob = new Blob([jsonString], { type: "application/json" })
    const url = URL.createObjectURL(blob)

    const link = document.createElement("a")
    link.href = url
    link.download = `${fileName}.json`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)

    URL.revokeObjectURL(url)

    return { success: true, message: `تم تصدير البيانات بنجاح إلى ${fileName}.xlsx (ج.م)` }
  } catch (error) {
    console.error("خطأ في تصدير البيانات إلى Excel:", error)
    return { success: false, message: "حدث خطأ أثناء تصدير البيانات إلى Excel: " + error.message }
  }
}

// تصدير البيانات إلى PDF
export function exportToPDF(
  data: any[],
  fileName: string,
  title: string,
  columns: { header: string; dataKey: string }[],
) {
  try {
    // محاكاة تصدير البيانات إلى PDF
    console.log(`تصدير ${data.length} سجل إلى PDF باسم ${fileName}`)

    // في بيئة حقيقية، يمكن استخدام مكتبة مثل jsPDF و jsPDF-AutoTable
    // const jsPDF = require('jspdf')
    // const autoTable = require('jspdf-autotable')
    // const doc = new jsPDF()
    // doc.text(title, 14, 22)
    // autoTable(doc, {
    //   head: [columns.map(col => col.header)],
    //   body: data.map(row => columns.map(col => row[col.dataKey])),
    //   startY: 30,
    //   theme: 'grid',
    //   styles: { font: 'amiri', halign: 'right' },
    //   headStyles: { fillColor: [41, 128, 185], textColor: 255 },
    // })
    // doc.save(`${fileName}.pdf`)

    // محاكاة تنزيل الملف
    const jsonString = JSON.stringify({ title, data }, null, 2)
    const blob = new Blob([jsonString], { type: "application/json" })
    const url = URL.createObjectURL(blob)

    const link = document.createElement("a")
    link.href = url
    link.download = `${fileName}.json`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)

    URL.revokeObjectURL(url)

    return { success: true, message: `تم تصدير البيانات بنجاح إلى ${fileName}.pdf (ج.م)` }
  } catch (error) {
    console.error("خطأ في تصدير البيانات إلى PDF:", error)
    return { success: false, message: "حدث خطأ أثناء تصدير البيانات إلى PDF: " + error.message }
  }
}

// طباعة البيانات
export function printData(data: any[], title: string, columns: { header: string; dataKey: string }[]) {
  try {
    // إنشاء نافذة طباعة جديدة
    const printWindow = window.open("", "_blank")
    if (!printWindow) {
      throw new Error("فشل في فتح نافذة الطباعة. يرجى التأكد من السماح بالنوافذ المنبثقة.")
    }

    // إنشاء محتوى HTML للطباعة
    let html = `
      <!DOCTYPE html>
      <html dir="rtl">
      <head>
        <title>${title}</title>
        <style>
          body { font-family: Arial, sans-serif; direction: rtl; }
          h1 { text-align: center; margin-bottom: 20px; }
          table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
          th, td { border: 1px solid #ddd; padding: 8px; text-align: right; }
          th { background-color: #f2f2f2; }
          tr:nth-child(even) { background-color: #f9f9f9; }
          .print-date { text-align: left; margin-bottom: 20px; font-size: 12px; }
          .footer { text-align: center; margin-top: 30px; font-size: 12px; }
          @media print {
            body { margin: 0; padding: 15mm; }
            .no-print { display: none; }
          }
        </style>
      </head>
      <body>
        <h1>${title}</h1>
        <div class="print-date">تاريخ الطباعة: ${new Date().toLocaleString("ar-SA")}</div>
        <table>
          <thead>
            <tr>
    `

    // إضافة رؤوس الأعمدة
    columns.forEach((column) => {
      html += `<th>${column.header}</th>`
    })

    html += `
            </tr>
          </thead>
          <tbody>
    `

    // إضافة بيانات الصفوف
    data.forEach((row) => {
      html += "<tr>"
      columns.forEach((column) => {
        html += `<td>${row[column.dataKey] !== undefined ? row[column.dataKey] : ""}</td>`
      })
      html += "</tr>"
    })

    html += `
          </tbody>
        </table>
        <div class="footer">
          <p>نظام إدارة المخزون - ${new Date().getFullYear()}</p>
        </div>
        <div class="no-print">
          <button onclick="window.print()">طباعة</button>
          <button onclick="window.close()">إغلاق</button>
        </div>
        <script>
          window.onload = function() {
            setTimeout(function() {
              window.print();
            }, 500);
          }
        </script>
      </body>
      </html>
    `

    // كتابة المحتوى في نافذة الطباعة
    printWindow.document.write(html)
    printWindow.document.close()

    return { success: true, message: "تم تحضير البيانات للطباعة (ج.م)" }
  } catch (error) {
    console.error("خطأ في طباعة البيانات:", error)
    return { success: false, message: "حدث خطأ أثناء تحضير البيانات للطباعة: " + error.message }
  }
}
